jQuery(document).ready(function(){
	/*even header*/
	if(jQuery("#img").length > 0) {
		jQuery("#img").fadegallery({
			control_event: "mouseover",
			auto_play: true,
			control: jQuery("ul#imgControl"),
			delay: 3
		});
	}							
	
	var _browserWidth = jQuery(window).width();
	var _browserHeight = jQuery(document).height();	
	jQuery(".WrapperSideBar").css({
		height: _browserHeight
	});	
	var isClose = false;
	if(jQuery("#toggle").length > 0){
		jQuery("#toggle").click(function(){
			
			if(!isClose){
				jQuery(this).removeClass("CloseBtn");
				jQuery(this).addClass("OpenBtn");
				jQuery("#sideBar").animate({
					left: '-183'
				}, function(){
					jQuery(".WrapperSideBar").addClass("Close");	
				});
				
				
				
				jQuery("#linkgame").animate({
					left: '20'
				});
				jQuery(this).attr({title : 'Mở'});
				isClose = true;
				frmBody = parent.document.getElementById('linkgame');				
				
			}else{
				jQuery(this).removeClass("OpenBtn");
				jQuery(this).addClass("CloseBtn");				
				jQuery("#sideBar").animate({
					left: '0'},
					function() {
						jQuery(".WrapperSideBar").removeClass("Close");
					  });				
				
				
				jQuery(this).attr({title : 'Đóng'});
				isClose = false;
			}
		});
	}	
	/******************************/
	if(jQuery(".Send").length > 0) {
		jQuery(".Send").hover(function(){
			jQuery(this).addClass('Over');
		},function(){
			jQuery(this).removeClass('Over');
		});
	}
	/******************************/
	
	jQuery("#idLogin").css({
		height: _browserHeight
	});
	var isClose1 = false;
	if(jQuery("#togglebot").length > 0){
		jQuery("#togglebot").click(function(){
			if(!isClose1){
				jQuery(this).removeClass("CloseBtnBot");
				jQuery(this).addClass("OpenBtnBot");
				
				jQuery("#sideBarBot").animate({
					bottom: '-173',
					height: 20
				});
				
				jQuery("#linkgamebot").animate({
					bottom: '25'					
				});
				jQuery(this).attr({title : 'Mở'});
				isClose1 = true;
				frmBody = parent.document.getElementById('linkgamebot');							
				jQuery(window).height() = _browserHeight - 193;
			}else{
				jQuery(this).removeClass("OpenBtnBot");
				jQuery(this).addClass("CloseBtnBot");				
				jQuery("#sideBarBot").animate({
					bottom: '0',
					height: 193},
					function() {						
					  });				
			
				jQuery(this).attr({title : 'Đóng'});
				isClose1 = false;
			}
		});
	}	
		/*-----SELECT------*/
	if (jQuery(".SelectUI").length > 0) {      
	   jQuery(".SelectUI").addSelectUI ({
            scrollbarWidth: 7 //default is 10
			
        });
    }
	
	/* Box dang nhap */
	if ( jQuery("#username").length >0){		
		
		jQuery('#username').bind('focus',function(){
			if(jQuery(this).val()=='Tài khoản Zing ID') {
				jQuery(this).val('');
			}
		});
		jQuery('#username').bind('blur',function(){
			if(jQuery(this).val()=='') {
				jQuery(this).val('Tài khoản Zing ID');
			}
		});
    }
	if ( jQuery("#password").length >0){		
		jQuery('#password').bind('focus',function(){
			if(jQuery(this).val()=='Mật khẩu') {
				jQuery(this).val('');
			}
		});
		jQuery('#password').bind('blur',function(){
			if(jQuery(this).val()=='') {
				jQuery(this).val('Mật khẩu');
			}
		});
		jQuery("#boxTab_3 > .ViewMore").hide();
		jQuery("#boxTab_3 > .ViewMore").eq(0).show();
		jQuery("#boxTab_3 > .Tab > li > a").hover(function(){
			var curActivePos = jQuery(this).parent().prevAll().length;
			jQuery("#boxTab_3 > .ViewMore").hide();
			jQuery("#boxTab_3 > .ViewMore").eq(curActivePos).show();
		});
	}
	
	if(jQuery("a.OpenPopup").length >0 ){	
		jQuery("a.OpenPopup").click(function(){
			var url = $(this).attr('href');
			var strclass = $(this).attr('rel');
			//var addclas = 'SurveyPopupHome';
			if(jQuery('#subspamlink iframe').length>0){
				jQuery('#subspamlink iframe').attr('src',url);
				jQuery('#subspamlink').removeClass('PopupQuick');								
				jQuery('#subspamlink').addClass(strclass);
			}
			createOverlays("subspamlink");			
			jQuery('.SurveyClose').bind('click', function() {
				closeVideo('subspamlink');				
				return false;
			});
			jQuery('#thewindowbackground').bind('click', function() {
				closeVideo('subspamlink');				
				return false;
			});		
			
			return false;
		});			
	}
});
	
var items = 7;
var _pos = 0;
var _step = 0;
jQuery(document).ready(function(){
	if(jQuery("ul#tabHeader").length > 0) {
		jQuery("ul#tabHeader").jcarousel({
			visible: items,
			scroll: items,
			initCallback: init,
			itemLastOutCallback: {
				onAfterAnimation: itemLastOutCallback
			}
			
		});
	}
});


function init(carousel, item){
	jQuery("ul#tabHeader > li").click(function(){
		_pos = jQuery(this).prevAll().length;
		showListServer(_pos);
		activeTabServer(_pos);
		return false;
		
	});
};

function itemLastOutCallback(carousel, item, index, state){
	if(state == 'next'){
		_step += items;
	}else{
		_step -= items;
	}
	showListServer(_step);
	activeTabServer(_step);
}
function showListServer (_pos){
	jQuery(this).parent().find("li").removeClass("Active");
	jQuery(this).addClass("Active");
	jQuery(".ListServer").removeClass("Active");
	jQuery(".ListServer").animate({opacity: 0},100);
	jQuery(".ListServer").eq(_pos).addClass("Active");
	jQuery(".ListServer").eq(_pos).animate({opacity: 1},100);
}

function activeTabServer(_pos){
	/*alert(_pos);*/
	jQuery("#tabHeader > li").removeClass("Active");
	jQuery("#tabHeader > li").eq(_pos).addClass("Active");
}