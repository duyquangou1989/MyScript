<?php

require_once ('FeedDialogAuthen.php');
include_once "../../include/config-url.php";

	global $uid;
    global $fi;
    global $config_appzm;
	if(isset($_POST['feedtype']) && !empty($_POST['uid']))
	{
		$feedtype = $_POST['feedtype'];
		$uid = $_POST['uid'];
		$secretkey = $config_appzm['secretkey'];
		$userIdFrom = $uid;
		$userIdTo = $uid;
		$actId = 1;
		$tplId = 3;
		$objectId = "";
		$attachName = "Đánh boss thế giới 1 lần";
		$attachHref = "http://me.zing.vn/apps/phuckhoi";
		$attachCaption = "pk.net.vn";
		$attachDescription = "Hôm nay ta vừa đánh BOSS một trận ra trò, các tiên hữu hãy cùng giúp ta cho BOSS một bài học nào! Phi cước hay liên chưởng, mọi người cứ thỏa sức lựa chọn nhé";
		$mediaType = 1;
		$mediaImage = "http://id.pk.net.vn/zm/zingapi/img/".$feedtype.".png";
		$mediaSource = "http://me.zing.vn/apps/phuckhoi";
		$actionLinkText = "Phục Khởi";
		$actionLinkHref = "http://me.zing.vn/apps/phuckhoi";
		
		switch($feedtype)
		{
			case 1 : 
					$attachName = "Đánh boss thế giới 1 lần";
					$attachDescription = "Hôm nay ta vừa đánh BOSS một trận ra trò, các tiên hữu hãy cùng giúp ta cho BOSS một bài học nào! Phi cước hay liên chưởng, mọi người cứ thỏa sức lựa chọn nhé";
					break;
			case 2 : 
					$attachName = "Nhận phần thưởng 100 điểm năng nổ";
					$attachDescription = "Sao? Vừa chơi thoải mái lại vừa được nhận lương ư? Sao? Tiền lương là Pháp Đơn ư? Cái đó có ăn được không vậy?";
					break;
			case 3 : 
					$attachName = "Thắng trong khi đấu kiếm";
					$attachDescription = "Tên kia, về mà luyện thêm vài chục năm nữa đi nhé, có biết ta đây nổi danh với tên gọi Độc Cô Cầu Bại không hả?";
					break;
					
			case 4 : 
					$attachName = "Thắng 1 lần trong phe chiến";
					$attachDescription = "Phe nào cũng vậy thôi, chỉ cần có ta tham gia thì chắc chắn là sẽ liên tục thắng. Sợ rồi chứ gì? Nhìn ngươi là ta biết ngươi thuộc dạng nhát gan rồi!";
					break;
			case 5 : 
					$attachName = "Thắng 1 trận trong bang chiến";
					$attachDescription = "Núi rừng này là của ta, ha ha… Ngươi là ai? Tới đây làm gì? Đây là địa bàn bang của bọn ta, rõ chưa hả?";
					break;
			case 6 : 
					$attachName = "Nhân vật đạt cấp 40";
					$attachDescription = "Nghe nói khi ai đạt cấp 40, sẽ xuất hiện một câu nói, chia sẻ câu nói này sẽ nhận được phần thưởng hậu hĩnh. Ta đạt 40 rồi, ta nhấn chia sẻ thôi…";
					break;
			case 7 : 
					$attachName = "Nhân vật đạt cấp 50";
					$attachDescription = "Nghe nói khi ai đạt cấp 50, sẽ xuất hiện một câu nói, chia sẻ câu nói này sẽ nhận được phần thưởng hậu hĩnh. Đạt cấp 50 đâu có gì khó!";
					break;
					
			case 8 : 
					$attachName = "Nhân vật đạt cấp 60";
					$attachDescription = "Nghe nói khi ai đạt cấp 60… Thôi không nói nhiều nữa, cứ nhấn đi! Lấy thật nhiều phần thưởng! Các huynh đệ, đua top với ta không?";
					break;
					
			case 9 : 
					$attachName = "Nhân vật đạt cấp 70";
					$attachDescription = "Ta đã đạt cấp 70 rồi. Đứng ở vị trí này thấy những người cấp 30, 40 sao mà bé nhỏ quá. Còn những kẻ cấp 80, 90 hãy chờ đấy, ta sẽ nhanh chóng đuổi kịp thôi!";
					break;
					
			case 10 : 
					$attachName = "Nhân vật đạt cấp 80";
					$attachDescription = "Cấp 80 và 79 có khác biệt nhiều không? Đương nhiên là có rồi, cách biệt rất lớn nữa là đằng khác! Cảm giác như trở thành một con người hoàn toàn mới…";
					break;
					
			case 11 : 
					$attachName = "Nhân vật đạt cấp 90";
					$attachDescription = "Dưới cấp 90 chỉ là ruồi muỗi thôi… Giờ ta đã đạt cấp 90, ngoài trời đất ra thì còn ai vĩ đại hơn ta?";
					break;
			case 12 : 
					$attachName = "Nhân vật đạt cấp 100";
					$attachDescription = "Nghe nói cấp 100 chỉ là truyền thuyết. Giờ ta nói cho mọi người biết, ta chính là truyền thuyết đây. Ta đã đạt cấp 100 rồi, mau đến đây ta cho bắt tay!";
					break;
			case 13 : 
					$attachName = "Lần đầu vượt qua phó bản Từ Vân Tự";
					$attachDescription = "Các huynh đệ, ta vừa vào Phó bản đánh cho bọn yêu quái tan tác, còn nhận được nhiều trang bị và tâm pháp tuyệt hảo, mọi người sao không mau tham gia?";
					break;				
			case 14 : 
					$attachName = "Lần đầu tiên vượt qua phó bản Thanh Loa Ma Cung";
					$attachDescription = "Các huynh đệ, ta vừa vào Phó bản đánh cho bọn yêu quái tan tác, còn nhận được nhiều trang bị và tâm pháp tuyệt hảo, mọi người sao không mau tham gia?";
					break;
			case 15 : 
					$attachName = "Lần đầu tiên vượt qua phó bản Tam Thi Mộ";
					$attachDescription = "Các huynh đệ, ta vừa vào Phó bản đánh cho bọn yêu quái tan tác, còn nhận được nhiều trang bị và tâm pháp tuyệt hảo, mọi người sao không mau tham gia?";
					break;
			case 16 : 
					$attachName = "Lần đầu tiên vượt qua phó bản Tử Vân Cung";
					$attachDescription = "Các huynh đệ, ta vừa vào Phó bản đánh cho bọn yêu quái tan tác, còn nhận được nhiều trang bị và tâm pháp tuyệt hảo, mọi người sao không mau tham gia?";
					break;
			case 17 : 
					$attachName = "Lần đầu tiên vượt qua phó bản Nguyệt Nhi Đảo";
					$attachDescription = "Các huynh đệ, ta vừa vào Phó bản đánh cho bọn yêu quái tan tác, còn nhận được nhiều trang bị và tâm pháp tuyệt hảo, mọi người sao không mau tham gia?";
					break;
			case 18 : 
					$attachName = "Lần đầu tiên vượt qua phó bản Ảo Ba Trì";
					$attachDescription = "Các huynh đệ, ta vừa vào Phó bản đánh cho bọn yêu quái tan tác, còn nhận được nhiều trang bị và tâm pháp tuyệt hảo, mọi người sao không mau tham gia?";
					break;
			case 19 : 
					$attachName = "Lần đầu tiên phá Thất Tuyệt Tỏa Vân Trận";
					$attachDescription = "Biết làm toán tích phân ư? Biết đến thuyết tương đối ư? Quá bình thường! Liệu có phá nổi Thất Tuyệt Tỏa Vân Trận không ?";
					break;
			case 20 : 
					$attachName = "Lần đầu tiên phá Tứ Tượng Nguyên Linh Trận";
					$attachDescription = "Biết làm toán tích phân ư? Biết đến thuyết tương đối ư? Quá bình thường! Liệu có phá nổi Tứ Tượng Nguyên Linh Trận không ?";
					break;
			case 21 : 
					$attachName = "Lần đầu tiên phá Kỳ Môn Độn Giáp Trận";
					$attachDescription = "Biết làm toán tích phân ư? Biết đến thuyết tương đối ư? Quá bình thường! Liệu có phá nổi  Kỳ Môn Độn Giáp Trận không ?";
					break;
			case 22 : 
					$attachName = "Lần đầu tiên phá Thiên Cương Địa Sát Trận";
					$attachDescription = "Biết làm toán tích phân ư? Biết đến thuyết tương đối ư? Quá bình thường! Liệu có phá nổi Thiên Cương Địa Sát Trận không ?";
					break;
			case 23 : 
					$attachName = "Lần đầu tiên phá Đô Thiên Liệt Hỏa Trận";
					$attachDescription = "Biết làm toán tích phân ư? Biết đến thuyết tương đối ư? Quá bình thường! Liệu có phá nổi Thất Tuyệt Tỏa Vân Trận không ?";
					break;
			case 24 : 
					$attachName = "Lần đầu tiên phá Điên Đảo Bát Quái Trận";
					$attachDescription = "Biết làm toán tích phân ư? Biết đến thuyết tương đối ư? Quá bình thường! Liệu có phá nổi Điên Đảo Bát Quái Trận không ?";
					break;
			case 25 : 
					$attachName = "Lần đầu tiên phá Tu Di Cửu Cung Trận";
					$attachDescription = "Biết làm toán tích phân ư? Biết đến thuyết tương đối ư? Quá bình thường! Liệu có phá nổi Tu Di Cửu Cung Trận không ?";
					break;
			case 26 : 
					$attachName = "Lần đầu tiên phá Bắc Đẩu Thất Tinh Trận";
					$attachDescription = "Biết làm toán tích phân ư? Biết đến thuyết tương đối ư? Quá bình thường! Liệu có phá nổi Bắc Đẩu Thất Tinh Trận không ?";
					break;
			case 27 : 
					$attachName = "Lần đầu tiên phá Tử Vi Thái Cực Trận";
					$attachDescription = "Biết làm toán tích phân ư? Biết đến thuyết tương đối ư? Quá bình thường! Liệu có phá nổi Tử Vi Thái Cực Trận không ?";
					break;
			case 28 : 
					$attachName = "Lần đầu tiên phá Ngũ Hành Diệt Tuyệt Trận";
					$attachDescription = "Biết làm toán tích phân ư? Biết đến thuyết tương đối ư? Quá bình thường! Liệu có phá nổi Ngũ Hành Diệt Tuyệt Trận không ?";
					break;
			case 29 : 
					$attachName = "Lần đầu tiên phá Kim Cang Phục Ma Trận";
					$attachDescription = "Biết làm toán tích phân ư? Biết đến thuyết tương đối ư? Quá bình thường! Liệu có phá nổi Kim Cang Phục Ma Trận không ?";
					break;
			case 30 : 
					$attachName = "Lần đầu tiên phá Lưỡng Nghi Vi Trần Trận";
					$attachDescription = "Biết làm toán tích phân ư? Biết đến thuyết tương đối ư? Quá bình thường! Liệu có phá nổi Lưỡng Nghi Vi Trần Trận không ?";
					break;
			case 31 : 
					$attachName = "Lần đầu nhận trang bị cam";
					$attachDescription = "Liệu có mấy ai có được trang bị cam như ta? Ngươi không phục ư? Vậy thì vào Phục Khởi mà thi thố với ta!";
					break;
			case 32 : 
					$attachName = "Lần đầu nhận pháp bảo";
					$attachDescription = "Có được pháp bảo rồi! Có được pháp bảo rồi! Ngươi cũng muốn có ư? Ta không cho đâu, muốn có thì vào Phục Khởi tự tìm lấy đi!";
					break;
			case 33 : 
					$attachName = "Lần đầu nhận tâm pháp";
					$attachDescription = "Cái gì đây nhỉ? Tu tiên tâm pháp… Sao? Tu tiên tâm pháp à? Vậy là ta sắp thành tiên rồi ư? Ta sắp thành tiên rồi!";
					break;
			case 34 : 
					$attachName = "Lần đầu hoàn thành nhiệm vụ sư môn";
					$attachDescription = "Thích quá đi mất! Trong game Phục Khởi bái sư không tốn học phí, lại còn được thưởng nữa chứ!";
					break;
			case 35 : 
					$attachName = "Lần đầu hoàn thành nhiệm vụ nha môn";
					$attachDescription = "Ái chà, nha sai đại ca, ta chỉ làm chút việc thôi mà, sao tặng ta nhiều bạc và kinh nghiệm như vậy chứ?";
					break;
			case 36 : 
					$attachName = "Lần đầu quay số khi đi phó bản nhóm";
					$attachDescription = "Thiên linh linh, địa linh linh, bảo bối bảo bối mau hiện hình! Úm ba la quay số ra quà xịn!";
					break;
			case 37 : 
					$attachName = "Lần đầu thăng cấp trận pháp";
					$attachDescription = "Muôn vàn gian khổ khó khăn cũng không ngăn được quyết tâm thăng cấp của ta, mọi người xem, ngay cả trận pháp của ta cũng có cấp độ cao hơn người khác!";
					break;
		}
		
		$fi = new FeedItem($userIdFrom, $userIdTo, $actId, $tplId, $objectId, $attachName, $attachHref, $attachCaption, $attachDescription, $mediaType, $mediaImage, $mediaSource, $actionLinkText, $actionLinkHref);
		$signkey = FeedDialogAuthen::creatSignKey($secretkey, $fi);
		
	?>
	zmf.ui(
                {
                    pub_key:"<?php echo $config_appzm['apikey']; ?>",
                    sign_key:"<?php echo $signkey; ?>",
                    action_id:<?php echo $fi->actId ?>,
                    uid_to: <?php echo $uid ?>,
                    object_id:"<?php echo $fi->objectId ?>",
                    attach_name:"<?php echo $fi->attachName ?>",
                    attach_href:"<?php echo $fi->attachHref ?>",
                    attach_caption:"<?php echo $fi->attachCaption ?>",
                    attach_des:"<?php echo $fi->attachDescription ?>",
                    media_type:<?php echo $fi->mediaType ?>,
                    media_img:"<?php echo $fi->mediaImage ?>",
                    media_src:"<?php echo $fi->mediaSource ?>",
                    actlink_text:"<?php echo $fi->actionLinkText ?>",
                    actlink_href:"<?php echo $fi->attachHref ?>",
                    tpl_id:<?php echo $fi->tplId ?>,
                    suggestion: []
                });
	
	<?php
	}	
?>


	
