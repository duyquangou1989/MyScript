function push_feed(feed_type, user_id)
{	
	
	if(window==window.top)
	{	
		//alert('Chức năng này sẽ được cập nhật sau');
		alert('Chức năng này chỉ thực hiện được khi chơi trên trang http://me.zing.vn/apps/phuckhoi');
		return;
	}
	$.ajax({        
       type: "POST",
       url: "http://id.pk.net.vn/zm/zingapi/pushfeed.php",
	   data : {feedtype : feed_type , uid : user_id },
	   success: function(data) {
	   eval(data);
		}
    }); 
	var flash = getSwf("SSCQ");
	flash.shareSend();

}

function invite(_title, _link) 
{
	zmXCall.callParent('inviteFriend', {title:_title, link:_link});
}

function inviteZM()
{
	var titlePK ='Mời bạn tham gia game Phục Khởi';
	var urlPK = 'http://me.zing.vn/apps/phuckhoi';
	alert(titlePK); return;
	zmXCall.callParent('Phục Khởi', {title:titlePK, link:urlPK});
	
}




