<?php

/*
 * create sign key for Feed Dialog
 */

class FeedItem {

	public $userIdFrom;
	public $userIdTo;
	public $actId;
	public $tplId;
	public $objectId;
	public $attachName;
	public $attachHref;
	public $attachCaption;
	public $attachDescription;
	public $mediaType;
	public $mediaImage;
	public $mediaSource;
	public $actionLinkText;
	public $actionLinkHref;

	public function FeedItem($userIdFrom, $userIdTo, $actId, $tplId, $objectId, $attachName, $attachHref, $attachCaption, $attachDescription, $mediaType, $mediaImage, $mediaSource, $actionLinkText, $actionLinkHref) {
		$this->userIdFrom = $userIdFrom;
		$this->userIdTo = $userIdTo;
		$this->actId = $actId;
		$this->tplId =$tplId;
		$this->objectId = $objectId;
		$this->attachName = $attachName;
		$this->attachHref = $attachHref;
		$this->attachCaption = $attachCaption;
		$this->attachDescription = $attachDescription;
		$this->mediaType = $mediaType;
		$this->mediaImage = $mediaImage;
		$this->mediaSource = $mediaSource;
		$this->actionLinkText = $actionLinkText;
		$this->actionLinkHref = $actionLinkHref;

		//define size item
		$this->userIdFrom = $userIdFrom;
		$this->userIdTo = $userIdTo;
		$this->objectId = $objectId;
		$this->actId = $actId;
		$this->tplId =$tplId;
		$this->attachName = (iconv_strlen($attachName, 'UTF-8') > 80) ? $attachName = iconv_substr($attachName, 0, 80) : $attachName;
		$this->attachHref = (iconv_strlen($attachHref, 'UTF-8') > 150) ? $attachHref = iconv_substr($attachHref, 0, 150) : $attachHref;
		$this->attachCaption = (iconv_strlen($attachCaption, 'UTF-8') > 30) ? $attachCaption = iconv_substr($attachCaption, 0, 30) : $attachCaption;
		$this->attachDescription = (iconv_strlen($attachDescription, 'UTF-8') > 200) ? $attachDescription = iconv_substr($attachDescription, 0, 200) : $attachDescription;
		$this->mediaType = $mediaType;
		$this->mediaImage = (iconv_strlen($mediaImage, 'UTF-8') > 150) ? $mediaImage = iconv_substr($mediaImage, 0, 150) : $mediaImage;
		$this->mediaSource = (iconv_strlen($mediaSource, 'UTF-8') > 150) ? $mediaSource = iconv_substr($mediaSource, 0, 150) : $mediaSource;
		$this->actionLinkText = (iconv_strlen($actionLinkText, 'UTF-8') > 20) ? $actionLinkText = iconv_substr($actionLinkText, 0, 20) : $actionLinkText;
		$this->actionLinkHref = (iconv_strlen($actionLinkHref, 'UTF-8') > 150) ? $actionLinkHref = iconv_substr($actionLinkHref, 0, 150) : $actionLinkHref;
	}

}

class FeedDialogAuthen {
	/*
	 * $secretkey: được cấp khi đăng kí app
	 * feed: nội dung feed
	 */

	public static function creatSignKey($secretkey, $feedItem) {

		$strKey =
				(
				$secretkey . ":" .
				$feedItem->userIdFrom . ":" .
				$feedItem->userIdTo . ":" .
				$feedItem->actId . ":" .
				$feedItem->tplId . ":" .
				$feedItem->objectId . ":" .
				$feedItem->attachName . ":" .
				$feedItem->attachHref . ":" .
				$feedItem->attachCaption . ":" .
				$feedItem->attachDescription . ":" .
				$feedItem->mediaType . ":" .
				$feedItem->mediaImage . ":" .
				$feedItem->mediaSource . ":" .
				$feedItem->actionLinkText . ":" .
				$feedItem->actionLinkHref
				);				
		return md5($strKey);
	}

}

?>
