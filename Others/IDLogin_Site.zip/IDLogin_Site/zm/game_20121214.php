<?php

session_start();
include_once "../include/SSO/CXSSO.php";
include_once "../include/SSO/SSO_Config.php";
include "../include/config-server.php";
include "../include/config-url.php";
include "../include/common.php";

include_once '../include/zingme-sdk/BaseZingMe.php';
include_once '../include/zingme-sdk/ZME_Me.php';
include_once '../include/zingme-sdk/ZME_User.php';

if(empty($_REQUEST['sign']))
{
	header("Location: ".$url['server']."");
	exit;
}

$signed_request = $_REQUEST['sign'];
$zm_Me = new ZME_Me($config_appzm);
$uid = $zm_Me->getUserLoggedIn($signed_request);
$access_token = $zm_Me->getAccessTokenFromSignedRequest($signed_request);
$user_info = $zm_Me->getInfo($access_token);
$zm_userid = $user_info["id"];
$zm_username = $user_info["username"];

//get userID passport from user name
$client =  new SoapClient('http://gis.esb.zing.vn/wsdl/Passport/PassportService.wsdl');
$body = array("sUsername" => $zm_username);
$arrResult = $client->RequestFunction("GetInfo",$body,"f4990ba5cde094e7cc5b00ce1d3a70aa");
if($arrResult[0]==1)
{
	$strResult = $arrResult[1]['PassportID'];
	//echo $strResult;exit;
}
$strResult = $arrResult[1]['PassportID'];

//end get userID passport from user name



/*$sid = $_COOKIE['session_info'];	

if(empty($sid))
{
	header("Location: ".$url['home']."");
	exit;
}
else
{
	if($sid != 'none')
	{	
		$vngSession = CXSSO::checkVNGSession($sid);
		$vngSessionArr = (array)$vngSession;
		$mc = new Memcached();
        $mc->addServer('10.30.75.52', 11211);
	}else{
		setcookie('session_info', '');
		header("Location: ".$url['home']."");
		exit;
	}	
}
if(empty($vngSessionArr["accountName"]))
{
	header("Location: ".$url['home']."");
}*/



/*$zm_sign = $_REQUEST['sign'];
$zm_Me = new ZME_Me($config_appzm);
$zm_userid = $zm_Me->getUserLoggedIn($zm_sign);

if($zm_userid!=$_REQUEST['zmuid'])
{
	header("Location: ".$url['home']."");
	exit;
}*/

$accName = $zm_username;
$userid = $strResult;

$server = $_GET['server'];

//$ip = $_GET['ip'];
//$port = $_GET['port'];
$server = preg_quote($server);

$ip =  $servers["s$server"]["ip"];
$port =  $servers["s$server"]["port"];

setcookie('server_name', $servers["s$server"]["name"]);


$mc = new Memcached();
$mc->addServer('10.30.75.52', 11211);

//check user_invite
$invited_sign = isset($_GET['invited_sign'])?  $_GET['invited_sign'] :'';

if($invited_sign!='')
{

	$mc_invited_key = 'invited_'.$invited_sign;
	$val = $mc->get($mc_invited_key);
	
	if(!empty($val))
	{
		$invited_server = explode("|",$val)[0];
		//if((!empty($invited_server))&&(!empty($invited_user)))
		{
			if($invited_server==$server)
			{	
				$invited_user = explode("|",$val)[1];
				
			}
		}
	}
	
}


/** Memcache: luu thong tin server choi nhieu nhat, gan nhat **/
/*** Gan nhat ***/

if($mc->get("[{$accName}][gannhat]")) {
	$gannhat = $mc->get("[{$accName}][gannhat]");
		if(strpos($gannhat,"s{$server}") == false) {
		$gannhat = $gannhat."|s{$server}|";
		$mc->set("[{$accName}][gannhat]",$gannhat,0);
	} else {
		$gannhat = preg_replace("/\|s".$server."\|/", "", $gannhat);
		$gannhat = $gannhat."|s{$server}|";
		$mc->set("[{$accName}][gannhat]",$gannhat,0);
	}
} else {
	$mc->add("[{$accName}][gannhat]","|s{$server}|",0);
}

/*** Nhieu nhat ***/
if($mc->get("[{$accName}][dachoi]")) {
	$dachoi = $mc->get("[{$accName}][dachoi]");
		if(strpos($dachoi,"s{$server}") == false || $dachoi == "") {
			$dachoi = $dachoi."|s{$server}:1|";
			$mc->set("[{$accName}][dachoi]",$dachoi,0);
		} else {
			preg_match("/\|s".$server.":[^\|]*\|/", $dachoi, $part);
			$tmp = implode("", str_replace("|", "", $part));
			$tmp = explode(":", $tmp);
			$counter = (int)$tmp[1] + 1;
			$newValue = preg_replace("/\|s".$server.":[^\|]*\|/", "|s".$server.":".$counter."|", $dachoi);
			$mc->set("[{$accName}][dachoi]",$newValue,0);
	}
} else {
	$mc->add("[{$accName}][dachoi]","|s{$server}:1|",0);
}

/*** Get bannerid ***/
/*
$today = date('Y-m-d');
if($mc->get("[{$accName}][tmp_bannerid]") || $mc->get("[{$accName}][zm_from_bannerid]")) {
	$bannerid = $mc->get("[{$accName}][tmp_bannerid]");
	if($mc->get("[{$accName}][zm_from_bannerid]")) {
$bannerid = $mc->get("[{$accName}][zm_from_bannerid]");
}
if(isset($banners[$bannerid])) {
		countBanner($bannerid);
	}

	if($mc->get("[{$accName}][from_bannerid]")) {
		$curBannerid = $mc->get("[{$accName}][from_bannerid]");
		if(strpos($curBannerid, ":{$server}|") == false ) {
			$newBannerid = $curBannerid."|{$bannerid}:{$server}|";
			$mc->set("[{$accName}][from_bannerid]",$newBannerid,0);
			if(isset($banners[$bannerid])) {
				$message = $accName.','.$server;
				$log->lfile("/home/cltvn/public_html/bannerid.log/{$today}/bannerid.{$bannerid}");
				$log->lwrite($message);
			}          
		}
	} else {
		$mc->add("[{$accName}][from_bannerid]","|{$bannerid}:{$server}|",0);
		if(isset($banners[$bannerid])) {
			$message = $accName.','.$server;
			$log->lfile("/home/cltvn/public_html/bannerid.log/{$today}/bannerid.{$bannerid}");
			$log->lwrite($message);
		}
	}
}
unset($_SESSION['bannerid']);
$mc->delete("[$accName][tmp_bannerid]");
$mc->delete("[{$accName}][zm_from_bannerid]");
*/

/** End memcache **/
/**--------------**/

function genRandom()
{
	$r = '';
	for($i = 0; $i < 12; ++ $i)
	{
		$r .= chr(mt_rand(0, 255));
	}
	return $r.pack("V", time());
}

function hashThem($username, $r)
{
	static $static_key1 = 'FUHuIEyBcM3OR2eh';
	static $static_key2 = 'Y7IAmfOBpAzknCK7';
	if(strlen($r) < 16)
		return NULL;
	$data = substr($r, 8, 4) . $static_key1 . substr($r, 0, 4) . $username . substr($r, 12, 4) . $static_key2 . substr($r, 4, 4);
	$data1 = sha1($data, true);
	return $r.$data1;
}
/*
if(!isset($_POST['userid']))
{
	header("location: /login.php");
	return;
}
*/
//SetCookie('sscq_userid', $_POST['userid'], time()+3600*24*30, '/');
//SetCookie('sscq_server', $_POST['server'], time()+3600*24*30, '/');
//SetCookie('sscq_port', $_POST['port'], time()+3600*24*30, '/');
SetCookie('sscq_userid', $userid, time()+3600*24*30, '/');
SetCookie('sscq_server', $ip, time()+3600*24*30, '/');
SetCookie('sscq_port', $port, time()+3600*24*30, '/');
$ccc = genRandom();
$data = hashThem(pack('VV', $userid, 0), $ccc);
$credit_var = urlencode(base64_encode($data));
$myRoot='';
$cfgserver = "112";
$is_newuser="0";
$ban = 0;
$file = "main_VI.swf";
$glocale = 'Viet';
$chan="zing";
$gid = "2" ;
if($env=='local')
	$cdnroot = 'http://local.pk.net.vn/sscq/';
else $cdnroot = 'http://pk.static.game.zing.vn/sscq/';
//$cdnroot = 'http://pk.static.game.zing.vn/sscq/';
//$server = $_POST['server'].":".$_POST['port'];
$serverport = $ip.":".$port;
if (isset($_GET['cdnroot'])) {
	$cdnroot = $_GET['cdnroot'];
}
$qpluslv = "1";
$myRoot=$cdnroot;
$wallow="1";
$isvip="1";
$viplv="6";
$isyearvip="1";
$isblue="1";
$via = "FB_25623" ;
$invited = "1391540" ;
$serverId = 99;
$isMerge=0;
$openid = $userid;
$openkey = "121212";
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="shortcut icon" href="http://img.zing.vn/phuckhoi/skin/phuckhoi-072012/images/favicon.ico" type="image/x-icon"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Phuc Khoi online – Tuyệt đỉnh PK</title>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="robots" content="index,follow" />
<link href="http://img.zing.vn/eventgame/intro/general/css/mainsite.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../css/style.css" />
<link href="../css/jcarousel.css" rel="stylesheet" />
<link href="../css/jselect.css" rel="stylesheet" />
<link href="../css/jselect-theme.css" rel="stylesheet" />
<link href="../css/j-navigation-left.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="http://img.zing.vn/eventgame/intro/general/js/mainsite.js"></script>
<!--[if IE 6]>
<script src="js/DD_belatedPNG_0.0.8a.js"></script>
<script>  
 	DD_belatedPNG.fix('#img);
</script>
<![endif]-->
<script type="text/javascript" src="../js/popup.js"></script>
<script type="text/javascript" src="../js/jselect/jselect.js"></script>
<script type="text/javascript" src="../js/jselect/jselect.external.js"></script>
<script type="text/javascript" src="../js/carousel.js"></script>
<script type="text/javascript" src="../js/common.js"></script>
<script type="text/javascript" src="http://img.zing.vn/eventgame/intro/general/js/track-idlogin/gt-analytic-idphuckhoi.js"></script>
<script type="text/javascript" src="http://img.zing.vn/phuckhoi/js/ga-phuckhoi-idlogin.js"></script>
<!--<script type="text/javascript" src="http://idlocal.pk.net.vn/js/jquery-1.6.4.min.js" ></script>-->
<script type="text/javascript" src="http://static.me.zing.vn/feeddialog/js/feed-dialog-1.01.js" ></script>
<script type="text/javascript" src="zingapi/pushfeed.js" ></script>
<script type="text/javascript" src=" http://static.me.zing.vn/v3/js/zm.xcall-1.15.min.js"></script>

<script type="text/javascript"  language="javascript">
		<!-- For version detection, set to min. required Flash Player version, or 0 (or 0.0.0), for no version detection. --> 
		var swfVersionStr = "10.0.0";
		<!-- To use express install, set to playerProductInstall.swf, otherwise the empty string. -->
		var xiSwfUrlStr = "playerProductInstall.swf";
		var flashvars = {};
		flashvars.userid = <?php echo $userid; ?>;
		flashvars.zm_userid = <?php echo $zm_userid; ?>;
		<?php if(!empty($invited_user))
		{ ?>
			flashvars.invited = <?php echo $invited_user; ?>;
		<?php }
		?>
		flashvars.hash = "<?php echo $credit_var; ?>";
		flashvars.cdnroot = "<?php echo $myRoot; ?>";
		flashvars.glocale = "<?php echo $glocale; ?>";
		flashvars.wallow = "0"; //0 is off, 1 is on
		flashvars.serverId = "<?php echo $serverId; ?>";
		flashvars.isMerge = "<?php echo $isMerge; ?>";
		flashvars.channel =  "<?php echo $chan; ?>";
		flashvars.openid = "<?php echo $openid; ?>";
		flashvars.openkey = "<?php echo $openkey; ?>";
		flashvars.server= "<?php echo $serverport; ?>";
		flashvars.via = "<?php echo $via; ?>";
		flashvars.invited = "<?php echo $invited; ?>";
		flashvars.gid = "<?php echo $gid; ?>";
		flashvars.isvip = "<?php echo $isvip; ?>";
		flashvars.viplv = "<?php echo $viplv; ?>";
		flashvars.qpluslv = "<?php echo $qpluslv; ?>";
		flashvars.isyearvip = "<?php echo $isyearvip; ?>";
		flashvars.isblue = "<?php echo $isblue; ?>";
		flashvars.ban = "<?php echo $ban; ?>";
		flashvars.cfg_server = "s172";
		var params = {};
		params.quality = "high";
		params.allowscriptaccess = "always";
		params.allowfullscreen = "true";
		params.wmode = "direct";
		var attributes = {};
		attributes.id = "SSCQ";
		attributes.name = "SSCQ";
		attributes.align = "middle";
		swfobject.embedSWF(
			"<?php echo $myRoot.$file; ?>?t="+(new Date()), "flashContent", 
			"1000", "580", 
			swfVersionStr, xiSwfUrlStr, 
			flashvars, params, attributes);
		<!-- JavaScript enabled so display the flashContent div in case it is not replaced with a swf object. -->
		swfobject.createCSS("#flashContent", "display:block;text-align:left;");
		function reloadpage() 
		{
			window.location.reload();
		}
		function username() 
		{
			return "abc"
		}
		function testItem(){
				var flash = getSwf("SSCQ");
				flash.inviteSend();
		}
		function getSwf(movieName) {
			   if (window.document[movieName])
			   {
							 return window.document[movieName];
			   }
			   if (navigator.appName.indexOf("Microsoft")==-1)
			   {
							 if (document.embeds && document.embeds[movieName])
							return document.embeds[movieName];
			   }
			   else
			   {
							return document.getElementById(movieName);
			   }
		}
		
    function addBookmark(title,url)
    {
      if (window.sidebar) {
        window.sidebar.addPanel(title, url,"");
      } else if( document.all ) {
        window.external.AddFavorite( url, title);
      } else if( window.opera && window.print ) {
        return true;
      }
    }
	</script>
<style type="text/css">
#linkgame {
	position: absolute;
	top: 0;
	left: 20px;
	width: 100%;
	height: 100%;
	border: none;
	box-sizing: border-box;
	-moz-box-sizing: border-box;
	-webkit-box-sizing: border-box;
}
#linkgamebot {
	position: absolute;
	bottom: 200px;
	left: 0;
	width: 100%;
	height: 100%;
	border: none;
	box-sizing: border-box;
	-moz-box-sizing: border-box;
	-webkit-box-sizing: border-box;
}
</style>


</head>
<body id="change" class="Ingame" onload="document.getElementById('SSCQ').focus()" >

<div id="gameplay">
		<div id="gameContent">
			<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td align="center" valign="middle">
						<div id="flashContent"></div>
					</td>
				</tr>
			</table> 
		</div>
</div>

<div id="sideBar">
        <div  class="WrapperSideBar">
            <h1><a href="<?php echo $url['home'];?>" title="Trở về trang chủ Phục Khởi">Phục Khởi</a></h1>
            <a href="javascript:void(0);" title="Đóng" id="toggle" class="CloseBtn NotTrack">Đóng / Mở</a>
            <div class="UserInfo2"><span><?php echo $accName; ?></span><a href="logout.php"> Thoát</a></div>
            <div class="ServerBox">
                <p class="Text"	>Máy chủ đang chơi:</p>
                <p class="ServerCurrent"><?php echo $servers["s$server"]["name"];?></p>
                <select class="SelectUI Theme_GP Theme_Human "  id="Server" name="" title="Máy chủ đã chọn" onchange="window.location = this.options[this.selectedIndex].value">
				<?php 
					if($mc->get("[{$accName}][dachoi]"))
					{
						$dachoi = $mc->get("[{$accName}][dachoi]");
						$dachoi = explode("|", $dachoi);
						$bigArr = array();
						
						foreach ($dachoi as $key) {
							if($key != "") {
							$bigArr[] = explode(":", $key)[0] ;
							}
						}
						$end_bigArr = count($bigArr)-1;
						for($i=$end_bigArr, $count=1; $i>=0; $i--, $count++) {
							$serverName = $bigArr[$i];
							if(!empty($serverName))
								echo '<option value="game.php?server='.$servers[$serverName]['id'].'&sign='.$signed_request.'&zmuid='.$zm_userid.'">'.$servers[$serverName]['name'].'</option>';
							if($count == 5) break;
						}
					}
				?>
                    <!--<option value="Value 1">Máy chủ 1</option>
                    <option value="Value 2">Máy chủ 2</option>
                    <option value="Value 3">Máy chủ 3</option>-->
					
					
                </select>
        	</div>
            
           	<iframe width="202" height="420" frameborder="0" src="http://launcher.game.zing.vn/PKVN/left-menu-0912.html" allowtransparency="1" scrolling="no"></iframe> 
        </div>
    </div>
	<script type="text/javascript"  language="javascript">
	function inviteZM()
	{
		<?php 
			$key_sign=md5($server.$userid);
			$invited_sign = 'invited_'.$key_sign; 
			//$mc->set($invited_sign, $server.'|'.$userid,0,2592000);
			$mc->set($invited_sign, $server.'|'.$userid);
			//$val =$mc->get($invited_sign);
			//echo "alert('".$val."'); return;";
		?>
		var titlePK ='Mời bạn bè tham gia game Phục Khởi';
		//var urlPK = 'http://me.zing.vn/apps/phuckhoilocal/?server=<?php echo $server; ?>&from_userid=<?php echo $userid; ?>';
		var urlPK = 'http://me.zing.vn/apps/phuckhoilocal/?invited_sign=<?php echo $key_sign; ?>';
		invite(titlePK, urlPK);
		var flash = getSwf("SSCQ");
		flash.inviteSend();
		
	//zmXCall.callParent('Phục Khởi', {title:titlePK, link:urlPK});
	}
	</script>
</body>
</html>
