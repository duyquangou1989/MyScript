<?php
session_start();
include_once "../include/SSO/CXSSO.php";
include_once "../include/SSO/SSO_Config.php";
include "../include/config-url.php";
include "../include/common.php";

$sid = isset($_GET['sid']) ?  $_GET['sid'] : '';
$signed_request =isset($_GET['signed_request'])? $_GET['signed_request'] :'' ;
$sign_user = isset($_GET['sign_user']) ? $_GET['sign_user'] :'';

if ($sid!= ''&& $sid!='none')
{
	$vngSession = CXSSO::checkVNGSession($sid);
	$vngSessionArr = (array)$vngSession;
}
if(!empty($vngSessionArr["accountName"]))
{
	setcookie('session_info',$sid);
	//header("Location: ".$config_appzm['urlzm']."");
	header("Location: http://id.pk.net.vn/zm/servers.php?signed_request=".$signed_request."&sign_user=".$sign_user);
	exit();
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Phục Khởi</title>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="robots" content="index,follow" />
<link href="http://img.zing.vn/eventgame/intro/general/css/mainsite.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link href="css/style-news.css" type="text/css" rel="stylesheet" />
<link href="css/banner-event.css" type="text/css" rel="stylesheet" />
<link href="css/jselect.css" type="text/css" rel="stylesheet" />
<link href="css/jselect-theme.css" type="text/css" rel="stylesheet" />
<link href="css/j-navigation-left.css" type="text/css" rel="stylesheet" />

<link href="css/dang-ky-nhanh.css" type="text/css" rel="stylesheet"  />
<link href="https://imgfw.zing.vn/imgid2/theme/default/keyboard/keyboard.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="http://img.zing.vn/eventgame/intro/general/js/mainsite.js"></script>
<!--[if IE 6]>
<script src="js/DD_belatedPNG_0.0.8a.js"></script>
<script>  
 	DD_belatedPNG.fix('img,.BtReg');
</script>
<![endif]-->
<script type="text/javascript" src="js/popup.js"></script>
<script type="text/javascript" src="js/jselect/jselect.js"></script>
<script type="text/javascript" src="js/jselect/jselect.external.js"></script>
<script type="text/javascript" src="js/carousel.js"></script>
<script type="text/javascript" src="js/jquery.ui.fadegallery.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<!--<script type="text/javascript" src="http://img.zing.vn/eventgame/intro/general/js/track-idlogin/gt-analytic-idphuckhoi.js"></script>-->
<script type="text/javascript" src="http://img.zing.vn/phuckhoi/js/ga-phuckhoi-idlogin.js"></script>
<!--
<script type="text/javascript" src="https://imgfw.zing.vn/imgid2/theme/default/products/common/trial_register.js"></script>
<script type="text/javascript" src="https://imgfw.zing.vn/imgid2/theme/default/keyboard/keyboard.js"></script>
<script type="text/javascript" src="https://imgfw.zing.vn/imgid2/theme/default/keyboard/addKeyboard.js"></script>
-->
</head>
<body>
<div id="wrapper" class="IDLogin">
    <div id="idLogin">
    	<h1><a href="#" title="Trở về trang chủ Phục Khởi">Trở về trang chủ Phục Khởi</a></h1>
        <div class="Login">
            <form onsubmit="_gaq.push(['_trackEvent', 'Form dang nhap', 'Link', 'IDLogin']);" target="_top" method="post" name="frmLogin" id="frmLogin" action="https://sso2.zing.vn/index.php?method=xdomain_login">
                <fieldset>
						<div class="BoxInput">
							<label>Tài khoản </label>
							<input type="text" name="u" id="username" value="Tài khoản Zing ID">
							<label>Mật khẩu</label>
							<input type="password" name="p" id="password" value="Mật khẩu">
						</div>
						<ul>
							<li><a href="https://id.zing.vn/forgotinfo/index.118.html" title="Quên mật khẩu" class="NotTrack">Quên mật khẩu</a> </li>
						</ul>
						<input type="submit" name="Đăng nhập" value=" " class="Send">
					</fieldset>
					<!--<input type="hidden" name="u1" value="<?php echo $config_appzm['urlzm'];?>">
					<input type="hidden" name="fp" value="<?php echo $config_appzm['urlzm'];?>"> -->
					
					<input type="hidden" name="u1" value="http://me.zing.vn/apps/phuckhoi">
					<input type="hidden" name="fp" value="http://me.zing.vn/apps/phuckhoi">
					<input type="hidden" name="pid" value="118">
            </form>
            
        </div>
        <div class="FormDangKy">
        	<iframe src="http://id.zing.vn/quickregister/game/index.118.ingame.html" style="height:315px;width:430px;border:none"></iframe>
        </div>
        <div class="BannerEvent">
			<iframe width="795" height="190" frameborder="0" src="http://launcher.game.zing.vn/PKVN/pknews.html" allowtransparency="1" scrolling="no"></iframe>
    	</div>
        <ul class="HoTro">
            <li> <a href="http://www.facebook.com/pkfanpages" target="_blank" title="Chia sẻ Facebook" class="Facebook">Chia sẻ Facebook</a></li>
            <li><a href="http://me.zing.vn/b/pkfanpage" target="_blank" title="Chia sẻ ZingMe" class="ZingMe">Chia sẻ ZingMe</a></li>
        </ul>
        <p class="Copyright2">Phuckhoi @ 2012</p>
        <a href="http://www.kingnet.com" target="_blank" title="KingNet" class="KingNet">Kingnet</a>
    </div>
    
</div>

</body>
</html>
