<?php
session_start();
include_once "../include/SSO/CXSSO.php";
include_once "../include/SSO/SSO_Config.php";
include "../include/config-server.php";
include "../include/config-url.php";
include "../include/common.php";

$sid = $_COOKIE['session_info'];		
if(empty($sid))
{
	header("Location: ".$url['home']."");
	exit;
}else{
	if($sid != 'none')
	{	
		$vngSession = CXSSO::checkVNGSession($sid);
		$vngSessionArr = (array)$vngSession;
	}else{
		setcookie('session_info', '');
		header("Location: ".$url['home']."");
		exit;
	}	
}

$flag = 1;
if(isset($_POST["submit"])) {
    connectMySQL();
    $cbcode = cleanQuery($_POST["cbcode"]);
    $get_cbcode = mysql_query("select * from cbcode where code='".$cbcode."' and account is NULL");
    if(mysql_num_rows($get_cbcode) == 0) {
        $flag = 0;
    } else {
        $update = mysql_query("update cbcode set account='".$vngSessionArr["accountName"]."' where code='".$cbcode."'");
        if($update) {
            header("Location: ../servers.php");
        }
    }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Phục Khởi</title>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="robots" content="index,follow" />
<link href="http://img.zing.vn/eventgame/intro/general/css/mainsite.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="css/style.css" />
<link href="css/jselect/jselect.css" rel="stylesheet" />
<link href="css/jselect/jselect-theme.css" rel="stylesheet" />
<link href="css/j-navigation-left.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="http://img.zing.vn/eventgame/intro/general/js/mainsite.js"></script>
<!--[if IE 6]>
<script src="js/DD_belatedPNG_0.0.8a.js"></script>
<script>  
 	DD_belatedPNG.fix('#wrapper .ShortLink li a,.Login form input,.Login form input.ChoiNgay,.Server h2,ul#tabHeader li a,ul.ServerHot, ul.ServerHot li a,ul.ListServer li a,ul.ListServer li.Hot a,ul.ListServer li.New a,ul.BoxButton li a.ImgHuongDan1,ul.BoxButton li a.ImgHuongDan2, ul.BoxButton li a.ImgHuongDan3,ul.BoxButton li a.ImgHuongDan4, ul.BoxButtonServer li a.ImgHuongDan1,ul.BoxButtonServer li a.ImgHuongDan2, ul.BoxButtonServer li a.ImgHuongDan3, ul.BoxButtonServer li a.ImgHuongDan4', .Login h2);
</script>
<![endif]-->
<script type="text/javascript" src="js/popup.js"></script>
<script type="text/javascript" src="js/jselect/jselect.js"></script>
<script type="text/javascript" src="js/jselect/jselect.external.js"></script>
<script type="text/javascript" src="js/carousel.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script type="text/javascript" src="http://img.zing.vn/eventgame/intro/general/js/track-idlogin/gt-analytic-idphuckhoi.js"></script>
<script type="text/javascript" src="http://img.zing.vn/phuckhoi/js/ga-phuckhoi-idlogin.js"></script>
<style type="text/css">
#linkgame {
	position: absolute;
	top: 0;
	left: 20px;
	width: 100%;
	height: 100%;
	border: none;
	box-sizing: border-box;
	-moz-box-sizing: border-box;
	-webkit-box-sizing: border-box;
}
#linkgamebot {
	position: absolute;
	bottom: 200px;
	left: 0;
	width: 100%;
	height: 100%;
	border: none;
	box-sizing: border-box;
	-moz-box-sizing: border-box;
	-webkit-box-sizing: border-box;
}
</style>
</head>

<body id="change">
<div id="thewindowbackground"></div>
<div id="wrapper_out">
  <div id="wrapper_in">
<div id="wrapper">
      <div class="AlphaTest">
<div id="idLogin">
        <ul class="MenuTop">
          <li><a href="http://pk.net.vn/index.html" class="TrangChuID" onclick="_gaq.push(['_trackEvent', 'Trang chu', 'Link', 'IDLogin']);" target="_blank" title="Trang chủ">Trang chủ</a></li>
          <li><a href="https://pay.zing.vn/zingxu/napthe.pkvn.html" class="NapTheID" onclick="_gaq.push(['_trackEvent', 'Nap the', 'Link', 'IDLogin']);" target="_blank" title="Nạp thẻ">Nạp thẻ</a></li>
          <li><a href="http://diendan.zing.vn/forumdisplay.php/3023-Phuc-Khoi.html" class="DienDanID" onclick="_gaq.push(['_trackEvent', 'Dien dan', 'Link', 'IDLogin']);" target="_blank" title="Diễn đàn">Diễn đàn</a></li>
          <li><a href="#" class="MayChuID" onclick="_gaq.push(['_trackEvent', 'MayChu', 'Link', 'IDLogin']);" title="MayChu">Máy chủ</a></li>
        </ul>
          <div class="NhapCode">
            
          <form target="_top" method="post" name="frmLogin" id="frmLogin" action="">
            <div class="frm_dangnhap">
              <div class="username">
                <input type="text" class="" value="" id="cbcode" name="cbcode"/>
              </div>    
				<?php
				if($flag == 0) {
					echo '<div class="ThongBaoLoi">
							<p>[ Code không đúng. Xin vui lòng đăng nhập lại ]</p>
						</div>';
				} /*else {
					echo '<div class="password">
							<input style="border: 0;background: none;color: #fff;" type="text" value="[ Nhập code Closed Beta để tiếp tục ]" readonly="readonly" />
						</div>';
				}*/
			?>       	
            </div>
            <input type="submit" name="submit" value="submit" class="XacNhan" />
          </form>
        </div>       
        <div class="BannerEvent">
          <iframe scrolling="no" marginheight="0" marginwidth="0" height="170" frameborder="0" width="540" src="http://launcher.game.zing.vn/PKVN/idnews.html"></iframe>
          </div>
    </div>
    
    <div id="sideBar">
    <div  class="WrapperSideBar">
      <h1><a href="#" title="Trở về trang chủ Phục Khởi"><img src="images/logo.gif" width="200" height="120" alt="Phục Khởi" /></a></h1>
      <a href="javascript:void(0);" title="Đóng" id="toggle" class="CloseBtn">Đóng / Mở</a>
      <p class="Text"	>Máy chủ đang chơi:</p>
      <p class="ServerCurrent"><?php echo $_COOKIE['server_name']; ?></p>
      <select class="SelectUI Theme_GP Theme_Human "  id="Server" name="" title="Máy chủ đã chọn" >
	  <!--
        <option value="Value 1">Máy chủ 1</option>
        <option value="Value 2">Máy chủ 2</option>
        <option value="Value 3">Máy chủ 3</option>
  	  -->
      </select>
      <div class="UserInfo"><?php echo $vngSessionArr["accountName"]; ?><a href="http://sso2.zing.vn/?method=logout&return=http://idlocal.pk.net.vn"> Thoát</a></div>
      <iframe scrolling="no" marginheight="0" marginwidth="0" height="600" frameborder="0" width="198" src="http://launcher.game.zing.vn/PKVN/leftMenu.html"></iframe>
    </div>
  </div>
</div>   
    </div>
  </div>
</div>
</body>
<div class="WrapperBottom" id="sideBarBot">
  <div><a href="javascript:void(0);" title="Đóng" id="togglebot" class="CloseBtnBot">Đóng / Mở</a></div>
  <div class="BottomContent">
    <iframe scrolling="no" marginheight="0" marginwidth="0" height="173" frameborder="0" width="760" src="http://launcher.game.zing.vn/PKVN/footer.html"></iframe>
  </div>
</div>
</html>
