// JavaScript Document

$(document).ready(function() {
	var windowWidth = jQuery(window).width();
	var windowHeight = jQuery(window).height();
	var popupWidth = jQuery('.Popup').width();
	var popupHeight = jQuery('.Popup').height();
	$('.Popup').css('top',(windowHeight-popupHeight)/2);
	$('.Popup').css('left',(windowWidth-popupWidth)/2);
	
	$(window).resize(function() {
		windowWidth = jQuery(window).width();
		windowHeight = jQuery(window).height();
  		$('.Popup').css('top',(windowHeight-popupHeight)/2);
		$('.Popup').css('left',(windowWidth-popupWidth)/2);
	});
	$('.PopupClose').click(function(){
  		$('.Popup').hide();
	});

});