// JavaScript Document 
 var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-28196578-7']);
  _gaq.push(['_trackPageview']);
  _gaq.push(['_trackPageLoadTime']);

  _gaq.push(
  ['secondTracker._setAccount', 'UA-12223470-1'], // rollup Mainsite
  ['secondTracker._trackPageview']
);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

