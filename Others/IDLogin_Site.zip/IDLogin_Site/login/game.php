+<?php
    function genRandom()
    {
        $r = '';
        for($i = 0; $i < 12; ++ $i)
        {
            $r .= chr(mt_rand(0, 255));
        }
        return $r.pack("V", time());
    }

    function hashThem($username, $r)
    {
        static $static_key1 = 'FUHuIEyBcM3OR2eh';
        static $static_key2 = 'Y7IAmfOBpAzknCK7';
        if(strlen($r) < 16)
            return NULL;
        $data = substr($r, 8, 4) . $static_key1 . substr($r, 0, 4) . $username . substr($r, 12, 4) . $static_key2 . substr($r, 4, 4);
		$data1 = sha1($data, true);
		return $r.$data1;
    }
    if(!isset($_POST['userid']))
    {
        header("location: /login.php");
		return;
    }
	SetCookie('sscq_userid', $_POST['userid'], time()+3600*24*30, '/');
	SetCookie('sscq_server', $_POST['server'], time()+3600*24*30, '/');
	SetCookie('sscq_port', $_POST['port'], time()+3600*24*30, '/');
	$ccc = genRandom();
    $data = hashThem(pack('VV', $_POST['userid'], 0), $ccc);
	$credit_var = urlencode(base64_encode($data));
	$myRoot='';
	$cfgserver = "112";
	$is_newuser="0";
	$ban = 0;
	$file = "main.swf";
	$glocale = 'zh_CN';
	$chan="qzone";
	$gid = "2" ;
	$cdnroot = 'http://local.pk.net.vn/sscq/';
	$server = $_POST['server'].":".$_POST['port'];
	if (isset($_GET['cdnroot'])) {
        $cdnroot = $_GET['cdnroot'];
    }
	$qpluslv = "1";
	$myRoot=$cdnroot;
	$wallow="1";
	$isvip="1";
	$viplv="6";
	$isyearvip="1";
	$isblue="1";
	$via = "FB_25623" ;
	$invited = "1391540" ;
	$serverId = 99;
	$isMerge=0;
	$openid = "100002175232373";
	$openkey = "121212";
?>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-cn">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf8" />
    <style type="text/css" media="screen"> 
		html, body	{ height:100%; }
	body { margin:0; padding:0; overflow:auto; text-align:center;
	       background-color:0 ; }   
	#flashContent { display:none; }
	</style>
	<!-- Enable Browser History by replacing useBrowserHistory tokens with two hyphens -->
		
	<script type="text/javascript" src="swfobject.js"></script>
	<script type="text/javascript"  language="javascript">
		<!-- For version detection, set to min. required Flash Player version, or 0 (or 0.0.0), for no version detection. --> 
		var swfVersionStr = "10.0.0";
		<!-- To use express install, set to playerProductInstall.swf, otherwise the empty string. -->
		var xiSwfUrlStr = "playerProductInstall.swf";
		var flashvars = {};
		flashvars.userid = <?php echo $_POST['userid']; ?>;
		flashvars.hash = "<?php echo $credit_var; ?>";
		flashvars.cdnroot = "<?php echo $myRoot; ?>";
		flashvars.glocale = "<?php echo $glocale; ?>";
		flashvars.wallow = "<?php echo $wallow; ?>";
		flashvars.serverId = "<?php echo $serverId; ?>";
		flashvars.isMerge = "<?php echo $isMerge; ?>";
		flashvars.channel =  "<?php echo $chan; ?>";
		flashvars.openid = "<?php echo $openid; ?>";
		flashvars.openkey = "<?php echo $openkey; ?>";
		flashvars.server= "<?php echo $server; ?>";
		flashvars.via = "<?php echo $via; ?>";
		flashvars.invited = "<?php echo $invited; ?>";
		flashvars.gid = "<?php echo $gid; ?>";
		flashvars.isvip = "<?php echo $isvip; ?>";
		flashvars.viplv = "<?php echo $viplv; ?>";
		flashvars.qpluslv = "<?php echo $qpluslv; ?>";
		flashvars.isyearvip = "<?php echo $isyearvip; ?>";
		flashvars.isblue = "<?php echo $isblue; ?>";
		flashvars.ban = "<?php echo $ban; ?>";
		flashvars.cfg_server = "s172";
		var params = {};
		params.quality = "high";
		params.allowscriptaccess = "always";
		params.allowfullscreen = "true";
		params.wmode = "direct";
		var attributes = {};
		attributes.id = "SSCQ";
		attributes.name = "SSCQ";
		attributes.align = "middle";
		swfobject.embedSWF(
			"<?php echo $myRoot.$file; ?>?t="+(new Date()), "flashContent", 
			"1000", "580", 
			swfVersionStr, xiSwfUrlStr, 
			flashvars, params, attributes);
		<!-- JavaScript enabled so display the flashContent div in case it is not replaced with a swf object. -->
		swfobject.createCSS("#flashContent", "display:block;text-align:left;");
		function reloadpage() 
		{
			window.location.reload();
		}
		function username() 
		{
			return "abc"
		}
		function testItem(){
				var flash = getSwf("SSCQ");
				flash.inviteSend();
		}
		function getSwf(movieName) {
			   if (window.document[movieName])
			   {
							 return window.document[movieName];
			   }
			   if (navigator.appName.indexOf("Microsoft")==-1)
			   {
							 if (document.embeds && document.embeds[movieName])
							return document.embeds[movieName];
			   }
			   else
			   {
							return document.getElementById(movieName);
			   }
		}
		
    function addBookmark(title,url)
    {
      if (window.sidebar) {
        window.sidebar.addPanel(title, url,"");
      } else if( document.all ) {
        window.external.AddFavorite( url, title);
      } else if( window.opera && window.print ) {
        return true;
      }
    }
	</script>
	<title>Test</title>
</head>
<body  onload="document.getElementById('SSCQ').focus()">
    <table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0"><tr><td align="center" valign="middle">
        <div id="flashContent">
        </div></td></tr></table>
</body>
</html>
