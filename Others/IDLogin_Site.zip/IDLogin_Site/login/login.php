<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-cn">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Login</title>
</head>
<body>
	<form name="loginform" action="game.php" method="POST">
	<table align="center" border="0" cellspacing="0">
		<tr><th>User_ID:</th><td><input maxLength="10" name="userid" value="<?php if(isset($_COOKIE['sscq_userid'])) echo $_COOKIE['sscq_userid']; ?>"></td></tr> 
				</td></tr>
		<tr><th>Server_IP:</th><td>
		       <input maxLength="100" name="server" value="<?php if(isset($_COOKIE['sscq_server'])) echo $_COOKIE['sscq_server']; ?>"/>
				</td></tr>
		<tr><th>Server_Port:</th><td>
		 <input maxLength="100" name="port" value="<?php if(isset($_COOKIE['sscq_port'])) echo $_COOKIE['sscq_port']; ?>"/>
				</td></tr>
		<tr><th colspan="2"><input type="submit" value="Login"/></th></tr>
	</table>
	</form>
</body>
</html>
