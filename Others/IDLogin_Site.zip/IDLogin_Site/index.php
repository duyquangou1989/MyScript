<?php
    session_start();
	require_once "include/SSO/CXSSO.php";
	require_once "include/SSO/SSO_Config.php";
	require_once 'include/SSO/TransitionUtil.php';
	require_once "include/config-server.php";
	require_once "include/config-url.php";
	require_once "include/common.php";
	
	// Tracking from VMAS
	if(!empty($_SERVER["QUERY_STRING"]))
	{
		if(empty($_SESSION['pkvn']['query_string_vmas'])){
			$query_string = $_SERVER["QUERY_STRING"];
			$_SESSION['pkvn']['query_string_vmas'] = $query_string;
		}	
	}
	//---------------------------------------------
	
	if (check_login()) 
	{
		$_SESSION['pkvn']['query_string_vmas'] = str_replace("sid=none","",$_SESSION['pkvn']['query_string_vmas']);
		header("Location: ".$url["server"]."?".$_SESSION['pkvn']['query_string_vmas']);
		exit;
	}else{
		if(!isset($_GET['sid']))
		{
			check_login_vng('');
		}
	}


	//global $url;
    /* For inspection */
    #if($_SERVER['HTTP_REFERER'] == '') {
    #	header("Location: http://idlocal.pk.net.vn");
    #}
    /**/
	
	
	
	// Tracking from Banner outside to IDLogin Site
	/*
	require_once 'include/config-banner.php';
	if(!empty($_GET["src_tr"]))
	{
		$tracking_code = strip_tags(addslashes(trim($_GET["src_tr"])));
		if(array_key_exists($tracking_code,$conf_tracking_banner)) 
		{
			$_SESSION['pkvn']['tracking_code'] = $tracking_code;
		}
	}
	
	//---------------------------------------------
	
	
	$queryStr = $_SERVER['QUERY_STRING'];
    if(!isset($_SESSION['bannerid'])) {
        if(preg_match("/bannerid/", $queryStr)) {
            $_SESSION['bannerid'] = $_GET['bannerid'];
        } elseif(preg_match("/banner/", $queryStr)) {
            $piece = explode(".", $queryStr);
            $_SESSION['bannerid'] = $piece[2];
        }
    }
	
    include_once("include/SSO/xdomain_login.php");
    
    
    $eventid = isset($_GET['eventid']) ?  $_GET['eventid'] : '';
	$type = isset($_GET['type']) ?  $_GET['type'] : '';
	$pid = isset($_GET['pid']) ?  $_GET['pid'] : '';
	$bannerid = isset($_GET['bannerid']) ?  $_GET['bannerid'] : '';
	
	if ($eventid != '' &type != '' && $pid != '' && $bannerid != '')
	{
		$XLogin = new XLogin(false);

	}
    else
	{
		$XLogin = new XLogin(true);
	}
    */
 
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Phuc Khoi online – Tuyệt đỉnh PK</title>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="robots" content="index,follow" />
<link rel="shortcut icon" href="http://img.zing.vn/phuckhoi/skin/phuckhoi-072012/images/favicon.ico" type="image/x-icon"/>
<link href="http://img.zing.vn/eventgame/intro/general/css/mainsite.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link href="css/style-news.css" type="text/css" rel="stylesheet" />
<link href="css/banner-event.css" type="text/css" rel="stylesheet" />
<link href="css/jselect.css" type="text/css" rel="stylesheet" />
<link href="css/jselect-theme.css" type="text/css" rel="stylesheet" />
<link href="css/j-navigation-left.css" type="text/css" rel="stylesheet" />
<link href="https://imgfw.zing.vn/imgid2/theme/default/keyboard/keyboard.css" rel="stylesheet" type="text/css" />

<!--<link href="css/dang-ky-nhanh.css" type="text/css" rel="stylesheet"  />-->


<script type="text/javascript" src="http://img.zing.vn/eventgame/intro/general/js/mainsite.js?ver=26042013"></script>
<!--[if IE 6]>
<script src="js/DD_belatedPNG_0.0.8a.js"></script>
<script>  
 	DD_belatedPNG.fix('img,.BtReg');
</script>
<![endif]-->
<script type="text/javascript" src="js/jselect/jselect.js"></script>
<script type="text/javascript" src="js/jselect/jselect.external.js"></script>
<script type="text/javascript" src="js/carousel.js"></script>
<script type="text/javascript" src="js/jquery.ui.fadegallery.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script type="text/javascript" src="http://img.zing.vn/phuckhoi/js/ga-phuckhoi-idlogin.js?version=1"></script>
<script type="text/javascript">
	var urlQuickReg="https://id.zing.vn/quickregister/game/index.118.ingame.html?reg_embed=true";
</script>
<script type="text/javascript" src="http://static.me.zing.vn/v3/js/zm.xcall-1.16.min.js"></script> 
<script type="text/javascript" src="http://img.zing.vn/eventgame/intro/general/call-function/widget-login-pkvn.js?version=26042013"></script>


<!--
<script type="text/javascript" src="https://imgfw.zing.vn/imgid2/theme/default/products/common/trial_register.js"></script>
<script type="text/javascript" src="https://imgfw.zing.vn/imgid2/theme/default/keyboard/keyboard.js"></script>
<script type="text/javascript" src="https://imgfw.zing.vn/imgid2/theme/default/keyboard/addKeyboard.js"></script>
-->

<!--<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 994251942;
var google_conversion_language = "en";
var google_conversion_format = "3";
var google_conversion_color = "ffffff";
var google_conversion_label = "1a8_CPqjkQQQpqmM2gM";
var google_conversion_value = 0;
/* ]]> */
</script>
<script type="text/javascript" src="http://www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="http://www.googleadservices.com/pagead/conversion/994251942/?value=0&amp;label=1a8_CPqjkQQQpqmM2gM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>-->



</head>
<body>
<div id="wrapper" class="IDLogin">
    <div id="idLogin">
    	
		<h1><a href="http://pk.net.vn/index.html" title="Trở về trang chủ Phục Khởi" onclick="_gaq.push(['_trackEvent','Logo', 'Link', 'IDLogin']);">Trở về trang chủ Phục Khởi</a></h1>
        <div class="Login">
        <div id="tabLoginPKVN">
            <div class="FrmDN">
            	
			<?php
            if(isset($_GET['err']) && $_GET['err']==2001){

                echo '
                    <div class="ThongBaoLoi">
                        <p> [ Tài khoản hoặc mật khẩu không đúng. Xin vui lòng đăng nhập lại ]</p>
                    </div>';
            }
			?>
            <form onsubmit="_gaq.push([\'_trackEvent\', \'Form dang nhap\', \'Link\', \'IDLogin\']);" target="_top" method="post" name="frmDN" id="frmDN" action="https://sso3.zing.vn/xlogin" method="post">
					<fieldset>
                    <div class="BoxInput">
                        <label>Tài khoản</label>
							<input type="text" name="u" id="username" value="Tài khoản"  title="Tài khoản"/>
							<label>Mật khẩu</label>
							<input type="password" name="p" id="password" value="Mật khẩu" />
                    </div>
                    
					<div class="BoxRight">
							<input type="submit" name="textfield2" value="Đăng nhập" class="Send" title="Đăng nhập"/>
							<a href="https://id.zing.vn/forgotinfo/index.118.html" title="Quên mật khẩu" class="PassWord" target="_blank" onclick="_gaq.push([\'_trackEvent\',\'Quen mat khau\', \'Link\', \'IDLogin\']);">Quên mật khẩu</a> </div>
                
					</fieldset>
					
					<input type="hidden" name="u1" value="<?php echo $url['home']?>" />
					<input type="hidden" name="fp" value="<?php echo $url['home']?>" />
					<input type="hidden" name="pid" value="118" />  
					<input type="hidden" name="apikey" value="94cbfd79768b4a0bb2b48a5bffb72ce0" />
					</form>
          	</div>

            <p>Nếu chưa có Zing ID. Bạn có thể đăng ký tại đây</p>
            <a class="DangKy" title="Đăng ký nhanh" href="#" id="ppregister_link" onclick="_gaq.push(['_trackEvent','Dang ky', 'Button Image', 'IDLogin']);">Đăng ký nhanh</a>

            
        </div>
        
     </div>       
    <!--<div class="FormDangKy">
         <a href="https://id.zing.vn/quickregister/game/index.118.ingame.html" id="quickReg"></a>
               <iframe src="https://id.zing.vn/quickregister/game/index.118.ingame.html" style="height:315px;width:430px;border:none" id="iframeQuickReg"></iframe>
        </div>-->
        <div class="BannerEvent">
			<iframe width="450" height="185" frameborder="0" src="http://launcher.game.zing.vn/PKVN/pk-launcher-112012.html" allowtransparency="1" scrolling="no"></iframe>
    	</div>
        
        <p class="Copyright2">Phuckhoi @ 2012</p>
		<a class="KingNet" title="KingNet" target="_blank" href="http://www.kingnet.com?pid=118&amp;eventid=788&amp;bannerid=381&amp;type=874">Kingnet</a>
    
    
</div>

</body>
</html>