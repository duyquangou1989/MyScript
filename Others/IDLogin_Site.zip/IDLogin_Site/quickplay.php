<?php
session_start();
include_once "include/SSO/CXSSO.php";
include_once 'include/SSO/TransitionUtil.php';
include_once "include/SSO/SSO_Config.php";
include "include/config-server.php";
include "include/config-url.php";
include "include/common.php";

//require_once 'include/config-banner.php';  //  config tracking code for banner
//require_once 'mysql_lib/mysql.php';

if (!isset($_GET["sid"]) || empty($_GET["sid"]))
{
		//die ("here");
		//echo "http://ssoapi.zing.vn/?method=checklogin_xdomain&aid=126&u=".$url['home'].'trial12.php'; exit();
		// ==================== CHOI NGAY ====================================================
		// GOI TU 1 DOMAIN .zing.vn den DOMAIN .com.vn se khong co sid cua passport. 
		// GOI ssoapi.zing.vn de lay sid tu passport
		$Redirect_URL = $url['home']."quickplay.php?".$_SERVER["QUERY_STRING"];
		//die($Redirect_URL);
		//echo $_SERVER["QUERY_STRING"];
		//exit;
		$URL_XSSO = "https://sso3.zing.vn/xchecklogin?apikey=".PUBLIC_KEY."&u=".urlencode($Redirect_URL);
		header("Location: $URL_XSSO");
		exit;
		// ==================== CHOI NGAY ====================================================
}

// KIEM TRA XEM DA CO CHECKXLOGIN THANH CONG CHUA
if(!empty($_GET["sid"])){
	$sid_SSO3 = TransitionUtil::decode($_GET["sid"],PRIVATE_KEY);
	$vngSession = CXSSO::checkVNGSession($sid_SSO3);
	$vngSessionArr = (array)$vngSession;
	
	//echo $sid_SSO3;
	//print_r($vngSession);
	//die();
	if(!$vngSession){
		setcookie('session_info', '');	
		//return $this->showLoginForm();
	}else{
		setcookie('session_info',$sid_SSO3);
	}
}
//-------------------------------------------------

//$sid = $_COOKIE['session_info'];		
if(empty($sid_SSO3))
{
	header("Location: ".$url['home']."");
	exit;
}
else
{
	if($sid_SSO3 != 'none')
	{	
		//$vngSession = CXSSO::checkVNGSession($sid);
		//$vngSessionArr = (array)$vngSession;
		$mc = new Memcached();
        $mc->addServer('172.16.9.52', 11211);
	}else{
		setcookie('session_info', '');
		header("Location: ".$url['home']."");
		exit;
	}	
}
if(empty($vngSessionArr["accountName"]))
{
	header("Location: ".$url['home']."");
}


//$zm_accName = $_REQUEST['usr'];
//$zm_userid = $_REQUEST['uid'];
$zm_userid =0;

/*
echo "<pre>";
print_r($vngSessionArr);
echo "</pre>";
*/

// OVERWRITE SERVER LIST (lay ra nhung server se open dung thoi gian Release Time)
$temp_server = array();
foreach ($servers as $key => $server) {
    if ($server['active']==1 && strtotime($server['release_time']) <= time()) { 
		$temp_server[$key]=$server;
	}
}

$sizeof=sizeof($temp_server);
$hot=0;
$new=0;
for($h=1;$h<=$sizeof;$h++){
	if($h==($sizeof-1)){ 
		$new = 1;
	}	
	if($h==($sizeof)){ 
		$hot = 1;
	}
	$temp_server["s$h"]["hot"]=$hot;
	$temp_server["s$h"]["new"]=$new;
}

$servers = $temp_server;
//echo "<pre>";
//print_r($temp_server);
//echo "</pre>";

//------------------------------------------------------------------------------

$accName = $vngSessionArr["accountName"];
$userid = $vngSessionArr["uin"];

// lay server cuoi cung = server hot
foreach($servers as $i => $value){
 		// lay server cuoi cung = server hot	
}
$server = $servers["$i"]["id"];
// lay server cuoi cung = server hot


//$ip = $_GET['ip'];
//$port = $_GET['port'];
$server = preg_quote($server);

$ip =  $servers["s$server"]["ip"];
$port =  $servers["s$server"]["port"];

setcookie('server_name', $servers["s$server"]["name"]);

/** Memcache: luu thong tin server choi nhieu nhat, gan nhat **/
/*** Gan nhat ***/
$mc = new Memcached();
$mc->addServer('172.16.9.52', 11211);
if($mc->get("[{$accName}][gannhat]")) {
	$gannhat = $mc->get("[{$accName}][gannhat]");
		if(strpos($gannhat,"s{$server}") == false) {
		$gannhat = $gannhat."|s{$server}|";
		$mc->set("[{$accName}][gannhat]",$gannhat,0);
	} else {
		$gannhat = preg_replace("/\|s".$server."\|/", "", $gannhat);
		$gannhat = $gannhat."|s{$server}|";
		$mc->set("[{$accName}][gannhat]",$gannhat,0);
	}
} else {
	$mc->add("[{$accName}][gannhat]","|s{$server}|",0);
}

/*** Nhieu nhat ***/
if($mc->get("[{$accName}][dachoi]")) {
	$dachoi = $mc->get("[{$accName}][dachoi]");
		if(strpos($dachoi,"s{$server}") == false || $dachoi == "") {
			$dachoi = $dachoi."|s{$server}:1|";
			$mc->set("[{$accName}][dachoi]",$dachoi,0);
		} else {
			preg_match("/\|s".$server.":[^\|]*\|/", $dachoi, $part);
			$tmp = implode("", str_replace("|", "", $part));
			$tmp = explode(":", $tmp);
			$counter = (int)$tmp[1] + 1;
			$newValue = preg_replace("/\|s".$server.":[^\|]*\|/", "|s".$server.":".$counter."|", $dachoi);
			$mc->set("[{$accName}][dachoi]",$newValue,0);
	}
} else {
	$mc->add("[{$accName}][dachoi]","|s{$server}:1|",0);
}

/*** Get bannerid ***/
/*
$today = date('Y-m-d');
if($mc->get("[{$accName}][tmp_bannerid]") || $mc->get("[{$accName}][zm_from_bannerid]")) {
	$bannerid = $mc->get("[{$accName}][tmp_bannerid]");
	if($mc->get("[{$accName}][zm_from_bannerid]")) {
$bannerid = $mc->get("[{$accName}][zm_from_bannerid]");
}
if(isset($banners[$bannerid])) {
		countBanner($bannerid);
	}

	if($mc->get("[{$accName}][from_bannerid]")) {
		$curBannerid = $mc->get("[{$accName}][from_bannerid]");
		if(strpos($curBannerid, ":{$server}|") == false ) {
			$newBannerid = $curBannerid."|{$bannerid}:{$server}|";
			$mc->set("[{$accName}][from_bannerid]",$newBannerid,0);
			if(isset($banners[$bannerid])) {
				$message = $accName.','.$server;
				$log->lfile("/home/cltvn/public_html/bannerid.log/{$today}/bannerid.{$bannerid}");
				$log->lwrite($message);
			}          
		}
	} else {
		$mc->add("[{$accName}][from_bannerid]","|{$bannerid}:{$server}|",0);
		if(isset($banners[$bannerid])) {
			$message = $accName.','.$server;
			$log->lfile("/home/cltvn/public_html/bannerid.log/{$today}/bannerid.{$bannerid}");
			$log->lwrite($message);
		}
	}
}
unset($_SESSION['bannerid']);
$mc->delete("[$accName][tmp_bannerid]");
$mc->delete("[{$accName}][zm_from_bannerid]");
*/

/** End memcache **/
/**--------------**/

function genRandom()
{
	$r = '';
	for($i = 0; $i < 12; ++ $i)
	{
		$r .= chr(mt_rand(0, 255));
	}
	return $r.pack("V", time());
}

function hashThem($username, $r)
{
	static $static_key1 = 'FUHuIEyBcM3OR2eh';
	static $static_key2 = 'Y7IAmfOBpAzknCK7';
	if(strlen($r) < 16)
		return NULL;
	$data = substr($r, 8, 4) . $static_key1 . substr($r, 0, 4) . $username . substr($r, 12, 4) . $static_key2 . substr($r, 4, 4);
	$data1 = sha1($data, true);
	return $r.$data1;
}
/*
if(!isset($_POST['userid']))
{
	header("location: /login.php");
	return;
}
*/
//SetCookie('sscq_userid', $_POST['userid'], time()+3600*24*30, '/');
//SetCookie('sscq_server', $_POST['server'], time()+3600*24*30, '/');
//SetCookie('sscq_port', $_POST['port'], time()+3600*24*30, '/');
SetCookie('sscq_userid', $userid, time()+3600*24*30, '/');
SetCookie('sscq_server', $ip, time()+3600*24*30, '/');
SetCookie('sscq_port', $port, time()+3600*24*30, '/');
sendMas ($accName, $server, 1);
$ccc = genRandom();
$data = hashThem(pack('VV', $userid, 0), $ccc);
$credit_var = urlencode(base64_encode($data));
$myRoot='';
$cfgserver = "112";
$is_newuser="0";
$ban = 0;
$file = "main_VI.swf";
$glocale = 'Viet';
$chan="zing";
$gid = "2" ;
//$cdnroot = 'http://local.pk.net.vn/sscq/';
$cdnroot = 'http://pk.static.game.zing.vn/sscq/';
//$server = $_POST['server'].":".$_POST['port'];
$serverport = $ip.":".$port;
if (isset($_GET['cdnroot'])) {
	$cdnroot = $_GET['cdnroot'];
}
$qpluslv = "1";
$myRoot=$cdnroot;
$wallow="1";
$isvip="1";
$viplv="6";
$isyearvip="1";
$isblue="1";
$via = "FB_25623" ;
$invited = "1391540" ;
$serverId = 99;
$isMerge=0;
//$openid = "100002175232373";
$openid = $userid;
$openkey = "121212";

//GHI LOG tracking banner VAO MYSQL tren server 10.13.8.3
/*
if(!empty($_SESSION['pkvn']['tracking_code']))
{
	$mysql = new mysqlcommand($conf_mysql,$conf_memcache);
	$ip = (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) ? $_SERVER["HTTP_X_FORWARDED_FOR"] : $_SERVER["REMOTE_ADDR"];
	$returnArr=$mysql->add_tracking_log($accName,$ip,$_SESSION['pkvn']['tracking_code'],$server);
	//$_SESSION['nlvn']['tracking_code'] = '';
}
*/
//-------------------------------------------------------
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="shortcut icon" href="http://img.zing.vn/phuckhoi/skin/phuckhoi-072012/images/favicon.ico" type="image/x-icon"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Phuc Khoi online – Tuyệt đỉnh PK</title>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="robots" content="index,follow" />
<link href="http://img.zing.vn/eventgame/intro/general/css/mainsite.css?1" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="css/style.css?1" />
<link href="css/jcarousel.css?1" rel="stylesheet" />
<link href="css/jselect.css?1" rel="stylesheet" />
<link href="css/jselect-theme.css?1" rel="stylesheet" />
<link href="css/j-navigation-left.css?1" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="http://img.zing.vn/eventgame/intro/general/js/mainsite.js"></script>
<!--[if IE 6]>
<script src="js/DD_belatedPNG_0.0.8a.js"></script>
<script>  
 	DD_belatedPNG.fix('#img);
</script>
<![endif]-->
<script type="text/javascript" src="js/popup.js"></script>
<script type="text/javascript" src="js/jselect/jselect.js"></script>
<script type="text/javascript" src="js/jselect/jselect.external.js"></script>
<script type="text/javascript" src="js/carousel.js"></script>
<script type="text/javascript" src="http://img.zing.vn/phuckhoi/js/ga-phuckhoi-idlogin.js?version=1"></script>
<script type="text/javascript" src="js/common.js"></script>
<!--<script type="text/javascript" src="http://idlocal.pk.net.vn/js/jquery-1.6.4.min.js" ></script>-->
<script type="text/javascript" src="http://static.me.zing.vn/feeddialog/js/feed-dialog-1.01.js" ></script>
<script type="text/javascript" src="http://id.pk.net.vn/zm/zingapi/pushfeed.js" ></script>
<script type="text/javascript" src=" http://static.me.zing.vn/v3/js/zm.xcall-1.15.min.js"></script>

<script type="text/javascript"  language="javascript">
		<!-- For version detection, set to min. required Flash Player version, or 0 (or 0.0.0), for no version detection. --> 
		var swfVersionStr = "10.0.0";
		<!-- To use express install, set to playerProductInstall.swf, otherwise the empty string. -->
		var xiSwfUrlStr = "playerProductInstall.swf";
		var flashvars = {};
		flashvars.userid = <?php echo $userid; ?>;
		flashvars.zm_userid = <?php echo $userid; ?>;
		flashvars.hash = "<?php echo $credit_var; ?>";
		flashvars.cdnroot = "<?php echo $myRoot; ?>";
		flashvars.glocale = "<?php echo $glocale; ?>";
		flashvars.wallow = "0"; //0 is off, 1 is on
		flashvars.serverId = "<?php echo $serverId; ?>";
		flashvars.isMerge = "<?php echo $isMerge; ?>";
		flashvars.channel =  "<?php echo $chan; ?>";
		flashvars.openid = "<?php echo $openid; ?>";
		flashvars.openkey = "<?php echo $openkey; ?>";
		flashvars.server= "<?php echo $serverport; ?>";
		flashvars.via = "<?php echo $via; ?>";
		flashvars.invited = "<?php echo $invited; ?>";
		flashvars.gid = "<?php echo $gid; ?>";
		flashvars.isvip = "<?php echo $isvip; ?>";
		flashvars.viplv = "<?php echo $viplv; ?>";
		flashvars.qpluslv = "<?php echo $qpluslv; ?>";
		flashvars.isyearvip = "<?php echo $isyearvip; ?>";
		flashvars.isblue = "<?php echo $isblue; ?>";
		flashvars.ban = "<?php echo $ban; ?>";
		flashvars.cfg_server = "s1";
		var params = {};
		params.quality = "high";
		params.allowscriptaccess = "always";
		params.allowfullscreen = "true";
		params.wmode = "direct";
		var attributes = {};
		attributes.id = "SSCQ";
		attributes.name = "SSCQ";
		attributes.align = "middle";
		swfobject.embedSWF(
			"<?php echo $myRoot.$file; ?>?t="+(new Date()), "flashContent", 
			"1000", "580", 
			swfVersionStr, xiSwfUrlStr, 
			flashvars, params, attributes);
		<!-- JavaScript enabled so display the flashContent div in case it is not replaced with a swf object. -->
		swfobject.createCSS("#flashContent", "display:block;text-align:left;");
		function reloadpage() 
		{
			window.location.reload();
		}
		function username() 
		{
			return "abc"
		}
		function testItem(){
				var flash = getSwf("SSCQ");
				flash.inviteSend();
		}
		function getSwf(movieName) {
			   if (window.document[movieName])
			   {
							 return window.document[movieName];
			   }
			   if (navigator.appName.indexOf("Microsoft")==-1)
			   {
							 if (document.embeds && document.embeds[movieName])
							return document.embeds[movieName];
			   }
			   else
			   {
							return document.getElementById(movieName);
			   }
		}
		
    function addBookmark(title,url)
    {
      if (window.sidebar) {
        window.sidebar.addPanel(title, url,"");
      } else if( document.all ) {
        window.external.AddFavorite( url, title);
      } else if( window.opera && window.print ) {
        return true;
      }
    }
	</script>
<style type="text/css">
#linkgame {
	position: absolute;
	top: 0;
	left: 20px;
	width: 100%;
	height: 100%;
	border: none;
	box-sizing: border-box;
	-moz-box-sizing: border-box;
	-webkit-box-sizing: border-box;
}
#linkgamebot {
	position: absolute;
	bottom: 200px;
	left: 0;
	width: 100%;
	height: 100%;
	border: none;
	box-sizing: border-box;
	-moz-box-sizing: border-box;
	-webkit-box-sizing: border-box;
}
</style>


</head>
<body id="change" class="Ingame" onload="document.getElementById('SSCQ').focus()" >

<div id="gameplay">
		<!--<div id="gameContent">
			<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">-->
				<tr>
					<td align="center" valign="middle">
						<div id="flashContent"></div>
					</td>
				</tr>
			<!--</table> -->
		</div>
</div>

<div id="sideBar">
        <div  class="WrapperSideBar">
            <h1><a href="<?php echo $url['home'];?>" title="Trở về trang chủ Phục Khởi">Phục Khởi</a></h1>
            <a href="javascript:void(0);" title="Đóng" id="toggle" class="CloseBtn NotTrack">Đóng / Mở</a>
            <div class="UserInfo2"><span><?php echo $accName; ?></span><a href="logout.php"> Thoát</a></div>
            <div class="ServerBox">
                <p class="Text"	>Máy chủ đang chơi:</p>
                <p class="ServerCurrent"><?php echo $servers["s$server"]["name"];?></p>
                <select class="SelectUI Theme_GP Theme_Human "  id="Server" name="" title="Máy chủ đã chọn" onchange="window.open(this.options[this.selectedIndex].value,'_blank')">
				<?php 
					if($mc->get("[{$accName}][dachoi]"))
					{
						$dachoi = $mc->get("[{$accName}][dachoi]");
						$dachoi = explode("|", $dachoi);
						$bigArr = array();
						
						foreach ($dachoi as $key) {
							if($key != "") {
							$bigArr[] = explode(":", $key)[0] ;
							}
						}
						$end_bigArr = count($bigArr)-1;
						for($i=$end_bigArr, $count=1; $i>=0; $i--, $count++) {
							$serverName = $bigArr[$i];
							if(!empty($serverName))
								echo '<option value="game.php?server='.$servers[$serverName]['id'].'">'.$servers[$serverName]['name'].'</option>';
							if($count == 5) break;
						}
					}
				?>
                    <!--<option value="Value 1">Máy chủ 1</option>
                    <option value="Value 2">Máy chủ 2</option>
                    <option value="Value 3">Máy chủ 3</option>-->
					
					
                </select>
        	</div>
            
           	<iframe width="202" height="470" frameborder="0" src="http://launcher.game.zing.vn/PKVN/left-menu-0912.html" allowtransparency="1" scrolling="no"></iframe> 
        </div>
    </div>
<!-- Google Code for Create Conv Conversion Page -->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 994251942;
var google_conversion_language = "en";
var google_conversion_format = "1";
var google_conversion_color = "ffffff";
var google_conversion_label = "r0eyCNLRkQUQpqmM2gM";
var google_conversion_value = 0;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/994251942/?value=0&amp;label=r0eyCNLRkQUQpqmM2gM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>
<!-- Advertiser 'Công ty TNHH Nội dung số Nguyên Bảo',  Conversion tracking 'Công ty TNHH Nội dung số Nguyên Bảo_PhucKhoi_Conversion' - DO NOT MODIFY THIS PIXEL IN ANY WAY -->
<img src="http://ad.yieldmanager.com/pixel?id=2380450&t=2" width="1" height="1" />
<!-- End of conversion tag -->
<?php 
$source = 1 ;  // da login thanh cong
if(!empty($_GET["src"]) && $_GET["src"]=="quickres")  // dang ky nhanh thanh cong
{
	$source = 0 ; 
}
?>
<img src="http://mas.zing.vn/loggingDirect.php?<?php echo 'u='.$userid.'&f='.$source.'&s='.$server.'&gc=PKVN';?>" width="0" height="0"></img>
</body>
</html>
