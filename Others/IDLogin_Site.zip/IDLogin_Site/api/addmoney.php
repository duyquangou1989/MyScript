<?php
    ini_set("display_errors",1);

    $key = 'sklifugngt3904kingnet.com';

    $time     = $_POST['time'];
    $params   = stripcslashes($_POST['params']);
    $sig      = $_POST['sig'];//签名
    $addition = $_POST['addition'];

    $token = hash_hmac("sha256", $key.$params.$time, $key);
    if($sig != $token)
    {
        echo 1001;
        exit;
    }

    $params   = unserialize($params);
    $addition = urldecode($addition);
    $addition_array = explode('|', $addition);

    list($currency,$orderid) = explode('#', $addition_array[1]);

    $sscq = new SscqControl();
    $sscq->setParams($params);
    $sscq->setOrderId($orderid);
    $sscq->setCurrency($currency);
    $sscq->add();

class SscqControl
{
    private $fsock  = null;
    private $params = null;
    private $orderid = null;
    private $currency = null;
    private $keyOne = 'I1TOcYnjVz29MuXV';
    private $keyTwo = 'kLvf03cKUSXuHG43';

    private $_securityMcConfig = array(
            array('host' => '10.30.75.52', 'port' => '11211'),
        );

    // 默认cache值
    private $cacheValue = "20110503ll";

    protected function getPrivateHashValue() {
        $mc = new Memcached();
        foreach($this->_securityMcConfig as $config) {
            $mclink = $mc->addserver($config['host'], $config['port']);
            if(!$mclink) {
                // export::showResult('ERROR::MC_CONNECT_ERROR', TRUE);
            }
        }
        $sscq_recharge_key_id = $mc->get('sscq_recharge_key_id');
        return  $sscq_recharge_key_id ? $sscq_recharge_key_id : $this->cacheValue;
    }


    public function generateHashValue($hashValue) {
        $randChar = '';
        for($i = 0; $i < 12; $i ++) {
            $randChar .= chr(mt_rand(0, 255));
        }
        $randChar .= pack('V', time());
        $hashValue = $this->pack8B($this->getPrivateHashValue());
        $data = substr($randChar, 8, 4).$this->keyOne.substr($randChar, 0, 4).
                $hashValue.substr($randChar, 12, 4).$this->keyTwo.substr($randChar, 4, 4);
        return $randChar.sha1($data, TRUE);

    }

    /**
     * pack8个字节
     * 将8个字节拆分成2个4字节，按小尾序
     */
    public function pack8B($value)
    {
        $int_32 = 4294967295;
        $low = $value & $int_32;
        $high = $value >> 32;
        $bin_64 = pack("VV",$low,$high);
        return $bin_64;
    }

    public function add()
    {
        $params   = $this->params;
        $orderid  = $this->orderid;
        $currency = $this->currency;
        //socket地址
        $uri    = $params['sid'];
        $uid    = $params['user_id'];
        $uid8B  = $this->pack8B($uid);
        //hash值
        $hash = $this->generateHashValue($uid8B);
        $data['hash']     = $hash;
        //订单号
        $data['orderlen'] = strlen($orderid);
        $data['orderid']  = $orderid;
        //uid
        $data['uid']      = $uid8B;
        //道具ID,固定
        $data['propsid']  = '29999';
        //发货数量
        $data['amount']   = $params['number'];
        //单位
        $data['currencylen'] = strlen($currency);
        $data['currency']    = $currency;
        //实际金额
        $data['moneylen']   = strlen($params['money']);
        $data['money']      = $params['money'];

        $dataStream = $this->packAll($data);
        $this->socketFunctionTest($uri,$dataStream);
        $getRes = $this->socketRead();
        $this->socketClose();

        //如果长度没有就说明没返回，认为是补单,因为游戏中已经加入
        if($getRes === false)
        {
            echo 1002;
            exit;
        }

        //返回的是二进制包，所以要解压
        /**
         * length          2
         * ctrl            1           0x1
         * cmd             1           0x9
         * ret             1           返回码
         * len             2           错误信息长
         * err             len         错误信息
         **/
        //$length    = unpack('v',substr($getRes, 0, 2));
        //$ctrl      = unpack('c',substr($getRes, 2, 1));
        //$cmd       = unpack('c',substr($getRes, 3, 1));
        $ret       = unpack('c',substr($getRes, 4, 1));
        $len       = unpack('v',substr($getRes, 5, 2));
        $err       = unpack('a'.$len[1],substr($getRes, 7, $len[1]));

        // var_dump($length, $ctrl, $cmd, $ret, $len, $err);exit();
        if(isset($ret[1]) && $ret[1] == 0)
        {
            echo 1;
            exit;
        }
        else
        {
            echo '3|'.json_encode($err);
            exit;
        }
    }

    //封装
    public function packAll($data)
    {
        // var_dump($data);
        $p = array();
        $count  = 56 +  $data['orderlen'] + $data['currencylen'] + $data['moneylen'];
        $p[]    = pack("v",$count);
        $p[]    = pack("C",0xCC);
        $p[]    = pack("C",0x1);
        $p[]    = pack("C",0x5);
        $p[]    = $data['hash'];
        $p[]    = pack("v",$data['orderlen']);
        $p[]    = pack("a".$data['orderlen'], $data['orderid']);
        $p[]    = $data['uid'];
        $p[]    = pack('v',$data['propsid']);
        $p[]    = pack('i',$data['amount']);
        $p[]    = pack('v',$data['currencylen']);
        $p[]    = pack('a'.$data['currencylen'],$data['currency']);
        $p[]    = pack('v',$data['moneylen']);
        $p[]    = pack('a'.$data['moneylen'],$data['money']);
        $pstream = implode(NULL, $p);
        return $pstream;
    }

    function socketCreate($url,$connectTimeout)
    {
        //建立连接
        $fsock = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        if(!$fsock) {
            return false;
        }

        $urlInfo = parse_url($url);
        $urlInfo["host"] = ($urlInfo["host"] == "" ? "/" : $urlInfo["host"]);
        $urlInfo["port"] = ($urlInfo["port"] == "" ? 80 : $urlInfo["port"]);
        $hostIp = gethostbyname($urlInfo["host"]);
        @socket_set_option($fsock, SOL_SOCKET,SO_SNDTIMEO, array("sec" =>
                                            $connectTimeout, "usec" => 0 ) );
        $a   = @socket_connect($fsock, $hostIp, $urlInfo["port"]);
        $ret = socket_select($fd_read = array($fsock), $fd_write=array($fsock),
                                           $except = NULL, $connectTimeout, 0);
        if($ret != 1){
            #trigger_error("connect error or timeout");
            @socket_close($fsock);
            return false;
        }
        return $fsock;
     }

    //参数需要二进制压缩
    function socketFunctionTest($url, $post_string,$connectTimeout=1,
                                                               $readTimeout=10)
    {
        if($this->fsock === null)
        {
            $this->fsock = $this->socketCreate($url,$connectTimeout);
        }

       if($this->fsock === false)
       {
            return false;
       }

        $send_len = @socket_write($this->fsock, $post_string);
        if(!$send_len){
            socket_close($this->fsock);
            return;
        }
        @socket_set_option($this->fsock, SOL_SOCKET, SO_RCVTIMEO, array("sec"=>
                                                $readTimeout, "usec" => 0));
        return true;
    }

    function socketRead($bufferSize=1024)
    {
        $ret = socket_read($this->fsock, $bufferSize);
        return $ret;
    }

    public function socketClose()
    {
        $this->sock_error = socket_strerror(socket_last_error($this->fsock));
        socket_clear_error();
        @socket_close($this->fsock);
    }

    public function setParams($params)
    {
        $this->params = $params;
    }

    public function setOrderId($orderid)
    {
        $this->orderid = $orderid;
    }

    public function setCurrency($currency)
    {
        $this->currency = $currency;
    }
}


