<?php

ini_set('display_errors', 'on');
error_reporting(E_ALL);

$host = $_GET["host"]; #'10.211.0.106';
$port = $_GET["port"]; #'8001';
$type = $_GET["type"]; #1;
$player = $_GET["player"]; #14710;

$param = array(
	'host' => $host,
	'port' => $port,
	'type' => $type,
	'player' => $player,
);

$p = array();
$p['t'] = time();
$p['class'] = 'sscqApiLib';
$p['action'] = 'playerQuires';
$p['params'] = json_encode($param);
$p['sig'] = md5($p['class'] . $p['action'] . $p['params'] . $p['t'] . '6057e1#bdb845#895ff3$218&c422');

//$url = 'http://data-s3.kingnet.net/api.php';
//$url = 'http://data-s3.kingnet.net/curl211test.php';
$url = 'http://gm.pk.net.vn/new/newshushan/indexapp1/libraries/curl211test.php';
$method = 'POST';

$h = curl_init();
curl_setopt($h, CURLOPT_URL, $url);
curl_setopt($h, CURLOPT_RETURNTRANSFER, 1);
if ($method == 'GET') {
	curl_setopt($h, CURLOPT_HEADER, 0);
} elseif ($method == 'POST') {
	curl_setopt($h, CURLOPT_POST, 1);
	curl_setopt($h, CURLOPT_POSTFIELDS, $p);
}
$ret = curl_exec($h);
curl_close($h);

//var_dump($ret);
//print_r(json_decode($ret, true));
//echo $ret;

$data = json_decode($ret, true);
echo (empty($data["msg"]["gold"]))? 0 : $data["msg"]["gold"];

exit;

?>
