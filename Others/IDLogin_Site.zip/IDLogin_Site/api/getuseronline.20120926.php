<?php

// 获取在线人数

//ini_set('display_errors', 'on');
//error_reporting(E_ALL);

$skey = 'phikiem123@/.,vngIebolah5sh';
$rs = array("ErrorCode"=>-6, "Msg"=>"System exception", "Online"=>"");

if(empty($_REQUEST["serverip"]) || empty($_REQUEST["serverport"])) {
	$rs["ErrorCode"] = -4;
	$rs["Msg"] = "Parameters error";
	echo json_encode($rs);
	exit;
}
$host = $_REQUEST["serverip"];
$port = $_REQUEST["serverport"];

$sig = md5($skey.$_REQUEST["serverip"].$_REQUEST["serverport"]);
if(empty($_REQUEST["sig"]) || $sig!=$_REQUEST["sig"]) {
	$rs["ErrorCode"] = -2;
	$rs["Msg"] = "Sig param is incorrect (Authenticate failed)";
	echo json_encode($rs);
	exit;
}

$param = array(
	'host' => $host,
	'port' => $port,
);

$p = array();
$p['t'] = time();
$p['class'] = 'sscqApiLib';
$p['action'] = 'statOnline';
$p['params'] = json_encode($param);
$p['sig'] = md5($p['class'] . $p['action'] . $p['params'] . $p['t'] . '');

$url = 'http://gm.pk.net.vn/new/newshushan/indexapp1/libraries/curl211test.php';
$method = 'POST';

$h = curl_init();
curl_setopt($h, CURLOPT_URL, $url);
curl_setopt($h, CURLOPT_RETURNTRANSFER, 1);
if ($method == 'GET') {
	curl_setopt($h, CURLOPT_HEADER, 0);
} elseif ($method == 'POST') {
	curl_setopt($h, CURLOPT_POST, 1);
	curl_setopt($h, CURLOPT_POSTFIELDS, $p);
}
$ret = curl_exec($h);
curl_close($h);

$data = $ret;
$data = json_decode($ret, true);
if(is_array($data) && !$data["error"]) {
	$rs["ErrorCode"] = 0;
	$rs["Online"] = $data["msg"];
} else {
	$rs["ErrorCode"] = -6;
	$rs["Msg"] = "System exception 2";
}

echo json_encode($rs);

exit;

?>