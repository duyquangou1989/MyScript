<?php

// 获取角色接口

//ini_set('display_errors', 'on');
//error_reporting(E_ALL);

$skey = 'phikiem123@/.,vngIebolah5sh';
$rs = array("ErrorCode"=>-6, "Msg"=>"");

if(empty($_REQUEST["serverip"]) || empty($_REQUEST["serverport"])) {
	$rs["ErrorCode"] = -4;
	$rs["Msg"] = "Server or Port Error!";
	echo json_encode($rs);
	exit;
}
$host = $_REQUEST["serverip"];
$port = $_REQUEST["serverport"];

if(empty($_REQUEST["playerId"])) {
	$rs["ErrorCode"] = -4;
	$rs["Msg"] = "playerId Error!";
	echo json_encode($rs);
	exit;
}
$playerId = $_REQUEST["playerId"];

if(empty($_REQUEST["title"])) {
	$rs["ErrorCode"] = -4;
	$rs["Msg"] = "title Error!";
	echo json_encode($rs);
	exit;
}
$title = $_REQUEST["title"];

if(empty($_REQUEST["content"])) {
	$rs["ErrorCode"] = -4;
	$rs["Msg"] = "content Error!";
	echo json_encode($rs);
	exit;
}
$content = $_REQUEST["content"];

$items = array();
if(!empty($_REQUEST["items"])) {
	$items_list = explode(",", $_REQUEST["items"]);
	foreach($items_list as $v) {
		$item_data = explode("_", $v);
		if(!empty($item_data[0]) && !empty($item_data[1])) {
			$items[ $item_data[0] ] = $item_data[1];
		}
	}
}
if(empty($items)) {
	$rs["ErrorCode"] = -4;
	$rs["Msg"] = "items Error!";
	echo json_encode($rs);
	exit;
}

$coin = empty($_REQUEST["coin"]) ? 0 : intval($_REQUEST["coin"]);
$liquan = empty($_REQUEST["liquan"]) ? 0 : intval($_REQUEST["liquan"]);
$gold = empty($_REQUEST["gold"]) ? 0 : intval($_REQUEST["gold"]);

$sig = md5($playerId.$skey.$_REQUEST["serverip"].$_REQUEST["serverport"]);
if(empty($_REQUEST["sig"]) || $sig!=$_REQUEST["sig"]) {
	$rs["ErrorCode"] = -2;
	$rs["Msg"] = "sig Error!";
	echo json_encode($rs);
	exit;
}

$param = array(
	'host' => $host,
	'port' => $port,
	'pid' => array($playerId),
	'title' => $title,
	'content' => $content,
	'coin' => $coin,
	'liquan' => $liquan,
	'gold' => $gold,
	'achievement' => 0,
	'items' => $items,
	'bind' => 1,
);

$p = array();
$p['t'] = time();
$p['class'] = 'sscqApiLib';
$p['action'] = 'sendWuPin';
$p['params'] = json_encode($param);
$p['sig'] = md5($p['class'] . $p['action'] . $p['params'] . $p['t'] . '');

$url = 'http://gm.pk.net.vn/new/newshushan/indexapp1/libraries/curl211test.php';
$method = 'POST';

//var_dump($param, $p);

$h = curl_init();
curl_setopt($h, CURLOPT_URL, $url);
curl_setopt($h, CURLOPT_RETURNTRANSFER, 1);
if ($method == 'GET') {
	curl_setopt($h, CURLOPT_HEADER, 0);
} elseif ($method == 'POST') {
	curl_setopt($h, CURLOPT_POST, 1);
	curl_setopt($h, CURLOPT_POSTFIELDS, $p);
}
$ret = curl_exec($h);
//var_dump(curl_getinfo($h));
//var_dump(curl_error($h));
curl_close($h);

$ret = json_decode($ret, true);
if($ret["error"]) {
	$rs["ErrorCode"] = -2;
	$rs["Msg"] = $ret["msg"];
	echo json_encode($rs);
	exit;	
}
//var_dump($ret);

$rs["ErrorCode"] = 0;
echo json_encode($rs);

exit;

?>