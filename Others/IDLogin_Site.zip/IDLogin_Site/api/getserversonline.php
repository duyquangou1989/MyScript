<?php 
include "../include/config-server.php";
echo json_encode($servers);
?>