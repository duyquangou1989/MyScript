<?php

// 获取角色接口

//ini_set('display_errors', 'on');
//error_reporting(E_ALL);

$skey = 'phikiem123@/.,vngIebolah5sh';
$rs = array("ErrorCode"=>-6, "AccountName"=>"", "Msg"=>"");

if(empty($_REQUEST["accountName"])) {
	$rs["ErrorCode"] = -4;
	$rs["Msg"] = "Input accountName";
	echo json_encode($rs);
	exit;
}
$player = $_REQUEST["accountName"];
$rs["AccountName"] = $player;

if(empty($_REQUEST["serverip"]) || empty($_REQUEST["serverport"])) {
	$rs["ErrorCode"] = -4;
	$rs["Msg"] = "Input serverip or serverport";
	echo json_encode($rs);
	exit;
}
$host = $_REQUEST["serverip"];
$port = $_REQUEST["serverport"];

$sig = md5($player.$skey.$_REQUEST["serverip"].$_REQUEST["serverport"]);
if(empty($_REQUEST["sig"]) || $sig!=$_REQUEST["sig"]) {
	$rs["ErrorCode"] = -2;
	$rs["Msg"] = "sig error!";
	echo json_encode($rs);
	exit;
}

$param = array(
	'host' => $host,
	'port' => $port,
	'type' => 1,
	'player' => $player,
);
//var_dump($param);

$p = array();
$p['t'] = time();
$p['class'] = 'sscqApiLib';
$p['action'] = 'playerQuires';
$p['params'] = json_encode($param);
$p['sig'] = md5($p['class'] . $p['action'] . $p['params'] . $p['t'] . '');
//var_dump($p);

$url = 'http://gm.pk.net.vn/www/shushan/indexapp1/libraries/gmtapi.php';
$method = 'POST';

$h = curl_init();
curl_setopt($h, CURLOPT_URL, $url);
curl_setopt($h, CURLOPT_RETURNTRANSFER, 1);
if ($method == 'GET') {
	curl_setopt($h, CURLOPT_HEADER, 0);
} elseif ($method == 'POST') {
	curl_setopt($h, CURLOPT_POST, 1);
	curl_setopt($h, CURLOPT_POSTFIELDS, $p);
}
$ret = curl_exec($h);
//var_dump(curl_getinfo($h), curl_error($h));
curl_close($h);

$data = json_decode($ret, true);
if(!$data || empty($data["msg"])) {
	$rs["ErrorCode"] = -1;
	$rs["Msg"] = "Api error!";
	echo json_encode($rs);
	exit;	
}

$rs["ErrorCode"] = 0;
$rs = array_merge($rs, $data["msg"]);
echo json_encode($rs);

exit;

?>