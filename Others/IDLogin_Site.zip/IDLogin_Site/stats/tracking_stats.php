<?php
require_once("../include/config-banner.php");
$conn = mysql_connect($conf_mysql[0],$conf_mysql[1],$conf_mysql[2]);
if(!$conn)
{
	die('Can not connect DB');
}
mysql_select_db($conf_mysql[3],$conn);

// THONG KE THEO NGAY
$sql = "select DATE_FORMAT(date_created,'%Y-%m-%d') as dc , count(*) as num from tracking_banner_log group by dc order by dc ASC";
$result = mysql_query($sql);
$byDate =  "<table width='50%' border=1><tr bgcolor='#00CC00'><td>Ngay tracking</td><td>So luong account</td></tr>";
while ($row = mysql_fetch_array($result))
{
	$byDate .= "<tr><td>".$row[0]."</td><td>".$row[1]."</td></tr>";
}
$byDate .= "</table>";
//--------------------

// THONG KE THEO SERVER
$sql = "select server_id, count(*) as num from tracking_banner_log group by server_id order by server_id ASC";
$result = mysql_query($sql);
$byServer = "<table width='50%' border=1><tr bgcolor='#00CC00'><td>Server ID</td><td>So luong account</td></tr>";
while ($row = mysql_fetch_array($result))
{
        $byServer .= "<tr><td>".$row[0]."</td><td>".$row[1]."</td></tr>";
}
$byServer .= "</table>";
//--------------------

// THONG KE THEO TRACKING CODE
$sql = "select tracking_code, count(*) as num from tracking_banner_log group by tracking_code order by tracking_code ASC";
$result = mysql_query($sql);
$byTrackingCode = "<table width='50%' border=1><tr bgcolor='#00CC00'><td>Tracking Code</td><td>So luong account</td></tr>";
while ($row = mysql_fetch_array($result))
{
        $byTrackingCode .= "<tr><td>".$row[0]."</td><td>".$row[1]."</td></tr>";
}
$byTrackingCode .= "</table>";
//--------------------

mysql_close($conn);

echo '<table width="100%" border="0">
  <tr>
    <td valign="top">'.$byDate.'</td>
    <td valign="top">'.$byServer.'</td>
	<td valign="top">'.$byTrackingCode.'</td>
  </tr>
</table>';
?>
