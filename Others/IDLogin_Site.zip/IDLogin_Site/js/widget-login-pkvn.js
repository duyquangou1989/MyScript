		var flagLoad=0;
		var jsWidget;
		function RegisterSuccess(){			
			window.location = "http://id.pk.net.vn/game.php?server=15";
		}
			function readyWidget() {
				//ZRegisterWidget.showPopup();
				flagLoad=1;
				

			}
			(function(d, s, id) {
				var js, fjs = d.getElementsByTagName(s)[0];
				if (d.getElementById(id)) return;
				js = d.createElement(s); js.id = id;
				
				js.src = "https://img.zing.vn/idzing/theme/default/js/register-1.01.js#callback=RegisterSuccess&captcha=1&productid=118";
				if ($.browser.msie) {
					js.onreadystatechange = function() {
						if (this.readyState == "loaded" || this.readyState == 'complete') {
							readyWidget();
							
						}
					};
				} else {
					js.onload = function() {
						readyWidget();
						
					};
				}
				fjs.parentNode.insertBefore(js, fjs);
				
				jsWidget =js;
			} (document, 'script', 'zpp-jssdk'));
			
			//alert(jsWidget);