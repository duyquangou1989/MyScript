    $(document).ready(function () {
		
		if(jQuery("#nav").length > 0){
			$("#nav").addNavigation({
				event: "mouseover",
				effect: false,
			   activeSection: activemenu_nav
			});
		}
			
		if(jQuery("#sidenav").length > 0){
			$("#sidenav").addNavigationLeft({
				event: "click",
				effect: true,
				activeSection: activesidenav,
				callback: function () {
					showActive();
				}
			});
		}  
	
    });
	
	function showActive() {
		$("#sidenav").find(".Hilite").addClass("Active");
		$("#sidenav").find(".Hilite").each(function () {
			var self = $(this);
			self.find("ul:first").show();
		});
	}

