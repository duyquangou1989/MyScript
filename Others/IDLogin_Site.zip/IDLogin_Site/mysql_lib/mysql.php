<?php
	require_once("sendmail.php");
    class result
	{
		public $fbacc;
		public $err_num;
		public function __construct($fbacc,$err_num)
		{
			 $this->fbacc=$fbacc;
			 $this->err_num=$err_num;
		}
		public function set_acc($fbacc,$err_num)
		{
			$this->fbacc=$fbacc;
			$this->err_num=$err_num;
		}
		public function set_err($err_num)
		{
			$this->err_num=$err_num;
		}
	}
	class checkzmacc
	{
		public $zmacc;
		public $err_num;
		public function __construct($zmacc,$err_num)
		{
			 $this->zmacc=$zmacc;
			 $this->err_num=$err_num;
		}
		public function set_acc($zmacc,$err_num)
		{
			$this->zmacc=$zmacc;
			$this->err_num=$err_num;
		}
		public function set_err($err_num)
		{
			$this->err_num=$err_num;
		}
	}
	class error
	{
		public $description;
		public $err_code;
		public function __construct($description,$err_code)
		{
			 $this->description=$description;
			 $this->err_code=$err_code;
		}
		public function set_err($description,$err_code)
		{
			 $this->description=$description;
			 $this->err_code=$err_code;
		}
	}
	class mysqlcommand
	{
		public $str_mysql;
		public $str_memcache;
		public $err;
		//////methods for facebook
		public function __construct($conf_mysql_facebook,$conf_memcache)
		{
			 $this->str_mysql=$conf_mysql_facebook;
			 $this->str_memcache=$conf_memcache;
			 $this->err="";
		}
		public function anti_sql($sql) 
		{
			$sql = str_replace(sql_regcase("/(from|select|insert|delete|where|drop table|show tables|#|*|--|\)/"),"",$sql);
			return trim(strip_tags(addslashes($sql)));
		}
		/*
			Authour : QuanH
		*/
		public function add_guest_login($guest_acc,$real_acc,$ip,$serverid)
		{
				$this->conn=mysql_connect($this->str_mysql[0],$this->str_mysql[1],$this->str_mysql[2]);
				$err=new error('',0);
				if(!$this->conn)
				{
					$this->err="can't connect database";
					$err->set_err(1,"can't connect database");
					//send_email2($mail_from, $mail_to, 'insert_acc[NLVN] Check app on facebook', $this->err);
					return json_encode($err);
				}
				mysql_select_db($this->str_mysql[3],$this->conn);
				////////////sql injection
				$guest_acc = $this->anti_sql($guest_acc);
				$real_acc  = $this->anti_sql($real_acc);
				$ip        = $this->anti_sql($ip);
				$date_converted	= date('Y-m-d H:i:s');
				$serverid  = $this->anti_sql($serverid);
				///////////////////////// add guest login convert to real account
				
				$result=mysql_query("insert into guest_login_converted(id,guest_account,real_account,ip,date_converted,server_id) values(NULL,'$guest_acc','$real_acc','$ip','$date_converted','$serverid')");
				if(!$result)
				{
					$this->err=mysql_error();
					$err->set_err(2,mysql_error());
					send_email2($mail_from, $mail_to, 'add_guest_login[DTQ]', $this->err);
				}
				mysql_close($this->conn);
				return json_encode($err);
		}
		/*
			Authour : QuanH
		*/
		public function add_tracking_log($accountname,$ip,$tracking_code,$serverid)
		{
				$this->conn=mysql_connect($this->str_mysql[0],$this->str_mysql[1],$this->str_mysql[2]);
				$err=new error('',0);
				if(!$this->conn)
				{
					$this->err="can't connect database";
					$err->set_err(1,"can't connect database");
					//send_email2($mail_from, $mail_to, 'insert_acc[NLVN] Check app on facebook', $this->err);
					return json_encode($err);
				}
				mysql_select_db($this->str_mysql[3],$this->conn);
				////////////sql injection
				$accountname = $this->anti_sql($accountname);
				$ip        = $this->anti_sql($ip);
				$tracking_code  = $this->anti_sql($tracking_code);
				$serverid  = $this->anti_sql($serverid);
				///////////////////////// add guest login convert to real account
				
				$result=mysql_query("CALL usp_tracking_code('$accountname','$ip','$tracking_code','$serverid')");
				//print mysql_error();
				//echo "CALL usp_tracking_code('$accountname','$ip','$tracking_code','$serverid');";
				
				if(!$result)
				{
					$this->err=mysql_error();
					$err->set_err(2,mysql_error());
					send_email2($mail_from, $mail_to, 'tracking_banner_log[DTQ]', $this->err);
				}
				mysql_close($this->conn);
				return json_encode($err);
		}
		//--------------------------------------------------------------------------------------------
		public function insert_acc($fbacc,$zmacc)
		{
				$this->conn=mysql_connect($this->str_mysql[0],$this->str_mysql[1],$this->str_mysql[2]);
				$err=new error('',0);
				if(!$this->conn)
				{
					$this->err="can't connect database";
					$err->set_err(1,"can't connect database");
					send_email2($mail_from, $mail_to, 'insert_acc[NLVN] Check app on facebook', $this->err);
					return json_encode($err);
				}
				mysql_select_db("facebook",$this->conn);
				////////////sql injection
				$fbacc=$this->anti_sql($fbacc);
				$zmacc=$this->anti_sql($zmacc);
				$ngay	= date('H:i:s j/n/Y');
				/////////////////////////check exist
				$check=mysql_query("select fb_accname from account where fb_accname='{$fbacc}'");
				if(mysql_num_rows($check)>0)
				{
					$err->set_err(3,"account already exist");
				}
				/////////////////////////////////////
				$result=mysql_query("insert into account(fb_accname,zm_accname,updatetime,status,bannerId) values('".$fbacc."','".$zmacc."','".$ngay."',1,1000)");
				if(!$result)
				{
					$this->err=mysql_error();
					$err->set_err(2,mysql_error());
					send_email2($mail_from, $mail_to, 'insert_acc[NLVN] Check app on facebook', $this->err);
				}
				mysql_close($this->conn);
				return json_encode($err);
		} 
		public function update_zmacc($fbacc,$zmacc)
		{
				$this->conn=mysql_connect($this->str_mysql[0],$this->str_mysql[1],$this->str_mysql[2]);
				$err=new error('',0);
				if(!$this->conn)
				{
					$this->err="can't connect database";
					$err->set_err(1,"can't connect database");
					send_email2($mail_from, $mail_to, 'update_zmacc[NLVN] Check app on facebook', $this->err);
					return json_encode($err);
				}
				mysql_select_db("facebook",$this->conn);
				////////////sql injection
				$fbacc=$this->anti_sql($fbacc);
				$zmacc=$this->anti_sql($zmacc);
				$ngay	= date('H:i:s j/n/Y');
				/////////////////////////
				$result=mysql_query("update account set zm_accname='{$zmacc}',updatetime='{$ngay}', status=1 where fb_accname='{$fbacc}'");
				if(!$result)
				{
					$this->err=mysql_error();
					$err->set_err(2,mysql_error());
					send_email2($mail_from, $mail_to, 'update_zmacc[NLVN] Check app on facebook', $this->err);
				}
				mysql_close($this->conn);
				return json_encode($err);
		} 
		public function get_zm_acc($fbacc)
		{
		    $memcache = new Memcache;
			$memcache->connect($this->str_memcache[0],$this->str_memcache[1]);
			$rs=new checkzmacc('',3);
			if(!$memcache)
			{
			  $this->err="can't connect memcache";
			  $rs->set_err(2);
			  send_email2($mail_from, $mail_to, 'get_zm_acc[NLVN] Check app on facebook', $this->err);
			  return json_encode($rs);
			}
			$value=$memcache->get($fbacc);
			if($value!=null)
			{
				$rs->set_acc($value,0);
			}
			else
			{
				$this->conn=mysql_connect($this->str_mysql[0],$this->str_mysql[1],$this->str_mysql[2]);
				if(!$this->conn)
				{
					$this->err="can't connect database";
					$rs->set_err(1);
					send_email2($mail_from, $mail_to, 'get_zm_acc[NLVN] Check app on facebook', $this->err);
					return json_encode($rs);
				}
				mysql_select_db("facebook",$this->conn);
				////////////sql injection
				$fbacc=$this->anti_sql($fbacc);
				////////
				$result=mysql_query("select fb_accname,zm_accname from account where fb_accname='{$fbacc}'");
				if(!$result)
				{
					$this->err=mysql_error();
					send_email2($mail_from, $mail_to, 'get_zm_acc[NLVN] Check app on facebook', $this->err);
				}
				if(mysql_num_rows($result)>0)
				{
					while($row=mysql_fetch_array($result))
					{
						$rs->set_acc($row[1],0);
						$memcache->set($row[0],$row[1],0,604800);//luu  memcache 7 ngay
					}
				}
				mysql_close($this->conn);
			}
			return json_encode($rs);
		}
		
		public function get_fb_acc($zmacc)
		{
		    $memcache = new Memcache;
			$memcache->connect($this->str_memcache[0],$this->str_memcache[1]);
			$rs=new result('',3);
			if(!$memcache)
			{
			  $this->err="can't connect memcache";
			  $rs->set_err(2);
			  send_email2($mail_from, $mail_to, 'get_fb_acc[NLVN] Check app on facebook', $this->err);
			  return json_encode($rs);
			}
			$value=$memcache->get($zmacc);
			if($value!=null)
			{
				$rs->set_acc($value,0);
			}
			else
			{
				$this->conn=mysql_connect($this->str_mysql[0],$this->str_mysql[1],$this->str_mysql[2]);
				if(!$this->conn)
				{
					$this->err="can't connect database";
					$rs->set_err(1);
					send_email2($mail_from, $mail_to, 'get_fb_acc[NLVN] Check app on facebook', $this->err);
					return json_encode($rs);
				}
				mysql_select_db("facebook",$this->conn);
				////////////sql injection
				$zmacc=$this->anti_sql($zmacc);
				////////
				$result=mysql_query("select fb_accname,zm_accname from account where zm_accname='{$zmacc}'");
			    if(!$result)
				{
					$this->err=mysql_error();
					send_email2($mail_from, $mail_to, 'get_fb_acc[NLVN] Check app on facebook', $this->err);
				}
				if(mysql_num_rows($result)>0)
				{
					while($row=mysql_fetch_array($result))
					{
						$rs->set_acc($row[0],0);
						$memcache->set($row[1],$row[0],0,604800);//luu  memcache 7 ngay
					}
				}
				mysql_close($this->conn);
			}
			return json_encode($rs);
		}
		public function geterr()
		{
			return $this->err;
		}
		////////////////
		//methods for sdk history.
		public function insert_history($Ngay,$MoTa,$Flag)
		{
				$this->conn=mysql_connect($this->str_mysql[0],$this->str_mysql[1],$this->str_mysql[2]);
				if(!$this->conn)
				{
					$this->err="can't connect database";
					send_email2($mail_from, $mail_to, 'insert_history[NLVN] tool open new server cho sdk', $this->err);
					return false;
				}
				mysql_select_db("sdkhistory",$this->conn);
				////////////sql injection
				$Ngay=$this->anti_sql($Ngay);
				$MoTa=$this->anti_sql($MoTa);
				$Flag=$this->anti_sql($Flag);
				///////////////
				$result=mysql_query("insert into sdkhistory(Ngay,MoTa,Flag) values('".$Ngay."','".$MoTa."',{$Flag})");
				if(!$result)
				{
					$this->err=mysql_error();
					send_email2($mail_from, $mail_to, 'insert_history[NLVN] tool open new server cho sdk', $this->err);
				}
				mysql_close($this->conn);
				return $result;
		} 
		public function delete_history($Ngay)
		{
				$this->conn=mysql_connect($this->str_mysql[0],$this->str_mysql[1],$this->str_mysql[2]);
				if(!$this->conn)
				{
					$this->err="can't connect database";
					send_email2($mail_from, $mail_to, 'delete_history[NLVN] tool open new server cho sdk', $this->err);
					return false;
				}
				mysql_select_db("sdkhistory",$this->conn);
				////////////sql injection
				$Ngay=$this->anti_sql($Ngay);
				//////////////
				$result=mysql_query("delete from sdkhistory where Ngay='".$Ngay."'");
				if(!$result)
				{
					$this->err=mysql_error();
					send_email2($mail_from, $mail_to, 'delete_history[NLVN] tool open new server cho sdk', $this->err);
				}
				mysql_close($this->conn);
				return $result;
		}
		public function showall($Ngay,$Flag)
		{
				$this->conn=mysql_connect($this->str_mysql[0],$this->str_mysql[1],$this->str_mysql[2]);
				if(!$this->conn)
				{
					$this->err="can't connect database";
					send_email2($mail_from, $mail_to, 'showall[NLVN] tool open new server cho sdk', $this->err);
					return false;
				}
				mysql_select_db("sdkhistory",$this->conn);
				$result=null;
				////////////sql injection
				$Ngay=$this->anti_sql($Ngay);
				$Flag=$this->anti_sql($Flag);
				////////////
				if($Ngay=="")
				{
					$result=mysql_query("select * from sdkhistory where Flag=".$Flag);
				}
				else
				{
					$result=mysql_query("select * from sdkhistory where Flag={$Flag} and Ngay='".$Ngay."'");
				}
				if(!$result)
				{
					$this->err=mysql_error();
					send_email2($mail_from, $mail_to, 'showall[NLVN] tool open new server cho sdk', $this->err);
				}
				$rs=array();
				if(mysql_num_rows($result)>0)
				{
					$i=0;
					while($row=mysql_fetch_array($result))
					{
						$rs[$i++]=array($row[1],$row[2]);
					}
				}
				return $rs;
		}
			////////////////
		//methods for tracing bannerid
		public function update_traceBanerId_uqee($bannerId)
		{
				$this->conn=mysql_connect($this->str_mysql[0],$this->str_mysql[1],$this->str_mysql[2]);
				$err=new error('',0);
				if(!$this->conn)
				{
					$this->err="can't connect database";
					$err->set_err(1,"can't connect database");
					send_email2($mail_from, $mail_to, 'update_traceBanerId_uqee[NLVN] Check function tracing bannerId', $this->err);
					return json_encode($err);
				}
				mysql_select_db("marketting",$this->conn);
				////////////sql injection
				$BannerId=$this->anti_sql($bannerId);
				/////////////////////////
				$result="";
				$date=strtotime(date("Y-m-d",time()));
				$date=strftime("%Y-%m-%d",$date);
				/////////////check exist bannerid
				if($BannerId!=-1)
				{
					$row=mysql_query("select channelName from channel where channelId={$BannerId}");
					if(mysql_num_rows($row)<=0)
					{
						exit();
					}
				}
				/////////////////
				if($BannerId ==null || $BannerId==-1)
				{
					$result=mysql_query("select Id from count_click where BannerId=-1 and Ngay='{$date}'");
					if((mysql_num_rows($result)>0))
					{
						$result=mysql_query("update count_click set Count=Count+1 where BannerId=-1 and Ngay='{$date}'");
					}
					else
					{
						$result=mysql_query("insert into count_click(BannerId,Count,Ngay) values(-1,1,'{$date}')");
					}
				}
				else
				{
					$result=mysql_query("select Id from count_click where BannerId='{$BannerId}' and Ngay='{$date}'");
					if((mysql_num_rows($result)>0))
					{
						$result=mysql_query("update count_click set Count=Count+1 where BannerId='{$BannerId}' and Ngay='{$date}'");
					}
					else
					{
						$result=mysql_query("insert into count_click(BannerId,Count,Ngay) values({$BannerId},1,'{$date}')");
					}
				}
				if(!$result)
				{
					$this->err=mysql_error();
					$err->set_err(2,mysql_error());
					send_email2($mail_from, $mail_to, 'update_traceBanerId_uqee[NLVN] Check function tracing bannerId', $this->err);
				}
				mysql_close($this->conn);
				return json_encode($err);
		} 
		public function update_traceBanerId($bannerId)
		{
				$this->conn=mysql_connect($this->str_mysql[0],$this->str_mysql[1],$this->str_mysql[2]);
				$err=new error('',0);
				if(!$this->conn)
				{
					$this->err="can't connect database";
					$err->set_err(1,"can't connect database");
					send_email2($mail_from, $mail_to, 'update_traceBanerId[NLVN] Check function tracing bannerId', $this->err);
					return json_encode($err);
				}
				mysql_select_db("traceclick",$this->conn);
				////////////sql injection
				$BannerId=$this->anti_sql($bannerId);
				/////////////////////////
				$result="";
				$date=strtotime(date("Y-m-d",time()));
				$date=strftime("%Y-%m-%d",$date);
				$test="";
				if($BannerId ==null || $BannerId==-1)
				{
					$result=mysql_query("select Id from count_banner where BannerId=-1 and Ngay='{$date}'");
					$test="select Id from count_banner where BannerId=-1 and Ngay='{$date}'";
					if((mysql_num_rows($result)>0))
					{
						$result=mysql_query("update count_banner set Count=Count+1 where BannerId=-1 and Ngay='{$date}'");
						$test="update count_banner set Count=Count+1 where BannerId=-1 and Ngay='{$date}'";
					}
					else
					{
						$result=mysql_query("insert into count_banner(BannerId,Count,Ngay) values(-1,1,'{$date}')");
						$test="insert into count_banner(BannerId,Count,Ngay) values(-1,1,'{$date}')";
					}
				}
				else
				{
					$result=mysql_query("select Id from count_banner where BannerId='{$BannerId}' and Ngay='{$date}'");
					$test="select Id from count_banner where BannerId='{$BannerId}' and Ngay='{$date}'";
					if((mysql_num_rows($result)>0))
					{
						$result=mysql_query("update count_banner set Count=Count+1 where BannerId='{$BannerId}' and Ngay='{$date}'");
						$test="update count_banner set Count=Count+1 where BannerId='{$BannerId}' and Ngay='{$date}'";
					}
					else
					{
						$result=mysql_query("insert into count_banner(BannerId,Count,Ngay) values({$BannerId},1,'{$date}')");
						$test="insert into count_banner(BannerId,Count,Ngay) values({$BannerId},1,'{$date}')";
					}
				}
				if(!$result)
				{
					$this->err=mysql_error();
					$err->set_err(2,mysql_error());
					send_email2($mail_from, $mail_to, $test.':update_traceBanerId[NLVN] Check function tracing bannerId', $this->err);
				}
				mysql_close($this->conn);
				return json_encode($err);
		} 
		public function getCount_traceBanerId($bannerId,$ngay)
		{
				$this->conn=mysql_connect($this->str_mysql[0],$this->str_mysql[1],$this->str_mysql[2]);
				$err=new error('',0);
				if(!$this->conn)
				{
					$this->err="can't connect database";
					$err->set_err(1,"can't connect database");
					send_email2($mail_from, $mail_to, 'getCount_traceBanerId[NLVN] Check function tracing bannerId', $this->err);
					return json_encode($err);
				}
				mysql_select_db("traceclick",$this->conn);
				////////////sql injection
				$BannerId=$this->anti_sql($bannerId);
				/////////////////////////
				$result="";
				if($BannerId ==null || $BannerId=="")
				{
					$result=mysql_query("select sum(Count) from count_banner where Ngay='{$ngay}'");
				}
				else
				{
					$result=mysql_query("select sum(Count) from count_banner where BannerId='{$BannerId}' and Ngay='{$ngay}' ");
				}
				if(mysql_num_rows($result)>0)
				{
					while($row=mysql_fetch_array($result))
					{
						return $row[0];
					}
				}
				if(!$result)
				{
					$this->err=mysql_error();
					$err->set_err(2,mysql_error());
					send_email2($mail_from, $mail_to, 'getCount_traceBanerId[NLVN] Check function tracing bannerId', $this->err);
					return 0;
				}
				mysql_close($this->conn);
				return 0;
		} 
		//////////////////////////all banner on memcache
		public function getAll_banner_mem()
		{
			$memcache = new Memcache;
			$memcache->connect($this->str_memcache[0],$this->str_memcache[1]);
			if(!$memcache)
			{
			  $this->err="can't connect memcache";
			  send_email2($mail_from, $mail_to, 'getAll_banner_mem[NLVN] error on function getAll_banner_memcache', $this->err);
			  return null;
			}
			$arr_banner=unserialize($memcache->get("all_banner"));
			if($arr_banner!=null)
			{
				return $arr_banner;
			}
			else
			{
				$this->conn=mysql_connect($this->str_mysql[0],$this->str_mysql[1],$this->str_mysql[2]);
				if(!$this->conn)
				{
					$this->err="can't connect database";
					send_email2($mail_from, $mail_to, 'getAll_banner_mem[NLVN] error on function getAll_banner_memcache', $this->err);
					return null;
				}
				mysql_select_db("marketting",$this->conn);
				////////
				$result=mysql_query("select Id,channelId,channelName from channel where status=0");
				if(!$result)
				{
					$this->err=mysql_error();
					send_email2($mail_from, $mail_to, '(getAll_banner_mem)[NLVN] error on function getAll_banner_memcache', $this->err);
					return null;
				}
				$arr_banner=array();
				if(mysql_num_rows($result)>0)
				{
					while($row=mysql_fetch_array($result))
					{
						$arr_banner[$row['Id']]=array('channelId'=>$row['channelId'],'channelName'=>$row['channelName']);
					}
					$memcache->set("all_banner",serialize($arr_banner));
				}
				mysql_close($this->conn);
				return $arr_banner;
			}
		} 
		
	}
?>