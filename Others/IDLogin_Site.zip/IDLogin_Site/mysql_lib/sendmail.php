<?php
$message = "";
$today = date('Y-m-d H:i:s');
$mail_from  = "alert@idngoalong.zing.vn";
$mail_to    = "chucvv@vng.com.vn";
$mail_cc    = "chucvv@vng.com.vn";
//send_email2($mail_from, $mail_to, '[NLVN] Check app on facebook', $message);
function send_email2($mail_from, $mail_to, $title, $message)
{
    global $today, $mail_cc;
    $title .= " $today";
    $data = "<p>Now is $today</p>";
    $data .= "<p>There are some errors</p>";
    $data .= "<p>$message</p>";
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= 'From: NLVN Alert <alert@idngoalong.zing.vn>' . "\r\n";
    $headers .= 'Cc: '.$mail_cc. "\r\n";
    $result = mail($mail_to, $title, $data, $headers);
}
?>