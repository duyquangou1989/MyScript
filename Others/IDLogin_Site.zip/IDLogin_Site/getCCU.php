<?php
include "include/config-server.php";
include "include/common.php";
include "include/ccu.php";

for($i=count($servers); $i>=1; $i--) {
$ccu = getUserOnline($servers["s$i"]["private"],$servers["s$i"]["port"]);

/** Memcache: luu thong tin CCU each server **/
$mc = new Memcached();
$mc->addServer('172.16.9.52', 11211);
echo $mc->get("[s$i][cculocal]");
if($mc->get("[s$i][cculocal]")== 0) {
	echo 'Set'.$i.'-'.$ccu;
	//exit;
	$mc->set("[s$i][cculocal]",$ccu,0);}
else { 
	echo 'Add'.$i.'-'.$ccu;
	$mc->add("[s$i][cculocal]",$ccu,0);}
}
?>
