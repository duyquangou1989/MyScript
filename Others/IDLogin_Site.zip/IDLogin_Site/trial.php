<?php

session_start();
include_once "include/SSO/CXSSO.php";
include_once "include/SSO/SSO_Config.php";
include_once 'include/SSO/TransitionUtil.php';
include_once "include/config-server.php";
include_once "include/config-url.php";
include_once "include/common.php";


	// Tracking from Banner outside to IDLogin Site
	/*
	require_once 'include/config-banner.php';
	if(!empty($_GET["src_tr"]))
	{
		$tracking_code = strip_tags(addslashes(trim($_GET["src_tr"])));
		if(array_key_exists($tracking_code,$conf_tracking_banner)) 
		{
			$_SESSION['pkvn']['tracking_code'] = $tracking_code;
		}
	}
	*/
	//---------------------------------------------


$eventid = isset($_GET['eventid']) ?  $_GET['eventid'] : '';
$type = isset($_GET['type']) ?  $_GET['type'] : '';
$pid = isset($_GET['pid']) ?  $_GET['pid'] : '';
$bannerid = isset($_GET['bannerid']) ?  $_GET['bannerid'] : ''; 

// KIEM TRA XEM DA CO CHECKXLOGIN THANH CONG CHUA
if(!empty($_GET["sid"])){
		$sid_SSO3 = TransitionUtil::decode($_GET["sid"],PRIVATE_KEY);
		$vngSession = CXSSO::checkVNGSession($sid_SSO3);
		
		//echo $sid_SSO3;
		//print_r($vngSession);
		//die();
		if(!$vngSession){
			setcookie('session_info', '');	
			//return $this->showLoginForm();
		}else{
			setcookie('session_info',$sid_SSO3);
		}
}
//-----------------------------------------------

$sid = (!empty($sid_SSO3))? $sid_SSO3 : $_COOKIE['session_info'];
if(empty($sid))
{
	$sid_param = isset($_GET['sid']) ?  $_GET['sid'] : '';

	if($sid_param == '')
	{
		//die ("here");
		//echo "http://ssoapi.zing.vn/?method=checklogin_xdomain&aid=126&u=".$url['home'].'trial12.php'; exit();
		// ==================== CHOI NGAY ====================================================
		// GOI TU 1 DOMAIN .zing.vn den DOMAIN .com.vn se khong co sid cua passport. 
		// GOI ssoapi.zing.vn de lay sid tu passport
		$Redirect_URL = $url['home']."trial.php?".$_SERVER["QUERY_STRING"];
		//die($Redirect_URL);
		//echo $_SERVER["QUERY_STRING"];
		//exit;
		$URL_XSSO = "https://sso3.zing.vn/xchecklogin?apikey=".PUBLIC_KEY."&u=".urlencode($Redirect_URL);
		header("Location: $URL_XSSO");
		exit;
		// ==================== CHOI NGAY ====================================================
	}
	else
	{
		if($sid_param == 'none')
		{	
			//setcookie('session_info', '');
			//echo "exit do sid=none";exit;
			header("Location: ".$url['home']."index.php?".$_SERVER["QUERY_STRING"]);
			exit;
		}
		else
		{

			$vngSession = CXSSO::checkVNGSession($sid_param);
			$vngSessionArr = (array)$vngSession;
			
			if(!empty($vngSessionArr["accountName"]))
			{
			
				setcookie('session_info', $sid_param);
			}
			else
			{
				//echo "exit do ko dich dc session : ".$sid_param ;exit;
				header("Location: ".$url['home']."index.php?".$_SERVER["QUERY_STRING"]);
				exit;
			}
		}
	}
}
else
{
	if($sid == 'none')
	{	
		setcookie('session_info', '');
		header("Location: ".$url['home']."index.php?".$_SERVER["QUERY_STRING"]);
		exit;
	}
	else{
	
		$vngSession = CXSSO::checkVNGSession($sid);
		$vngSessionArr = (array)$vngSession;
		
	}	
}

if(empty($vngSessionArr["accountName"]))
{
	//setcookie('session_info', '');
	//echo " 123 exit do ko dich dc session : ".$sid_param ; exit;
	header("Location: ".$url['home']."index.php?".$_SERVER["QUERY_STRING"]);
	exit();
}



$userid = $vngSessionArr["uin"];
$serverNo = count($servers);
$newestServer = 0;


for($i=1 ; $i<=$serverNo; $i++ )
{
	if($servers["s$i"]["active"] == 1 )
	{
	//	echo $userid;
	//	echo "<br>";
	//	echo $servers["s$i"]["private"];
	//	echo "<br>";
	//	echo $servers["s$i"]["port"];
	//	echo "<br>";
		if(CheckUserInGame($userid,$servers["s$i"]["private"],$servers["s$i"]["port"]))
		{
			header("Location: ".$url['home']."servers.php?".$_SERVER["QUERY_STRING"]);
			exit;  
			return;
		}  
		$newestServer = "s$i";
	}
} 

/*
if($_SERVER["REMOTE_ADDR"]=='118.102.7.146'){
	echo "<pre>";
	print_r($vngSessionArr);
	echo "</pre>";
	echo "Lastest server: ".$newestServer;
	exit;
}
*/
//$newestServer ='s20';
//$newestServer ='s'.rand(13,15);
?>
<html>
	<head>
		<script type="text/javascript" src="http://img.zing.vn/phuckhoi/js/ga-phuckhoi-idlogin.js?version=1"></script>
	</head>
	<body></body>
</html>
<?php 
header('Location: game.php?server='.$servers["$newestServer"]["id"]."&".$_SERVER["QUERY_STRING"]);
exit; 
return;

function CheckUserInGame($uid,$ip,$port)
{
	$secret_key = 'phikiem123@/.,vngIebolah5sh'; // Không đươc thay đổi tùy tiện
	$sign = md5($uid.$secret_key.$ip.$port);
	$urljson = 'http://172.16.9.52/api/getuser.php?accountName='.$uid.'&serverip='.$ip.'&serverport='.$port.'&sig='.$sign;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $urljson);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
	$curlout= curl_exec($ch);
	curl_close($ch);
	$response = json_decode($curlout,true);
	
	/*
	if($_SERVER["REMOTE_ADDR"]=='118.102.7.146'){
		echo $sign;
		echo "Check User: <pre>";
		print_r($response);
		echo "</pre>";
	}
	*/
	if( $response['ErrorCode']== 0) return true;
	return false;
}


?>
