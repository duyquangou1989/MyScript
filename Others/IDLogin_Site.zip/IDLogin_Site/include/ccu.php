<?php
$ccu = array(
'1' => '351',
);

/*
#!/bin/sh
wget 10.30.68.10/ccu.php -O ccu.txt
ccu_file_tmp="/home/ltvn/public_html/include/ccu.tmp.php"
ccu_file="/home/ltvn/public_html/include/ccu.php"
echo -e "<?php\n\$ccu = array(\n" >> $ccu_file_tmp
while read line; do
    serverID=$(echo $line | awk '{ print $4 }')
    ccu=$(echo $line | awk '{ print $3 }')    
    echo -e "'$serverID' => '$ccu'," >> $ccu_file_tmp
done < ccu.txt
echo ");" >> $ccu_file_tmp
rm -rf $ccu_file
mv $ccu_file_tmp $ccu_file
chown ltvn.ltvn $ccu_file
rsync -av --stats --delete /home/ltvn/public_html/include/ 10.30.68.3:/home/ltvn/public_html/include/
*/
