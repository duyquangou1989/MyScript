<?php
/* this class provide functions to write log fo file */

class Logging {
    private $log_file = '/var/log/pkvn/username.bannerid';
    private $nl = "\n";
    private $fp = null;

    public function lfile($path) {
        $this->log_file = $path;
    }

    public function lwrite($message) {
        if (!$this->fp) {
            $this->lopen();
        }
        fwrite($this->fp, "$message". $this->nl);
    }

    public function lclose() {
        fclose($this->fp);
    }

    private function lopen() {
        $lfile = $this->log_file;
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $this->nl = "\r\n";
        }
        $today = date('Y-m-d');
        $this->fp = fopen($lfile . '_' . $today .'.csv', 'a') or exit("Can't open $lfile!");
    }
}

