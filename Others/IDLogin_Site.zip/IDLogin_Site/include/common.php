<?php
function check_login_vng($src) //check login for xcross
{
	global $url;

	if($src=='zingme')
	{
		header("location: https://sso3.zing.vn/xchecklogin?apikey=".PUBLIC_KEY."&u=".$url["home"]."zm/servers.php");
		exit;
	}
	else
	{
		header("location: https://sso3.zing.vn/xchecklogin?apikey=".PUBLIC_KEY."&u=".$url["home"]);
		exit;
	}
}
function check_login()
{

	$sid = isset($_GET['sid']) ?  $_GET['sid'] : '';
	if(empty($sid) || $sid=='none')
	{
		if($_COOKIE["session_info"]=="")
		{
			return false;
		}
		$sid=$_COOKIE["session_info"];
	}
	if($sid != 'none')
	{
		setcookie('session_info',$sid);	
	}
	else
	{
		setcookie('session_info', '');
		return false;
	}

	$sid = TransitionUtil::decode($sid,PRIVATE_KEY);
	$vngSession = CXSSO::checkVNGSession($sid); 

	if (empty($vngSession) OR empty($vngSession->accountName) OR empty($vngSession->uin)) 
	{
		return false;   
	}

	if (!isset($_SESSION['pkvn']['accname'])) 
	{
		session_regenerate_id();
	}

	$_SESSION['pkvn']['accname'] = strip_tags(strtolower($vngSession->accountName));
	$_SESSION['pkvn']['accid']   = intval($vngSession->uin);
	$_SESSION['pkvn']['hostname']= $vngSession->hostname;
	return true;
}

function getUserOnline($ip,$port){
include "secret.php";
$sig = md5($skey.$ip.$port);
$url = 'http://172.16.9.52/api/getuseronline.php?serverip='.$ip.'&serverport='.$port.'&sig='.$sig;
//echo $url;
//exit;

$h = curl_init();
curl_setopt($h, CURLOPT_URL, $url);
curl_setopt($h, CURLOPT_RETURNTRANSFER, 1);
//curl_setopt($h, CURLOPT_HEADER, 0);
curl_setopt($h,CURLOPT_CONNECTTIMEOUT, 4);
$ret = curl_exec($h);
if(!$ret) {
    echo curl_error($h);
}
curl_close($h);

//$data = $ret;
//$data = json_decode($ret, true);

//$ret = file_get_contents('$url');
//echo $ret;

//var_dump($ret);
//print_r(json_decode($ret)->Online);
return json_decode($ret)->Online;
}

function showStatusAuto($CCU){
    $CCU = (int)$CCU;
	$str='';
    if($CCU <= 1000){
        $str = '<span class="Tot">(Tốt)</span>';
    } elseif ($CCU <= 1500) {
        $str = '<span class="GanDay">(Gần đầy)</span>';
    } else {
        $str = '<span class="Day">(Đầy)</span>';
    }
	return $str;
}

function showStatusManual($status) {
    switch ($status) {
        case '0':                            
            echo '<span class="Tot">(Tốt)</span></a></li>';
            break;
        case '1':
            echo '<span class="GanDay">(Gần đầy)</span></a></li>';
            break;
        case '2':
            echo '<span class="Day">(Đầy)</span></a></li>';
            break;
    }
}

function connectMySQL() {
    include "secret.php";
    $conn = mysql_connect($mysql["host"], $mysql["user"], $mysql["password"]) or die(mysql_error());
    return mysql_select_db($mysql["db"], $conn);
}

function connectMySQL1($host,$db) {
    include "secret.php";
    $conn = mysql_connect($host, $mysql["user"], $mysql["password"]) or die(mysql_error());
    return mysql_select_db($db, $conn);
}

function countBanner($bannerid) {
    connectMySQL();
    $bannerid = cleanQuery($bannerid);
    $get_counter = mysql_query("select access_count from banner_id where banner_id=".intval($bannerid)."");
    $counter = mysql_fetch_array($get_counter);
    $counter = $counter['access_count'];
    $counter = $counter + 1;
    mysql_query("update banner_id set access_count=".$counter." where banner_id=".intval($bannerid)."");
}

/** http://www.tech-evangelist.com/2007/11/05/preventing-sql-injection-attack/ **/
function cleanQuery($string) {
    if(get_magic_quotes_gpc()) { // prevents duplicate backslashes
        $string = stripslashes($string);
    }
    if (phpversion() >= '4.3.0') {
        $string = mysql_real_escape_string($string);
    } else {
        $string = mysql_escape_string($string);
    }
    return $string;
}

function getTopUser($serverid) {
   if($serverid = 1) {
	connectMySQL('172.16.9.51','asss_s1');
   }
}

function stripUnicode($str){
  if(!$str) return false;
   $unicode = array(
      'a'=>'á|à|ả|ã|ạ|ă|ắ|ặ|ằ|ẳ|ẵ|â|ấ|ầ|ẩ|ẫ|ậ',
      'd'=>'đ',
      'e'=>'é|è|ẻ|ẽ|ẹ|ê|ế|ề|ể|ễ|ệ',
      'i'=>'í|ì|ỉ|ĩ|ị',
      'o'=>'ó|ò|ỏ|õ|ọ|ô|ố|ồ|ổ|ỗ|ộ|ơ|ớ|ờ|ở|ỡ|ợ',
      'u'=>'ú|ù|ủ|ũ|ụ|ư|ứ|ừ|ử|ữ|ự',
      'y'=>'ý|ỳ|ỷ|ỹ|ỵ',
   );
foreach($unicode as $nonUnicode=>$uni) $str = preg_replace("/($uni)/i",$nonUnicode,$str);
return $str;
}


function CheckUserExistInGame($uid,$ip,$port)
{
	$secret_key = 'phikiem123@/.,vngIebolah5sh'; // Không đươc thay đổi tùy tiện
	$sign = md5($uid.$secret_key.$ip.$port);
	$urljson = 'http://172.16.9.52/api/getuser.php?accountName='.$uid.'&serverip='.$ip.'&serverport='.$port.'&sig='.$sign;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $urljson);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
	$curlout= curl_exec($ch);
	curl_close($ch);
	$response = json_decode($curlout,true);
	if( $response['ErrorCode']== 0) return true;
	return false;
}
//Check login MAS

function sendMas($username,$serverid,$flag){
	$opts = array(
		'http' => array(
		'timeout' => "30",
		)
	);
	$context  = stream_context_create($opts);
	if (!isset($_COOKIE["MAS_AID"]) || !isset($_COOKIE["MAS_CID"]) || !isset($_COOKIE["MAS_BID"]) || $_COOKIE["MAS_GC"] != 'pk.net.vn'){
		return;
	}
	else{
		$x = 'flag='.$flag.'&server='.$serverid.'&un='.$username.'&a='.$_COOKIE["MAS_AID"].'&c='.$_COOKIE["MAS_CID"].'&b='.$_COOKIE["MAS_BID"];
		$url = "http://10.30.88.3/pkvn/get.php?$x";
		file_get_contents($url,false,$context);
		return;
	}
}
 	
?>
