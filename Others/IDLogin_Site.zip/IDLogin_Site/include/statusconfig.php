<?php 
define('FULL',1500);
define('AVERAGE',1000);
?>
