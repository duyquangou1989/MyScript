<?php

/**
 * Copyright 2011 ZingMe
 * 
 */
class ZME_Me extends BaseZingMe {

	
	private $info_path = "me/@%s";
	private $friends_path = "me/friends/@%s";

	public function __construct($config) {
		parent::__construct($config);
	}

	/**
	 * Get profile info of user logged in with access_token
	 *
	 * @param type $access_token
	 * @param type $fields . Fields can be 'id','username','displayname','tinyurl','profile_url','gender','dob'
	 * @return user info of user with access token
	 */
	public function getInfo($access_token, $fields='') {
		$path = sprintf($this->info_path, $this->appname);

		$params = array();
		$params['access_token'] = $access_token;
		if (!empty($fields))
			$params['fields'] = $fields;

		$url = $this->getUrl("graph", $path, $params);

		$data = $this->sendRequest($url);
		return $data;
	}

	/**
	 * Get friends list of user logged in with access_token
	 *
	 * @param type $access_token
	 * 
	 * @return list of friend id
	 */
	public function getFriends($access_token) {
		$path = sprintf($this->friends_path, $this->appname);
		$params = array();
		$params['access_token'] = $access_token;
		if (!empty($fields))
			$params['fields'] = $fields;

		$url = $this->getUrl("graph", $path, $params);
		$data = $this->sendRequest($url);
		return $data;
	}

}

?>
