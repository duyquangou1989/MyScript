<?php
//define('AGENT','');
//define('PREFIX','');

$mysql = array(
    "host" => "localhost",
    "user" => "idpage",
    "password" => "idpage1@",
    "db" => "alphabeta",
);

$skey = 'phikiem123@/.,vngIebolah5sh';
?>
