<?php
$conf_tracking_banner =
array
(
	'shc'=> array('title'=>'Shortcut','url'=>''),
	'lbl'=> array('title'=>'La Ban Link','url'=>'http://www.laban.vn'),
	'bra'=> array('title'=>'Brand 3','url'=>''),
	'acp'=> array('title'=>'Active page','url'=>''),	
	'csm'=> array('title'=>'Active Page CSM','url'=>''),
);

$conf_memcache = array('172.16.9.21', 11211);
$conf_mysql	   = array('172.16.9.21','pkvn','123456!@#$%^','vng_guest_login');
?>