<?php
//config
//define('VNG_SESSION_HOST','10.30.17.213');	// ip vng session, passport cung cap local
define('VNG_SESSION_HOST','10.30.8.202');	// ip vng session, passport cung cap real

define('VNG_SESSION_PORT','9090'); //port vng session, passport cung cap

//define('URL_LOGOUT','http://ssolocal.zing.vn/?method=logout&return=');//dev
//define('URL_LOGOUT','http://sso2.zing.vn/?method=logout&return=');//real	

define('URL_LOGOUT','https://sso3.zing.vn/logout?return=');//dev

//define('URL_RETURN_LOGOUT','http://ssostaging.zing.vn/ssostaging/login.php');//return logout url
define('URL_RETURN_LOGOUT','https://sso3.zing.vn/xchecklogin?apikey=94cbfd79768b4a0bb2b48a5bffb72ce0&u=http://id.pk.net.vn');//return logout url

//define('URL_VNG_SSO','http://ssolocal.zing.vn/index.php');//dev
//define('URL_VNG_SSO','https://sso2.zing.vn/index.php');//real	


define('URL_VNG_SSO','https://sso3.zing.vn/');//dev
define('PRIVATE_KEY','b22037948a9141a4af41fe534cac5dcc');
define('PUBLIC_KEY','94cbfd79768b4a0bb2b48a5bffb72ce0');
	
?>
