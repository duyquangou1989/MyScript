<?php
include 'CSSO.php';
include_once 'SSO_Config.php';

class Login{
	var $cookies = "";
	var $return_login_fail_url = "";
	var $return_login_success_url = "";
	var $return_logout_url = "";
	var $product_id = "";
	var $error_message = "";
	function Login(){
		$this->cookies = CSSO::getCookies(); //Lấy cookies tại client	
		$this->return_login_fail_url = "http://idlocal.pk.net.vn"; //Trở về trang này khi login không thành công
		$this->return_login_success_url = "http://idlocal.pk.net.vn";	//Trở về trang này khi login thành công
		$this->return_logout_url = "http://idlocal.pk.net.vn"; //Trở về trang này sau khi logout	
		$this->product_id = 118;//Mã sản phẩm hiện tại, passport đã cung cấp trước đây
		
		//check return code
		$mess = isset($_GET['mess']) ?  $_GET['mess'] : '';
		$err = isset($_GET['err']) ?  $_GET['err'] : '';
		if($mess == 'succ')
		{
			$this->error_message = "";
		}else{
			switch($err)
			{
				case '2001':
					$this->error_message = "Tên đăng nhập hoặc mật khẩu không đúng";
					break;
				case '1001':
					$this->error_message = "Lỗi tạo VNG session";
					break;
				case '1003':
					$this->error_message = "Lỗi service PP";
					break;
			}
		}
	}
	/**
	Check Login
	Giá trị trả về của vngSession:
		[session] => FwSession_Session Object
        (
            [createTime] => 0
            [lastAccess] => 0
            [uin] => 0 //PP id
            [zin] => 0//not use at this time
            [accountName] => //zing nick
            [hostname] => //host of client
            [useragent] => //IP
        )
	**/
	function checkLogin(){		
		$vngSession = CSSO::checkVNGSession($this->cookies);
		if($vngSession){
		    header("Location: http://idpk.net.vn/servers.php");
		}
	}
	
	/**
	Login form:
		Method: POST
		Action: http://sso2.zing.vn/index.php?method=login
		u : UserName(4-24 char)
		p : Password(6-32char)
		longtime : check/uncheck (cho phép ghi nhớ đăng nhập/ hoặc không)
		u1: return url khi login thành công.
		fp : return url khi login không thành công.
		pid : ProductID của sản phâm (passport cung cấp khi có product mới).
	**/	
	function showLoginForm(){
		$html = '
			<form target="_top" method="post" name="frmLogin" id="frmLogin" action="'.URL_VNG_SSO.'?method=login">
		          <div class="frm_dangnhap">
		            <div class="username">
		              <input type="text" class="" value="Tài khoản" id="username" name="u">
		            </div>
		            <div class="password">
		              <input type="password" class="" value="Password" id="password" name="p">
		            </div>
		          </div>
			  <input type="hidden" name="u1" value="'.$this->return_login_success_url.'" />
	                  <input type="hidden" name="fp" value="'.$this->return_login_fail_url.'" />
	                  <input type="hidden" name="pid" value="'.$this->product_id.'" />
		          <input type="submit" value="Chơi ngay" class="ChoiNgay" >
		        </form>';
		echo $html;
	}
	
	function logout(){
		return CSSO::logout($this->return_url_logout);
	}
}
?>

