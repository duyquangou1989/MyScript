<?php

include 'CXSSO.php';
include_once 'SSO_Config.php';	
include 'TransitionUtil.php';

class XLogin{

	var $x ="";
	var $return_check_url = "";
	var $return_login_fail_url = "";
	var $return_login_success_url = "";
	var $return_logout_url = "";
	var $return_after_login_success = "";
	var $product_id = "";
	var $error_message='';
	var $env = '';
	var $url =  array();
	
	function XLogin($checklogin){		
		include "include/config-url.php";
		$this->url = $url;
		//var_dump($_SERVER["HTTP_REFERER"]); exit();
		/*if(!empty($_SERVER["HTTP_REFERER"])){
	
			$this->return_login_success_url = $url['home'].'?zm=1';	//Trở về trang này khi login thành công		
		}
		else{*/
			$this->return_login_success_url = $url['home'];	//Trở về trang này khi login thành công
			//$this->return_after_login_success = $url['server'];
		
		$this->return_after_login_success = $url['server'];
		
		
		$this->return_login_fail_url = $url['home'];
		$this->return_check_url = $url['home'];//Trở về trang này sau khi logout	
		$this->return_logout_url = $url['home'];//Trở về trang này sau khi logout	
		$this->product_id = 118;//Mã sản phẩm hiện tại, passport đã cung cấp trước đây
		$this->env = $env;
		//echo '<a href=""http://id".$this->env.".pk.net.vn""> Vào trang login</a><br/>';
		//echo $this->showLoginButton();
		
		
		
		if ($checklogin) $this->checkLocalLogin();
	}
	function checkLocalLogin(){
		
		$sid = isset($_GET['sid']) ?  $_GET['sid'] : '';
		$mess = isset($_GET['mess']) ?  $_GET['mess'] : '';
		$err = isset($_GET['err']) ?  $_GET['err'] : '';
		
		if(!empty($sid) && $sid != 'none')
		{	
			$sid = TransitionUtil::decode($sid,PRIVATE_KEY);
			$this->getLoginInfo($sid);
		}
		else
		{
			if($sid == 'none')
			{
				$localSS = $_COOKIE['session_info'];
				if($localSS != NULL && !empty($localSS))
				{
					$this->getLoginInfo($sid);
				}
			}		
			else
			{
				if($mess != 'succ' && !empty($err))
				{
					$this->error_message = 'Tên đăng nhập hay mật khẩu không đúng';
				}else{
					$this->error_message = '';
				}
				setcookie('session_info', '');
				
				// Kiem tra REQUEST_URI
				if(!empty($_SERVER["REQUEST_URI"])){
					$Redirect_URL = $this->url['home'].$_SERVER["REQUEST_URI"];
				}else{
					$Redirect_URL = $this->url['home'];
				}	
				// --------------------
				header("Location: https://sso3.zing.vn/xchecklogin?apikey=94cbfd79768b4a0bb2b48a5bffb72ce0&u=".urlencode($Redirect_URL));
				exit;
				
				//return $this->showLoginForm();
			}
		}		
		
		
		/*$localSS = $_COOKIE['session_info'];
		//echo $localSS ; exit();
		if($localSS != NULL && !empty($localSS))
		{
			$this->getLoginInfo($localSS);
		}else{

			$sid = isset($_GET['sid']) ?  $_GET['sid'] : '';
			$mess = isset($_GET['mess']) ?  $_GET['mess'] : '';
			$err = isset($_GET['err']) ?  $_GET['err'] : '';
			if(empty($sid))
			{
				header("Location: http://ssoapi.zing.vn/?method=checklogin_xdomain&aid=126&u=http://idlocal.pk.net.vn/cb02/");
			}
			if(!empty($sid) && $sid != 'none')
			{	
				
				$this->getLoginInfo($sid);
			}else{
				
				if($mess != 'succ' && !empty($err))
				{
					$this->error_message = 'Tên đăng nhập hay mật khẩu không đúng';
				}else{
					$this->error_message = '';
				}
				setcookie('session_info', '');
				//return $this->showLoginForm();
			}
		}*/
	}
	function getLoginInfo($sid)
	{
		
		$vngSession = CXSSO::checkVNGSession($sid);
			//echo '<pre>';
			//print_r($vngSession);
			//exit;

		if(!$vngSession){
			setcookie('session_info', '');	
			//return $this->showLoginForm();
		}else{
			
			setcookie('session_info',$sid);
			if(!empty($_GET['zm']))
			{				
				$this->return_after_login_success = "http://me.zing.vn/apps/phuckhoi";
			}	

/*
if($_SERVER['REMOTE_ADDR']=='118.102.7.146')
{
	echo '<pre>';
	print_r($vngSession);
	echo "<br>SID: ".$sid;
	echo "<br>URL: ".$this->return_after_login_success;
	echo "<br>";
	echo $_COOKIE['session_info'];
	exit;
	die('111');
}			
*/		
			header("Location: ".$this->return_after_login_success);		
			/*
			echo 'Thông tin session trả về<br/><pre>';
			print_r($vngSession);
			echo '</pre>';
			echo '<a href="xdomain_logout.php">Thoát</a>';
			*/
			exit;
		}
	}
	function print_var($value, $exit = true)
	{
		echo '<pre>';
		print_r($value);
		if($exit)exit;
	}	
	/**
	Login form:
		Method: POST
		Action: http://sso2.zing.vn/index.php?method=login
		u : UserName(4-24 char)
		p : Password(6-32char)
		longtime : check/uncheck (cho phép ghi nhớ đăng nhập/ hoặc không)
		u1: return url khi login thành công.
		fp : return url khi login không thành công.
		pid : ProductID của sản phâm (passport cung cấp khi có product mới).
	**/	
	function showLoginForm(){
		$html = '
				 <form onsubmit="_gaq.push([\'_trackEvent\', \'Form dang nhap\', \'Link\', \'IDLogin\']);" target="_top" method="post" name="frmDN" id="frmDN" action="'.URL_VNG_SSO.'xlogin" method="post">
					<fieldset>
                    <div class="BoxInput">
                        <label>Tài khoản</label>
							<input type="text" name="u" id="username" value=""  title="Tài khoản Zing"/>
							<label>Mật khẩu</label>
							<input type="password" name="p" id="password" value="Mật khẩu" />
                    </div>
                    
					<div class="BoxRight">
							<input type="submit" name="textfield2" value="Đăng nhập" class="Send" title="Đăng nhập"/>
							<a href="https://id.zing.vn/forgotinfo/index.118.html" title="Quên mật khẩu" class="PassWord" target="_blank" onclick="_gaq.push([\'_trackEvent\',\'Quen mat khau\', \'Link\', \'IDLogin\']);">Quên mật khẩu</a> </div>
                
					</fieldset>
					
					<input type="hidden" name="u1" value="'.$this->return_login_success_url.'" />
					<input type="hidden" name="fp" value="'.$this->return_login_fail_url.'" />
					<input type="hidden" name="pid" value="'.$this->product_id.'" />  
					<input type="hidden" name="apikey" value="'.PUBLIC_KEY.'" />
					</form>';
		echo $html;
		//exit;
	}

	/**
		
	**/
	function logout(){
		setcookie('session_info', '');
		return CXSSO::logout($this->return_url_logout);
	}
	
}

?>
