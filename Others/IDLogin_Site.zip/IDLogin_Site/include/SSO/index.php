<?php
header("Location: http://idlocal.pk.net.vn");
