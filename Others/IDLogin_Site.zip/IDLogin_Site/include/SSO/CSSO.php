<?php
include 'SSO_Config.php';
include 'SSO_Cookies.php';
include 'SSO_GetIP.php';
include 'SSO_Session.php';
include 'thriftlib/Thrift.php';
include 'thriftlib/protocol/TBinaryProtocol.php';
include 'thriftlib/transport/TSocket.php';
include 'thriftlib/transport/THttpClient.php';
include 'thriftlib/transport/TFramedTransport.php';
include 'thriftlib/packages/sms/sms_types.php';
include 'thriftlib/packages/sms/SessionServiceRead.php';
//include 'thriftlib/packages/sms/SessionServiceWrite.php';
class CSSO{
	function CSSO(){}
	/**
	 * get cookie from client
	 *
	 */
	public static function getCookies(){
		return array(
			'vngauth' => Cookies::getCookie('vngauth'),
			'uin' => Cookies::getCookie('uin'),
			'skey' => Cookies::getCookie('skey'),
			'acn' => Cookies::getCookie('acn'),
		);		
	}	
	/**
	 * check logged-in status from VNG SSO server
	 *
	 * @param array $cookies
	 * @param string $host
	 * @param string $port
	 */
	public static function checkVNGSession($cookies="",$host=VNG_SESSION_HOST,$port=VNG_SESSION_PORT){
		if($cookies['vngauth'] && $cookies['uin']){
			$obj = new Session(array('host'=>$host, "port"=>$port));
			$useragent = strtoupper(md5($_SERVER['HTTP_USER_AGENT']));
			$ipAddress = getRealIp();
			$result = $obj->read($cookies['vngauth']);			
			if($result->resultCode == 0){
				//Please uncomment when you deploying to live environment
				/*if($result->session->hostname != $ipAddress){
					CSSO::clearCookies();
					return false;
				}*/
				if($result->session->useragent != $useragent){
					CSSO::clearCookies();
					return false;
				}
				if($cookies['uin'] != 'o'.CSSO::converAccountCode($result->session->uin))
				{
					CSSO::clearCookies();
					return false;
				}
				return $result->session;
			}	
		}
		CSSO::clearCookies();
		return false;
	}		
	/**
	 * logout
	 *
	 * @param string $return_url
	 */
	public static function logout($return_url=URL_RETURN_LOGOUT){
		header("Location: ".URL_LOGOUT.$return_url);
		exit;
	}
	public static function converAccountCode($passportID=''){
		$passportID = trim($passportID);
		if(strlen($passportID) == 10)
			return $passportID;
		$numZero = 9-strlen($passportID);
		$tmp = '0';
		for($i=0;$i<$numZero;$i++){
			$tmp.='0';
		}				
		$passportID = $tmp.$passportID;
		if(strlen($passportID) == 10)
			return $passportID;
		return 0;
	}
	public static function clearCookies()
	{
		try{
			header('P3P: CP="NOI ADM DEV PSAi COM NAV OUR OTRo STP IND DEM"');
			setcookie('vngauth', 'deleted', time()-365*24*3600, '/', 'zing.vn');
			setcookie('uin', 'deleted', time()-365*24*3600, '/', 'zing.vn');
			setcookie('skey', 'deleted', time()-365*24*3600, '/', 'zing.vn');
			setcookie('acn', 'deleted', time()-365*24*3600, '/', 'zing.vn');
			setcookie('acs', 'deleted', time()-365*24*3600, '/', 'zing.vn');
			setcookie('ZAUTH', 'deleted', time()-365*24*3600, '/', 'zing.vn');
			setcookie('ZMES', 'deleted', time()-365*24*3600, '/', 'zing.vn');
		}catch(Exception $e)
		{
		}
	}
}
?>
