<?php
echo "tesst"; exit();
$env = 'local';
$url = array( 
"home" => "http://id".$env.".pk.net.vn/",
"server" => "http://id".$env.".pk.net.vn/servers.php",
"game" => "http://id".$env.".pk.net.vn//game.php",
"gamezm" => "http://id".$env.".pk.net.vn/gamezm.php",
"zm" => "http://dev.me.zing.vn/apps/phuckhoilocal",
);
?>
