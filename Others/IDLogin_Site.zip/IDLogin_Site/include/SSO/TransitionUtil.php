<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TransitionUtil
 *
 * @author nghiadc
 */
class TransitionUtil {

	//put your code here
	public static function encode($source, $key) {
		if (!empty($source) && !empty($key)) {
			$vals = self::xorKey(self::stringToByte($source), self::stringToByte($key));
			$vals =self::addNoise($vals, rand());
			$strbyte = self::byteToString($vals);
			$rs = self::encodeBase64UrlSafe($strbyte);
			return  $rs;
		}
		return null;
	}

	public static function decode($hashed, $key) {
		$base64_decode = self::decodeBase64UrlSafe($hashed);
		$vals = self::stringToByte($base64_decode);
		if (!empty($vals) && !empty($key)) {
			$vals = self::removeNoise($vals);
			$vals = self::xorKey($vals, self::stringToByte($key));
			return self::byteToString($vals);
		}
		return null;
	}

	private static function addNoise($bytes, $val) {
		$vals = unpack("C*", pack("i", $val));
		$i = 0;
		$len = count($bytes);
		$ret = array();
		while ($i < $len) {
			$ret[$i] = ($bytes[$i] ^ $vals[$i % 4]);
			$i++;
		}
		$k = 0;
		for (; $i < $len + 4; $i++) {
			$ret[$i] = $vals[$k++];
		}
		return $ret;
	}

	private static function xorKey($bytes, $keys) {
		$ret = array();
		$len = count($bytes);
		$keylen = count($keys);
		for ($i = 0; $i < $len; $i++) {
			$ret[$i] = ($bytes[$i] ^ $keys[$i % $keylen]);
		}
		return $ret;
	}

	private static function removeNoise($bytes) {
		$ret = array();
		$vals = array();
		$len = count($bytes) - 4;
		for ($i = 0; $i < 4; $i++) {
			$vals[$i] = $bytes[$i + $len];
		}
		for ($i = 0; $i < $len; $i++) {
			$ret[$i] = ($bytes[$i] ^ $vals[$i % 4]);
		}
		return $ret;
	}

	private static function stringToByte($string) {
		$data = array();
		for ($i = 0; $i < strlen($string); $i++) {
			$data[$i] = ord($string[$i]);
		}
		return $data;
	}

	private static function byteToString($data) {
		$string = "";
		for ($i = 0; $i < count($data); $i++) {
			$string.= chr($data[$i]);
		}
		return $string;
	}

	private static function encodeBase64UrlSafe($value) {
		return str_replace(array('+', '/'), array('-', '_'), base64_encode($value));
	}

	private static function decodeBase64UrlSafe($value) {
		return base64_decode(str_replace(array('-', '_'), array('+', '/'), $value));
	}
}
?>