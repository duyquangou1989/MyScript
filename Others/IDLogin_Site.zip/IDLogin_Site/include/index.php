<?php
    session_start();
    /* For inspection */
    #if($_SERVER['HTTP_REFERER'] == '') {
    #	header("Location: http://idlocal.pk.net.vn");
    #}
    /**/
    include_once("include/SSO/xdomain_login.php");
    
    /** Get banner id included in query string **/
    /** Request came from idpk set default bannerid is 27 **/
     
    $queryStr = $_SERVER['QUERY_STRING'];
    if(!isset($_SESSION['bannerid'])) {
        if(preg_match("/bannerid/", $queryStr)) {
            $_SESSION['bannerid'] = $_GET['bannerid'];
        } elseif(preg_match("/banner/", $queryStr)) {
            $piece = explode(".", $queryStr);
            $_SESSION['bannerid'] = $piece[2];
        }
    }
    
    /** Check login **/
    $XLogin = new XLogin();
    //$XLogin->XCheckLogin();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="shortcut icon" href="http://img.zing.vn/phuckhoi/skin/phuckhoi-072012/images/favicon.ico" type="image/x-icon"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Phục Khởi</title>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="robots" content="index,follow" />
<link href="http://img.zing.vn/eventgame/intro/general/css/mainsite.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="css/style.css" />
<link href="css/jselect/jselect.css" rel="stylesheet" />
<link href="css/jselect/jselect-theme.css" rel="stylesheet" />
<link href="css/j-navigation-left.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="http://img.zing.vn/eventgame/intro/general/js/mainsite.js"></script>
<!--[if IE 6]>
<script src="js/DD_belatedPNG_0.0.8a.js"></script>
<script>  
 	DD_belatedPNG.fix('#wrapper .ShortLink li a,.Login form input,.Login form input.ChoiNgay,.Server h2,ul#tabHeader li a,ul.ServerHot, ul.ServerHot li a,ul.ListServer li a,ul.ListServer li.Hot a,ul.ListServer li.New a,ul.BoxButton li a.ImgHuongDan1,ul.BoxButton li a.ImgHuongDan2, ul.BoxButton li a.ImgHuongDan3,ul.BoxButton li a.ImgHuongDan4, ul.BoxButtonServer li a.ImgHuongDan1,ul.BoxButtonServer li a.ImgHuongDan2, ul.BoxButtonServer li a.ImgHuongDan3, ul.BoxButtonServer li a.ImgHuongDan4', .Login h2, a.CloseBtn, a.CloseBtnBot);
</script>
<![endif]-->
<script type="text/javascript" src="js/popup.js"></script>
<script type="text/javascript" src="js/jselect/jselect.js"></script>
<script type="text/javascript" src="js/jselect/jselect.external.js"></script>
<script type="text/javascript" src="js/carousel.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script type="text/javascript" src="http://img.zing.vn/eventgame/intro/general/js/track-idlogin/gt-analytic-idphuckhoi.js"></script>
<script type="text/javascript" src="http://img.zing.vn/phuckhoi/js/ga-phuckhoi-idlogin.js"></script> 
<style type="text/css">
#linkgame {
	position: absolute;
	top: 0;
	left: 20px;
	width: 100%;
	height: 100%;
	border: none;
	box-sizing: border-box;
	-moz-box-sizing: border-box;
	-webkit-box-sizing: border-box;
}
#linkgamebot {
	position: absolute;
	bottom: 200px;
	left: 0;
	width: 100%;
	height: 100%;
	border: none;
	box-sizing: border-box;
	-moz-box-sizing: border-box;
	-webkit-box-sizing: border-box;
}
</style>
</head>

<body>
<div id="wrapper" class="IDLogin">
<div id="idLogin">
        <ul class="MenuTop">
          <li><a href="http://pk.net.vn/index.html" class="TrangChuID" onclick="_gaq.push(['_trackEvent', 'Trang chu', 'Link', 'IDLogin']);" target="_blank" title="Trang chủ">Trang chủ</a></li>
          <li><a href="https://pay.zing.vn/zingxu/napthe.pkvn.html" class="NapTheID" onclick="_gaq.push(['_trackEvent', 'Nap the', 'Link', 'IDLogin']);" target="_blank" title="Nạp thẻ">Nạp thẻ</a></li>
          <li><a href="http://diendan.zing.vn/forumdisplay.php/3023-Phuc-Khoi.html" class="DienDanID" onclick="_gaq.push(['_trackEvent', 'Dien dan', 'Link', 'IDLogin']);" target="_blank" title="Diễn đàn">Diễn đàn</a></li>
          <li><a href="#" class="MayChuID" onclick="_gaq.push(['_trackEvent', 'MayChu', 'Link', 'IDLogin']);" title="MayChu">Máy chủ</a></li>
        </ul>
        <div class="Login">
          <h2 class="Title_DangNhap">Đăng Nhập</h2>
		  <?php $XLogin->showLoginForm(); ?>
		  <!--
          <form target="_top" method="post" name="frmLogin" id="frmLogin" action="https://app.zing.vn/auth/index.php/login/auth">
            <div class="frm_dangnhap">
              <div class="username">
                <input type="text" class="" value="Tài khoản Zing ID" id="username" name="username"/>
              </div>
              <div class="password">
                <input type="password" class="" value="Password" id="password" name="password"/>
              </div> 
            </div>
            <input type="submit" value="Chơi ngay" class="ChoiNgay" />
          </form>
		  -->
        </div>
		<?php
			/*	if(isset($_GET['err']) && $_GET['err']==2001){
					echo '
							<p> [ Tài khoản hoặc mật khẩu không đúng. Xin vui lòng đăng nhập lại ]</p>
						 ';
				}
			*/	
		?>
        <a href="#" title="Quên mật khẩu" class="ForgotPassword">Quên mật khẩu</a> <a class="DangKyNhanh" href="https://id.zing.vn/quickregister/game/index.109.html?reg_embed=true" onclick="_gaq.push(['_trackEvent', 'Dang ky nhanh', 'Button Image', 'IDLogin']);" rel="" title="Đăng ký nhanh" >Đăng ký nhanh</a>
        <div class="BannerEvent">
          <iframe scrolling="no" marginheight="0" marginwidth="0" height="170" frameborder="0" width="540" src="http://launcher.game.zing.vn/PKVN/idnews.html"></iframe>
        </div>
      </div>
      
      <div class="WrapperBottom" id="sideBarBot">
      	<div> <a href="javascript:void(0);" title="Đóng" id="togglebot" class="CloseBtnBot">Đóng / Mở</a> </div>
      	<div class="BottomContent">          
          <iframe scrolling="no" marginheight="0" marginwidth="0" height="173" frameborder="0" width="750" src="http://launcher.game.zing.vn/PKVN/footer.html"></iframe>
          </div>
    </div>
    
    <div id="sideBar">
    <div  class="WrapperSideBar">
      <h1><a href="#" title="Trở về trang chủ Phục Khởi"><img src="images/logo.gif" width="200" height="120" alt="Phục Khởi" /></a></h1>
      <a href="javascript:void(0);" title="Đóng" id="toggle" class="CloseBtn">Đóng / Mở</a>
      <p class="Text"	>Máy chủ đang chơi:</p>
      <p class="ServerCurrent">Mãnh Long</p>
      <select class="SelectUI Theme_GP Theme_Human "  id="Server" name="" title="Máy chủ đã chọn" >
        <option value="Value 1">Máy chủ 1</option>
        <option value="Value 2">Máy chủ 2</option>
        <option value="Value 3">Máy chủ 3</option>
      </select>
      <iframe scrolling="no" marginheight="0" marginwidth="0" height="600" frameborder="0" width="198" src="http://launcher.game.zing.vn/PKVN/leftMenu.html"></iframe>
    </div>
  </div>
</div>   

</body>

</html>
