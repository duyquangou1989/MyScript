<?php
$env = '';
$url = array( 
"home" => "http://id".$env.".pk.net.vn/",
"server" => "http://id".$env.".pk.net.vn/servers.php",
"game" => "http://id".$env.".pk.net.vn/game.php",
//"gamezm" => "http://id".$env.".pk.net.vn/gamezm.php",
//"zm" => "http://dev.me.zing.vn/apps/phuckhoilocal",
);

if($env == 'local')
{
	$config_appzm = array(
		'appname' => 'phuckhoilocal',
		'apikey' => '45a5ebf4758d9a91bf383f643349dc4d',
		'secretkey' => '89654eb8c8c6b958c53a24df28beab96',
		'urlzm' => 'http://me.zing.vn/apps/phuckhoilocal',
		'url' => 'http://idlocal.pk.net.vn/zm/game.php',
		'env' => 'production'
	);
}
else
{
	$config_appzm = array(
		'appname' => 'phuckhoi',
		'apikey' => '2fdc7244a1385be1567facb71b92c433',
		'secretkey' => '03dee6b270e4873e2bc8d7e9eabacea7',
		'url' => 'http://me.zing.vn/apps/phuckhoi',
		'url' => 'http://id.pk.net.vn/zm/game.php',
		'env' => 'production'
	);
}
?>
