<?php
session_start();
include_once "include/SSO/CXSSO.php";
include_once "include/SSO/SSO_Config.php";
include_once 'include/SSO/TransitionUtil.php';
include_once "include/config-server.php";
include "include/config-url.php";
include "include/common.php";

$sid = isset($_GET['sid']) ?  $_GET['sid'] : '';
	
if($sid == '' || $sid == 'none')
{
	header("Location: ".$url['home']."");
	exit;
}
else
{	
	$sid_SSO3 = TransitionUtil::decode($sid,PRIVATE_KEY);
	$vngSession = CXSSO::checkVNGSession($sid_SSO3);
	$vngSessionArr = (array)$vngSession;
}
if(empty($vngSessionArr["accountName"]))
{
	setcookie('session_info', '');
	header("Location: ".$url['home']."");
	exit;
}
setcookie('session_info', $sid);
$userid = $vngSessionArr["uin"];
$serverNo = count($servers);
$newestServer = 0;
for($i=1 ; $i<=$serverNo; $i++ )
{
	if($servers["s$i"]["active"] == 1 )
	{
		if(CheckUserExistInGame($userid,$servers["s$i"]["private"],$servers["s$i"]["port"]))
		{
			header("Location: ".$url['home']."");
			exit;  
			return;
		}  
		$newestServer = "s$i";
	}
} 

$newestServer ='s20';
header('Location: game.php?server='.$servers["$newestServer"]["id"]);
exit; 
return;


 ?>