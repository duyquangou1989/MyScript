<?php
include_once 'include/SSO/SSO_Config.php';

class XLogout{
	var $return_logout_url = "";
	
	function XLogout(){
		$this->return_logout_url = "http://id.pk.net.vn/zm_tamgiao/index.php";//Trở về trang này sau khi logout	
		$this->logout();
	}
	function logout()
	{
		setcookie('session_info', '');
		header("Location: ".'http://sso2.zing.vn/?method=xdomain_logout&return='.$this->return_logout_url);
		exit;
	}
}
unset($_SESSION['pkvn']);
$lout = new XLogout();
?>
