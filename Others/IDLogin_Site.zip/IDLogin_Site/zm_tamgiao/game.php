<?php
session_start();
header('P3P: CP="NOI ADM DEV PSAi COM NAV OUR OTRo STP IND DEM"');

//include_once "../include/SSO/CXSSO.php";
//include_once "../include/SSO/SSO_Config.php";
include "config-server.php";
include "../include/config-url.php";
include "../include/common.php";


// CHECK LOGIN FOR INSIDE ZINGME APPS
if (empty($_SESSION['pkvn']['zingme']) || empty($_SESSION['pkvn']['accname']) || empty($_SESSION['pkvn']['accid'])) 
{
	header("Location: ".$url['home']."zm_tamgiao/servers.php");
	exit;
}
// CHECK LOGIN FOR INSIDE ZINGME APPS

$server = $_GET['server'];
if(strtotime($servers["s$server"]['release_time']) > time()) // Server chua den thoi gian release
{
	header("Location: ".$url["home"]."zm_tamgiao/servers.php");
	exit;
}

$accName = $_SESSION['pkvn']['accname'];
$zm_userid  = intval($_SESSION['pkvn']['accid']);
$server = $_GET['server'];

if(empty($_SESSION['pkvn']['userid']))
{
	//get userID passport from user name
	$client =  new SoapClient('http://gis.esb.zing.vn/wsdl/Passport/PassportService.wsdl');
	$body = array("sUsername" => $accName);
	$arrResult = $client->RequestFunction("GetInfo",$body,"f4990ba5cde094e7cc5b00ce1d3a70aa");
	if($arrResult[0]==1)
	{
		$passportID = $arrResult[1]['PassportID'];
		$_SESSION['pkvn']['userid'] = $passportID;
		//echo $strResult;
		//exit;
	}
}
$userid = $_SESSION['pkvn']['userid'];

/*
echo "<pre>";
var_dump($_SESSION['pkvn']);
echo "</pre><p>";
echo "userid: ".$userid;
die('<p>herer');
*/


//$ip = $_GET['ip'];
//$port = $_GET['port'];
$server = preg_quote($server);

$ip =  $servers["s$server"]["ip"];
$port =  $servers["s$server"]["port"];

setcookie('server_name', $servers["s$server"]["name"]);

/** Memcache: luu thong tin server choi nhieu nhat, gan nhat **/
/*** Gan nhat ***/
$mc = new Memcached();
$mc->addServer('172.16.9.52', 11211);
if($mc->get("[{$accName}][gannhat]")) {
	$gannhat = $mc->get("[{$accName}][gannhat]");
		if(strpos($gannhat,"s{$server}") == false) {
		$gannhat = $gannhat."|s{$server}|";
		$mc->set("[{$accName}][gannhat]",$gannhat,0);
	} else {
		$gannhat = preg_replace("/\|s".$server."\|/", "", $gannhat);
		$gannhat = $gannhat."|s{$server}|";
		$mc->set("[{$accName}][gannhat]",$gannhat,0);
	}
} else {
	$mc->add("[{$accName}][gannhat]","|s{$server}|",0);
}

/*** Nhieu nhat ***/
if($mc->get("[{$accName}][dachoi]")) {
	$dachoi = $mc->get("[{$accName}][dachoi]");
		if(strpos($dachoi,"s{$server}") == false || $dachoi == "") {
			$dachoi = $dachoi."|s{$server}:1|";
			$mc->set("[{$accName}][dachoi]",$dachoi,0);
		} else {
			preg_match("/\|s".$server.":[^\|]*\|/", $dachoi, $part);
			$tmp = implode("", str_replace("|", "", $part));
			$tmp = explode(":", $tmp);
			$counter = (int)$tmp[1] + 1;
			$newValue = preg_replace("/\|s".$server.":[^\|]*\|/", "|s".$server.":".$counter."|", $dachoi);
			$mc->set("[{$accName}][dachoi]",$newValue,0);
	}
} else {
	$mc->add("[{$accName}][dachoi]","|s{$server}:1|",0);
}

/*** Get bannerid ***/
/*
$today = date('Y-m-d');
if($mc->get("[{$accName}][tmp_bannerid]") || $mc->get("[{$accName}][zm_from_bannerid]")) {
	$bannerid = $mc->get("[{$accName}][tmp_bannerid]");
	if($mc->get("[{$accName}][zm_from_bannerid]")) {
$bannerid = $mc->get("[{$accName}][zm_from_bannerid]");
}
if(isset($banners[$bannerid])) {
		countBanner($bannerid);
	}

	if($mc->get("[{$accName}][from_bannerid]")) {
		$curBannerid = $mc->get("[{$accName}][from_bannerid]");
		if(strpos($curBannerid, ":{$server}|") == false ) {
			$newBannerid = $curBannerid."|{$bannerid}:{$server}|";
			$mc->set("[{$accName}][from_bannerid]",$newBannerid,0);
			if(isset($banners[$bannerid])) {
				$message = $accName.','.$server;
				$log->lfile("/home/cltvn/public_html/bannerid.log/{$today}/bannerid.{$bannerid}");
				$log->lwrite($message);
			}          
		}
	} else {
		$mc->add("[{$accName}][from_bannerid]","|{$bannerid}:{$server}|",0);
		if(isset($banners[$bannerid])) {
			$message = $accName.','.$server;
			$log->lfile("/home/cltvn/public_html/bannerid.log/{$today}/bannerid.{$bannerid}");
			$log->lwrite($message);
		}
	}
}
unset($_SESSION['bannerid']);
$mc->delete("[$accName][tmp_bannerid]");
$mc->delete("[{$accName}][zm_from_bannerid]");
*/

/** End memcache **/
/**--------------**/

function genRandom()
{
	$r = '';
	for($i = 0; $i < 12; ++ $i)
	{
		$r .= chr(mt_rand(0, 255));
	}
	return $r.pack("V", time());
}

function hashThem($username, $r)
{
	static $static_key1 = 'FUHuIEyBcM3OR2eh';
	static $static_key2 = 'Y7IAmfOBpAzknCK7';
	if(strlen($r) < 16)
		return NULL;
	$data = substr($r, 8, 4) . $static_key1 . substr($r, 0, 4) . $username . substr($r, 12, 4) . $static_key2 . substr($r, 4, 4);
	$data1 = sha1($data, true);
	return $r.$data1;
}

//SetCookie('sscq_userid', $_POST['userid'], time()+3600*24*30, '/');
//SetCookie('sscq_server', $_POST['server'], time()+3600*24*30, '/');
//SetCookie('sscq_port', $_POST['port'], time()+3600*24*30, '/');
SetCookie('sscq_userid', $userid, time()+3600*24*30, '/');
SetCookie('sscq_server', $ip, time()+3600*24*30, '/');
SetCookie('sscq_port', $port, time()+3600*24*30, '/');
$ccc = genRandom();
$data = hashThem(pack('VV', $userid, 0), $ccc);
$credit_var = urlencode(base64_encode($data));
$myRoot='';
$cfgserver = "112";
$is_newuser="0";
$ban = 0;
$file = "main_VI.swf";
$glocale = 'Viet';
$chan="zing";
$gid = "2" ;
if($env=='local')
	$cdnroot = 'http://local.pk.net.vn/sscq/';
else $cdnroot = 'http://pk.static.game.zing.vn/sscq/';

$cdnroot = 'http://pk.static.game.zing.vn/sscq/';
//$cdnroot = 'http://pk.static.game.zing.vn/sscq/';
//$server = $_POST['server'].":".$_POST['port'];
$serverport = $ip.":".$port;
if (isset($_GET['cdnroot'])) {
	$cdnroot = $_GET['cdnroot'];
}
$qpluslv = "1";
$myRoot=$cdnroot;
$wallow="1";
$isvip="1";
$viplv="6";
$isyearvip="1";
$isblue="1";
$via = "FB_25623" ;
$invited = "1391540" ;
$serverId = 99;
$isMerge=0;
$openid = $userid;
$openkey = "121212";


?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="shortcut icon" href="http://img.zing.vn/phuckhoi/skin/phuckhoi-072012/images/favicon.ico" type="image/x-icon"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Tam Giao online </title>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="robots" content="index,follow" />
<link href="http://img.zing.vn/eventgame/intro/general/css/mainsite.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="css/style.css" />
<link href="css/jcarousel.css" rel="stylesheet" />
<link href="css/jselect.css" rel="stylesheet" />
<link href="css/jselect-theme.css" rel="stylesheet" />
<link href="css/j-navigation-left.css" type="text/css" rel="stylesheet" />

<script type="text/javascript" src="http://img.zing.vn/eventgame/intro/general/js/mainsite.js"></script>


<script type="text/javascript" src="js/jselect/jselect.js"></script>
<script type="text/javascript" src="js/jselect/jselect.external.js"></script>
<script type="text/javascript" src="js/carousel.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script type="text/javascript" src="http://img.zing.vn/eventgame/intro/general/js/track-idlogin/gt-analytic-idphuckhoi.js"></script>
<script type="text/javascript" src="http://img.zing.vn/phuckhoi/js/ga-phuckhoi-idlogin.js"></script>

<script type="text/javascript" src="http://static.me.zing.vn/feeddialog/js/feed-dialog-1.01.js" ></script>
<script type="text/javascript" src="http://id.pk.net.vn/zm_tamgiao/zingapi/pushfeed.js" ></script>
<script type="text/javascript" src="http://static.me.zing.vn/v3/js/zm.xcall-1.16.min.js"></script>
<script type="text/javascript"  language="javascript">
		<!-- For version detection, set to min. required Flash Player version, or 0 (or 0.0.0), for no version detection. --> 
		var swfVersionStr = "10.0.0";
		<!-- To use express install, set to playerProductInstall.swf, otherwise the empty string. -->
		var xiSwfUrlStr = "playerProductInstall.swf";
		var flashvars = {};
		flashvars.userid = <?php echo $userid; ?>;
		flashvars.zm_userid = <?php echo $zm_userid; ?>;
		flashvars.hash = "<?php echo $credit_var; ?>";
		flashvars.cdnroot = "<?php echo $myRoot; ?>";
		flashvars.glocale = "<?php echo $glocale; ?>";
		flashvars.wallow = "0"; //0 is off, 1 is on
		flashvars.serverId = "<?php echo $serverId; ?>";
		flashvars.isMerge = "<?php echo $isMerge; ?>";
		flashvars.channel =  "<?php echo $chan; ?>";
		flashvars.openid = "<?php echo $openid; ?>";
		flashvars.openkey = "<?php echo $openkey; ?>";
		flashvars.server= "<?php echo $serverport; ?>";
		flashvars.via = "<?php echo $via; ?>";
		flashvars.invited = "<?php echo $invited; ?>";
		flashvars.gid = "<?php echo $gid; ?>";
		flashvars.isvip = "<?php echo $isvip; ?>";
		flashvars.viplv = "<?php echo $viplv; ?>";
		flashvars.qpluslv = "<?php echo $qpluslv; ?>";
		flashvars.isyearvip = "<?php echo $isyearvip; ?>";
		flashvars.isblue = "<?php echo $isblue; ?>";
		flashvars.ban = "<?php echo $ban; ?>";
		flashvars.cfg_server = "s1";
		var params = {};
		params.quality = "high";
		params.allowscriptaccess = "always";
		params.allowfullscreen = "true";
		//params.wmode = "direct";
		params.wmode = "transparent";
		var attributes = {};
		attributes.id = "SSCQ";
		attributes.name = "SSCQ";
		attributes.align = "middle";
		swfobject.embedSWF(
			"<?php echo $myRoot.$file; ?>?t="+(new Date()), "flashContent", 
			"1000", "580", 
			swfVersionStr, xiSwfUrlStr, 
			flashvars, params, attributes);
		<!-- JavaScript enabled so display the flashContent div in case it is not replaced with a swf object. -->
		swfobject.createCSS("#flashContent", "display:block;text-align:left;z-index:1");
		function reloadpage() 
		{
			window.location.reload();
		}
		function username() 
		{
			return "abc"
		}
		function testItem(){
				var flash = getSwf("SSCQ");
				flash.inviteSend();
		}
		function getSwf(movieName) {
			   if (window.document[movieName])
			   {
							 return window.document[movieName];
			   }
			   if (navigator.appName.indexOf("Microsoft")==-1)
			   {
							 if (document.embeds && document.embeds[movieName])
							return document.embeds[movieName];
			   }
			   else
			   {
							return document.getElementById(movieName);
			   }
		}
		
    function addBookmark(title,url)
    {
      if (window.sidebar) {
        window.sidebar.addPanel(title, url,"");
      } else if( document.all ) {
        window.external.AddFavorite( url, title);
      } else if( window.opera && window.print ) {
        return true;
      }
    }
	</script>
<style type="text/css">
#linkgame {
	position: absolute;
	top: 0;
	left: 20px;
	width: 100%;
	height: 100%;
	border: none;
	box-sizing: border-box;
	-moz-box-sizing: border-box;
	-webkit-box-sizing: border-box;
}
#linkgamebot {
	position: absolute;
	bottom: 200px;
	left: 0;
	width: 100%;
	height: 100%;
	border: none;
	box-sizing: border-box;
	-moz-box-sizing: border-box;
	-webkit-box-sizing: border-box;
}

.loading_page
{
position:absolute;
left:0px;
top:0px;
z-index:100;
}

.stop_loading_page
{
display:none;
position:absolute;
left:0px;
top:0px;
z-index:-100;
}
</style>
</head>
<body id="change" class="Ingame"  >

<img src="images/loading_page.jpg" width="<?php echo $_GET['width'];?>" height="<?php echo $_GET['height'];?>" id="LoadImg" class="loading_page"/>
<div id="gameplay" style="z-index:1">
		<div id="gameContent">
			<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td align="center" valign="middle">
						<div id="flashContent"></div>
					</td>
				</tr>
			</table> 
		</div>
</div>

<div id="sideBar" style="z-index:1">
        <div  class="WrapperSideBar">
            <h1><a href="<?php echo $url['home'].'zm_tamgiao/servers.php';?>" title="Trở về trang chủ Tam Giáo">Tam Giáo</a></h1>
            <a href="javascript:void(0);" title="Đóng" id="toggle" class="CloseBtn NotTrack">Đóng / Mở</a>
            <div class="UserInfo2"><span><?php echo $accName; ?></span></div>
            <div class="ServerBox">
                <p class="Text"	>Máy chủ đang chơi:</p>
                <p class="ServerCurrent"><?php echo $servers["s$server"]["name"];?></p>
                 <select class="SelectUI Theme_GP Theme_Human "  id="Server" name="" title="Máy chủ đã chọn" onChange="openGame(this.value);">
				<?php 

				$accName = $_SESSION['pkvn']['accname'];

				if($mc->get("[{$accName}][gannhat]")) {
					$gannhat = $mc->get("[{$accName}][gannhat]");
					$gannhat = explode("|", $gannhat);
					$bigArr = array();
					foreach ($gannhat as $key) {
						if($key != "") {
						$bigArr[] = $key;
						}
					}
					$end_bigArr = count($bigArr)-1;
					for($i=$end_bigArr, $count=1; $i>=0; $i--, $count++) {
						$serverName = $bigArr[$i];
						if(!empty($serverName))
							echo '<option value="'.$url['home'].'zm_tamgiao/game.php?server='.$servers[$serverName]['id'].'">'.$servers[$serverName]['name'].'</option>';
						if($count == 5) break;
					}
				}
				?>
                    <!--<option value="Value 1">Máy chủ 1</option>
                    <option value="Value 2">Máy chủ 2</option>
                    <option value="Value 3">Máy chủ 3</option>-->
					
					
                </select>
        	</div>
            
           	<iframe width="202" height="470" frameborder="0" src="http://launcher.game.zing.vn/PKVN/tamgiao-launcher-left-menu-062013.html" allowtransparency="1" scrolling="no"></iframe> 
        </div>
    </div>
    
<!-- Tich hop VMAS cua GSO !-->
<img src="http://mas.zing.vn/logging.php?<?php echo 'u='.$userid.'&f='.$_SESSION['pkvn']['vmas_status'].'&s='.$server.'&gc=PKVN';?>" width="0" height="0"></img>
<!-- Tich hop VMAS cua GSO !-->

</body>

<script>

function loading()
{
	document.getElementById("LoadImg").className="loading_page";
}
function stop_loading()
{
	document.getElementById("LoadImg").className="stop_loading_page";
}

function page_first_load()
{
	window.setTimeout(function(){document.getElementById("LoadImg").className="stop_loading_page"},10000);
} 
//onLoad="document.getElementById('SSCQ').focus()"
window.onload=page_first_load;


// Ghi log tracking tu kenh ZingMe (G2)
zmXCall.callParent("logNewRole","<?php echo $servers["s$server"]["name"];?>");
// Ghi log tracking tu kenh ZingMe (G2)

function openGame(url)
{
	window.location.href=url;
}
</script>
</html>
