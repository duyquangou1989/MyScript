<?php
$servers = array(
"s1" => array("id" => "1", "name" => "Thục Sơn", "active" => "1", "hot" => "1", "status" => "0", "new" => "1", "ip" => "103.23.158.20", "port" => "8000", "private" => "172.16.9.38", "release_time" => "2013-06-21 09:50:00"),
"s2" => array("id" => "2", "name" => "Thiên Sơn", "active" => "1", "hot" => "1", "status" => "0", "new" => "1", "ip" => "103.23.158.21", "port" => "8000", "private" => "172.16.9.39", "release_time" => "2013-06-26 08:50:00"),
);

?>
