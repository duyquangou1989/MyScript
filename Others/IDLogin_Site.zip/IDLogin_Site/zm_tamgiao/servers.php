<?php
session_start();
header('P3P: CP="NOI ADM DEV PSAi COM NAV OUR OTRo STP IND DEM"');
//error_reporting(E_ALL & ~E_NOTICE);


//==========================================
$from_time = "2013-07-04 00:00:00";
$to_time   = "2013-07-06 00:00:00";

$begin_time = strtotime($from_time);
$end_time   = strtotime($to_time);
$now = time();

if ($now >= $begin_time && $now <= $end_time) {
	exit();
}
//==========================================

//include_once "../include/SSO/CXSSO.php";
//include_once "../include/SSO/SSO_Config.php";
include_once "config-server.php";
include "../include/config-url.php";
include "../include/common.php";

require_once '../include/zingme-sdk/BaseZingMe.php';
require_once '../include/zingme-sdk/ZME_Me.php';
require_once '../include/zingme-sdk/ZME_User.php';

$config_live = array(
	'appname' => 'tamgiao',
	'apikey' => 'aed75502e92e436181845a20548a87d4',
	'secretkey' => 'f19af80547394511813783f26e614b73',
	'env' => 'production'
);

$config = $config_live;
$zm_Me = new ZME_Me($config);
$login_url = 'http://me.zing.vn/apps/tamgiao';
$signed_request = $_REQUEST["signed_request"];



if(strlen($signed_request)==0)  // chua login ZingMe notfound zmlistserver
{
	echo '<script>window.top.location.href="http://login.me.zing.vn/?url='.$login_url.'";</script>';
    exit;
}

$access_token = $zm_Me->getAccessTokenFromSignedRequest($signed_request);
$me = $zm_Me->getInfo($access_token,$fields="id,username");

if(sizeof($me)>0)
{
	$_SESSION['pkvn']['zingme']  = 1;
	$_SESSION['pkvn']['accname'] = $me["username"];
	$_SESSION['pkvn']['accid']   = intval($me["id"]);
	$_SESSION['pkvn']['userid'] = "";
}

// CHECK LOGIN FOR INSIDE ZINGME APPS
/*
echo "<pre>";
print_r($_SESSION['pkvn']);
echo "</pre>";
exit();
*/

//--------------------------------------------------------------------------------------------------------

// OVERWRITE SERVER LIST (lay ra nhung server se open dung thoi gian Release Time)
$temp_server = array();
foreach ($servers as $key => $server) {
    if ($server['active']==1 && strtotime($server['release_time']) <= time()) { 
		$temp_server[$key]=$server;
	}
}

$sizeof=sizeof($temp_server);
$hot=0;
$new=0;
for($h=1;$h<=$sizeof;$h++){
	if($h==($sizeof-1)){ 
		$new = 1;
	}	
	if($h==($sizeof)){ 
		$hot = 1;
	}
	$temp_server["s$h"]["hot"]=$hot;
	$temp_server["s$h"]["new"]=$new;
}

$servers = $temp_server;
//echo "<pre>";
//print_r($temp_server);
//echo "</pre>";

//------------------------------------------------------------------------------

$mc = new Memcached();
$mc->addServer('172.16.9.52', 11211);

// NEU LA USER MOI SE REDIRECT VAO SERVER CUOI CUNG
$accName = $_SESSION['pkvn']['accname'];
$str_recent_servers = $mc->get("[{$accName}][gannhat]");
$recent_servers = explode("|", $str_recent_servers);
foreach ($recent_servers as $key) {
	if($key != "") {
		$re_servers[] = $key;
	}
}

$AutoRedirectToHotServer=0;
if(sizeof($re_servers)==0)
{
	foreach($servers as $key_i => $value){
	 // lay server cuoi cung = server hot	
	}
	$hotserver_key = $value["id"];
	$AutoRedirectToHotServer=1; // flag
}

// NEU LA USER MOI SE REDIRECT VAO SERVER CUOI CUNG	

?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="shortcut icon" href="http://img.zing.vn/phuckhoi/skin/phuckhoi-072012/images/favicon.ico" type="image/x-icon"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Tam Giao online</title>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="robots" content="index,follow" />
<link href="http://img.zing.vn/eventgame/intro/general/css/mainsite.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="css/style.css" />
<link href="css/style-news.css" type="text/css" rel="stylesheet" />
<link href="css/banner-event.css" type="text/css" rel="stylesheet" />
<link href="css/jcarousel.css" rel="stylesheet" />
<link href="css/jselect/jselect.css" rel="stylesheet" />
<link href="css/jselect/jselect-theme.css" rel="stylesheet" />
<link href="css/j-navigation-left.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="http://img.zing.vn/eventgame/intro/general/js/mainsite.js"></script>
<!--[if IE 6]>
<script src="js/DD_belatedPNG_0.0.8a.js"></script>
<script>  
 	DD_belatedPNG.fix('img,.GifNew');
</script>
<![endif]-->
<script type="text/javascript" src="js/jquery.ui.fadegallery.js"></script>
<script type="text/javascript" src="/js/jselect/jselect.js"></script>
<script type="text/javascript" src="/js/jselect/jselect.external.js"></script>
<script type="text/javascript" src="js/carousel.js"></script>
<script type="text/javascript" src="js/common.js"></script>


<script type="text/javascript" src="http://static.me.zing.vn/v3/js/zm.xcall-1.04.min.js"></script>

</head>
<body>
<div id="wrapper">
  <div id="idLogin">
  	<h1><a href="#" title="Trở về trang chủ Tam Giáo">Trở về trang chủ Tam Giáo</a></h1>
    <div id="recentServer">
        <select class="SelectUI Theme_GP Theme_Human "  id="Server" name="" title="Máy chủ đã chơi gần nhất" onChange="openFullScreen(1310,1024,this.value)">
           <?php
				$accName = $_SESSION['pkvn']['accname'];

				if($mc->get("[{$accName}][gannhat]")) {
					$gannhat = $mc->get("[{$accName}][gannhat]");
					$gannhat = explode("|", $gannhat);
					$bigArr = array();
					foreach ($gannhat as $key) {
						if($key != "") {
						$bigArr[] = $key;
						}
					}
					$end_bigArr = count($bigArr)-1;
					for($i=$end_bigArr, $count=1; $i>=0; $i--, $count++) {
						$serverName = $bigArr[$i];
						if(!empty($serverName))
							echo '<option value="'.$url['home'].'zm_tamgiao/game.php?server='.$servers[$serverName]['id'].'">'.$servers[$serverName]['name'].'</option>';
						if($count == 5) break;
					}
				}
					
            ?>
        </select>
    </div>
    <div id="serverPlayLast">
        <select class="SelectUI Theme_GP Theme_Human "  id="Server" name="" title="Máy chủ đã chơi" onChange="openFullScreen(1310,1024,this.value)">
            <?php 
				$accName = $_SESSION['pkvn']['accname'];

				if($mc->get("[{$accName}][gannhat]")) {
					$gannhat = $mc->get("[{$accName}][gannhat]");
					$gannhat = explode("|", $gannhat);
					$bigArr = array();
					foreach ($gannhat as $key) {
						if($key != "") {
						$bigArr[] = $key;
						}
					}
					$end_bigArr = count($bigArr)-1;
					for($i=$end_bigArr, $count=1; $i>=0; $i--, $count++) {
						$serverName = $bigArr[$i];
						if(!empty($serverName))
							echo '<option value="'.$url['home'].'zm_tamgiao/game.php?server='.$servers[$serverName]['id'].'">'.$servers[$serverName]['name'].'</option>';
						if($count == 5) break;
					}
				}
			?>
        </select>
    </div>
    <div class="UserInfo"><span><?php echo $accName; ?></span></div>
    <div class="Server">
      <ul class="ServerHot">
	  
		<?php 
			$length =9;
			$serverNo = count($servers);                    
			$tabNoInt = (int)(($serverNo / $length)+1);
			
			for($i=$serverNo, $ind=1 ; $i>=1; $i--) 
			{
					if( $ind<=3)
					{
						if($servers["s$i"]["hot"] == 1 && $servers["s$i"]["active"] == 1)
						{
							echo '<li><span class="GifNew">New</span><span class="Total">'.$servers["s$i"]["id"].'</span><a href="javascript:openFullScreen(1310,1024,\''.$url['home'].'zm_tamgiao/game.php?server='.$servers["s$i"]['id'].'\')" title="'.$servers["s$i"]["name"].'" class="">'.$servers["s$i"]["name"].'</a></li>';
							$ind++;
						}
					}
			}
						
		?>
   
      </ul>
      <div id="nav">
    <!-- SERVER CHOICE ---->
       <?php
		$server_total = 0;
		foreach ($servers as $server) {
			if ($server['active']==1) { 
				//echo $key; 
				$server_total++;
			}
		}
		$server_page = ceil($server_total/9);

//echo "Page:".$server_page;

            echo "<ul id='tabHeader'>";      
            $server_page_1 = $server_page -1;
            for ($i=$server_page_1; $i>=0; $i--) {
                $class1 = ($i==$server_page_1) ? "Active" : "";
                $name1  = $i*9 + 9;                                        
                $name1  = ($name1<10) ? "0{$name1}" : $name1;
                $name2  = $name1 - 8;
                $name2  = ($name2<10) ? "0{$name2}" : $name2;
                $name2  = "$name1 - $name2";
                echo "<li class='{$class1}'><a rel='#S{$name1}' href='#' title='{$name2}'>{$name2}</a></li>\n";
                
            }
            echo "</ul>";  
    
        ?>
    <!-- SERVER CHOICE ---->
    
    <!-- LIST SERVER ---->              
       
    <!-- List of servers --> 
    <?php
                $server_page_index = 1;
                $r1 = 0;
                $servers = array_reverse($servers);
                foreach ($servers as $key => $server) {                            
                    if ($server['active']==1) {
                        if ($r1%9==0) {
                            $id1 = $r1+1;
                            if ($id1<10) $id1 = "0{$id1}";
                            if ($r1!=0) echo "</ul>\n";
                            if ($r1==0){
                                echo "<ul class='ListServer Active' id='S{$id1}'>\n";   
                            }else{
                                echo "<ul class='ListServer' id='S{$id1}'>\n";  
                            }
                            // Neu la Page dau tien
                            if($server_page_index==1)
                            {
                                $number_of_space = $server_page*9 - sizeof($servers); // Tinh so Space phai bu vao Page cho du 10 item/1 page
                                $servers_in_first_page = 9 - $number_of_space;				// Tinh so server hien thi trong Page dau tien
                            }
                            //---------------------
                        }
                        if ($server['hot']==1) $status_hot = "class='Hot'";
                        else $status_hot = '';
						
						$ccu = $mc->get("[$key][ccureal]");
						echo '<li><a href="javascript:openFullScreen(1310,1024,\''.$url['home'].'zm_tamgiao/game.php?server='.$servers[$key]['id'].'\')" title="'.$servers[$key]["name"].'" class=""><span class="Total">'.$servers[$key]["id"].'</span>'.$servers[$key]["name"].showStatusAuto($ccu).'</a>';
						if($servers[$key]["new"] == 1) echo '<span class="ServerNew">New</span>';
					
                        $r1++;
                        
                        // Tinh Space bu vao Page dau tien
                        $server_index = $r1;
                        if($server_page_index==1 && $server_index==$servers_in_first_page){  
                        // Neu la Page dau tien, va so luong server hien thi trong Page dau tien = so le cua tong so server (Vi du: tong so server: 36 thi so le la 6)
                             $space = 1;
                             while ($space<=$number_of_space) {                            
                                echo "<li > &nbsp;</li>\n";
                                $space++;
                            }
                            $r1=9; // gan r1=10 de ket thuc Page dau tien
                        }
                        //---------------------------------
                        if ($r1%9==0) {  // Het 1 Page thi tang them 1
                            $server_page_index++; // Qua page tiep theo (10 server 1 page)
                        }
                    }
                }     
                while ($r1%9!=0) {                            
                    echo "<li > &nbsp;</li>\n";
                    $r1++;
                }
                echo "</ul>\n";
        ?>
     
      </div>
    </div>
    <div class="BannerEvent">
			
    </div>
    
    <ul class="HoTro">
        <li> <a href="#" target="_blank" title="Chia sẻ Facebook" class="Facebook">Chia sẻ Facebook</a></li>
        <li><a href="#" target="_blank" title="Chia sẻ ZingMe" class="ZingMe">Chia sẻ ZingMe</a></li>
    </ul>
    <p class="Copyright2">Tam Giáo @ 2013</p>
    <a href="http://www.kingnet.com" target="_blank" title="KingNet" class="KingNet">Kingnet</a>
  </div>

</div>

<script type="text/javascript" src="http://static.me.zing.vn/v3/js/zm.xcall-1.15.min.js"></script>
<script>		


function openFullScreen(_width, _height, _url) {
	// 100% fullscreen
	zmXCall.getViewport(function(resp){
		_height = resp.height - 38;
		_width = resp.width;
		new_url = _url + '&width=' + _width + '&height=' + _height;
		zmXCall.callParent('openFullFrame', { width: _width, height: _height, url: new_url });
	});
}
function fullload()
{
	<?php
		// NEW GAMER SE OPEN FULL SCREEN CHOI GAME TRONG SERVER MOI NHAT
		if($AutoRedirectToHotServer==1){
			echo "openFullScreen('1310', '600', 'http://id.pk.net.vn/zm_tamgiao/game.php?server=$hotserver_key&flag=full');";
		}
	?>	
	return;
}
window.onload=fullload;
</script>
<?php
// XAC DICH NGUON GOI DEN CUA VMAS
if(isset($_SERVER['HTTP_REFERER'])){
	$parts_url = parse_url($_SERVER['HTTP_REFERER']);
	$query = isset($parts_url['query']) ? $parts_url['query'] :
	(isset($parts_url['fragment']) ? $parts_url['fragment'] : '');
	if($query) {
		parse_str($query, $parts_query);
		if (isset($parts_query['utm_medium']) &&
		isset($parts_query['utm_campaign'])) {
			$status = 1;
		}else {
			$status = 2;
		}
	}else{
		$status = 2;
	}
}else{
	$status = 2;
}
if(!empty($status)){
		$_SESSION['pkvn']['vmas_status']   =  $status ;
}
// XAC DICH NGUON GOI DEN CUA VMAS

$website = '';
$campaign = '';
							
$_SERVER_URL = $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];

$parts_url = parse_url($_SERVER_URL);
$query = isset($parts_url['query']) ? $parts_url['query'] : (isset($parts_url['fragment']) ? $parts_url['fragment'] : '');
if($query) {
	parse_str($query, $parts_query);
	if (isset($parts_query['utm_medium']) &&isset($parts_query['utm_campaign'])) {
		$website = $parts_query['utm_medium'];
		$campaign = $parts_query['utm_campaign'];
	}
}

?>
<img src='http://mas.zing.vn/m.php?utm_term=PKVN&utm_appstore=ZingMe&Bwebsite=<?php echo $website?>&Bcampaign=<?php echo $campaign?>'></img>
</body>
</html>
