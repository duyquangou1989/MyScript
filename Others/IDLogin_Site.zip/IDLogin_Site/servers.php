<?php
session_start();
require_once "include/SSO/CXSSO.php";
require_once "include/SSO/SSO_Config.php";
require_once 'include/SSO/TransitionUtil.php';
require_once "include/config-server.php";
require_once "include/config-url.php";
require_once "include/common.php";

if (!check_login()) 
{
	header("Location: ".$url["home"]);
	exit;
}

// OVERWRITE SERVER LIST (lay ra nhung server se open dung thoi gian Release Time)
$temp_server = array();
foreach ($servers as $key => $server) {
    if ($server['active']==1 && strtotime($server['release_time']) <= time()) { 
		$temp_server[$key]=$server;
	}
}

$sizeof=sizeof($temp_server);
$hot=0;
$new=0;
for($h=1;$h<=$sizeof;$h++){
	if($h==($sizeof-1)){ 
		$new = 1;
	}	
	if($h==($sizeof)){ 
		$hot = 1;
	}
	$temp_server["s$h"]["hot"]=$hot;
	$temp_server["s$h"]["new"]=$new;
}

$servers = $temp_server;
//echo "<pre>";
//print_r($temp_server);
//echo "</pre>";

//------------------------------------------------------------------------------

$mc = new Memcached();
$mc->addServer('172.16.9.52', 11211);

// NEU LA USER MOI SE REDIRECT VAO SERVER CUOI CUNG
$accName = $_SESSION['pkvn']['accname'];
$str_recent_servers = $mc->get("[{$accName}][gannhat]");
$recent_servers = explode("|", $str_recent_servers);
foreach ($recent_servers as $key) {
	if($key != "") {
		$re_servers[] = $key;
	}
}
if(sizeof($re_servers)==0)
{
	foreach($servers as $key_i => $value){
	 // lay server cuoi cung = server hot	
	}
	$hotserver_key = $value["id"];
	header("location:game.php?server=".$hotserver_key);
	exit();
}
// NEU LA USER MOI SE REDIRECT VAO SERVER CUOI CUNG	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="shortcut icon" href="http://img.zing.vn/phuckhoi/skin/phuckhoi-072012/images/favicon.ico" type="image/x-icon"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Phuc Khoi online – Tuyệt đỉnh PK</title>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="robots" content="index,follow" />
<link href="http://img.zing.vn/eventgame/intro/general/css/mainsite.css?1" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="css/style.css?1" />
<link href="css/style-news.css?1" type="text/css" rel="stylesheet" />
<link href="css/banner-event.css?1" type="text/css" rel="stylesheet" />
<link href="css/jcarousel.css?1" rel="stylesheet" />
<link href="css/jselect/jselect.css?1" rel="stylesheet" />
<link href="css/jselect/jselect-theme.css?1" rel="stylesheet" />
<link href="css/j-navigation-left.css?1" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="http://img.zing.vn/eventgame/intro/general/js/mainsite.js"></script>
<!--[if IE 6]>
<script src="js/DD_belatedPNG_0.0.8a.js"></script>
<script>  
 	DD_belatedPNG.fix('img,.GifNew');
</script>
<![endif]-->
<script type="text/javascript" src="js/jquery.ui.fadegallery.js"></script>
<script type="text/javascript" src="js/jselect/jselect.js"></script>
<script type="text/javascript" src="js/jselect/jselect.external.js"></script>
<script type="text/javascript" src="js/carousel.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script type="text/javascript" src="http://img.zing.vn/phuckhoi/js/ga-phuckhoi-idlogin.js?version=1"></script>
</script>

</head>
<body>
<div id="wrapper">
  <div id="idLogin">
  	<h1><a href="http://pk.net.vn/index.html" title="Trở về trang chủ Phục Khởi">Trở về trang chủ Phục Khởi</a></h1>
    <div id="recentServer">
        <select class="SelectUI Theme_GP Theme_Human "  id="Server" name="" title="Máy chủ đã chơi gần nhất" onchange="window.open(this.options[this.selectedIndex].value,'_blank')">
			<?php
	
				$accName = $_SESSION['pkvn']['accname'];
				if($mc->get("[{$accName}][gannhat]")) {
					$gannhat = $mc->get("[{$accName}][gannhat]");
					$gannhat = explode("|", $gannhat);
					$bigArr = array();
					foreach ($gannhat as $key) {
						if($key != "") {
						$bigArr[] = $key;
						}
					}
					$end_bigArr = count($bigArr)-1;
					for($i=$end_bigArr, $count=1; $i>=0; $i--, $count++) {
						$serverName = $bigArr[$i];
						if(!empty($serverName))
							echo '<option value="game.php?server='.$servers[$serverName]['id'].'">'.$servers[$serverName]['name'].'</option>';
						if($count == 5) break;
					}
				}
            ?>
        </select>
    </div>
    <div id="serverPlayLast">
        <select class="SelectUI Theme_GP Theme_Human "  id="Server" name="" title="Máy chủ đã chơi" onchange="window.open(this.options[this.selectedIndex].value,'_blank')">
			<?php 
				//$accName = $_SESSION['pkvn']['accname'];
				if($mc->get("[{$accName}][dachoi]"))
				{
					$dachoi = $mc->get("[{$accName}][dachoi]");
					$dachoi = explode("|", $dachoi);
					$bigArr = array();
					
					foreach ($dachoi as $key) {
						if($key != "") {
						$bigArr[] = explode(":", $key)[0] ;
						}
					}
					$end_bigArr = count($bigArr)-1;
					for($i=$end_bigArr, $count=1; $i>=0; $i--, $count++) {
						$serverName = $bigArr[$i];
						if(!empty($serverName))
							echo '<option value="game.php?server='.$servers[$serverName]['id'].'">'.$servers[$serverName]['name'].'</option>';
						if($count == 5) break;
					}
				}
			?>
          
        </select>
    </div>
    <div class="UserInfo"><span><?php echo $_SESSION['pkvn']['accname']; ?></span><a href="logout.php"> [Thoát]</a></div>
    <div class="Server">
      <ul class="ServerHot">
		<?php 
			$length =10;
			$serverNo = count($servers);                    
			$tabNoInt = (int)(($serverNo / $length)+1);
			
			for($i=$serverNo, $ind=1 ; $i>=1; $i--) 
			{
					if( $ind<=2)
					{
						if($servers["s$i"]["hot"] == 1 && $servers["s$i"]["active"] == 1)
						{
							echo '<li><span class="GifNew">New</span><span class="Total">'.$servers["s$i"]["id"].'</span><a  onclick="_gaq.push([\'_trackEvent\', \''.stripUnicode($servers["s$i"]["name"]).'\', \'Link\', \'IDLogin\']);" href="game.php?server='.$servers["s$i"]["id"].'" title="'.$servers["s$i"]["name"].'" class="">'.$servers["s$i"]["name"].'</a></li>';
							$ind++;
						}
					}
			}
			
			
			/*for($i=1, $ind=1 ; $i<=$serverNo; $i++) 
			{
					if( $ind<=3)
					{
						if($servers["s$i"]["hot"] == 1 && $servers["s$i"]["active"] == 1)
						{
							echo '<li><span class="GifNew">New</span><span class="Total">'.$servers["s$i"]["id"].'</span><a  onclick="_gaq.push([\'_trackEvent\', \''.stripUnicode($servers["s$i"]["name"]).'\', \'Link\', \'IDLogin\']);" href="game.php?server='.$servers["s$i"]["id"].'" title="'.$servers["s$i"]["name"].'" class="">'.$servers["s$i"]["name"].'</a></li>';
							$ind++;
						}
					}
			}*/
		?>
        
      </ul>
      <div id="nav">
    <!-- SERVER CHOICE ---->
       <?php
		$server_total = 0;
		foreach ($servers as $server) {
			if ($server['active']==1) { 
				//echo $key; 
				$server_total++;
			}
		}
		$server_page = ceil($server_total/10);

//echo "Page:".$server_page;

            echo "<ul id='tabHeader'>";      
            $server_page_1 = $server_page -1;
            for ($i=$server_page_1; $i>=0; $i--) {
                $class1 = ($i==$server_page_1) ? "Active" : "";
                $name1  = $i*10 + 10;                                        
                $name1  = ($name1<10) ? "0{$name1}" : $name1;
                $name2  = $name1 - 9;
                $name2  = ($name2<10) ? "0{$name2}" : $name2;
                $name2  = "$name1 - $name2";
                echo "<li class='{$class1}'><a rel='#S{$name1}' href='#' title='{$name2}'>{$name2}</a></li>\n";
                
            }
            echo "</ul>";  
    
        ?>
    <!-- SERVER CHOICE ---->
    
    <!-- LIST SERVER ---->              
       
    <!-- List of servers --> 
    <?php
               
                $server_page_index = 1;
                $r1 = 0;
                $servers = array_reverse($servers);
                foreach ($servers as $key => $server) {                            
                    if ($server['active']==1) {
                        if ($r1%10==0) {
                            $id1 = $r1+1;
                            if ($id1<10) $id1 = "0{$id1}";
                            if ($r1!=0) echo "</ul>\n";
                            if ($r1==0){
                                echo "<ul class='ListServer Active' id='S{$id1}'>\n";   
                            }else{
                                echo "<ul class='ListServer' id='S{$id1}'>\n";  
                            }
                            // Neu la Page dau tien
                            if($server_page_index==1)
                            {
                                $number_of_space = $server_page*10 - sizeof($servers); // Tinh so Space phai bu vao Page cho du 10 item/1 page
                                $servers_in_first_page = 10 - $number_of_space;				// Tinh so server hien thi trong Page dau tien
                            }
                            //---------------------
                        }
                        if ($server['hot']==1) $status_hot = "class='Hot'";
                        else $status_hot = '';
						
						$ccu = $mc->get("[$key][ccureal]");
						echo '<li><a onclick="_gaq.push([\'_trackEvent\', \''.stripUnicode($servers[$key]["name"]).'\', \'Link\', \'IDLogin\']);" href="game.php?server='.$servers[$key]["id"].'" title="'.$servers[$key]["name"].'" class=""><span class="Total">'.$servers[$key]["id"].'</span>'.$servers[$key]["name"].showStatusAuto($ccu).'</a>';
					if($servers[$key]["new"] == 1) echo '<span class="ServerNew">New</span>';
					
                        $r1++;
                        
                        // Tinh Space bu vao Page dau tien
                        $server_index = $r1;
                        if($server_page_index==1 && $server_index==$servers_in_first_page){  
                        // Neu la Page dau tien, va so luong server hien thi trong Page dau tien = so le cua tong so server (Vi du: tong so server: 36 thi so le la 6)
                             $space = 1;
                             while ($space<=$number_of_space) {                            
                                echo "<li > &nbsp;</li>\n";
                                $space++;
                            }
                            $r1=10; // gan r1=10 de ket thuc Page dau tien
                        }
                        //---------------------------------
                        if ($r1%10==0) {  // Het 1 Page thi tang them 1
                            $server_page_index++; // Qua page tiep theo (10 server 1 page)
                        }
                    }
                }     
                while ($r1%10!=0) {                            
                    echo "<li > &nbsp;</li>\n";
                    $r1++;
                }
                echo "</ul>\n";
        ?>
      </div>
    </div>
    <div class="BannerEvent">
			<!--<iframe width="450" height="185" frameborder="0" src="http://launcher.game.zing.vn/PKVN/pknews.html" allowtransparency="1" scrolling="no"></iframe>-->
			<iframe width="450" height="185" frameborder="0" src="http://launcher.game.zing.vn/PKVN/pk-launcher-112012.html" allowtransparency="1" scrolling="no"></iframe>
    </div>
    
    <p class="Copyright2">Phuckhoi @ 2012</p>
	<a class="KingNet" title="KingNet" target="_blank" href="http://www.kingnet.com">Kingnet</a>
  </div>
</div>

</body>
</html>
