<?php
require_once("../include/config-server.php");

//echo "IP:".$_SERVER["REMOTE_ADDR"];

//echo "<pre>";
//print_r($conf_servers);

$server_list = array();
$index = 0;
foreach($servers as $key => $data){
	if($data["active"]==1 && strtotime($data['release_time']) <= time()){
		$server_list[$index]["zid"] = $index+1;
		$server_list[$index]["servername"] = $data["name"];
		$server_list[$index]["serverip"] = $data["private"];
		$server_list[$index]["serverport"] = $data["port"];
		$index++;
	}
}
echo json_encode($server_list);

//echo "<pre>";
//print_r($server_list);
?>
