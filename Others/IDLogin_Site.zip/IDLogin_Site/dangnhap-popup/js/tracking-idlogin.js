var urlArray = ['gunny.zing.vn','volam.zing.vn','img.zing.vn']; // Direct url


jQuery(document).ready(function(){		
		
	if ( jQuery("ul#tabIdLogin li a").length > 0 ) {
		jQuery("ul#tabIdLogin li a").bind ("click", function () {
			var liTab= jQuery(this).attr("rel");		
			jQuery("ul#tabIdLogin li").removeClass("Active");
			jQuery(this).parent().addClass("Active");
			jQuery(".TabContent").hide();
			jQuery("#" +liTab).show();	

		})
	}
	if ( jQuery("a.ChangeTab").length > 0 ) {
		jQuery("a.ChangeTab").bind ("click", function () {
			var liTab= jQuery(this).attr("rel");		
			showTabLogin(liTab);		
		})
	}
	
	// kiem tra referrer
	try {				
		var urlReferrer = document.referrer;
		//console.log('nguon: '+urlReferrer);
		
		if (urlReferrer == '' ){
			showTabLogin("tabLogin");
		}
		else {
			if (checkURLReferer(urlArray)){
				showTabLogin("tabLogin");
			}
			else {
				showTabLogin("tabQuickReg");
			}
		}
		
	} catch(exp){}		
	
	
	
})

function showTabLogin(liTab){
	jQuery("ul#tabIdLogin li").removeClass("Active");
	var linkDoc= jQuery('ul#tabIdLogin li a');
		
	jQuery.each(linkDoc, function(i, val) { 
		if( jQuery(this).attr("rel")==liTab){
			jQuery(this).parent().addClass("Active");
		}
	})	
	jQuery(".TabContent").hide();
	jQuery("#" +liTab).show();		

}
function checkURLReferer(urlArray){
	var _referer = document.referrer.split('/');			
	var _url =  _referer[2];
	if(_referer[3]=='intro'){
		return false;
	}
	for (i in urlArray){
		var pattUrl = new RegExp(urlArray[i]);
		if (pattUrl.test(_url)){
			return true;
		} 
	}
	return false;
}