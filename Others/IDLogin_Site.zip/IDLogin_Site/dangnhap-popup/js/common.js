jQuery(document).ready(function(){
	/* Box dang nhap */
	if ( jQuery("#username").length >0){		
		
		jQuery('#username').bind('focus',function(){
			if(jQuery(this).val()=='Tài khoản Zing') {
				jQuery(this).val('');
			}
		});
		jQuery('#username').bind('blur',function(){
			if(jQuery(this).val()=='') {
				jQuery(this).val('Tài khoản Zing');
			}
		});
    }
	if ( jQuery("#password").length >0){		
		jQuery('#password').bind('focus',function(){
			if(jQuery(this).val()=='Mật khẩu') {
				jQuery(this).val('');
			}
		});
		jQuery('#password').bind('blur',function(){
			if(jQuery(this).val()=='') {
				jQuery(this).val('Mật khẩu');
			}
		});
	}
})