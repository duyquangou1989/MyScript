## Update execution
1. Close the Server
2. Make sure the server after closing, the new file replaces the original program.
3. start Server

## Update Active Configuration
1. Use the new `pyscripter` or` settings` replace the original file
2. Use `POnyDebugger` loaded the new configuration file, the command is as follows:
		
		# 18899 is Debug port.
		./PyDebugger 127.0.0.1 18899  reloadall.py
		# This appears to indicate success.
		[2016-01-15 17:02:09][ LOG ][PyDebugger]