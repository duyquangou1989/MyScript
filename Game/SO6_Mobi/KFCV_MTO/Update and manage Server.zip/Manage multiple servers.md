## Manage multiple servers
### Config Startup script
####gamestart.sh

0. Change the `homedir` value
1. Copy to the game server root directory.
2. `chmod +x gamestart.sh`

### Config Multi-server management script
####SvrControl

1. Change the `ServerList` value in the  `config.py`.
2. `chmod +x main.py`
3. example:：

		./main.py SERVERID {gm|ps|as|bm|bs|gs|common|game} {start|stop|status}

SERVERID：

When there are multiple servers separated by spaces, example:

	./main.py 10001 10002 10003 gs status
	# It will operate 100,011,000,210,003 three servers.

all: Select all servers.

GameType:

	gm: GMServerd
	ps: PayServerd
	as: AuthServerd
	bm: BattleManagerd
	bs: BattleServerd
	gs: GameServerd
	common: GMServerd  PayServerd AuthServerd
	game: BattleManagerd BattleServerd GameServerd 
Actions:
	{start|stop|status}


