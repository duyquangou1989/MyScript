#coding=utf8

import MFightData

class FightData(MFightData.FightDataProxy):
    def __init__(self):
        MFightData.FightDataProxy.__init__(self)

        