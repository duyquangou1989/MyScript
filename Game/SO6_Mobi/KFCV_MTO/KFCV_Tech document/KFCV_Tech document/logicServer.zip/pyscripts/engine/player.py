#coding=utf8

import MPlayer

class Player(MPlayer.PlayerProxy):
    def __init__(self):
        MPlayer.PlayerProxy.__init__(self)
        
    def onLoad(self, data):
        for k in data:
            setattr(self, k, data[k])
            
    def onSave(self):
        result = {}
        for k in self.__dict__:
            if k.startswith("s_"):
                result[k] = getattr(self, k)
        return result