#coding=utf8

import MGuildMember

class GuildMember(MGuildMember.GuildMemberProxy):
    def __init__(self):
        MGuildMember.GuildMemberProxy.__init__(self)
        
    def onLoad(self, data):
        for k in data:
            setattr(self, k, data[k])
            
    def onSave(self):
        result = {}
        for k in self.__dict__:
            if k.startswith("s_"):
                result[k] = getattr(self, k)
        return result