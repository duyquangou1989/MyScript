#coding=utf8

import MItem

class Item(MItem.ItemProxy):
    def __init__(self):
        MItem.ItemProxy.__init__(self)
        
    def __del__(self):
        pass
    
    def onLoad(self, data):    
        for k in data:
            setattr(self, k, data[k])
            
    def onSave(self):
        result = {}
        for k in self.__dict__:
            if k.startswith("s_"):
                result[k] = getattr(self, k)
        return result
        
    def canUse(self, player):
        return False
        
    def doUse(self, player):
        return False
    
class ItemManager:
    def __init__(self):
        self.mItemClasses = {}
        
    def register(self, typeID, itemClass):
        if typeID not in self.mItemClasses:
            self.mItemClasses[typeID] = itemClass
            m = __import__("item")
            setattr(m, "Item%s" % (typeID), itemClass)
        else:
            syserr("重复注册道具类：%s:%s" % (typeID, itemClass))
            
    def getClass(self, typeID):
        if name in self.mItemClasses:
            return self.mItemClasses[typeID]
        else:
            syserr("未注册道具类：%s" % (typeID))
            return None
            
    def createItem(self, typeID):
        itemClass = self.mItemClasses.get(typeID)
        if itemClass:
            return itemClass()
        else:
            syserr("未注册道具类：%s" % (typeID))
            return None
        
gItemMgr = ItemManager()

