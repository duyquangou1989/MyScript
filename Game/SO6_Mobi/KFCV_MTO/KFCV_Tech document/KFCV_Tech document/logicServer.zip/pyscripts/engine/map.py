#coding=utf8

import MMap

class Map(MMap.MapProxy):
    def __init__(self):
        MMap.MapProxy.__init__(self)
        