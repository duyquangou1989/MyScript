#coding=utf8

import MShop

class Shop(MShop.ShopProxy):
    def __init__(self):
        MShop.ShopProxy.__init__(self)
        
    def __del__(self):
        pass
    