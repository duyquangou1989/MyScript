#coding=utf8

import MDungeon

DA_Animation         = 1
DA_Fight             = 2
DA_Box               = 3

class Dungeon(MDungeon.DungeonProxy):
    def __init__(self):
        MDungeon.DungeonProxy.__init__(self)
        
    
    