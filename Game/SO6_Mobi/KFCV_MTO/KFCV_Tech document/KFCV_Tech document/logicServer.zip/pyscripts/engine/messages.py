#coding=utf8

# 服务器通知
MSG_TIME_SECOND         = 1         # 服务器每秒通知，param0为当前服务器帧，param1为当前服务器运行时间（单位毫秒）
MSG_TIME_MINUTE         = 2         # 服务器每分钟通知，param0为当前服务器帧，param1为当前服务器运行时间（单位毫秒）
MSG_SERVER_STARTUP      = 3         # 服务器启动完毕
MSG_RELOAD_CONFIG       = 4         # 重新读取配置文件，param0为目标目录，param1为上次目录
MSG_DAY_CHANGED         = 5         # 服务器天发生变化了
MSG_ACTIVITY_STARTOVER  = 6         # 活动初始化完毕（活动配置Load完成）
MSG_SERVER_SHUTDOWN     = 7         # 服务器即将关闭通知

# 玩家消息
MSG_PLAYER_CREATED                  = 100       # 新玩家创建，param0为玩家对象，param1为空
MSG_PLAYER_ONLINE                   = 101       # 玩家上线，param0为玩家对象，param1为空
MSG_PLAYER_OFFLINE                  = 102       # 玩家下线，param0为玩家对象，param1为空
MSG_PLAYER_LEVELUP                  = 103       # 玩家升级，param0为玩家对象，param1为空
MSG_PLAYER_DAY_CHANGED              = 104       # 玩家天变化，param0为玩家对象，param1为空

MSG_PLAYER_VIPLEVEL_CHANGED         = 105       # 玩家VIP等级变化，Param0为玩家对象，param1为上次vip等级

MSG_PLAYER_MONEY_CHANGED            = 106       # 玩家银币变化，Param0为玩家对象，Param1为变化值
MSG_PLAYER_GOLDMONEY_CHANGED        = 107       # 玩家金币变化，Param0为玩家对象，Param1为（变化值，GoldMoneyChangedWay）
MSG_PLAYER_ENERGY_CHANGED           = 108       # 玩家真气变化，Param0为玩家对象，Param1为变化值
MSG_PLAYER_SPAR_CHANGED             = 109       # 玩家晶石变化，Param0为玩家对象，Param1为变化值

MSG_PLAYER_TRAIN_ROLE               = 110       # 玩家角色培养，param0为玩家对象，param1为培养的角色

MSG_PLAYER_ENTER_MAP                = 111       # 玩家进入地图，param0为玩家对象，param1为地图对象
MSG_PLAYER_LEAVE_MAP                = 112       # 玩家离开地图，param0为玩家对象，param1为地图对象
MSG_PLAYER_ENTER_DUNGEON            = 113       # 玩家进入副本，param0为玩家对象，param1为副本对象
MSG_PLAYER_LEAVE_DUNGEON            = 114       # 玩家离开副本，param0为玩家对象，param1为副本对象
MSG_PLAYER_FINISH_DUNGEON           = 115       # 玩家通关副本，param0为玩家对象，param1为(副本对象, 星)

MSG_PLAYER_DROP_ITEM                = 116       # 玩家分解道具，param0为玩家对象，param1为(道具类型，道具子类型，道具个数)
MSG_PLAYER_EXCHANGE_ITEM            = 117       # 玩家兑换道具，param0为玩家对象，param1为购买的道具
MSG_PLAYER_EQUIP_ITEM               = 118       # 玩家装备道具，param0为玩家对象，param1为(角色对象，道具对象)
MSG_PLAYER_STRENGTHEN_ITEM          = 119       # 玩家强化道具，param0为玩家对象，param1为道具对象
MSG_PLAYER_COMBINE_ITEM             = 120       # 玩家合成道具，param0为玩家对象，param1为合成后道具对象

MSG_PLAYER_ENTER_ARENA              = 121       # 玩家进入竞技场，param0为玩家对象，param1为（自己原来的名次，自己当前名次，是否胜利，对方名字）
MSG_PLAYER_GOT_ARENA_REWARD         = 122       # 玩家获得竞技场奖励，param0为玩家对象，param1为（自己当前名次，获得铜钱，获得声望）

MSG_PLAYER_JOIN_GUILD               = 123       # 玩家加入公会，param0为玩家对象，param1为公会对象
MSG_PLAYER_QUIT_GUILD               = 124       # 玩家离开公会，param0为玩家对象，param1为公会对象
MSG_PLAYER_GUILD_DESTROY            = 125       # 公会销毁，param0为最后一个退出公会的玩家对象，param1为公会对象
MSG_PLAYER_DONATE_GUILD             = 126       # 玩家公会建设，param0为玩家对象，param1为贡献度

MSG_PLAYER_BATTLEPOINT_CHANGED      = 127       # 玩家战斗力发生改变，param0为玩家对象，param1为战斗力

MSG_PLAYER_RANDOM_OTHER             = 128       # 玩家抽命运，param0为玩家对象，param1为（道具类型，道具子类型，道具数量）
MSG_PLAYER_RANDOM_ITEM              = 129       # 玩家抽同伴，param0为玩家对象，param1为（角色ID，是否重复）

MSG_PLAYER_ITEM_UPGRADE             = 130       # 道具升级，param0为玩家对象，param1为道具对象
MSG_PLAYER_ITEM_ADVANCE             = 131       # 道具进阶，param0为玩家对象，param1为道具对象

MSG_PLAYER_SKILL_UPGRADE            = 132       # 技能升级，param0为玩家对象，param1为技能对象
MSG_PLAYER_SKILL_ADVANCE            = 133       # 技能进阶，param0为玩家对象，param1为技能对象

MSG_PLAYER_TALENT_UPGRADE           = 134       # 心法升级，param0为玩家对象，param1为心法对象
MSG_PLAYER_TALENT_ADVANCE           = 135       # 心法进阶，param0为玩家对象，param1为心法对象

MSG_PLAYER_FINISH_TASK              = 136       # 完成任务，param0为玩家对象，param1为任务ID
MSG_PLAYER_FINISH_DAILY_TASK        = 137       # 完成日常，param0为玩家对象，param1为日常ID

MSG_PLAYER_STONE_USE                = 138       # 镶嵌宝石，param0为玩家对象，param1为道具对象
MSG_PLAYER_STONE_COMBINE            = 139       # 合成宝石，param0为玩家对象，param1为合成后道具对象

MSG_PLAYER_PET_INVOKE               = 140       # 解锁宠物，param0为玩家对象，param1为宠物对象
MSG_PLAYER_PET_UPGRADE              = 141       # 升级宠物，param0为玩家对象，param1为合成后宠物对象
MSG_PLAYER_PET_ADVANCE              = 142       # 进阶宠物，param0为玩家对象，param1为合成后宠物对象

MSG_PLAYER_SINGLE_PVP               = 143       # 单人pvp，param0为玩家对象
MSG_PLAYER_SINGLE_BOSS              = 144       # 单人boss，param0为玩家对象
MSG_PLAYER_MULT_BOSS                = 145       # 多人boss，param0为玩家对象
MSG_PLAYER_BUY_MONEY                = 146       # 金币兑换，param0为玩家对象，param1为（金币数量，钻石数量）
MSG_PLAYER_LOTTERY                  = 147       # 抽奖，param0为玩家对象，param1为抽奖类型（0=道具，1=其他
MSG_PLAYER_ADD_FRIEND               = 148       # 添加好友，param1为玩家对象，param1为好友对象
MSG_PLAYER_TRAIN_ADVANCE            = 149       # 筋脉突破，param1为玩家对象

MSG_BATTLEGAME_GAME_STARTED         = 150       # 实时战斗游戏正式开始，param0为游戏索引，param1为空
MSG_BATTLEGAME_GAME_START_FAILED    = 151       # 实时战斗游戏开启失败，param0为游戏索引，param1为结果（int）
MSG_BATTLEGAME_GAME_FINISHED        = 152       # 实时战斗游戏正式结束，param0为游戏索引，param1为空
MSG_BATTLEGAME_GAME_DATA_SYNC       = 153       # 实时战斗数据同步，param0为游戏索引，param1为具体数据（json格式）
MSG_BATTLEGAME_PLAYER_JOINED        = 154       # 实时战斗玩家加入战斗，param0为游戏索引，param1为列表（玩家UUID，结果）
MSG_BATTLEGAME_PLAYER_DEAD          = 155       # 实时战斗玩家死亡，param0为游戏索引，param1为玩家UUID
MSG_BATTLEGAME_PLAYER_QUIT          = 156       # 实时战斗玩家主动退出，param0为游戏索引，param1为列表（玩家UUID，结果，剩余血量（列表（职业，百分比）））
MSG_BATTLEGAME_ACTOR_DEAD           = 157       # 实时战斗玩家角色死亡，param0为游戏索引，param1为列表（玩家UUID，击杀者UUID， 角色职业）
MSG_BATTLEGAME_PLAYER_REVIVE        = 158       # 实时战斗玩家复活，param0为游戏索引，param1为列表（玩家UUID，结果）
MSG_BATTLEGAME_PLAYER_NEED_REVIVE   = 159       # 实时战斗玩家需要复活，param0为游戏索引，param1为玩家UUID
MSG_BATTLEGAME_PLAYER_REQUEST_REVIVE= 160       # 实时战斗玩家申请复活，param0为游戏索引，param1为列表（玩家UUID，剩余时间）
MSG_BATTLEGAME_PLAYER_BUFF          = 161       # 实时战斗玩家添加buff结果，param0为游戏索引，param1为列表（玩家UUID，buffid，结果）

# 以下为Python中发起的消息
MSG_PLAYER_JOIN_BOSSBATTLE          = 1001      # 玩家参加BOSS战，param0为玩家对象，param1为bossID
MSG_PLAYER_JOIN_INDIANAJONES        = 1002      # 玩家参加夺宝奇兵，param0为玩家对象，param1为空
MSG_PLAYER_JOIN_KINGLEAGUE          = 1003      # 玩家参加王者争霸，param0为玩家对象，param1为空
MSG_PLAYER_JOIN_RICHMAN             = 1004      # 玩家参加勇者游戏，param0为玩家对象，param1为空
MSG_PLAYER_JOIN_EIGHTEEN            = 1005      # 玩家参加十八摸，param0为玩家对象
MSG_PLAYER_JOIN_ESCORT              = 1006      # 玩家参加护送活动，param0为玩家对象
MSG_PLAYER_JOIN_PLUDER              = 1007      # 玩家参加掠夺活动，param0为玩家对象
MSG_PLAYER_REFRESH_SPARSHOP         = 1008      # 玩家刷新神秘商店，param0为玩家对象
MSG_PLAYER_PLUNDER_COMBINE          = 1009      # 玩家在掠夺活动中合成道具
# GoldMoneyChangedWay
GMCW_Unknown                = 0     # 无效
GMCW_Dungeon                = 1     # 副本
GMCW_Pay                    = 2     # 充值
GMCW_PayFromGift            = 3     # 礼包充值
GMCW_Gift                   = 4     # 礼包（非充值）
GMCW_Activity               = 5     # 活动

GMCW_BuyItem                = 6     # 购买道具（商店）
GMCW_BuyVitality            = 7     # 购买体力
GMCW_BuyMoney               = 8     # 招财神符
GMCW_BuyPractice            = 9     # 加速打坐
GMCW_BuyArenaPoint          = 10    # 购买竞技场点数
GMCW_BuyBagNum              = 11    # 购买背包数量

GMCW_UpgradeDivinationStage = 12    # 直接升级占卜阶段
GMCW_ResetHeroDungeon       = 13    # 重置英雄副本
GMCW_CombineItem            = 14    # 合成道具
GMCW_CombineItemAllInOne    = 15    # 合成道具（直接用金币）
GMCW_PetSkillRefresh        = 16    # 宠物刷新技能
GMCW_PetPassiveSkillRefresh = 17    # 宠物刷新被动技能
GMCW_PetTrain               = 18    # 宠物培养
GMCW_RoleTrain              = 19    # 培养角色
GMCW_GoldMoneyUse			= 100	# 元宝消耗