#coding=utf8

import MMain
import copy
from traceback import print_exc
from messages import *
from os import path

class Engine:
    def __init__(self):
        syslog("Start game module manager...")
        
        self.mModules = {}
        self.mTextProtocols = {}
        self.mActivities = {}       # 特殊活动

        self.mStrings = []
        self.loadStrings()

        import __builtin__
        __builtin__.getModuleData = self.getModuleData
        __builtin__.setModuleData = self.setModuleData
        __builtin__.GlobalStrings = self.mStrings
        
    def loadStrings(self):
        filename = "settings/strings.svr.txt"
        stringFile = open(filename, "r")
        lines = stringFile.readlines()
        stringFile.close()

        for line in lines:
            editedLine = line.replace("\n", "")
            editedLine = editedLine.replace("\\r", "")
            editedLine = editedLine.replace("\r", "")
            editedLine = editedLine.replace("\\n", "\r\n")
            editedLine = editedLine.replace("\\t", "\t")
            self.mStrings.append(editedLine)

        syslog("Strings loaded.")

    def register(self, moduleID, gameModule, msgs, overwrite=False):
        if isinstance(msgs, type([])) or isintance(msgs, type(())):
            
            if overwrite or (moduleID not in self.mModules):
                self.mModules[moduleID] = [
                    msgs,
                    gameModule,
                ]
                syslog("Register game module %s ok." % (moduleID))
            else:
                syserr("Register game module %s failed. Module id is already exists[%s]." % (moduleID, self.mModules[moduleID][1]))
        else:
            syserr("Register module %s failed. Message type error[%s]." % (moduleID, type(msgs)))

    def registerActivity(self, activityIdenfityID, gameModule, overwrite=False):
        if overwrite or (activityIdenfityID not in self.mActivities):
            self.mActivities[activityIdenfityID] = gameModule
            syslog("Register activity module %s ok." % (activityIdenfityID))
        else:
            syserr("Register activity module %s failed. Module id is already exists[%s]." % (activityIdenfityID, self.mModules[activityIdenfityID]))

    def registerTextProtocol(self, protocolName, callback, overwrite=False):
        if overwrite or protocolName not in self.mTextProtocols:
            self.mTextProtocols[protocolName] = callback
            return True
        else:
            syserr("Register text protocol failed. Protocol name [%s] is already exists." % (protocolName))
            return False

    def invokeTextProtocol(self, player, protocolName, data):
        if protocolName in self.mTextProtocols:
            try:
                self.mTextProtocols[protocolName](player, data)
            except:
                syserr("Invoke text protocol [%s] callback failed." % (protocolName))
                print_exc()
        else:
            syserr("Invalid text protocol [%s]." % (protocolName))
            
    def moduleFilter(self, msg):
        result = []
        for moduleID in self.mModules:
            if msg in self.mModules[moduleID][0]:
                result.append(self.mModules[moduleID][1])
                
        return result

    def invoke(self, msg, param0, param1):
        for gameModule in self.moduleFilter(msg):
            try:
                gameModule.invoke(msg, param0, param1)
            except:
                print_exc()

        if msg == MSG_PLAYER_ONLINE:
            player = param0
            actID = self.checkActivity()

            if actID > 0:
                self.sendActivityIdentifyID(actID, True, True, player)
            
    def getMenu(self, player, npcID):
        menuItems = []
        for moduleID in self.mModules:
            gameModule = self.mModules[moduleID][1]
            try:
                menuItem = gameModule.getMenu(player, npcID)
                if type(menuItem) == type(()) or type(menuItem) == type([]):
                    menuItems.extend(menuItem)
            except:
                syserr("Get menu failed.")
                print_exc()
                    
        player.t_CurMenuItems = menuItems
        player.t_CurMenuNpcID = npcID        
        return menuItems
    
    def clickMenu(self, player, menuItemIndex):
        if "t_CurMenuItems" in player.__dict__ and "t_CurMenuNpcID" in player.__dict__:
            menuItems = player.t_CurMenuItems
            if menuItemIndex >= 0 and menuItemIndex < len(menuItems):
                menuFunc = menuItems[menuItemIndex][1]
                if menuFunc:
                    npcID = player.t_CurMenuNpcID
                    player.t_CurMenuItems = []
                    player.t_CurMenuNpcID = 0
                    
                    menuFunc(player, npcID)
                return True
        else:
            return False
        
    def getModuleData(self, player, moduleID, default=None):
        if "s_ModuleData" not in player.__dict__:
            player.s_ModuleData = {}

        if moduleID not in player.s_ModuleData:
            if default:
                player.s_ModuleData[moduleID] = copy.deepcopy(default)
            else:
                player.s_ModuleData[moduleID] = {}

        return player.s_ModuleData[moduleID]

    def setModuleData(self, player, moduleID, data):
        if "s_ModuleData" not in player.__dict__:
            player.s_ModuleData = {}

        player.s_ModuleData[moduleID] = copy.deepcopy(data)

    def checkActivity(self):
        resultID = 0
        for activityIdenfityID in self.mActivities:
            gameModule = self.mActivities[activityIdenfityID] 
            try:
                if gameModule.isActived():
                    resultID = activityIdenfityID
                    break
            except:
                print_exc()
        return resultID

    def sendActivityIdentifyID(self, identifyID, isOpened = True, isFirstOnline = False, player = None):
        response = []
        response.append(identifyID)
        if isOpened:
            response.append(1)
        else:
            response.append(0)
        if isFirstOnline:
            response.append(1)
        else:
            response.append(0)

        if not player:
            players = MMain.getAllPlayers()
            for tmpPlayer in players:
                clientID = tmpPlayer.getClientID()
                if clientID != -1:
                    MMain.sendTextProtocol(tmpPlayer, "S2C_ActivityIdentifyID", response)
        else:
            MMain.sendTextProtocol(player, "S2C_ActivityIdentifyID", response)

    def cfgPathReplaceSettingsWith(self, orgpath, newDir):
        if orgpath[:9]=='settings/' or orgpath[:9]=='settings\\':
            newpath = newDir+""+orgpath[8:]
            if path.exists(newpath):
                return newpath
            return None
        else:
            print "警告：配置文件不是以settings开头", orgpath
        return orgpath
        
Instance = Engine()
