#coding=utf8

import MPet

class Pet(MPet.PetProxy):
    def __init__(self):
        MPet.PetProxy.__init__(self)

    def __del__(self):
        pass
    
    def onLoad(self, data):
        for k in data:
            setattr(self, k, data[k])
            
    def onSave(self):
        result = {}
        for k in self.__dict__:
            if k.startswith("s_"):
                result[k] = getattr(self, k)
        return result

