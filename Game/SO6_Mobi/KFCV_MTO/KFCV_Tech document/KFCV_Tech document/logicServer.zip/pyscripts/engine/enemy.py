#coding=utf8

import MEnemy

class Enemy(MEnemy.EnemyProxy):
    def __init__(self):
        MEnemy.EnemyProxy.__init__(self)
        