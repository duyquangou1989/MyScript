#coding=utf8

# 列表相加
vec_add = lambda a,b : list([x+y for x,y in zip(a,b)])

# "1,2,3" => [1,2,3]
def loadStrToVec(strTableValue):
    strs = strTableValue.split(',')
    strList = []
    for str in strs:
        strList.append(int(str))

    return strList