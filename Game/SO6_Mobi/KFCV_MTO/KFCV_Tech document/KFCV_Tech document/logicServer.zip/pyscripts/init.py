#coding=utf8
import time
import __builtin__

class Logger:
    def __init__(self):
        pass
    
    def log(self, msg):
        t = time.localtime()
        try:
            print "[%04d-%02d-%02d %02d:%02d:%02d][ LOG ][Python] %s" % (
                t.tm_year,
                t.tm_mon,
                t.tm_mday,
                t.tm_hour,
                t.tm_min,
                t.tm_sec,
                msg
            )
        except:
            print "[%04d-%02d-%02d %02d:%02d:%02d][ERROR][Python] Log msg type error." % (
                t.tm_year,
                t.tm_mon,
                t.tm_mday,
                t.tm_hour,
                t.tm_min,
                t.tm_sec,
            )
            
    def err(self, msg):
        t = time.localtime()
        try:
            print "[%04d-%02d-%02d %02d:%02d:%02d][ERROR][Python] %s" % (
                t.tm_year,
                t.tm_mon,
                t.tm_mday,
                t.tm_hour,
                t.tm_min,
                t.tm_sec,
                msg
            )
        except:
            print "[%04d-%02d-%02d %02d:%02d:%02d][ERROR][Python] Log msg type error." % (
                t.tm_year,
                t.tm_mon,
                t.tm_mday,
                t.tm_hour,
                t.tm_min,
                t.tm_sec,
            )
            
            
gLogger = Logger()
__builtin__.syslog = gLogger.log
__builtin__.syserr = gLogger.err

import engine
import initmodules
