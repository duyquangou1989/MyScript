#coding=utf8

import engine
import MMain
import sys
import time
import json
import random

from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

RED_GOLD980      = 980
RED_GOLD1880     = 1880
RED_GOLD5880     = 5880

class ChargeBonus(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.InitData = {}
        self.mRedType = []
        self.mGloble = {}
        self.mLRedID = []
        self.mRedID = 0

    def getName(self):
        return "ChargeBonus"

    def isActived(self, player):      
        return True

    def getInfo(self, player):
        result = {}
        return json.dumps(result)

    def doAction(self, player, actData):
        actData = json.loads(actData)
        idx = actData["Get"]
        if idx in self.mGloble:
            red = self.mGloble[idx]
            redlist = red[1]
            if player.getName() in red[2]:
                return Err_Repetition
            else:
                rtype = red[0]
                m = random.randint(0,len(redlist) - 1)
                value = redlist[m]
                reward = [rtype, value,]
                self.addReward(player, reward)
                red[2].append(player.getName())
                return json.dumps({
                    "Result": 1,
                    "ResultDesc": "",
                    "Action": "Get",
                    "Name": red[3],
                    "Reward": [rtype, value],
                })
        else:
            return json.dumps({"Result":12, "ResultDesc":GlobalStrings[36]})

    def doChargebonus(self,player,goldMoney):
        redP = -1
        for idx in self.mRedType:
            redP = idx
            if goldMoney > idx:
                break
        if redP != -1:
            if redP in self.InitData:
                playerName = player.getName()
                redID = self.mRedID
                self.mRedID += 1                
                redType = self.InitData[redP][0]
                redTotal = self.InitData[redP][1]
                redNum = self.InitData[redP][2]

                redlist = []
                for i in xrange(redNum):
                    if i == redNum - 1:
                        m = redTotal
                    else:
                        m = random.randint(1, (int)(redTotal - (redNum - i - 1)) / (redNum - i) * 2)
                    redTotal -= m
                    redlist.append(m)
                print "bonus content:%s" % redlist
                RedIdNum = len(self.mLRedID)
                while RedIdNum > 20:
                    delid = self.mLRedID[0]
                    if delid in self.mGloble:
                        del self.mGloble[delid]
                    del self.mLRedID[0]
                    RedIdNum = len(self.mLRedID)

                self.mGloble[redID] = [redType, redlist, [], playerName,time.time()]
                self.mLRedID.append(redID)

                msg1 = GlobalStrings[37] % (playerName, goldMoney)
                MMain.sendHorseMessage(msg1)

                allPlayers = MMain.getAllPlayers()
                for tmpPlayer in allPlayers:
                    clientID = tmpPlayer.getClientID()
                    if clientID != -1:
                        response = (self.mID, 1, playerName, redID, goldMoney)
                        MMain.sendTextProtocol(tmpPlayer, "S2C_ChargeActivity1", response)

    def loadConfig(self, path):
        rewardsFilename = "%schargebonus.txt" % (path)
        tb = TabFile()
        if tb.load(rewardsFilename):
            initdata = {}
            redType = []
            for i in xrange(tb.mRowNum):
                chargeType = tb.get(i, 0, 0, True)
                rewardType = tb.get(i, 1, 0, True)
                rewardTotal = tb.get(i, 2, 0, True)
                bonusNum = tb.get(i, 3, 0, True)
                redType.append(chargeType)
                initdata[chargeType] = (rewardType, rewardTotal, bonusNum)
            self.InitData = initdata
            self.mRedType = redType
            return True
        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_DAY_CHANGED:
            self.mGloble = {}

        elif msg == MSG_PLAYER_GOLDMONEY_CHANGED:
            player = param0
            goldMoney, payWay, productId = param1
            if payWay == 2:
                if productId != "sl_tw_zsk_150" and productId != "sl_tw_yk_300" and productId != "sl_tw_zsk_2090" and productId != "sl_tw_520":
                    self.doChargebonus(player,goldMoney)

    def getMenu(self, player, npcID):
        return []

ModuleID = 41
Instance = ChargeBonus(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_DAY_CHANGED,
    MSG_PLAYER_GOLDMONEY_CHANGED,
])
