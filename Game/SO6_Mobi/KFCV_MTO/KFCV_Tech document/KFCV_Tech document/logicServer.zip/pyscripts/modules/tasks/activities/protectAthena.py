#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

OPENLEVEL                   = 1
COUNTPERDAY                 = 3

class ProtectAthena(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mAthena = []

    def isActived(self, player):
        if player.getLevel() >= OPENLEVEL:
            if "s_ProtectAthena" not in player.__dict__:
                player.s_ProtectAthena = COUNTPERDAY

            return True
        else:
            return False

    def getName(self):
        return "ProtectAthena"

    def getInfo(self, player):
        if self.isActived(player):
            info = {}
            info["Result"] = 1
            info["DungeonID"] = self.mAthena
            info["ResetCount"] = player.s_ProtectAthena

            friends = MMain.getFriends(player.getName())
            num = 0
            tempfr = []
            for name in friends:
                targetPlayer = MMain.getPlayerByName(name)
                if targetPlayer:
                    level = targetPlayer.getLevel()
                    battlePoint = targetPlayer.getBattlePoint()
                    tempfr.append((name, level, battlePoint))
                    num += 1
                    if num == 5:
                        break
            info["FiveFriends"] = tempfr
            return json.dumps(info)
        else:
            return Err_NotOpen

    def getCount(self, player):
        if self.isActived(player):
            return player.s_ProtectAthena
        return 0

    def doAction(self, player, actData):
        if self.isActived(player):
            actData = json.loads(actData)
            action = actData["ProtectAthena"]

            if player.s_ProtectAthena > 0:
                return Err_Ok
            else:
                return Err_NotEnoughCount

    def loadConfig(self, path):
        filename = "%sprotectathena.txt" % (path)
        tb = TabFile()
        if tb.load(filename):
            athena = []
            for i in xrange(tb.mRowNum):
                level                           = tb.get(i, 0, 0, True)
                dungeonID                       = tb.get(i, 1, 0, True)

                athena.append((level, dungeonID))
            self.mAthena = athena
            return True
        else:
            syserr("Loading PvE Config failed...")
            return False

    def checkHasReward(self, player):
        pass

    def addPoint(self, player):
        if self.isActived(player):
            player.s_ProtectAthena += 1
            return True
        else:
            return False

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_LEVELUP:
            player = param0
            level = player.getLevel()
            if level == OPENLEVEL:
                if self.isActived(player):
                    response = (
                            self.mID
                        )
                    MMain.sendTextProtocol(player, "S2C_NotifyActOpen", response)

        elif msg == MSG_PLAYER_DAY_CHANGED:
            player = param0

            if self.isActived(player):
                player.s_ProtectAthena = COUNTPERDAY

        elif msg == MSG_PLAYER_FINISH_DUNGEON:
            player = param0
            dungeon, star, costTime = param1
            dungeonID = dungeon.getID()

            if self.isActived(player):
                for i in self.mAthena:
                    if i[1] == dungeonID:
                        if player.s_ProtectAthena > 0:
                            player.s_ProtectAthena -= 1
                        break

    def getMenu(self, player, npcID):
        return []

ModuleID = 9
Instance = ProtectAthena(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_LEVELUP,
    MSG_PLAYER_DAY_CHANGED,
    MSG_PLAYER_FINISH_DUNGEON,    
])
