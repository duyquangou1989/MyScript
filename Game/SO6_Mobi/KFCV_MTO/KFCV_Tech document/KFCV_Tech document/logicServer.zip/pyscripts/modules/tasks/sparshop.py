#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
import bisect
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

WEIGHT1 = 5  # 权重1的商品个数
WEIGHT2 = 2
WEIGHT3 = 1

INDEX_IDX               = 0
INDEX_REWARD_VALUE      = 1
INDEX_PRICE_TYPE        = 2
INDEX_PRICE             = 3
INDEX_WEIGHT            = 4
INDEX_RATE              = 5
INDEX_LIMIT_UPPER       = 6
INDEX_LIMIT_LOWER       = 7
INDEX_LIMIT_LEVEL       = 8
INDEX_NEEDMSG           = 9

class SparShop(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        
        self.mID = moduleID

        self.mTableData = []
        self.mRefreshPrice = 10

        engine.Instance.registerTextProtocol("C2S_SparShop", self.onProtocol)

    def getName(self):
        return "SparShop"
        
    def checkPlayerData(self, player):
        if not "s_sparshop" in player.__dict__:
            player.s_sparshop=[0,#刷新次数              0
                                {},#已经购买的物品      1
                                [],#当前神秘商店物品    2
                                ]
    def isOpened(self):
        return True

    def buildInitData(self, player):
        playerLevel = player.getLevel()
        refreshCount = player.s_sparshop[0]
        buyCount = player.s_sparshop[1]
        player.s_sparshop[2] = []
        randomlist1 = []
        randomlist2 = []
        randomlist3 = []
        randomitem1 = []
        randomitem2 = []
        randomitem3 = []
        randbase1 = 0
        randbase2 = 0
        randbase3 = 0
        for reward in self.mTableData:
            if reward[INDEX_LIMIT_LEVEL] <= playerLevel and reward[INDEX_LIMIT_LOWER] <= refreshCount:
                if reward[INDEX_LIMIT_UPPER] == -1 or reward[INDEX_LIMIT_UPPER] > buyCount.get(reward[INDEX_IDX], 0):
                    if reward[INDEX_WEIGHT] == 1:                        
                        randbase1 += reward[INDEX_RATE]
                        randomlist1.append(randbase1)
                        randomitem1.append(reward)
                    if reward[INDEX_WEIGHT] == 2:
                        randbase2 += reward[INDEX_RATE]
                        randomlist2.append(randbase2)
                        randomitem2.append(reward)
                    if reward[INDEX_WEIGHT] == 3:
                        randbase3 += reward[INDEX_RATE]
                        randomlist3.append(randbase3)
                        randomitem3.append(reward)
        # weight 1
        for i in xrange(WEIGHT1):
            thisrand = random.randint(0, randbase1)
            idx = bisect.bisect_left(randomlist1, thisrand)
            randitem = randomitem1[idx]
            buyCount[randitem[INDEX_IDX]] = buyCount.get(randitem[INDEX_IDX], 0) + 1

            if randitem[INDEX_LIMIT_UPPER] != -1 and randitem[INDEX_LIMIT_UPPER] <= buyCount.get(randitem[INDEX_IDX], 0):
                randomlist1.pop(idx)
                randomitem1.pop(idx)
                #重新构造随机列表
                randbase1 = 0
                randomlist1 = []
                for itr in randomitem1:
                    randbase1 += itr[INDEX_RATE]
                    randomlist1.append(randbase1)
            player.s_sparshop[2].append(randitem)
        # weight 2
        for i in xrange(WEIGHT2):
            thisrand = random.randint(0, randbase2)
            idx = bisect.bisect_left(randomlist2, thisrand)
            randitem = randomitem2[idx]

            buyCount[randitem[INDEX_IDX]] = buyCount.get(randitem[INDEX_IDX], 0) + 1

            if randitem[INDEX_LIMIT_UPPER] != -1 and randitem[INDEX_LIMIT_UPPER] <= buyCount.get(randitem[INDEX_IDX], 0):
                randomlist2.pop(idx)
                randomitem2.pop(idx)
                #重新构造随机列表
                randbase2 = 0
                randomlist2 = []
                for itr in randomitem2:
                    randbase2 += itr[INDEX_RATE]
                    randomlist2.append(randbase2)
            player.s_sparshop[2].append(randitem)          
        # weight 3
        for i in xrange(WEIGHT3):
            thisrand = random.randint(0, randbase3)
            idx = bisect.bisect_left(randomlist3, thisrand)
            randitem = randomitem3[idx]

            buyCount[randitem[INDEX_IDX]] = buyCount.get(randitem[INDEX_IDX], 0) + 1

            if randitem[INDEX_LIMIT_UPPER] != -1 and randitem[INDEX_LIMIT_UPPER] <= buyCount.get(randitem[INDEX_IDX], 0):
                randomlist3.pop(idx)
                randomitem3.pop(idx)
                #重新构造随机列表
                randbase3 = 0
                randomlist3 = []
                for itr in randomitem3:
                    randbase3 += itr[INDEX_RATE]
                    randomlist3.append(randbase3)
            player.s_sparshop[2].append(randitem)

    def getInfo(self, player):

        data = player.s_sparshop[2]
        
        info = {}
        rewards = []
        for reward in data:
            rewards.append((
                reward[INDEX_IDX],
                reward[INDEX_REWARD_VALUE],
                reward[INDEX_PRICE_TYPE],
                reward[INDEX_PRICE],
                reward[INDEX_WEIGHT],
            ))
        info["Rewards"] = rewards
        info["FreeCount"] = player.getBuyNum(4)
        info["RefreshPrice"] = self.mRefreshPrice
        return json.dumps({
            "Result": 1,
            "ResultDesc": "",
            "Action": "info",
            "Info": info,
        })

    def doAction(self, player, actData):
        if not self.isOpened():
            return Err_NotOpen

        data = json.loads(actData)
        pdata = player.s_sparshop[2]

        actionType = data["Action"]
        if actionType == "buy":
            index = data["Index"]
            idx = 0
            for reward in pdata:
                if index == reward[INDEX_IDX]:
                    if reward[INDEX_PRICE_TYPE] == REWARD_TYPE_SPAR:
                        if player.getSpar() < reward[INDEX_PRICE]:
                            return Err_NotEnoughMoney
                    if reward[INDEX_PRICE_TYPE] == REWARD_TYPE_GOLDMONEY:
                        if player.getGoldMoney() < reward[INDEX_PRICE]:
                            return Err_NotEnoughGoldMoney

                    realReward = reward[INDEX_REWARD_VALUE]
                    if self.canAddReward(player, realReward):
                        if reward[INDEX_PRICE_TYPE] == REWARD_TYPE_SPAR:
                            player.addSpar(-reward[INDEX_PRICE])
                            MMain.dbLogActivityUseSpar(player, self.mID, reward[INDEX_PRICE])
                        if reward[INDEX_PRICE_TYPE] == REWARD_TYPE_GOLDMONEY:
                            player.addGoldMoney(-reward[INDEX_PRICE])
                            MMain.dbLogActivityUseGoldMoney(player, self.mID, reward[INDEX_PRICE])

                        self.addReward(player, realReward)
                        if reward[INDEX_NEEDMSG] == 1:
                            message = GlobalStrings[31] % (player.getName(), self.getRewardDesc(realReward))
                            MMain.sendHorseMessage(message)
                        player.s_sparshop[2].pop(idx)
                        player.saveToDB()
                        engine.Instance.invoke(MSG_PLAYER_EXCHANGE_ITEM, player, None)
                        return json.dumps({
                            "Result": 1,
                            "ResultDesc": "",
                            "Action": "buy",
                            "Reward": realReward,
                        })

                    else:
                        return Err_NotEnoughSpace
                
                idx += 1
        elif actionType == "refresh":
            if player.getBuyNum(4) > 0:
                player.addBuyNum(4, -1)
                self.buildInitData(player)
                engine.Instance.invoke(MSG_PLAYER_REFRESH_SPARSHOP, player, None)
                return json.dumps({
                    "Result": 1,
                    "ResultDesc": "",
                    "Action": "refresh",
                })

            else:
                if player.getGoldMoney() < self.mRefreshPrice:
                    return Err_NotEnoughGoldMoney
                engine.Instance.invoke(MSG_PLAYER_REFRESH_SPARSHOP, player, None)
                player.addGoldMoney(-self.mRefreshPrice)
                MMain.dbLogActivityUseGoldMoney(player, self.mID, self.mRefreshPrice)
                player.s_sparshop[0] += 1
                self.buildInitData(player)
                engine.Instance.invoke(MSG_PLAYER_EXCHANGE_ITEM, player, None)
                return json.dumps({
                    "Result": 1,
                    "ResultDesc": "",
                    "Action": "refresh",
                })

        elif actionType == "info":
            return self.getInfo(player)

        else:
            return Err_Unknown

    def onProtocol(self, player, data):
        result = self.doAction(player, data[0])

        response = (result, )
        MMain.sendTextProtocol(player, "S2C_SparShop", response)

    def loadConfig(self, path):
        rewardFilename = "%ssparshop.txt" % (path)

        tb = TabFile()   
        if tb.load(rewardFilename):
            tables = []
            for i in xrange(tb.mRowNum):

                idx = tb.get(i, INDEX_IDX, 0, True)
                rewardValue = tb.get(i, INDEX_REWARD_VALUE, "", False).replace("\\n", "\n").replace("\"", "")
                priceType = tb.get(i, INDEX_PRICE_TYPE, 0, True)
                price = tb.get(i, INDEX_PRICE, 0, True)
                weight = tb.get(i, INDEX_WEIGHT, 0, True)
                rate = tb.get(i, INDEX_RATE, 0, True)
                limitUpper = tb.get(i, INDEX_LIMIT_UPPER, -1, True)
                limitLower = tb.get(i, INDEX_LIMIT_LOWER, 0, True)
                limitLevel = tb.get(i, INDEX_LIMIT_LEVEL, 0, True)
                needMsg = (tb.get(i, INDEX_NEEDMSG, 0, True) == 1)
                
                tmpItem = []
                tmpBlocks = rewardValue.split(";")
                if tmpBlocks:
                    itemBlocks = tmpBlocks[0].split(",")
                    if len(itemBlocks) == 3:
                        tmpItem = (
                            int(itemBlocks[0]),
                            int(itemBlocks[1]),
                            int(itemBlocks[2]),
                        )
                    elif len(itemBlocks) == 2:
                        tmpItem = (
                            int(itemBlocks[0]),
                            int(itemBlocks[1]),
                        )

                rewardValue = tmpItem

                tables.append((
                    idx,
                    rewardValue,
                    priceType,
                    price,
                    weight,
                    rate,
                    limitUpper,
                    limitLower,
                    limitLevel,
                    needMsg,
                ))

            self.mTableData = tables
        else:
            syserr("Loading %s failed." % (rewardFilename))
            return False

        return True

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)
            
        elif msg == MSG_PLAYER_CREATED:
            player = param0
            self.checkPlayerData(player)
            if self.isOpened():
                self.buildInitData(player)
                    
        elif msg == MSG_PLAYER_DAY_CHANGED:
            player = param0
            self.checkPlayerData(player)
            player.s_sparshop[0] = 0
            player.s_sparshop[1] = {}

    def getMenu(self, player, npcID):
        return []

ModuleID = 3
Instance = SparShop(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_DAY_CHANGED,
    MSG_PLAYER_CREATED,
])
