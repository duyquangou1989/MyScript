# coding=utf-8
import engine
import MMain
import sys
import time
import json
import random
import bisect
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

STARTTIME = 480
ENDTIME = 1410
MAXOPENNUM = 3
MAXJOINTIME = 2
OPENACTIVITYMONEY = 298
DOUBLEREWARDCOUNSUME = 20
OPENSTAMP = 60*60

class GuildDungeon(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        self.mID = moduleID
        self.InitDungeonReward = {}
        self.InitActivityReward = {}
        self.GlobalData = {}
        self.mdictEndTime = {}

    def getName(self):
        return "GuildDungeon"

    def isActived(self, player):
        return True
         
    def isOpened(self):
        CurTime = time.localtime()
        CurMTime = CurTime.tm_hour * 60 + CurTime.tm_min
        if CurMTime >= STARTTIME and CurMTime <= ENDTIME:
            return True
        else:
            return False

    #def getMinute(self):
    #    CurTime = time.localtime()
    #    CurMTime = CurTime.tm_hour * 60 + CurTime.tm_min
    #    return CurMTime

    def getSeconds(self):
        return int(time.time())

    def getInfo(self , player):
        playerName = player.getName()
        guildName = player.getGuildName()
        guild = MMain.getGuildByName(guildName)
        if guild:
            guildLevel = guild.getLevel()
            guildMaster = guild.getMasterName()
            guildMember = guild.getMember(playerName)
            if guildMember:
                if self.isOpened():
                    gdInfo = {}
                    dunConfig = []
                    for dungeonid in self.InitDungeonReward:
                        data = self.InitDungeonReward[dungeonid]
                        dunConfig.append((dungeonid,data[0],data[1]))

                    gdInfo["rewards"] = self.InitActivityReward[guildLevel]
                    gdInfo["dungeon"] = dunConfig
                    gdInfo["openMoney"] = OPENACTIVITYMONEY
                    gdInfo["doubleMoney"] = DOUBLEREWARDCOUNSUME

                    if guildName in self.GlobalData:
                        guildData = self.GlobalData[guildName]
                        if guildData[0] == 0 and guildMaster == playerName:
                            gdInfo["openMoney"] = 0

                        if guildData[2] > 0:
                            gdInfo["guildContribute"] = guildData[4]
                            gdInfo["isOpen"] = ((guildData[2] - self.getSeconds())/60 + 1)#guildData[2] - self.getMinute()
                            if playerName in guildData[3]:
                                playerData = guildData[3][playerName]
                                gdInfo["jointime"] = (MAXJOINTIME - playerData[0],MAXJOINTIME)
                                gdInfo["myContribute"] = playerData[1]
                            else:
                                gdInfo["myContribute"] = 0
                                gdInfo["jointime"] = (MAXJOINTIME,MAXJOINTIME)
                        else:
                            gdInfo["guildContribute"] = 0
                            gdInfo["myContribute"] = 0
                            gdInfo["jointime"] = (MAXJOINTIME,MAXJOINTIME)
                            gdInfo["isOpen"] = 0
                    else:
                        if guildMaster == playerName:
                            gdInfo["openMoney"] = 0
                        gdInfo["guildContribute"] = 0
                        gdInfo["myContribute"] = 0
                        gdInfo["jointime"] = (MAXJOINTIME,MAXJOINTIME)
                        gdInfo["isOpen"] = 0
                    gdInfo["Result"] = 0
                    return json.dumps(gdInfo)
                else:
                    return json.dumps({"Result":1,"ResultDesc":GlobalStrings[134]})
        return Err_Cannot

    def NotifyOpenActivity(self, player, message):
        MMain.sendHorseMessage(message)
        MMain.sendHorseMessage(message)

        guildName = player.getGuildName()
        guild = MMain.getGuildByName(guildName)
        guildMembers = guild.getAllMembers()
        sysmemessage = GlobalStrings[135] %(player.getName())
        for name in guildMembers:
            player = MMain.getPlayerByName(name)
            if player:
                self.notifyActReward(player, True)
                MMain.sendSysMessage(player,sysmemessage)
                
    def doAction(self , player , actData):
        playerName = player.getName()
        guildName = player.getGuildName()
        guild = MMain.getGuildByName(guildName)
        if guild :
            guildMaster = guild.getMasterName()
            guildLevel = guild.getLevel()
            guildMember = guild.getMember(playerName)
            if guildMember:
                result = {
                    "Result":0,
                    "ResultDesc":GlobalStrings[56]
                    }
                if self.isOpened():
                    jdata = json.loads(actData)
                    if jdata["do"] == "open":
                        result["do"] = "open"
                        message = GlobalStrings[136] %(guildName)
                        #minute = self.getMinute() + OPENSTAMP
                        seconds = self.getSeconds() + OPENSTAMP
                        if guildName in self.GlobalData:
                            guildData = self.GlobalData[guildName]
                            if guildData[2] == 0:                            
                                if guildData[0] == 0 and guildMaster == playerName:
                                    self.GlobalData[guildName] = [1, guildData[1], seconds, {}, 0, guildLevel]
                                    self.NotifyOpenActivity(player, message)
                                    MMain.dbLogGuildMiZang(player, guildLevel, 0)
                                elif guildData[1] < MAXOPENNUM:
                                    if player.getGoldMoney() >= OPENACTIVITYMONEY:
                                        player.addGoldMoney(-OPENACTIVITYMONEY)
                                        MMain.dbLogActivityUseGoldMoney(player, self.mID, OPENACTIVITYMONEY)
                                        self.GlobalData[guildName] = [guildData[0], guildData[1] + 1, seconds, {}, 0, guildLevel]
                                        self.NotifyOpenActivity(player, message)
                                        MMain.dbLogGuildMiZang(player, guildLevel, 1)
                                    else:
                                        result["Result"] = 7
                                        result["ResultDesc"] =GlobalStrings[137]
                            elif guildData[2] > 0:
                                result["Result"] = 8
                                result["ResultDesc"] =GlobalStrings[138]
                            else:
                                self.GlobalData[guildName] = [guildData[0], guildData[1], 0, {}, 0, guildLevel]
                        else:
                            guildData = [0,0,0,{},0, guildLevel]     #会长开启   普通开启   结束时间   成员参加信息   当前帮贡
                            if guildMaster == playerName:
                                guildData[0] = 1
                                guildData[2] = seconds
                                self.GlobalData[guildName] = guildData
                                self.NotifyOpenActivity(player, message)
                                MMain.dbLogGuildMiZang(player, guildLevel, 0)
                            else:
                                if player.getGoldMoney() >= OPENACTIVITYMONEY:
                                    guildData[1] += 1
                                    guildData[2] = seconds
                                    self.GlobalData[guildName] = guildData
                                    self.NotifyOpenActivity(player, message)
                                    player.addGoldMoney(-OPENACTIVITYMONEY)
                                    MMain.dbLogActivityUseGoldMoney(player, self.mID, OPENACTIVITYMONEY)
                                    MMain.dbLogGuildMiZang(player, guildLevel, 1)
                                else:
                                    result["Result"] = 0
                                    result["ResultDesc"] =GlobalStrings[137]
                            self.GlobalData[guildName] = guildData

                    elif jdata["do"] == "double":
                        result["do"] = "double"
                        if player.getGoldMoney() < DOUBLEREWARDCOUNSUME:
                            result["Result"] = 7
                            result["ResultDesc"] = GlobalStrings[139]

                    elif jdata["do"] == "join":
                        result["do"] = "join"
                        isdouble = jdata["isdouble"] 
                        if guildName in self.GlobalData:
                            guildData = self.GlobalData[guildName]
                            if playerName in guildData[3]:
                                playerData = guildData[3][playerName]
                                if playerData[0] < MAXJOINTIME:
                                    playerData[2] = 0
                                    if isdouble == 1 and player.getGoldMoney() > DOUBLEREWARDCOUNSUME:
                                        playerData[2] = 1
                                else:
                                    result["Result"] = 8
                                    result["ResultDesc"] = GlobalStrings[140]
                            else:
                                playerData = [0,0,0] # 次数   贡献   是否双倍
                                if isdouble == 1 and player.getGoldMoney() > DOUBLEREWARDCOUNSUME:
                                    playerData[2] = 1
                                guildData[3][playerName] = playerData
                else:
                    result["Result"] = 8
                    result["ResultDesc"] = GlobalStrings[134]
                return json.dumps(result)
        return Err_Cannot

    def loadConfig(self, filepath):
        dungeonfile = "%sdungeonreward.txt" % (filepath)
        activityfile = "%sactivityreward.txt" % (filepath)
        tb = TabFile()
        if tb.load(dungeonfile):
            for i in xrange(tb.mRowNum):
               dungeonId = tb.get(i, 0, 0, True) 
               dungeontype = tb.get(i, 1, 0, True) 
               contribute = tb.get(i,2, 0,True)
               self.InitDungeonReward[dungeonId] = (dungeontype, contribute)
        else:
            syserr("Load %s failed." % (dungeonfile))
            return False
        if tb.load(activityfile):
            for i in xrange(tb.mRowNum):
                guildLevel = tb.get(i,0,0,True)
                contribute = tb.get(i,1,"",False)
                strreward = tb.get(i,2,"",False)
                rewards = strreward.split(";")
                listitem = []
                listres = []
                for reward in rewards:
                    temp = reward.split(",")
                    if len(temp) == 3:
                        listitem.append((
                                int(temp[0]),
                                int(temp[1]),
                                int(temp[2]),
                            ))
                    if len(temp) == 2:
                        listres.append((
                                int(temp[0]),
                                int(temp[1]),
                            ))
                temp = contribute.split(";")
                if len(temp) == 2:
                    start = temp[0]
                    end = temp[1]
                    if guildLevel in self.InitActivityReward:
                        self.InitActivityReward[guildLevel].append((int(start), int(end), listitem, listres))
                    else:
                        self.InitActivityReward[guildLevel] = [(int(start), int(end), listitem, listres)]
        else:
            syserr("Load %s failed." % (activityfile))
            return False
        return True

    def invoke(self , msg , param0 , param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerGuildActivity(self.mID, self)
            self.loadConfig("settings/guild/activity/guilddungeon/")
            data = MMain.getSetting("GuildDungeon")
            if data:
                self.GlobalData = data
            endtimes = MMain.getSetting("GuildDungeonEndTime")
            if endtimes:
                self.mdictEndTime = endtimes

        elif msg == MSG_PLAYER_FINISH_DUNGEON:
            player = param0
            dungeon, star, costTime = param1
            playerName = player.getName()
            guildName = player.getGuildName()
            dungeonID = dungeon.getID()
            if dungeonID in self.InitDungeonReward:
                guild = MMain.getGuildByName(guildName)
                if guild:
                    guildMember = guild.getMember(playerName)
                    if guildMember:
                        if guildName in self.GlobalData:
                            guildData = self.GlobalData[guildName]
                            if playerName in guildData[3] and guildData[2] > 0:
                                playerData = guildData[3][playerName]
                                if playerData[0] < MAXJOINTIME:
                                    playerData[0] +=1
                                    if playerData[2] == 1 and player.getGoldMoney() > DOUBLEREWARDCOUNSUME:
                                        player.addGoldMoney(-DOUBLEREWARDCOUNSUME)
                                        MMain.dbLogActivityUseGoldMoney(player, self.mID, OPENACTIVITYMONEY)
                                        doubleReward = self.InitDungeonReward[dungeonID][1] * 2
                                        playerData[1] += doubleReward
                                        guildData[4] += doubleReward
                                        guildMember.addMeritorious(doubleReward)
                                        guildMember.saveToDB()
                                        guild.updatePost()
                                        guild.addBuildGuildProgress(doubleReward)
                                        guild.addExperience(doubleReward)
                                        guild.saveToDB()
                                        MMain.dbLogGuildMiZangFight(player, 1,dungeonID,  doubleReward, guildMember.getMeritorious())
                                    else:
                                        singleReward = self.InitDungeonReward[dungeonID][1]
                                        playerData[1] += singleReward
                                        guildData[4] += singleReward
                                        guildMember.addMeritorious(singleReward)
                                        guildMember.saveToDB()
                                        guild.updatePost()
                                        guild.addBuildGuildProgress(singleReward)
                                        guild.addExperience(singleReward)
                                        guild.saveToDB()
                                        MMain.dbLogGuildMiZangFight(player, 0,dungeonID,  singleReward, guildMember.getMeritorious())
                                    if playerData[0] < MAXJOINTIME:
                                        self.notifyActReward(player, True)  

        elif msg == MSG_TIME_MINUTE:
            curTime = time.time()
            t = time.localtime(curTime)
            curMTime = t.tm_hour * 60 + t.tm_min
            for guildName in self.GlobalData:
                guildData = self.GlobalData[guildName]
                endTime = guildData[2]
                contribute = guildData[4]
                level = guildData[5]
                if endTime < curTime or ENDTIME <= curMTime:
                    if level in self.InitActivityReward:
                        rewardDatas = self.InitActivityReward[level]
                        for rewardData in rewardDatas:
                            if contribute >=rewardData[0] and contribute <=rewardData[1]:
                                for playerName in self.GlobalData[guildName][3]:
                                    mail = {}
                                    mail["RecvUUID"] = ""
                                    mail["RecvName"] = playerName
                                    mail["CreateTime"] = int(curTime)
                                    mail["ValidTime"] = mail["CreateTime"] + 86400 * 3
                                    mail["Head"] = ""
                                    mail["Body"] = GlobalStrings[141]
                                    mail["Res"] = rewardData[3]
                                    mail["Items"] = rewardData[2]
                                    MMain.sendMail(mail)
                                break
                    self.GlobalData[guildName][2] = 0
                    self.GlobalData[guildName][3] = {}
                    self.GlobalData[guildName][4] = 0

            if (t.tm_min % 5) == 1:
                MMain.setSetting("GuildDungeon", self.GlobalData)
                MMain.setSetting("GuildDungeonEndTime",self.mdictEndTime)
            if curMTime == 40:
                self.GlobalData = {}
        #elif msg == MSG_DAY_CHANGED:
        #    self.GlobalData = {}

        elif msg == MSG_PLAYER_ONLINE:
            player = param0
            playerName = player.getName()
            guildName = player.getGuildName()

            if guildName in self.GlobalData:
                guildData = self.GlobalData[guildName]
                if guildData[2] > 0:
                    if playerName in guildData[3]:
                        playerData = guildData[3][playerName]
                        if playerData[0] < MAXJOINTIME:
                            self.notifyActReward(player, True)
                    else:
                        self.notifyActReward(player, True)



ModuleID = 44
Instance = GuildDungeon(ModuleID)
engine.Instance.register(ModuleID , Instance,[
    MSG_SERVER_STARTUP,
    MSG_TIME_MINUTE,
    MSG_PLAYER_FINISH_DUNGEON,
    MSG_DAY_CHANGED,
    MSG_PLAYER_ONLINE,
])

