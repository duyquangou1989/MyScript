# coding=utf-8
import engine
import MMain
import sys
import time
import json
import random
import bisect
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

ONE_CONTRIBUTE_CONSUME = 1000
TEN_CONTRIBUTE_CONSUME = 9000

RESULT_NO_GUILD = json.dumps({"Result":1, "ResultDesc":GlobalStrings[145]})
RESULT_NO_GUILDMEMBER = json.dumps({"Result":2, "ResultDesc":GlobalStrings[146]})
RESULT_NOT_ENOUGH_MERITOR = json.dumps({"Result":3, "ResultDesc":GlobalStrings[147]})
RESULT_TYPE_ERROR = json.dumps({"Result":4, "ResultDesc":GlobalStrings[121]})
RESULT_NOT_TNOUGH_BLACK = json.dumps({"Result":5, "ResultDesc":GlobalStrings[148]})

DATA_INDEX		= 0
DATA_REWARD		= 1
DATA_LV			= 2

ITEM_TYPE		= 0
ITEM_ID			= 1
ITEM_NUM		= 2

BUDDHA_TYPE_ONE = 1
BUDDHA_TYPE_TEN = 2

class GuildBuddha(ActivityBase):
	def __init__(self, moduleID):
		ActivityBase.__init__(self)
		self.mID = moduleID
		self.mTableData = []
		self.mWeight = 0
		self.mGlobalMsg = []

	def loadConfig(self, path):
		buddhafilename = "%srewards.txt" % (path)
		tb = TabFile()
		if tb.load(buddhafilename):
			tables = []
			weight = 0
			for i in xrange(tb.mRowNum):
				
				index 		= tb.get(i, DATA_INDEX, "", True)
				tmpreward 	= tb.get(i, DATA_REWARD, "", False).replace("\\n", "\n").replace("\"", "")
				tmpweight 	= tb.get(i, DATA_LV, 0, True)
				
				tmpItem = []
				tmpBlocks = tmpreward.split(";")
				itemBlocks = tmpBlocks[0].split(",")
				if len(itemBlocks) == 3:
					tmpItem = (
						int(itemBlocks[ITEM_TYPE]),
						int(itemBlocks[ITEM_ID]),
						int(itemBlocks[ITEM_NUM]),
					)
				reward = tmpItem
				weight += tmpweight
				tables.append((index,reward,tmpweight))
			self.mTableData = tables
			self.mWeight = weight
		else:
			syserr("Loading %s failed." % (buddhafilename))
			return False
		return True

	def getName(self):
		return "GuildBuddha"
		
	def calReward(self, player, type):
		guild = MMain.getGuildByName(player.getGuildName())
		if guild:
			rewards = self.mTableData
			randPercent = random.randint(1, self.mWeight)
			percent = 0
			for item in rewards:
				percent += item[2]
				if randPercent <= percent:
					return item[1]
		else:
			return []

	def getInfo(self, player):
		guild = MMain.getGuildByName(player.getGuildName())
		if guild:
			guildmember = guild.getMember(player.getName())
			if guildmember:
				buddha = {}
				buddha["onetime"] = ONE_CONTRIBUTE_CONSUME
				buddha["tentime"] = TEN_CONTRIBUTE_CONSUME
				buddha["contribute"] = guildmember.getMeritorious()
				if "s_records" not in guild.__dict__:
					guild.s_records = []
				buddha["records"] = guild.s_records
				return 	json.dumps(buddha)
			else:
				return ""
		else:
			return ""
	def getWordColor(self, quality):
		if quality < 0:
			return "[F5F0C6]"
		elif quality < 3:
			return "[A0E71F]"
		elif quality < 6:
			return "[15a5ef]"
		elif quality < 9:
			return "[9515ef]"
		elif quality < 12:
			return "[ef8615]"
		else:
			return "[ffffff]"

	def doAction(self, player, actData):
		guild = MMain.getGuildByName(player.getGuildName())
		if guild:
			guildmember = guild.getMember(player.getName())
			if guildmember:
				jdata = json.loads(actData)
				buhhdatype = jdata["type"]
				meritorious = guildmember.getMeritorious()
				if buhhdatype == BUDDHA_TYPE_ONE:
					if player.getBagFreeSpace() >= 1:
						reward = self.calReward(player,buhhdatype)
						if self.canAddReward(player , reward):
							if ONE_CONTRIBUTE_CONSUME <= meritorious:
								guildmember.addMeritorious(-ONE_CONTRIBUTE_CONSUME)
								tmpitem = MMain.createItem(reward[0] , reward[1] , reward[2])
								if tmpitem:
									quality = tmpitem.getQuality()
									msg = GlobalStrings[149] % (player.getName() , self.getWordColor(quality),tmpitem.getName())
									#self.mGlobalMsg.insert(0, msg)
									if "s_records" not in guild.__dict__:
										guild.s_records = []
									guild.s_records.insert(0, msg)
									msgNum = len(guild.s_records)
									while msgNum > 20:
										del guild.s_records[msgNum - 1]
										msgNum = len(guild.s_records)
								self.addReward(player , reward)
								MMain.dbLogGuildBuddha(player, ONE_CONTRIBUTE_CONSUME, guildmember.getMeritorious(),reward[1])


								return json.dumps({
									"Result": 0,
									"ResultDesc": GlobalStrings[150],
									"type":buhhdatype,
									"Reward": reward
								})
							else:
								return RESULT_NOT_ENOUGH_MERITOR
						else:
							return RESULT_NOT_TNOUGH_BLACK
					else:
						return RESULT_NOT_TNOUGH_BLACK
				elif buhhdatype == BUDDHA_TYPE_TEN:
					if player.getBagFreeSpace() >= 10:
						if TEN_CONTRIBUTE_CONSUME <= meritorious:
							guildmember.addMeritorious(-TEN_CONTRIBUTE_CONSUME)
							count = 0
							tmpreward = []
							while count < 10:
								count = count + 1
								reward = self.calReward(player,buhhdatype)
								if self.canAddReward(player , reward):
									tmpitem = MMain.createItem(reward[0] , reward[1] , reward[2])
									if tmpitem:
										quality = tmpitem.getQuality()
										msg = GlobalStrings[149] % (player.getName() , self.getWordColor(quality), tmpitem.getName())
										#self.mGlobalMsg.insert(0, msg)
										if "s_records" not in guild.__dict__:
											guild.s_records = []
										guild.s_records.insert(0, msg)
										msgNum = len(guild.s_records)
										while msgNum > 20:
											del guild.s_records[msgNum - 1]
											msgNum = len(guild.s_records)
									self.addReward(player , reward)
									tmpreward.append(reward)
									MMain.dbLogGuildBuddha(player, TEN_CONTRIBUTE_CONSUME, guildmember.getMeritorious(),reward[1])
								else:
									return RESULT_NOT_TNOUGH_BLACK
							return json.dumps({
								"Result": 0,
								"ResultDesc": GlobalStrings[150],
								"type":buhhdatype,
								"Reward": tmpreward
							})
						else:
							return RESULT_NOT_ENOUGH_MERITOR
					else:
						return RESULT_NOT_TNOUGH_BLACK
				else:
					return RESULT_TYPE_ERROR
			else:
				return RESULT_NO_GUILDMEMBER
		else:
			return RESULT_NO_GUILD

	def invoke(self, msg, param0, param1):
		if msg == MSG_SERVER_STARTUP:
			MMain.registerGuildActivity(self.mID, self)
			self.loadConfig("settings/guild/activity/guildbuddha/")

ModuleID = 10
Instance = GuildBuddha(ModuleID)
engine.Instance.register(ModuleID , Instance,[
	MSG_SERVER_STARTUP,
	MSG_PLAYER_ONLINE,
])