#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

REWARD_INDEX_TYPE           = 0
REWARD_INDEX_VALUE          = 1

RESULT_NOT_ACTIVED = json.dumps({"Result":1, "ResultDesc":GlobalStrings[50]})
RESULT_ALREADY = json.dumps({"Result":2, "ResultDesc":GlobalStrings[205]})
RESULT_BAG_FULL = json.dumps({"Result":3, "ResultDesc":GlobalStrings[168]})
RESULT_NOT_FINISHED = json.dumps({"Result":4, "ResultDesc":GlobalStrings[175]})
RESULT_TEAM_FULL = json.dumps({"Result":5, "ResultDesc":GlobalStrings[206]})
RESULT_INVALID = json.dumps({"Result":6, "ResultDesc":GlobalStrings[207]})

class DailyFirstRecharge(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID

        self.mRewards = []
        self.mInitData = [False,]
        self.mMagnification = 2

    def isActived(self, player):
        actived = ActivityBase.isActived(self, player)

        data = self.getPlayerData(player, self.mInitData)
        if data[0]:
            return False
        else:
            return actived

    def getName(self):
        return GlobalStrings[208]

    def getInfo(self, player):
        data = self.getPlayerData(player, self.mInitData)

        info = {}
        info["Rewards"] = self.mRewards

        return json.dumps(info)

    def doAction(self, player, actData):
        return RESULT_INVALID

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)

        syslog("Loading DailyFirstRecharge config...")

        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = []
            for i in xrange(tb.mRowNum):
                offset = 0;

                rewardType = tb.get(i, 0, 0, True)
                rewardValue = tb.get(i, 1, "", False).replace("\"", "")

                if rewardType == REWARD_TYPE_ITEM:
                    tmpItems = []
                    tmpBlocks = rewardValue.split(";")
                    for tmpBlock in tmpBlocks:
                        itemBlocks = tmpBlock.split(",")
                        if len(itemBlocks) == 3:
                            tmpItems.append((
                                int(itemBlocks[0]),
                                int(itemBlocks[1]),
                                int(itemBlocks[2]),
                            ))
                    rewardValue = tmpItems
                else:
                    rewardValue = int(rewardValue)

                rewards.append((
                    rewardType,
                    rewardValue,
                ))

            self.mRewards = rewards

            return True

        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_ONLINE:
            player = param0
            
            if self.isActived(player):
                data = self.getPlayerData(player, self.mInitData)
                if not data[0]:
                    self.notifyActReward(player, True)

        elif msg == MSG_PLAYER_DAY_CHANGED:
            player = param0

            data = self.getPlayerData(player, self.mInitData)
            data[0] = False
            self.notifyActReward(player, True)

        elif msg == MSG_PLAYER_GOLDMONEY_CHANGED:
            player = param0
            value, way, productId = param1

            if self.isActived(player):
                if way == GMCW_Pay:
                    data = self.getPlayerData(player, self.mInitData)
                    if not data[0]:
                        data[0] = True
                        player.s_Purchased = True

                        # 发奖励
                        mail = {}
                        mail["RecvUUID"] = player.getUUID()
                        mail["RecvName"] = player.getName()
                        mail["ValidTime"] = int(time.time() + 86400 * 3)
                        mail["Head"] = GlobalStrings[209]
                        mail["Body"] = GlobalStrings[209]
                        mail["Res"] = []
                        mail["Items"] = []

                        for reward in self.mRewards:
                            if reward[0] == REWARD_TYPE_ITEM:
                                for rewardItem in reward[1]:
                                    mail["Items"].append(rewardItem)
                            else:
                                mail["Res"].append(reward)

                        MMain.sendMail(mail)

                        MMain.sendBoxMessage(player, GlobalStrings[304])
                        self.notifyActReward(player, False)

    def getMenu(self, player, npcID):
        return []

ModuleID = 28
Instance = DailyFirstRecharge(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_DAY_CHANGED,
    MSG_PLAYER_GOLDMONEY_CHANGED,
])
