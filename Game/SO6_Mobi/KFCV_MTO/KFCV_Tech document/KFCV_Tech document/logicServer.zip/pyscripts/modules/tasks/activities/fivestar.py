#coding=utf8

import engine
import MMain
import sys
import time
import calendar
import json
import random
import bisect
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

class FiveStar(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        self.mID = moduleID
        self.mRewards = []
    def getName(self):
        return "FiveStar"

    def isActived(self, player):
        curTime = int(time.time())
        if self.mBeginTime <=curTime and self.mEndTime > curTime:
            if "s_fivestar" not in player.__dict__:
                return True
        return False

    def getInfo(self, player):
        info = {}
        if "s_fivestar" not in player.__dict__:
            if "s_fivestaropen" not in player.__dict__:
                info["openstatus"] = 0
            else:
                info["openstatus"] = 1
            info["result"] = 0
            if len(self.mRewards) > 0:
                data = self.mRewards[0]
                info["rewards"] = data[0]
                info["desc"] = data[1]
                info["iosurl"] = data[2]
                info["adrurl"] = data[3]
            else:
                info["result"] = 2
        else:
            info["result"] = 1
        return json.dumps(info)

    def doAction(self, player, actData):
        jsonData = json.loads(actData)
        if jsonData["do"] == "open":
            if "s_fivestaropen" not in player.__dict__:
                player.s_fivestaropen = 1
                return json.dumps({"Result":1, "do":"open","ResultDesc":GlobalStrings[56]})
            else:
                return Err_Invalid
        elif jsonData["do"] == "get":
            if "s_fivestaropen" in player.__dict__:
                if "s_fivestar" not in player.__dict__:
                    rewards = self.mRewards[0][0]
                    if self.canAddAllReward(player, rewards):
                        for reward in rewards:
                            self.addReward(player, reward)
                        player.s_fivestar = 1
                        return json.dumps({"Result":1, "do":"get","ResultDesc":GlobalStrings[56]})
                    else:
                        return Err_NotEnoughSpace
                else:
                    return Err_Repetition
            else:
                return Err_Invalid

    def loadConfig(self, path):
        rewardFile = "%srewards.txt" %(path)
        tb = TabFile()
        if tb.load(rewardFile):
            rewards = []
            for i in xrange(tb.mRowNum):
                rewardStr = tb.get(i, 0, "", False).replace("\n", "")
                desc   = tb.get(i, 1, "", False).replace("\n", "")
                iosurl = tb.get(i, 2, "", False).replace("\n", "")
                adrurl = tb.get(i, 3, "", False).replace("\n", "")
                reward = [
                    [int(value) for value in reward.split(",")]
                        for reward in rewardStr.split(";") if reward and reward.count(',') in (1, 2)
                ]
                rewards.append((reward, desc, iosurl, adrurl))
            self.mRewards = rewards
        else:
            syserr("Load %s failed." % (rewardFile))
            return False
        return True

    def getMenu(self, player, npcID):
        return []
    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)
        elif msg == MSG_PLAYER_ONLINE:
            player = param0
            if "s_fivestaropen" in player.__dict__:
                if "s_fivestar" not in player.__dict__:
                    self.notifyActReward(player, True)

ModuleID = 52
Instance = FiveStar(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
])
        