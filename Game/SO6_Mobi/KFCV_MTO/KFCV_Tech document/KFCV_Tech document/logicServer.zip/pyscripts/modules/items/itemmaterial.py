#coding=utf8

import MItem
import item

class ItemMaterial(item.Item):
    def __init__(self):
        item.Item.__init__(self)
        
item.gItemMgr.register(MItem.ItemType.Material, ItemMaterial)