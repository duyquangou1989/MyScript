#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

# Sell Index
INDEX_SELL_oldPrice         = 0
INDEX_SELL_newPrice         = 1
INDEX_SELL_items            = 2
INDEX_SELL_COUNT            = 3

class GroupBuy(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mCfgSell = []          # 销售表;
        self.mCfgMilestones = []    # 阶段目标配置信息;

        self.mGlobalData = [0,{}]
    def getName(self):
        return "GroupBuy"

    # 下发团购信息;
    def getInfo(self, player):
        info = {}
        info["TotalSell"] = self.mGlobalData[0]
        info["Sells"] = self.mCfgSell
        info["milestones"] = self.mCfgMilestones
        info["laveTime"] = (int)(self.mEndTime - time.time())
        return json.dumps(info)

    def doAction(self, player, actData):
        if self.isActived(player) == False:
            return Err_NotOpen

        data = json.loads(actData)
        print "[GroupBuy]get ask: %s" % (data)
        
        actionType = data["Action"]
        if actionType == "Buy":     # 购买商品;
            buyNum = int(data["Num"])
            playerUUID = player.getUUID()
            playerName = player.getName()
            price = self.mCfgSell[INDEX_SELL_newPrice]
            realPrice = price * buyNum
            if realPrice < 0 :
                player.addGoldMoney(buyNum)
                MMain.dbLogActivityUseGoldMoney(player, self.mID, realPrice)
                return Err_Unknown
            if player.getGoldMoney() >= realPrice:
                items = []
                for item in self.mCfgSell[INDEX_SELL_items]:
                    items.append((item[0][0],
                        item[0][1],
                        item[0][2] * buyNum))
                if self.canAddAllReward(player, items):
                    player.addGoldMoney(-realPrice)
                    MMain.dbLogActivityUseGoldMoney(player, self.mID, realPrice)
                    for item in items:
                        self.addReward(player, item)
                else:
                    return Err_NotEnoughSpace
                self.mGlobalData[0] += buyNum
                self.mGlobalData[1][playerUUID] = playerName
                MMain.setSetting("gb_globalData", self.mGlobalData)
                return Err_Ok
            else:
                return Err_Failed
        return Err_Unknown

    def loadConfig(self, path):
        # 销售表配置读取;
        fileSell = "%s%s.txt" % (path, "sell")
        syslog("[GroupBuy] Loading config: %s" % (fileSell))
        tbSell = TabFile()
        if tbSell.load(fileSell):
            cfgSell = []
            cfgSell = [None for j in xrange(INDEX_SELL_COUNT)]
            Row = 0
            Col = 0

            # 价格;
            cfgSell[INDEX_SELL_oldPrice] = tbSell.get(Row, Col, 0, True)      # oldPrice
            Col += 1
            cfgSell[INDEX_SELL_newPrice] = tbSell.get(Row, Col, 0, True)      # newPrice
            Col += 1
            # 商品;
            cfgSell[INDEX_SELL_items] = []                                    # items
            for i in xrange(Col, tbSell.mColNum):
                itemstr  = tbSell.get(Row, Col, "", False).replace("\"", "")
                Col += 1
                itemInfo = [
                    [int(value) for value in reward.split(",")]
                        for reward in itemstr.split(";") if reward and reward.count(',') in (1, 2)
                ]
                cfgSell[INDEX_SELL_items].append(itemInfo)
            self.mCfgSell = cfgSell
        else:
            syserr("Load %s failed." % (fileSell))
            return False
            
        # 阶段目标配置表读取;
        fileMS = "%s%s.txt" % (path, "milestones")
        syslog("[GroupBuy] Loading config: %s" % (fileMS))
        tbMS = TabFile()
        if tbMS.load(fileMS):
            cfgMilestones = []
            for i in xrange(tbMS.mRowNum):
                msGoal   = tbMS.get(i, 0, 0, True)
                itemstr  = tbMS.get(i, 1, "", False).replace("\"", "")
                itemInfo = [
                    [int(value) for value in reward.split(",")]
                        for reward in itemstr.split(";") if reward and reward.count(',') in (1, 2)
                ]

                cfgMilestones.append((
                    msGoal,                         # 阶段目标;
                    itemInfo,                       # 阶段奖励表;
                ))
            self.mCfgMilestones = cfgMilestones
        else:
            syserr("Load %s failed." % (fileMS))
            return False
        return True

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)
            # 信息读取;
            globalData = MMain.getSetting("gb_globalData")
            if globalData:
                self.mGlobalData = globalData

        elif msg == MSG_TIME_MINUTE:
            curTime = time.time()
            t = time.localtime(self.mEndTime)
            t1 = time.localtime(curTime)
            curMTime = t1.tm_hour *60 + t1.tm_min
            endMtime = t.tm_hour *60 + t.tm_min
            if t1.tm_year == t.tm_year and t1.tm_mon == t.tm_mon and t1.tm_mday == t.tm_mday and t1.tm_hour == t.tm_hour and t1.tm_min == t.tm_min:
                print "group buy rewards"
                items = []
                ress = []
                milestone = ()
                totalSell = self.mGlobalData[0]
                buyPlayers = self.mGlobalData[1]
                for m in self.mCfgMilestones:
                    if totalSell >= m[0]:
                        if milestone:
                            if milestone[0] < m[0]:
                                milestone = m
                        else:
                            milestone = m
                if len(milestone) == 2:
                    for res in milestone[1]:
                        if len(res) == 3:
                            items.append(res)
                        elif len(res) == 2:
                            ress.append(res)
                    for UUID in buyPlayers:
                        mail = {}
                        mail["RecvUUID"] = UUID
                        mail["RecvName"] = buyPlayers[UUID]
                        mail["CreateTime"] = int(curTime)
                        mail["ValidTime"] = mail["CreateTime"] + 86400 * 3
                        mail["Head"] = GlobalStrings[53]
                        mail["Body"] = GlobalStrings[54] %(milestone[0])
                        mail["Res"] = ress
                        mail["Items"] = items
                        MMain.sendMail(mail)
                self.mGlobalData = [0,{}]
                MMain.setSetting("gb_globalData", self.mGlobalData)
                
    def getMenu(self, player, npcID):
        return []

ModuleID = 60
Instance = GroupBuy(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_TIME_MINUTE,
])
