#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
import bisect
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

class GoldBoubleReward(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        self.mID = moduleID
        self.InitData = {}
        self.mGloble = {}
        self.mRedID = 0

    def getName(self):
        return "GoldBoubleReward"
        
    def isOpened(self):
        return True

    def isActived(self, player):      
        return True

    def doSetOrUpInfo(self, player, goldMoney):
        if not "s_aStyleFirst" in player.__dict__:
            player.s_aStyleFirst = []
        if goldMoney in player.s_aStyleFirst:
            print "chargefirst reward had get!!!"
        else:
            player.addGoldMoney(goldMoney)
            MMain.dbLogActivityAddGoldMoney(player, self.mID, goldMoney)
            player.s_aStyleFirst.append(goldMoney)

    def getInfo(self, player):
        if not "s_aStyleFirst" in player.__dict__:
            player.s_aStyleFirst = []
        Info = {}
        Info["hasrewards"] = player.s_aStyleFirst
        return json.dumps(Info)
        
    def doAction(self, player, actData):
        pass

    def loadConfig(self, path):
        return True

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
           MMain.registerActivity(self.mID, self)
           
        elif msg == MSG_PLAYER_GOLDMONEY_CHANGED:
            player = param0
            goldMoney = param1[0]
            payWay = param1[1]
            productId = param1[2]
            if payWay == GMCW_Pay:
                if productId == "sl_tw_60"  or productId == "sl_tw_315" or productId == "sl_tw_530" or productId == "sl_tw_1145" or productId == "sl_tw_2405"  or productId == "sl_tw_3530":
                    self.doSetOrUpInfo(player, goldMoney)
        elif msg == MSG_DAY_CHANGED:
            self.mGloble = {}

    def getMenu(self, player, npcID):
        return []


ModuleID = 37
Instance = GoldBoubleReward(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_GOLDMONEY_CHANGED,
    MSG_DAY_CHANGED,
])
