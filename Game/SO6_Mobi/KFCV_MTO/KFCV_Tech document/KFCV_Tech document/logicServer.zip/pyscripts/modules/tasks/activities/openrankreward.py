# coding=utf8
import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *
from traceback import print_exc

IsOpen = True

STATE_GOING         = 1     # 进行中
STATE_ANNOUNCE      = 2     # 结果出来了，跑马灯通告一天中
STATE_END           = 3     # 活动结束了

Text_Rank = [GlobalStrings[61], GlobalStrings[62], GlobalStrings[63]]


class OpenRankReward(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        self.mID = moduleID
        self.mServerOpenTime = 0
        self.mState = STATE_GOING

    def getName(self):
        return "RankReward"

    def isActived(self, player):
        return True

    def getCurDay(self):
        return int((time.time() - self.mServerOpenTime) / 86400) + 1

    def getInfo(self, player):
        result = {}
        result["ServerDay"] = self.getCurDay()
        result["StartTime"] = self.mBeginTime
        result["EndTime"] = self.mEndTime
        return json.dumps(result)

    def doAction(self, player, actData):
        return Err_Ok

    def loadConfig(self, path):
        return True

    def invoke(self, msg, param0, param1):
        if not IsOpen:
            return

        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)
            startTime = MMain.getSetting("starttime")
            if startTime:
                self.mServerOpenTime = startTime
            else:
                t = time.localtime(time.time())
                time1 = time.mktime(time.strptime(time.strftime('%Y-%m-%d 00:00:00', t), '%Y-%m-%d %H:%M:%S'))
                self.mServerOpenTime = int(time1)
                MMain.setSetting("starttime", self.mServerOpenTime)

        elif msg == MSG_ACTIVITY_STARTOVER:
            self.TopData = MMain.getSetting("RankTopData")
            if not self.TopData:
                self.TopData = {"gived" : 0, "levelTops":[], "bpTops":[], "respon":0}

            self.CheckState()

        elif msg == MSG_DAY_CHANGED:
            print("MSG_DAY_CHANGED")
        elif msg == MSG_TIME_MINUTE:
            self.processTime()
        elif msg == MSG_PLAYER_ONLINE:
            self.processPlayerLogin(param0)


    def processTime(self):
        curTime = time.time()
        curLTime = time.localtime(curTime)

        #if curLTime.tm_min % 10 == 0:       # 10分钟检测一次
        if True:       # 1分钟检测一次
            lastState = self.mState
            self.CheckState()
            if self.mState == STATE_ANNOUNCE:
                # 没有发奖励，就发(尝试2次)
                if lastState != self.mState and self.TopData["gived"] < 2:
                    self.TopData["gived"] += 1
                    MMain.setSetting("RankTopData", self.TopData)
                    print("give award")
                    MMain.httpRankAward()   # http回调到onNotifyTopRank 返回排名

                # 整点了(跑马灯)
                #if True:
                if curLTime.tm_min == 0:
                    if len(self.TopData["levelTops"]) != 0 and len(self.TopData["bpTops"]) != 0:
                        self.announce()


    def CheckState(self):
        curTime = time.time()
        curTime - self.mServerOpenTime

        if self.mEndTime - curTime > 86400:
            self.mState = STATE_GOING
        elif self.mEndTime - curTime > 0:
            self.mState = STATE_ANNOUNCE
        else:
            self.mState = STATE_END

    def onNotifyTopRank(self, respon):
        print("onNotifyTopRank:")
        self.TopData["gived"] = 2
        self.TopData["respon"] = 1
        try:
            rankDatas = json.loads(respon)
        except:
            print_exc()
            return

        print(rankDatas[0])     # level
        print(rankDatas[1])     # bp

        self.TopData["levelTops"] = []
        length = min(len(rankDatas[0]["ranks"]), 3)
        for i in range(length):
            r = rankDatas[0]["ranks"][i]
            if r:
                self.TopData["levelTops"].append(r["n"].encode('utf-8'))

        self.TopData["bpTops"] = []
        length = min(len(rankDatas[1]["ranks"]), 3)
        for i in range(length):
            r = rankDatas[1]["ranks"][i]
            if r:
                self.TopData["bpTops"].append(r["n"].encode('utf-8'))

        MMain.setSetting("RankTopData", self.TopData)
        print(self.TopData["levelTops"])
        print(self.TopData["bpTops"])
        # 立即发一次跑马灯
        self.announce()

    # 跑马灯
    def announce(self):
        print("openrank ann")

        msgs = self.formatAnnounceMsg()
        for msg in msgs:
            MMain.sendHorseMessage(msg)

    def formatAnnounceMsg(self):
        msgs = []
        msg = ""
        if len(self.TopData["levelTops"]) != 0:
            peoples = ""

            for n in range(len(self.TopData["levelTops"])):
                if n != len(self.TopData["levelTops"]) - 1:
                    peoples += "%s：[ef8615]%s[-]，" % (Text_Rank[n],self.TopData["levelTops"][n])
                else:
                    peoples += "%s：[ef8615]%s[-]。" % (Text_Rank[n],self.TopData["levelTops"][n])

            msg = GlobalStrings[64] % peoples
            msgs.append(msg)

        msg = ""
        if len(self.TopData["bpTops"]) != 0:
            peoples = ""

            for n in range(len(self.TopData["bpTops"])):
                if n != len(self.TopData["bpTops"]) - 1:
                    peoples += "%s：[ef8615]%s[-]，" % (Text_Rank[n],self.TopData["bpTops"][n])
                else:
                    peoples += "%s：[ef8615]%s[-]。" % (Text_Rank[n],self.TopData["bpTops"][n])

            msg += GlobalStrings[65] % peoples
            msgs.append(msg)

        return msgs

    def processPlayerLogin(self, player):
        if time.time() < self.mEndTime + 604800: # 发通知邮件活动结束后七天前有效
            if len(self.TopData["levelTops"]) != 0 and len(self.TopData["bpTops"]) != 0:
                if not "s_OpenRankRewardNotify" in player.__dict__:
                    player.s_OpenRankRewardNotify = False

                if not player.s_OpenRankRewardNotify:
                    msgs = self.formatAnnounceMsg()
                    for msg in msgs:
                        player.s_OpenRankRewardNotify = True
                        mail = {}
                        mail["RecvUUID"] = ""
                        mail["RecvName"] = player.getName()
                        mail["CreateTime"] = int(time.time())
                        mail["ValidTime"] = mail["CreateTime"] + 86400 * 3
                        mail["Head"] = ""
                        mail["Body"] = msg
                        mail["Res"] = []
                        mail["Items"] = []
                        MMain.sendMail(mail)



ModuleID = 58
Instance = OpenRankReward(ModuleID)

engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_ACTIVITY_STARTOVER,
    MSG_DAY_CHANGED,
    MSG_TIME_MINUTE,
    MSG_PLAYER_ONLINE,
])

#    MSG_PLAYER_LEVELUP,
 # MSG_PLAYER_BATTLEPOINT_CHANGED,