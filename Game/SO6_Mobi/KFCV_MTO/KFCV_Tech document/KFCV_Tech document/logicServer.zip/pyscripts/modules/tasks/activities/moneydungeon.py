#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
import calendar
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

LIMITTIME = 5
OPENLEVEL = 5
RESULT_OK = json.dumps({"Result":0,"ResultDesc":GlobalStrings[56]})
RESULT_NOTENUGH = json.dumps({"Result":1, "ResultDesc":GlobalStrings[57]})
RESULT_NOTOPEN = json.dumps({"Result":2, "ResultDesc":GlobalStrings[58]})

class MoneyDungeon(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        self.mID = moduleID
        self.mBossDungeon = []
        self.mGlobelData = {}
    def getName(self):
        return "MoneyDungeon"

    def isOpened(self, player):
        level = player.getLevel()
        if level >= OPENLEVEL:
            return True
        else:
            return False

    def getInfo(self,player):
        data = {}
        data["config"] = self.mBossDungeon
        if "s_mMoneyDungeonTime" not in player.__dict__:
            player.s_mMoneyDungeonTime = LIMITTIME
        data["limittime"] = player.s_mMoneyDungeonTime
        data["openlevel"] = OPENLEVEL
        return json.dumps(data)

    def doAction(self , player , actData):
        if self.isOpened(player):
            jdata = json.loads(actData)
            playerName = player.getName()
            if jdata["do"] == "enter":
                if "s_mMoneyDungeonTime" not in player.__dict__:
                    player.s_mMoneyDungeonTime = LIMITTIME
                if player.s_mMoneyDungeonTime > 0:
                    return RESULT_OK
                else:
                    return RESULT_NOTENUGH

    def addPoint(self, player):
        if "s_mMoneyDungeonTime" not in player.__dict__:
            player.s_mMoneyDungeonTime = LIMITTIME
        player.s_mMoneyDungeonTime += 1
        return True

    def decPoint(self,player):
        if "s_mMoneyDungeonTime" not in player.__dict__:
            player.s_mMoneyDungeonTime = LIMITTIME
        if player.s_mMoneyDungeonTime > 0:
            player.s_mMoneyDungeonTime -= 1
            return True
        else:
            return False

    def loadConfig(self, path):
        dungeonfile = "%sdungeon.txt" %(path)
        tb = TabFile()
        if tb.load(dungeonfile):
            dungeons = []
            for i in xrange(tb.mRowNum):
                dungeonID               = tb.get(i, 0, -1, True)
                level                   = tb.get(i, 9, -1, True)
                t = dungeonID / 10000
                if t == 11:
                    dungeons.append((level, dungeonID,))
            self.mBossDungeon = dungeons

    def invoke(self , msg , param0 , param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_DAY_CHANGED:
            player = param0
            player.s_mMoneyDungeonTime = LIMITTIME

ModuleID = 45
Instance = MoneyDungeon(ModuleID)
engine.Instance.register(ModuleID , Instance,[
    MSG_SERVER_STARTUP,
    MSG_PLAYER_DAY_CHANGED,
])
