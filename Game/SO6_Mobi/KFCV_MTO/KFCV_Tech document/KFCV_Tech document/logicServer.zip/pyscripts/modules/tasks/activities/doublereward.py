#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

class DoubleReward(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        
        self.mID = moduleID
        self.mDesc = {}

    def getName(self):
        return GlobalStrings[212]

    def getInfo(self, player):
        allDoubleReward = MMain.getAllDoubleReward()

        descs = []
        for drType in allDoubleReward:
            if allDoubleReward[drType]:
                drTimes = allDoubleReward[drType]
                descs.append((
                    drType,
                    self.mDesc[drType],
                    drTimes[0],
                    drTimes[1],
                ))
        info = {}
        info["Desc"] = descs

        return json.dumps(info)

    def doAction(self, player, actData):
        pass

    def loadConfig(self, path):
        descFilename = "%sdesc.txt" % (path)

        tb = TabFile()
        if tb.load(descFilename):
            descs = {}
            for i in xrange(tb.mRowNum):
                drType = tb.get(i, 0, 0, True)
                drDesc = tb.get(i, 1, "", False)
                descs[drType] = drDesc

            self.mDesc = descs
        else:
            syserr("Loading %s failed." % (descFilename))

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

    def getMenu(self, player, npcID):
        return []


ModuleID = 22
Instance = DoubleReward(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
])
