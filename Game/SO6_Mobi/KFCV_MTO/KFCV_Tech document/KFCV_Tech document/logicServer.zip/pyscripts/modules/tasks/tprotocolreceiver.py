#coding=utf8
import MMain
import engine
import random

global g_dungeonIDList
g_dungeonIDList = [10010101,10010111,
10010102,10010201,10010202,10010203,10110101,10110102,10110201,10110202,10110301,
10110302,10110303,10210101,10210102,10210103,10210201,10210202,10210203,10210301,
10210302,10210303,10210304,10310101,10310111,10310121,10310102,10310112,10310122,
10310103,10310104,10310114,10310201,10310211,10310221,10310202,10310203,10310213,
10310204,10310205,10310215,10310301,10310302,10310312,10310303,10310304,10310314,
10310305,10310306,10310316,10310307,]

g_winmsglst = [GlobalStrings[159],
               GlobalStrings[160], ]

g_losemsglst = [GlobalStrings[161],
                GlobalStrings[162],   ]

def g_RandMapID():
    global g_dungeonIDList
    nLen = len(g_dungeonIDList)
    idx = random.randint(0, nLen-1)
    return g_dungeonIDList[idx]

def g_RandOneMsg(msgtype):
    if msgtype == "win":
        nLen = len(g_winmsglst)
        idx = random.randint(0, nLen-1)
        return g_winmsglst[idx]
    elif msgtype == "lose":
        nLen = len(g_losemsglst)
        idx = random.randint(0, nLen-1)
        return g_losemsglst[idx]

    return "no msg"

def PKCallback(isSrcWin, srcDamage, dstDamage, params):
    message = ""
    if isSrcWin:
        message = g_RandOneMsg("win")
    else:
        message = g_RandOneMsg("lose")

    showUsers = params[0]  # 这个params是调用MMain.fightAndShow时传进来的
    mapID = g_RandMapID() 
    clientCallback = "friendpk"
    clientCallbackParam = "{}"

    # 参数介绍
    # showUsers是一个Player的index列表，表示要显示战斗的玩家
    # mapID为战斗场景的地图ID
    # clientCallback是一个字符串，用于在客户端做额外的回调处理
    # message是战斗结束后显示给玩家看的文字，传入""则不显示
    # clientCallbackParam是传送给客户端回调的时候的参数，自行定义，字符串
    return showUsers, mapID, message, clientCallback, clientCallbackParam

class TFriendPKReceiver:
    def __init__(self):
        engine.Instance.registerTextProtocol("C2S_PK_Friend", self.ReceiveFriendPK)

    def ReceiveFriendPK(self, player, data):
        friendname = data[0]

        ro = player.getRoleByTypeID(0)
        lv = ro.getLevel()
        if player.getSophisticate() < lv * 25 + 100: #阅历不够
            MMain.sendCenterMessage(player, GlobalStrings[163])
            return
        
        friendPlayer = MMain.getPlayerByName(friendname)
        if friendPlayer == None:
            #进入异步加载流程
            callbackParam = player.getName()
            MMain.loadOfflinePlayer(friendname, self.loadcallback, callbackParam)
            
        else:
            self.startPK(player, friendPlayer)
            
    def loadcallback(self, friendPlayer, srcName):
        player = MMain.getPlayerByName(srcName)
        if player == None:
            return
        
        if friendPlayer == None:
            MMain.sendCenterMessage(player, GlobalStrings[164])
            return
        
        self.startPK(player, friendPlayer)
        
    def startPK(self, player, friendPlayer):
        if player != None and friendPlayer != None:
            #reduct sophisticate
            ro = player.getRoleByTypeID(0)
            lv = ro.getLevel()
            sophisticate = lv * 25 + 100
            player.addSophisticate(sophisticate * (-1))
            
            srcFightData = player.getFightData()
            dstFightData = friendPlayer.getFightData()
            MMain.fightAndShow(srcFightData, dstFightData, PKCallback, [[player.getIndex()], srcFightData, dstFightData])


FriendIns = TFriendPKReceiver()

def getArenaHistroyFight(player, data):
    url = data[0]

    MMain.showArenaHistroyFight(player, url, GlobalStrings[165], GlobalStrings[166])

engine.Instance.registerTextProtocol("C2S_ShowArenaHistroyFight", getArenaHistroyFight)
