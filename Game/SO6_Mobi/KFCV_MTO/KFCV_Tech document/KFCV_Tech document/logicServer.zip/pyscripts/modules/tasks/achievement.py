#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *
from maintask import Instance as mtInstance

ACHI_FINISH_DUNGEON_NUM                     = 1
ACHI_FINISH_THIS_DUNGEON                    = 2
ACHI_FINISH_ARENA                           = 3
ACHI_FINISH_ARENA_AND_WIN                   = 4
ACHI_FINISH_TASK_NUM                        = 5
ACHI_FINISH_THIS_TASK                       = 6
ACHI_FINISH_DAILY_TASK                      = 7
ACHI_LEVEL                                  = 8
ACHI_VIPLEVEL                               = 9
ACHI_GET_MONEY                              = 10
ACHI_BATTLE_POINT                           = 11
ACHI_ROLE_STRENGTH                          = 12
ACHI_EQUIP_ADVANCE                          = 13
ACHI_EQUIP_UPGRADE                          = 14
ACHI_EQUIP_GS                               = 15
ACHI_SKILL_ADVANCE                          = 16
ACHI_SKILL_UPGRADE                          = 17
ACHI_SKILL_GS                               = 18
ACHI_TALENT_ADVANCE                         = 19
ACHI_TALENT_UPGRADE                         = 20
ACHI_TALENT_GS                              = 21
ACHI_RANDOM_SEARCH                          = 22

ACHI_TYPE_COUNT                             = 23

ACHI_DATA_INDEX_STAGE                       = 0
ACHI_DATA_INDEX_ID                          = 1
ACHI_DATA_INDEX_TYPE                        = 2
ACHI_DATA_INDEX_DESCRIPTION                 = 3
ACHI_DATA_INDEX_DATA                        = 4
ACHI_DATA_INDEX_COUNT                       = 5

ACHI_STAGE_UNCHANT                          = 0
ACHI_STAGE_CHANTED                          = 1
# Achievement reward
ACHI_REWARD_LEVEL                           = 0
ACHI_REWARD_MONEY                           = 1
ACHI_REWARD_ENERGY                          = 2

# Achievement reward result
ACHI_UNKNOWN            = 0
ACHI_OK                 = 1
ACHI_NOT_FINISHED       = 18
ACHI_ALREADY_GET        = 14

DBLOG_ACHI_REWARD   = 54

class Achievement(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        
        self.mID = moduleID
        self.mAchievements = {}
        self.mAchieveStage = {}              #
        self.mRewards = {}

    def getName(self):
        return "Achievement"
        
    def loadConfig(self, path):
        achiFilename = "%sachievement.txt" % (path)
        chanFilename = "%schanting.txt" % (path)
        tb = TabFile()
        if tb.load(achiFilename):
            achievements = {}
            achievestage = {}
            for i in xrange(tb.mRowNum):
                achi = [None for j in xrange(ACHI_DATA_INDEX_COUNT)]

                achi[ACHI_DATA_INDEX_STAGE]                 = tb.get(i, ACHI_DATA_INDEX_STAGE, 0, True)
                achi[ACHI_DATA_INDEX_ID]                    = tb.get(i, ACHI_DATA_INDEX_ID, 0, True)
                achi[ACHI_DATA_INDEX_TYPE]                  = tb.get(i, ACHI_DATA_INDEX_TYPE, 0, True)
                achi[ACHI_DATA_INDEX_DESCRIPTION]           = tb.get(i, ACHI_DATA_INDEX_DESCRIPTION, "", False).replace("\"", "")
                achi[ACHI_DATA_INDEX_DATA]                  = tb.get(i, ACHI_DATA_INDEX_DATA, 0, True)

                achiID = achi[ACHI_DATA_INDEX_ID]
                stageID = achi[ACHI_DATA_INDEX_STAGE]

                if achiID in achievements:
                    syserr("Achievement id %s already exists." % (achiID))
                    return False
                else:
                    achievements[achiID] = achi
                    if stageID in achievestage:
                        achievestage[stageID].append(achiID)
                    else:
                        achievestage[stageID] = [achiID, ]

            self.mAchieveStage = achievestage
            self.mAchievements = achievements
        else:
            syserr("Load %s failed." % (achiFilename))
            return False

        tb = TabFile()
        if tb.load(chanFilename):
            rewards = {}
            for i in xrange(tb.mRowNum):
                level               = tb.get(i, ACHI_REWARD_LEVEL, 0, True)
                money               = tb.get(i, ACHI_REWARD_MONEY, 0, True)
                energy              = tb.get(i, ACHI_REWARD_ENERGY, 0, True)

                if level in rewards:
                    syserr("Achievement Reward level %s already exists." % (level))
                    return False
                else:
                    rewards[level] = [level, money, energy,]

            self.mRewards = rewards
            return True
        else:
            syserr("Load %s failed." % (chanFilename))
            return False

    def checkPlayerData(self, player):
        if "s_AchieveStage" not in player.__dict__:
            player.s_AchieveStage = {}
        if "s_Achievements" not in player.__dict__:
            player.s_Achievements = {}

        attrs = (
            "TotalGetMoney",
            "TotalGetGoldMoney",
            "TotalGetEnergy",
            "TotalArenaNum",
            "TotalArenaWinNum",
            "TotalDungeonNum",
            "TotalRoleStrength"
            "TotalTaskNum",
            "TotalDailyTaskNum",
            "TotalEquipAdvance",
            "TotalEquipUpgrade",
            "TotalSkillAdvance",
            "TotalSkillUpgrade",
            "TotalTalentAdvance",
            "TotalTalentUpgrade",
            "TotalRandomSearchNum",
        )
        moduleData = getModuleData(player, self.mID, {})
        for attrName in attrs:
            if attrName not in moduleData:
                moduleData[attrName] = 0

    def getPlayerAttr(self, player, attrName):
        moduleData = getModuleData(player, self.mID, {})
        if attrName in moduleData:
            return moduleData[attrName]
        else:
            return 0

    def setPlayerAttr(self, player, attrName, value):
        moduleData = getModuleData(player, self.mID, {})
        moduleData[attrName] = value

    def addPlayerAttr(self, player, attrName, value):
        moduleData = getModuleData(player, self.mID, {})
        if attrName in moduleData:
            moduleData[attrName] += value
        else:
            moduleData[attrName] = value

    def chanting(self, player, stageID):
        if "s_AchieveStage" not in player.__dict__:
            player.s_AchieveStage = {}
        result = []
        if stageID in player.s_AchieveStage:
            if player.s_AchieveStage[stageID] == ACHI_STAGE_UNCHANT:
                player.s_AchieveStage[stageID] = ACHI_STAGE_CHANTED
                r = random.randint(0, 1)
                if r:
                    energy = self.mRewards[player.getLevel()][ACHI_REWARD_ENERGY]
                    player.addEnergy(energy)
                    result = [ACHI_OK, stageID, 6, energy, ]
                else:
                    money = self.mRewards[player.getLevel()][ACHI_REWARD_MONEY]
                    player.addMoney(money)
                    result = [ACHI_OK, stageID, 1, money, ]
                
            else:
                result = [ACHI_ALREADY_GET, stageID, ]
        else:
            result = [ACHI_NOT_FINISHED, stageID, ]
        
        return result

    def getAchievements(self, player):
        if "s_Achievements" not in player.__dict__:
            player.s_Achievements = {}

        result = []
        for achiID in self.mAchievements:
            isFinished = (achiID in player.s_Achievements)

            achi = self.mAchievements[achiID]
            achiType = achi[ACHI_DATA_INDEX_TYPE]
            achiStage = achi[ACHI_DATA_INDEX_STAGE]
            description = self.getAchievementDescription(player, achiID)

            result.append((achiID, isFinished, achiStage, description))

        return result

    def getAchievementDescription(self, player, achiID):
        if achiID in self.mAchievements:
            achi = self.mAchievements[achiID]

            achiID = achi[ACHI_DATA_INDEX_ID]
            achiType = achi[ACHI_DATA_INDEX_TYPE]
            achiData = achi[ACHI_DATA_INDEX_DATA]
            achiDesc = achi[ACHI_DATA_INDEX_DESCRIPTION]

            curValue = 0
            baseValue = 0

            if achiType == ACHI_FINISH_DUNGEON_NUM:
                baseValue = achiData
                curValue = self.getPlayerAttr(player, "TotalDungeonNum")

            elif achiType == ACHI_FINISH_THIS_DUNGEON:
                curValue = -1

            elif achiType == ACHI_FINISH_ARENA:
                baseValue = achiData
                curValue = self.getPlayerAttr(player, "TotalArenaNum")

            elif achiType == ACHI_FINISH_ARENA_AND_WIN:
                baseValue = achiData
                curValue = self.getPlayerAttr(player, "TotalArenaWinNum")

            elif achiType == ACHI_FINISH_TASK_NUM:
                baseValue = achiData
                curValue = self.getPlayerAttr(player, "TotalTaskNum")

            elif achiType == ACHI_FINISH_THIS_TASK:
                curValue = -1

            elif achiType == ACHI_FINISH_DAILY_TASK:
                baseValue = achiData
                curValue = self.getPlayerAttr(player, "TotalDailyTaskNum")

            elif achiType == ACHI_LEVEL:
                baseValue = achiData
                curValue = player.getLevel()

            elif achiType == ACHI_VIPLEVEL:
                baseValue = achiData
                curValue = player.getVipLevel()

            elif achiType == ACHI_GET_MONEY:
                baseValue = achiData
                curValue = self.getPlayerAttr(player, "TotalGetMoney")

            elif achiType == ACHI_BATTLE_POINT:
                baseValue = achiData
                curValue = player.getBattlePoint()

            elif achiType == ACHI_ROLE_STRENGTH:
                baseValue = achiData
                curValue = self.getPlayerAttr(player, "TotalRoleStrength")

            elif achiType == ACHI_EQUIP_ADVANCE:
                baseValue = achiData
                curValue = self.getPlayerAttr(player, "TotalEquipAdvance")

            elif achiType == ACHI_EQUIP_UPGRADE:
                baseValue = achiData
                curValue = self.getPlayerAttr(player, "TotalEquipUpgrade")

            elif achiType == ACHI_EQUIP_GS:
                curValue = -1

            elif achiType == ACHI_SKILL_ADVANCE:
                baseValue = achiData
                curValue = self.getPlayerAttr(player, "TotalSkillAdvance")

            elif achiType == ACHI_SKILL_UPGRADE:
                baseValue = achiData
                curValue = self.getPlayerAttr(player, "TotalSkillUpgrade")

            elif achiType == ACHI_SKILL_GS:
                curValue = -1

            elif achiType == ACHI_TALENT_ADVANCE:
                baseValue = achiData
                curValue = self.getPlayerAttr(player, "TotalTalentAdvance")

            elif achiType == ACHI_TALENT_UPGRADE:
                baseValue = achiData
                curValue = self.getPlayerAttr(player, "TotalTalentUpgrade")

            elif achiType == ACHI_TALENT_GS:
                curValue = -1

            elif achiType == ACHI_RANDOM_SEARCH:
                baseValue = achiData
                curValue = self.getPlayerAttr(player, "TotalRandomSearchNum")
                    
            if curValue > baseValue:
                curValue = baseValue

            if curValue == -1:
                achiDesc = achiDesc.replace("{0}", "").replace("/", "")
            else:
                achiDesc = achiDesc.replace("{0}", str(curValue)).replace("{1}", str(baseValue))

            return achiDesc

    def notifyActFinish(self, player, achiID):
        if achiID in self.mAchievements:
            achi = self.mAchievements[achiID]
            achiType = achi[ACHI_DATA_INDEX_TYPE]
            achiStage = achi[ACHI_DATA_INDEX_STAGE]
            description = self.getAchievementDescription(player, achiID)

            response = (
                    self.mID,
                    achiID,
                    achiStage,
                    description,
                )

            MMain.sendTextProtocol(player, "S2C_NotifyActFinish", response)

    def notifyActStgFinish(self, player, stageID):
        response = (
                self.mID,
                stageID,
            )
        MMain.sendTextProtocol(player, "S2C_NotifyActStgFinish", response)

    def checkFinishStage(self, player, achiID):
        if achiID in self.mAchievements:
            stageID = self.mAchievements[achiID][ACHI_DATA_INDEX_STAGE]
            if stageID in self.mAchieveStage:
                for achiID in self.mAchieveStage[stageID]:
                    if achiID not in player.s_Achievements:
                        return False
                return True
        return False

    def checkFinish(self, player, achiType):
        if "s_Achievements" not in player.__dict__:
            player.s_Achievements = {}

        isFinish = False
        for achiID in self.mAchievements:
            if achiID not in player.s_Achievements and achiType == self.mAchievements[achiID][ACHI_DATA_INDEX_TYPE]:
                if self.isAchievementFinished(player, achiID):
                    isFinish = True
                    stageID = self.mAchievements[achiID][ACHI_DATA_INDEX_STAGE]
                    player.s_Achievements[achiID] = stageID
                    self.notifyActFinish(player, achiID)
                    if stageID not in player.s_AchieveStage and self.checkFinishStage(player, achiID):
                        player.s_AchieveStage[stageID] = ACHI_STAGE_UNCHANT
                        self.notifyActStgFinish(player, stageID)

    def isAchievementFinished(self, player, achiID):
        if achiID in player.s_Achievements:
            return True

        if achiID in self.mAchievements:
            achi = self.mAchievements[achiID]

            achiID = achi[ACHI_DATA_INDEX_ID]
            achiType = achi[ACHI_DATA_INDEX_TYPE]
            achiData = achi[ACHI_DATA_INDEX_DATA]

            if achiType == ACHI_FINISH_DUNGEON_NUM:
                return achiData <= self.getPlayerAttr(player, "TotalDungeonNum")

            elif achiType == ACHI_FINISH_THIS_DUNGEON:
                pass

            elif achiType == ACHI_FINISH_ARENA:
                return achiData <= self.getPlayerAttr(player, "TotalArenaNum")

            elif achiType == ACHI_FINISH_ARENA_AND_WIN:
                return achiData <= self.getPlayerAttr(player, "TotalArenaWinNum")

            elif achiType == ACHI_FINISH_TASK_NUM:
                return achiData <= self.getPlayerAttr(player, "TotalTaskNum")

            elif achiType == ACHI_FINISH_THIS_TASK:
                pass

            elif achiType == ACHI_FINISH_DAILY_TASK:
                return achiData <= self.getPlayerAttr(player, "TotalDailyTaskNum")

            elif achiType == ACHI_LEVEL:
                return achiData <= player.getLevel()

            elif achiType == ACHI_VIPLEVEL:
                return achiData <= player.getVipLevel()

            elif achiType == ACHI_GET_MONEY:
                return achiData <= self.getPlayerAttr(player, "TotalGetMoney")

            elif achiType == ACHI_BATTLE_POINT:
                return achiData <= player.getBattlePoint()

            elif achiType == ACHI_ROLE_STRENGTH:
                return achiData <= self.getPlayerAttr(player, "TotalRoleStrength")

            elif achiType == ACHI_EQUIP_ADVANCE:
                return achiData <= self.getPlayerAttr(player, "TotalEquipAdvance")

            elif achiType == ACHI_EQUIP_UPGRADE:
                return achiData <= self.getPlayerAttr(player, "TotalEquipUpgrade")

            elif achiType == ACHI_EQUIP_GS:
                pass

            elif achiType == ACHI_SKILL_ADVANCE:
                return achiData <= self.getPlayerAttr(player, "TotalSkillAdvance")

            elif achiType == ACHI_SKILL_UPGRADE:
                return achiData <= self.getPlayerAttr(player, "TotalSkillUpgrade")

            elif achiType == ACHI_SKILL_GS:
                pass

            elif achiType == ACHI_TALENT_ADVANCE:
                return achiData <= self.getPlayerAttr(player, "TotalTalentAdvance")

            elif achiType == ACHI_TALENT_UPGRADE:
                return achiData <= self.getPlayerAttr(player, "TotalTalentUpgrade")

            elif achiType == ACHI_TALENT_GS:
                pass

            elif achiType == ACHI_RANDOM_SEARCH:
                return achiData <= self.getPlayerAttr(player, "TotalRandomSearchNum")

        else:
            return False

    def getMenu(self, player, npcID):
        return []

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_CREATED:
            player = param0
            self.checkPlayerData(player)

        elif msg == MSG_PLAYER_ONLINE:
            player = param0
            self.checkPlayerData(player)

            needRefreshStage = True
            for stageID in self.mAchieveStage:
                if stageID not in player.s_AchieveStage:
                    for achiID in self.mAchieveStage[stageID]:
                        if achiID not in player.s_Achievements:
                            needRefreshStage = False
                            break
                    if needRefreshStage:
                        player.s_AchieveStage[stageID] = ACHI_STAGE_UNCHANT


        elif msg == MSG_PLAYER_DAY_CHANGED:
            player = param0
            if "s_AchieveStage" not in player.__dict__:
                player.s_AchieveStage = {}
            for stageID in player.s_AchieveStage:
                player.s_AchieveStage[stageID] = ACHI_STAGE_UNCHANT

        elif msg == MSG_PLAYER_LEVELUP:
            player = param0
            self.checkFinish(player, ACHI_LEVEL)

        elif msg == MSG_PLAYER_VIPLEVEL_CHANGED:
            player = param0

        elif msg == MSG_PLAYER_MONEY_CHANGED:
            player = param0
            money = param1

            if money > 0:
                self.addPlayerAttr(player, "TotalGetMoney", money)
                self.checkFinish(player, ACHI_GET_MONEY)

        elif msg == MSG_PLAYER_TRAIN_ROLE:
            player = param0
            self.addPlayerAttr(player, "TotalRoleStrength", 1)
            self.checkFinish(player, ACHI_ROLE_STRENGTH)

        elif msg == MSG_PLAYER_ITEM_UPGRADE:
            player = param0
            self.addPlayerAttr(player, "TotalEquipUpgrade", 1)
            self.checkFinish(player, ACHI_EQUIP_UPGRADE)
            self.checkFinish(player, ACHI_EQUIP_GS)

        elif msg == MSG_PLAYER_ITEM_ADVANCE:
            player = param0
            self.addPlayerAttr(player, "TotalEquipAdvance", 1)
            self.checkFinish(player, ACHI_EQUIP_ADVANCE)

        elif msg == MSG_PLAYER_SKILL_UPGRADE:
            player = param0
            self.addPlayerAttr(player, "TotalSkillUpgrade", 1)
            self.checkFinish(player, ACHI_SKILL_UPGRADE)
            self.checkFinish(player, ACHI_SKILL_GS)

        elif msg == MSG_PLAYER_SKILL_ADVANCE:
            player = param0
            self.addPlayerAttr(player, "TotalSkillAdvance", 1)
            self.checkFinish(player, ACHI_SKILL_ADVANCE)

        elif msg == MSG_PLAYER_TALENT_UPGRADE:
            player = param0
            self.addPlayerAttr(player, "TotalTalentUpgrade", 1)
            self.checkFinish(player, ACHI_TALENT_UPGRADE)
            self.checkFinish(player, ACHI_TALENT_GS)

        elif msg == MSG_PLAYER_TALENT_ADVANCE:
            player = param0
            self.addPlayerAttr(player, "TotalTalentAdvance", 1)
            self.checkFinish(player, ACHI_TALENT_ADVANCE)

        elif msg == MSG_PLAYER_FINISH_DUNGEON:
            player = param0
            dungeon, star, costTime = param1
            dungeonID = dungeon.getID()
            self.addPlayerAttr(player, "TotalDungeonNum", 1)
            self.checkFinish(player, ACHI_FINISH_DUNGEON_NUM)

            for achiID in self.mAchievements:
                if achiID not in player.s_Achievements:
                    achi = self.mAchievements[achiID]
                    stageID = achi[ACHI_DATA_INDEX_STAGE]
                    achiType = achi[ACHI_DATA_INDEX_TYPE]
                    achiData = achi[ACHI_DATA_INDEX_DATA]
                    if achiType == ACHI_FINISH_THIS_DUNGEON and achiData == dungeonID:
                        player.s_Achievements[achiID] = stageID
                        self.notifyActFinish(player, achiID)
                        if stageID not in player.s_AchieveStage and self.checkFinishStage(player, achiID):
                            player.s_AchieveStage[stageID] = ACHI_STAGE_UNCHANT
                            self.notifyActStgFinish(player, stageID)

        elif msg == MSG_PLAYER_ENTER_ARENA:
            player = param0
            result,rank = param1
            if result == 0:
                self.addPlayerAttr(player, "TotalArenaNum", 1)
                self.checkFinish(player, ACHI_FINISH_ARENA)
            if result == 1:
                self.addPlayerAttr(player, "TotalArenaWinNum", 1)
                self.checkFinish(player, ACHI_FINISH_ARENA_AND_WIN)

        elif msg == MSG_PLAYER_BATTLEPOINT_CHANGED:
            player = param0
            self.checkFinish(player, ACHI_BATTLE_POINT)

        elif msg == MSG_PLAYER_RANDOM_OTHER:
            player = param0

        elif msg == MSG_PLAYER_RANDOM_ITEM:
            player = param0

        elif msg == MSG_PLAYER_FINISH_TASK:
            player = param0
            taskID = param1
            self.addPlayerAttr(player, "TotalTaskNum", 1)
            self.checkFinish(player, ACHI_FINISH_TASK_NUM)

            for achiID in self.mAchievements:
                if achiID not in player.s_Achievements:
                    achi = self.mAchievements[achiID]
                    achiType = achi[ACHI_DATA_INDEX_TYPE]
                    achiData = achi[ACHI_DATA_INDEX_DATA]
                    if achiType == ACHI_FINISH_THIS_TASK and achiData == taskID:
                        player.s_Achievements[achiID] = achi[ACHI_DATA_INDEX_STAGE]
                        self.notifyActFinish(player, achiID)
                        if stageID not in player.s_AchieveStage and self.checkFinishStage(player, achiID):
                            player.s_AchieveStage[stageID] = ACHI_STAGE_UNCHANT
                            self.notifyActStgFinish(player, stageID)

        elif msg == MSG_PLAYER_FINISH_DAILY_TASK:
            player = param0
            self.addPlayerAttr(player, "TotalDailyTaskNum", 1)
            self.checkFinish(player, ACHI_FINISH_DAILY_TASK)

ModuleID = 4
Instance = Achievement(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_CREATED,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_DAY_CHANGED,
    MSG_PLAYER_LEVELUP,
    MSG_PLAYER_VIPLEVEL_CHANGED,
    MSG_PLAYER_MONEY_CHANGED,
    MSG_PLAYER_TRAIN_ROLE,
    MSG_PLAYER_ITEM_UPGRADE,
    MSG_PLAYER_ITEM_ADVANCE,
    MSG_PLAYER_SKILL_UPGRADE,
    MSG_PLAYER_SKILL_ADVANCE,
    MSG_PLAYER_TALENT_UPGRADE,
    MSG_PLAYER_TALENT_ADVANCE,
    MSG_PLAYER_FINISH_DUNGEON,
    MSG_PLAYER_ENTER_ARENA,
    MSG_PLAYER_BATTLEPOINT_CHANGED,
    MSG_PLAYER_RANDOM_OTHER,
    MSG_PLAYER_RANDOM_ITEM,
    MSG_PLAYER_FINISH_TASK,
    MSG_PLAYER_FINISH_DAILY_TASK,
])