#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

GM_BOAED = 1
GM_HOESE = 2


class InfoCenter(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mLed = {}#id:[]
        self.mBoard = {}
        self.mNotice = {}                      
        engine.Instance.registerTextProtocol("C2S_InfoCenter", self.onProtocol)

    def isActived(self, player):
        return True

    def getName(self):
        return "InfoCenter"

    def getInfo(self):
        return Err_OK

    def doAction(self):
        return Err_Ok

    def loadConfig(self):
        return True
#如果添加的数据已存在则删除数据
    def addNotice(self, NoticeData):
        if len(NoticeData) == 5:
            curTime = int(time.time())
            if NoticeData[3] > curTime:
                if not NoticeData[0]:
                    NoticeData[0] = MMain.genUUID()
                    self.mNotice[NoticeData[0]] = NoticeData
                else:
                    if NoticeData[0] in self.mNotice:
                        del self.mNotice[NoticeData[0]]

                MMain.setSetting("notice", self.mNotice)
                result = self.getNotice(True)
                self.notifyRefreshInfo(result)
            else: 
                print "GM send notice endtime is error"

    def getNotice(self,isVild):
        notice = []
        if isVild:
            curTime = int(time.time())
            for i in self.mNotice:
                if self.mNotice[i][3] > curTime:
                    notice.append(self.mNotice[i])
            return json.dumps({"notice": notice,})
        else:
            for i in self.mNotice:
                notice.append(self.mNotice[i])
            return notice
        

    def setNotice(self, NoticeData):
        pass
    def delNotice(self,Uid):
        if Uid in self.mNotice:
            del self.mNotice[Uid]
#添加数据如果存在uuid and 无效  则删除记录
    def addBoard(self, boardData):
        if len(boardData) == 7:
            curTime = int(time.time())
            if boardData[3] == 0:
                boardData[3] = curTime
            if not boardData[0]:
                boardData[0] = MMain.genUUID()
                self.mBoard[boardData[0]] = boardData
            else:
                if boardData[0] in self.mBoard and boardData[2] == 0:
                    del self.mBoard[boardData[0]]
            MMain.setSetting("board", self.mBoard)
            return True
        return False

    def getBoard(self,isVild):
        board = []
        curTime = int(time.time())
        if isVild:            
            for i in self.mBoard.keys():
                if len(self.mBoard[i]) == 7:
                    if self.mBoard[i][2] == 1 and self.mBoard[i][3] < curTime and self.mBoard[i][6] > curTime:
                        temp = self.mBoard[i]
                        board.append((temp[1],temp[3],temp[4],temp[5]))
                    elif self.mBoard[i][2] == 0 or self.mBoard[i][6] <= curTime:
                        del self.mBoard[i]
                elif self.mBoard[i][2] == 1 and self.mBoard[i][3] < curTime:
                    temp = self.mBoard[i]
                    board.append((temp[1],temp[3],temp[4],temp[5]))

            return json.dumps({"board": board,})
        else:
            for i in self.mBoard.keys():
                if len(self.mBoard[i]) == 7 and (self.mBoard[i][2] == 0 or self.mBoard[i][6] <= curTime):
                    del self.mBoard[i]
                    continue
                board.append(self.mBoard[i])
            return board

    def setBoard(self,BoardData):
        pass

    def delBoard(self,Uid):
        if Uid in self.mBoard:
            del self.mBoard[Uid]

    def notifyRefreshInfo(self, RefreshInfo):
        allPlayers = MMain.getAllPlayers()
        for tmpPlayer in allPlayers:
            clientID = tmpPlayer.getClientID()
            if clientID != -1:
                MMain.sendTextProtocol(tmpPlayer, "S2C_InfoCenter", (RefreshInfo, ))

    def onProtocol(self, player, data):
        jdata = json.loads(data[0])
        result = []
        if jdata["type"] == "notice":
            result = self.getNotice(True)
        elif jdata["type"] == "board":
            result = self.getBoard(True)

        MMain.sendTextProtocol(player, "S2C_InfoCenter", (result, ))

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            notice = MMain.getSetting("notice")
            if notice:
                #MMain.setSetting("notice", self.mNotice)
                self.mNotice = notice
            board = MMain.getSetting("board")
            if board:
                #MMain.setSetting("board", self.mBoard)
                self.mBoard = board
        elif msg == MSG_PLAYER_ONLINE:
            player = param0
            result = self.getNotice(True)
            MMain.sendTextProtocol(player, "S2C_InfoCenter", (result, ))

    def getMenu(self, player, npcID):
        return []

ModuleID = 20
Instance = InfoCenter(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
])
