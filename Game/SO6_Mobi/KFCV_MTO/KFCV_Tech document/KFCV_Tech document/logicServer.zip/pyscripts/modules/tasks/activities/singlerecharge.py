#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

REWARD_INDEX_TYPE           = 0
REWARD_INDEX_VALUE          = 1

RESULT_NOT_ACTIVED = json.dumps({"Result":1, "ResultDesc":GlobalStrings[50]})
RESULT_INDEX_ERROR = json.dumps({"Result":2, "ResultDesc":GlobalStrings[173]})
RESULT_NO_REWARD = json.dumps({"Result":3, "ResultDesc":GlobalStrings[276]})
RESULT_BAG_FULL = json.dumps({"Result":4, "ResultDesc":GlobalStrings[168]})
RESULT_NOT_FINISHED = json.dumps({"Result":5, "ResultDesc":GlobalStrings[175]})

class SingleRecharge(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID

        self.mRewards = []
        self.mInitData = {}

    def getName(self):
        return GlobalStrings[277]

    def getInfo(self, player):
        data = self.getPlayerData(player, self.mInitData)

        rewards = []
        for reward in self.mRewards:
            goldMoney = reward[0]

            rewardNum = 0
            if goldMoney in data:
                rewardNum = data[goldMoney]

            rewards.append((
                goldMoney,
                reward[1],
                rewardNum,
            ))
        rewards.sort()

        info = {}
        info["Rewards"] = rewards
        info["BeginTime"] = self.mBeginTime
        info["EndTime"] = self.mEndTime

        return json.dumps(info)

    def doAction(self, player, actData):
        if self.isActived(player):
            data = self.getPlayerData(player, self.mInitData)

            actData = json.loads(actData)
            index = actData["Index"]

            if index >= 0 and index < len(self.mRewards):
                index = len(self.mRewards) - index - 1
                rewardInfo = self.mRewards[index]
                targetValue = rewardInfo[0]
                rewards = rewardInfo[1]
                if targetValue in data:
                    if data[targetValue] > 0:
                        if self.canAddAllReward(player, rewards):
                            data[targetValue] -= 1
                            message = GlobalStrings[172]
                            for reward in rewards:
                                self.addReward(player, reward)
                                message += self.getRewardDesc(reward)

                            self.checkHasReward(player)
                            player.saveToDB()
                            return json.dumps({
                                "Result": 0,
                                "ResultDesc": message,
                            })
                        else:
                            return RESULT_BAG_FULL
                    else:
                        return RESULT_NO_REWARD
                else:
                    return RESULT_NOT_FINISHED
            else:
                return RESULT_INDEX_ERROR

        else:
            return RESULT_NOT_ACTIVED

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)

        syslog("Loading SingleRecharge config...")

        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = {}
            for i in xrange(tb.mRowNum):
                offset = 0;

                goldMoney = tb.get(i, 0, 0, True)
                rewardType = tb.get(i, 1, 0, True)
                rewardValue = tb.get(i, 2, "", False).replace("\"", "")

                if rewardType == REWARD_TYPE_ITEM:
                    tmpItems = []
                    tmpBlocks = rewardValue.split(";")
                    for tmpBlock in tmpBlocks:
                        itemBlocks = tmpBlock.split(",")
                        if len(itemBlocks) == 3:
                            tmpItems.append((
                                int(itemBlocks[0]),
                                int(itemBlocks[1]),
                                int(itemBlocks[2]),
                            ))
                    rewardValue = tmpItems
                else:
                    rewardValue = int(rewardValue)

                if goldMoney in rewards:
                    rewards[goldMoney].append((
                        rewardType,
                        rewardValue,
                    ))
                else:
                    rewards[goldMoney] = [(
                        rewardType,
                        rewardValue,
                    ),]

            self.mRewards = []
            for goldMoney in rewards:
                self.mRewards.append((
                    goldMoney,
                    rewards[goldMoney],
                ))
            self.mRewards.sort(reverse=True)

            return True

        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False

    def checkHasReward(self, player):
        data = self.getPlayerData(player, self.mInitData)

        hasReward = False
        for rewardInfo in self.mRewards:
            targetValue = rewardInfo[0]
            if targetValue in data:
                if data[targetValue] > 0:
                    hasReward = True
                    break

        self.notifyActReward(player, hasReward)

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        else:
            player = param0
            if player and self.isActived(player):
                if msg == MSG_PLAYER_ONLINE:
                    player = param0
                    self.checkHasReward(player)

                elif msg == MSG_PLAYER_GOLDMONEY_CHANGED:
                    player = param0
                    value, way, productId = param1

                    if way == GMCW_Pay:
                        data = self.getPlayerData(player, self.mInitData)

                        goldMoneyList = []
                        for rewardInfo in self.mRewards:
                            goldMoney = rewardInfo[0]
                            goldMoneyList.append(goldMoney)
                        goldMoneyList.sort(reverse = True)

                        for goldMoney in goldMoneyList:
                            if value >= goldMoney:
                                if goldMoney not in data:
                                    data[goldMoney] = 1
                                else:
                                    data[goldMoney] += 1

                                self.notifyActReward(player, True)
                                break

    def getMenu(self, player, npcID):
        return []

ModuleID = 13
Instance = SingleRecharge(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_GOLDMONEY_CHANGED,
])
