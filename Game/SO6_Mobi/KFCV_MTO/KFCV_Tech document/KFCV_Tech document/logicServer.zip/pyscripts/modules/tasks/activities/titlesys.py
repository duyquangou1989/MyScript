#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

TYPE_BUY_MONEY          = 1  # 购买铜钱
TYPE_UPBATTLEPOINT      = 2  # 提升战斗力
TYPE_INVOKEPET          = 3  # 获得宠物
TYPE_INVOKEHIGHPET      = 4  # 获得橙色宠物
TYPE_UPVIPLEVEL         = 5  # vip等级提升
TYPE_INVOKETALENT       = 6  # 解锁心法
TYPE_LOGINGAME          = 7  # 连续登录
TYPE_INVOKESTONE        = 8  # 镶嵌宝石
TYPE_UPARENALEVEL       = 9  # 擂台赛等级
TYPE_WINARENA           = 10 # 单人pk
TYPE_ADVANCESKILL       = 11 # 技能突破
TYPE_LOTTERY            = 12 # 抽奖
TYPE_HIGHEQUIPONE       = 13 # 少林神装
TYPE_HIGHEQUIPTWO       = 14 # 绫罗神装
TYPE_HIGHEQUIPTHREE     = 15 # 雪月神装
TYPE_EIGHTING           = 16 # 十八重楼
TYPE_ENDLESS            = 17 # 无尽之塔
TYPE_ITEM_UPGRADEONE    = 18 # 道具升级少林
TYPE_ITEM_UPGRADETWO    = 19 # 道具升级绫罗
TYPE_ITEM_UPGRADETHREE  = 20 # 道具升级雪月
TYPE_FINISHTHREESTAR    = 21 # 三星通关



DATA_TASK_INDEX_TYPE        = 0
DATA_TASK_INDEX_LEVEL       = 1
DATA_TASK_INDEX_NAME        = 2
DATA_TASK_INDEX_VALUE       = 3
DATA_TASK_INDEX_REWARD      = 4
#DATA_TASK_INDEX_HADATTR     = 9
DATA_TASK_INDEX_ONATTR     = 9


class TitleSys(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        self.mID = moduleID
        self.mTasks = {}
        self.mInitData = {}                 #taskType:count

    def getPlayerData(self, player):
        data = getModuleData(player, self.mID, {})
        if not "Tasks" in data:
            data["Tasks"] = copy.deepcopy(self.mInitData)

        return data

    def getName(self):
        return "TitleSys"

    def isActived(self, player):
        if player.getLevel() >= 10:
            return True
        else:
            return False



    def getInfo(self, player):
        result = {}

        data = self.getPlayerData(player)
        taskData = data["Tasks"]
        if "s_CurTitle" not in player.__dict__:
            player.s_CurTitle = 0
        showTaskData = []

        for tType in taskData:
            if tType in self.mTasks:
                realValue = taskData[tType]
                task = self.mTasks[tType]

                taskType = task[DATA_TASK_INDEX_TYPE]
                taskLevel = task[DATA_TASK_INDEX_LEVEL]
                taskName = task[DATA_TASK_INDEX_NAME]
                taskValue = task[DATA_TASK_INDEX_VALUE]
                taskReward = task[DATA_TASK_INDEX_REWARD]
                taskOnAttr = task[5]
                if taskType != TYPE_UPARENALEVEL:
                    if realValue >= taskValue:
                        realValue = taskValue
                if taskType == TYPE_UPARENALEVEL:
                    if realValue <= taskValue and realValue != 0:
                        realValue = 1
                    else:
                        realValue = 0
                    taskValue = 1
                elif taskType == TYPE_EIGHTING:
                    if realValue <= taskValue:
                        if realValue != 0:
                            realValue = 18 - (taskValue - realValue)
                    else:
                        realValue = 18
                    taskValue = 18
                elif taskType == TYPE_ENDLESS:
                    if realValue <= taskValue:
                        if realValue != 0:
                            realValue = 100 - (taskValue - realValue)
                    else:
                        realValue = 100
                    taskValue = 100

                CurTitle = False
                if taskReward == player.s_CurTitle:
                    CurTitle = True
                showTaskData.append((
                    taskType,
                    realValue,
                    taskValue,
                    taskReward,
                    CurTitle,
                    [],
                    taskOnAttr,
                ))

        result["Tasks"] = showTaskData
        return json.dumps(result)

    def doAction(self,player,actData):
        jdata = json.loads(actData)
        titleId = jdata["titleId"]
        if titleId == 0:
            player.s_CurTitle = titleId
            #self.callTitleBuff(player)
            #MMain.refreshTitleAttrToPlayer(player)
            MMain.notifyModified(player, 32 , player.s_CurTitle, player.s_CurTitle)
            #MMain.sendPlayerInfo(player)
            return Err_Ok
        if "s_myTitles" in player.__dict__:
            if titleId in player.s_myTitles :
                player.s_CurTitle = titleId
                #$self.callTitleBuff(player)
                #MMain.refreshTitleAttrToPlayer(player)
                MMain.notifyModified(player, 32 , player.s_CurTitle, player.s_CurTitle)
                #MMain.sendPlayerInfo(player)
                return Err_Ok
        return Err_NotExist
        
    def loadConfig(self, path):
        tasksFilename = "%stasks.txt" % (path)

        syslog("Loading TitleSys config...")

        tb = TabFile()
        if tb.load(tasksFilename):
            tasks = {}
            initdata = {}
            for i in xrange(tb.mRowNum):
                task = []
                taskType = tb.get(i, DATA_TASK_INDEX_TYPE, 0, True)
                taskLevel = tb.get(i, DATA_TASK_INDEX_LEVEL, 0, True)
                taskName = tb.get(i, DATA_TASK_INDEX_NAME, "", False).replace("\n", "")           
                taskValue = tb.get(i, DATA_TASK_INDEX_VALUE, 0, True)
                taskTitle = tb.get(i, DATA_TASK_INDEX_REWARD, 0, True)
                taskOnAttrStr = tb.get(i, DATA_TASK_INDEX_ONATTR, "", False).replace("\n", "")
                taskOnAttr = [
                    [int(value) for value in reward.split(",")]
                        for reward in taskOnAttrStr.split(";") if reward and reward.count(',') in (1, 2)
                ]

                task = [taskType, taskLevel, taskName, taskValue, taskTitle, taskOnAttr]
                tasks[taskType] = task
                initdata[taskType] = 0
            self.mTasks = tasks
            self.mInitData = initdata
            return True
        else:
            syserr("Load %s failed." % (tasksFilename))
            return False

    def addPoint(self, player, taskType, point):
        data = self.getPlayerData(player)
        taskData = data["Tasks"]
        if "s_myTitles" not in player.__dict__:
            player.s_myTitles = []
        if taskType in self.mTasks:
            task = self.mTasks[taskType]
            title = task[DATA_TASK_INDEX_REWARD]
            if title not in player.s_myTitles:
                if taskType in taskData:
                    if taskType == TYPE_UPARENALEVEL:
                        taskData[taskType] = point
                    elif taskType == TYPE_UPBATTLEPOINT:
                        taskData[taskType] = point
                    elif taskType == MSG_PLAYER_VIPLEVEL_CHANGED:
                        taskData[taskType] = point
                    elif taskType == MSG_PLAYER_DAY_CHANGED:
                        if point == 1:
                            taskData[taskType] += point
                        else:
                            taskData[taskType] = 1
                    elif taskType == TYPE_HIGHEQUIPONE or taskType == TYPE_HIGHEQUIPTWO or taskType == TYPE_HIGHEQUIPTHREE:
                        taskData[taskType] = point
                    elif taskType == TYPE_EIGHTING or taskType == TYPE_ENDLESS:
                        if point > taskData[taskType]:
                            taskData[taskType] = point
                    elif taskType == TYPE_FINISHTHREESTAR:
                        taskData[taskType] = point
                    elif taskType == TYPE_ITEM_UPGRADEONE or taskType == TYPE_ITEM_UPGRADETWO or taskType == TYPE_ITEM_UPGRADETHREE:
                        taskData[taskType] = point
                    elif taskType == TYPE_UPVIPLEVEL:
                        taskData[taskType] = point
                    else:
                        taskData[taskType] += point
                    if taskType == TYPE_UPARENALEVEL:
                        if taskData[taskType] <= task[DATA_TASK_INDEX_VALUE] and taskData[taskType] != 0:
                            self.addReward(player, (9,title))
                            self.notifyActReward(player, True)
                    else:
                        if taskData[taskType]>= task[DATA_TASK_INDEX_VALUE]:
                            self.addReward(player, (9,title))
                            self.notifyActReward(player, True)
                            
    def getCurTitle(self, player):
        if "s_CurTitle" not in player.__dict__:
            player.s_CurTitle = 0
        return player.s_CurTitle

    def callTitleBuff(self, player):
        onbuffs = []
        if "s_CurTitle" not in player.__dict__:
            player.s_CurTitle = 0
        if "s_myTitles" not in player.__dict__:
            player.s_myTitles = []   
        curTitle = player.s_CurTitle
        if curTitle in self.mTasks:
            titleData = self.mTasks[curTitle]
            for attr in titleData[5]:
                if len(attr) ==2:
                    onbuffs.append(attr)
        MMain.getTitleAttr(player, [], onbuffs)


    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        else:
            player = param0
            if msg == MSG_PLAYER_ONLINE:
                data = self.getPlayerData(player)
                taskData = data["Tasks"]
                for taskType in self.mInitData:
                    if taskType not in taskData:
                        taskData[taskType] = 0

            elif msg == MSG_PLAYER_BUY_MONEY:
                money = param1
                self.addPoint(player, TYPE_BUY_MONEY, money)

            elif msg == MSG_PLAYER_BATTLEPOINT_CHANGED:
                battlepoint = param1
                self.addPoint(player, TYPE_UPBATTLEPOINT, battlepoint)

            elif msg == MSG_PLAYER_PET_INVOKE:
                pet = param1
                self.addPoint(player, TYPE_INVOKEPET, 1)
                quality = pet.getQuality()
                if quality >= 9 and quality <= 11:
                    self.addPoint(player, TYPE_INVOKEHIGHPET, 1)

            elif msg == MSG_PLAYER_VIPLEVEL_CHANGED:
                self.addPoint(player, TYPE_UPVIPLEVEL, player.getVipLevel())

            elif msg == MSG_PLAYER_TALENT_ADVANCE:
                self.addPoint(player, TYPE_INVOKETALENT, 1)

            elif msg == MSG_PLAYER_DAY_CHANGED:
                CurTime = self.getZerotimestamp()
                LastTime = player.getLogoutTime()
                if CurTime - LastTime < 86400:
                    self.addPoint(player, TYPE_LOGINGAME, 1)
                else:
                    self.addPoint(player, TYPE_LOGINGAME, 0)
            elif msg == MSG_PLAYER_ENTER_ARENA:
                status, rank = param1
                if status == 1:
                    self.addPoint(player, TYPE_UPARENALEVEL, rank)
                    self.addPoint(player, TYPE_WINARENA, 1)
            elif msg == MSG_PLAYER_SKILL_ADVANCE:
                skillid = param1
                if skillid % 10 == 5 :
                    self.addPoint(player, TYPE_ADVANCESKILL, 1)
            elif msg == MSG_PLAYER_LOTTERY:
                mtype,maction = param1
                if mtype == 2:
                    if maction == 1:
                        self.addPoint(player, TYPE_LOTTERY, 1)
                    elif maction == 2:
                        self.addPoint(player, TYPE_LOTTERY, 10)
            elif msg == MSG_PLAYER_EQUIP_ITEM:
                index = player.getCurRole()
                role = MMain.getRole(index)
                num = 0
                if role:
                    for i in xrange(0, 7):
                        item = role.getEquipment(i)
                        if item:
                           quality = item.getQuality()
                           if quality >= 9 and quality <= 11:
                               num += 1
                    if role.getJob() == 1:
                        self.addPoint(player, TYPE_HIGHEQUIPONE, num)
                    elif role.getJob() == 2:
                        self.addPoint(player, TYPE_HIGHEQUIPTWO, num)
                    elif role.getJob() == 3:
                        self.addPoint(player, TYPE_HIGHEQUIPTHREE, num)
                else:
                    print "not find role ... "

            elif msg == MSG_PLAYER_FINISH_DUNGEON:
                dungeon, dungeonStar, costTime = param1
                dungeonID = dungeon.getID()
                dungeonType = int(dungeonID / 10000)
                if dungeonType == 4:
                    self.addPoint(player, TYPE_EIGHTING, dungeonID)
                elif dungeonType == 2:
                    if dungeonStar == 3:
                        if "s_finishdungeon" not in player.__dict__:
                            player.s_finishdungeon = []
                        if dungeonID not in player.s_finishdungeon:
                            player.s_finishdungeon.append(dungeonID)
                        self.addPoint(player, TYPE_FINISHTHREESTAR, len(player.s_finishdungeon))
                elif dungeonType == 5:
                    self.addPoint(player, TYPE_ENDLESS, dungeonID)

            elif msg == MSG_PLAYER_ITEM_UPGRADE:
                index = player.getCurRole()
                role  = MMain.getRole(index)
                if role:
                    level = role.getMinCasketInfoLevel()
                    if role.getJob() == 1:
                        self.addPoint(player, TYPE_ITEM_UPGRADEONE, level)
                    elif role.getJob() == 2:
                        self.addPoint(player, TYPE_ITEM_UPGRADETWO, level)
                    elif role.getJob() == 3:
                        self.addPoint(player, TYPE_ITEM_UPGRADETHREE, level)
                else:
                    print "not find role ...."



    def getMenu(self, player, npcID):
        return []        

ModuleID = 47
Instance = TitleSys(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_BUY_MONEY,
    MSG_PLAYER_BATTLEPOINT_CHANGED,
    MSG_PLAYER_PET_INVOKE,
    MSG_PLAYER_VIPLEVEL_CHANGED,
    MSG_PLAYER_TALENT_ADVANCE,
    MSG_PLAYER_DAY_CHANGED,
    MSG_PLAYER_ENTER_ARENA,
    MSG_PLAYER_SKILL_ADVANCE,
    MSG_PLAYER_LOTTERY,
    MSG_PLAYER_EQUIP_ITEM,
    MSG_PLAYER_FINISH_DUNGEON,
    MSG_PLAYER_ITEM_UPGRADE,

    ])
