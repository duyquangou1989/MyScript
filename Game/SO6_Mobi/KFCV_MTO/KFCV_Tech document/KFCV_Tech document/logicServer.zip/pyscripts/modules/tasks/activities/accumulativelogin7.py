#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

class AccumulativeLogin7(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID

        self.mRewards = {}
        self.mInitData = [0, 0, {}]                 #lastLoginTime, loginCount, GotRewardDay

    def isShow(self, player):
        data = self.getPlayerForeverData(player, self.mInitData)
        if len(data[2]) == 7:
            return False
        return True

    def getName(self):
        return "AccumulativeLogin7"

    def getInfo(self, player):
        data = self.getPlayerForeverData(player, self.mInitData)
        lastLoginTime = data[0]
        loginCount = data[1]

        rewards = []
        for day in self.mRewards:
            canGetReward = False
            gotRewardAlready = False
            if loginCount >= day:
                canGetReward = True
                if day in data[2]:
                    gotRewardAlready = True
            elif day in data[2]:
                gotRewardAlready = True

            rewards.append((
                day,
                self.mRewards[day],
                canGetReward,
                gotRewardAlready,
            ))
        rewards.sort()

        info = {}
        info["LoginCount"] = loginCount
        info["Rewards"] = rewards

        return json.dumps(info)

    def doAction(self, player, actData):
        data = self.getPlayerForeverData(player, self.mInitData)

        actData = json.loads(actData)
        day = actData["Day"]

        if day in self.mRewards:
            if day not in data[2]:
                if data[1] >= day:
                    rewards = self.mRewards[day]
                    if self.canAddAllReward(player, rewards):
                        data[2][day] = True
                        for reward in rewards:
                            self.addReward(player, reward)

                        self.checkHasReward(player)
                        player.saveToDB()
                        return Err_Ok
                    else:
                        return Err_NotEnoughSpace
                else:
                    return Err_Cannot
            else:
                return Err_Repetition
        else:
            return Err_Invalid

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)
        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = {}
            for i in xrange(tb.mRowNum):

                day             = tb.get(i, 0, 0, True)
                rewardstr       = tb.get(i, 1, "", False).replace("\"", "")

                extrareward = [
                    [int(value) for value in reward.split(",")]
                        for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2)
                ]

                rewards[day] = extrareward
            self.mRewards = rewards
            return True
        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False

    def checkHasReward(self, player):
        data = self.getPlayerForeverData(player, self.mInitData)

        hasReward = False
        for i in xrange(data[1]):
            day = i + 1
            if day not in data[2] and day <= 7:
                hasReward = True
                break

        self.notifyActReward(player, hasReward)

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_CREATED:
            player = param0
            if "s_accumulativelogin7" not in player.__dict__:
                player.s_accumulativelogin7 = [int(time.time()), 0, self.mRewards,]

        elif msg == MSG_PLAYER_ONLINE or msg == MSG_PLAYER_DAY_CHANGED:
            player = param0

            data = self.getPlayerForeverData(player, self.mInitData)
            lastLoginTime = data[0]
            loginCount = data[1]

            curLoginTime = int(time.time())

            lastLTime = time.localtime(lastLoginTime)
            curLTime = time.localtime(curLoginTime) 

            if lastLTime.tm_year == curLTime.tm_year and lastLTime.tm_mon == curLTime.tm_mon and lastLTime.tm_mday == curLTime.tm_mday:
                pass
            else:
                data[0] = curLoginTime
                data[1] += 1

            self.checkHasReward(player)

    def getMenu(self, player, npcID):
        return []

ModuleID = 16
Instance = AccumulativeLogin7(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_DAY_CHANGED,
])
