#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
import bisect
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

INDEX_PIECEID       = 0
INDEX_PRODTID       = 1
INDEX_STAGE         = 2

ITEM_ID             = 0
ITEM_TYPE           = 1
ITEM_PRICE          = 2
ITEM_PTIME          = 3

MAX_VIGOR           = 50
PLUNDER_COST        = 5
AUTO_PLUNDER_VIP    = 3

class Plunder(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mNeedSave = False
        self.mTotalRate = 0
        self.mLootReward = []
        self.mLootRate = []
        self.mProductInfo = {}                  #productID:[pieceID]
        self.mPieceInfo = {}                    #pieceID:[content]
        self.mPieceOwner = {}                   #pieceID:[playerUUID,]
        self.mPieceList = []                    #[pieceID,]
        self.mPieceRate = []                    #[rate,]
        self.mBlackList = {}                    #playerUUID:[pieceID,]
        self.mProtectInfo = {}                  #playerUUID:time
        self.mProtectItem = {}                  #itemID:[content]
        self.mMsg = {}                          #playerUUID:[[tarUUID, tarName, pieceID, time],]}

        engine.Instance.registerTextProtocol("C2S_Plunder", self.onProtocol)

    def isActived(self, player):
        return True

    def getName(self):
        return "Plunder"

    def getInfo(self, player):
        playerUUID = player.getUUID()
        info = {}
        pieceList = []

        pieceInfo = player.s_plunder[2]
        for pieID in pieceInfo:
            pieceList.append((pieID, pieceInfo[pieID]))
        info["Piece"] = pieceList
        info["Vigor"] = player.getVigor()
        info["Cost"] = PLUNDER_COST
        info["MaxVigor"] = MAX_VIGOR

        prtItem = []
        for prtID in self.mProtectItem:
            if prtID in player.s_plunder[1]:
                prtItem.append((prtID, player.s_plunder[1][prtID], self.mProtectItem[prtID][ITEM_PRICE]))
            else:
                prtItem.append((prtID, 0, self.mProtectItem[prtID][ITEM_PRICE]))

        info["ProtectTime"] = player.s_plunder[0]
        info["ProtectItem"] = prtItem

        return json.dumps({"Result":1, "ResultDesc":GlobalStrings[56], "Action": "info", "Info": info})

    def getRate(self, myLevel, tarLevel, isRobot, stage):
        if stage == 0:
            rate = 75
            robotrate = 36
        elif stage == 3:
            rate = 60
            robotrate = 31
        elif stage == 6:
            rate = 30
            robotrate = 16
        elif stage == 9:
            rate = 10
            robotrate = 6
        else:
            rate = 10
            robotrate = 6
        if isRobot:
            return robotrate
        else:
            rate = int(rate * (1 - (myLevel - tarLevel) * 0.05))
            if rate < robotrate:
                rate = robotrate
            if rate > 100:
                rate = 100
            return rate

    def addPiece2Player(self, player, pies):
        if player:
            playerUUID = player.getUUID()

            pdata = player.s_plunder[2]
            for i in pies:
                if i in pdata:
                    pdata[i] += 1
                else:
                    pdata[i] = 1
                msg = GlobalStrings[95] % (self.getPieceDesc(i))
                MMain.sendCenterMessage(player, msg)
                response = (self.mID, "get", i, pdata[i])
                MMain.sendTextProtocol(player, "S2C_NotifyActReward", response)
                if i in self.mPieceOwner:
                    if playerUUID not in self.mPieceOwner[i]:
                        self.mPieceOwner[i].append(playerUUID)

    def delPiece4Player(self, player, pies):
        if player:
            playerUUID = player.getUUID()

            pdata = player.s_plunder[2]
            for i in pies:
                if i in pdata:
                    pdata[i] -= 1
                    response = (self.mID, "modify", i, pdata[i])
                    MMain.sendTextProtocol(player, "S2C_NotifyActReward", response)
                    if pdata[i] <= 0:
                        del pdata[i]
                        if playerUUID in self.mPieceOwner[i]:
                            self.mPieceOwner[i].remove(playerUUID)
    
    def logPlunder(self, player, tar, pieceID):
        playerUUID = player.getUUID()
        if playerUUID not in self.mMsg:
            self.mMsg[playerUUID] = []
        plog = self.mMsg[playerUUID]
        record = [tar.getUUID(), tar.getName(), pieceID, int(time.time()),]
        plog.insert(0, record)
        plog = plog[0:3]

    def delLog(self, player, tarUUID, pieceID):
        playerUUID = player.getUUID()
        if playerUUID not in self.mMsg:
            self.mMsg[playerUUID] = []
        plog = self.mMsg[playerUUID]
        for i in xrange(len(plog)):
            rec = plog[i]
            if rec[0] == tarUUID and rec[2] == pieceID:
                del plog[i]
                break

    def isProtecting(self, player):
        curTime = int(time.time())
        if player.s_plunder[0] > curTime:
            return True
        return False

    def getPieceDesc(self, pieceID):
        if pieceID in self.mPieceInfo:
            pdata = self.mPieceInfo[pieceID]
            desc = "[%s]%s[-]" % (self.getItemColor(pdata[2]), pdata[3])
            return desc
        else:
            return ""

    def getlootreward(self):
        reward = []
        r = random.randint(0, self.mTotalRate - 1)
        hitidx = 0
        for idx in xrange(len(self.mLootRate)):
            if self.mLootRate[idx] > r:
                hitidx = idx
                break
            else:
                continue
        reward = self.mLootReward[hitidx]
        return reward

    def doAction(self, player, actData):
        data = json.loads(actData)
        playerUUID = player.getUUID()
        playerLevel = player.getLevel()

        actionType = data["Action"]
        if actionType == "refresh":
            pieID = data["Param0"]
            if pieID in self.mPieceInfo:
                content = self.mPieceInfo[pieID]
                stage = content[INDEX_STAGE]
                info = []
                curTime = int(time.time())
                if pieID in self.mPieceOwner:
                    playerUUIDList = self.mPieceOwner[pieID]
                    if len(playerUUIDList) >= 5:
                        tarUUIDs = random.sample(playerUUIDList, 4)
                        maxp = 2
                        for n in tarUUIDs:
                            tarPlayer = MMain.getPlayerByUUID(n)
                            if tarPlayer and tarPlayer.getLevel() > 10 and tarPlayer != player and not self.isProtecting(tarPlayer):
                                tarLevel = tarPlayer.getLevel()
                                maxp -= 1
                                info.append((tarPlayer.getUUID(), tarPlayer.getName(), False, tarLevel, self.getRate(playerLevel, tarLevel, False, stage)))
                                if maxp < 0:
                                    break
                while len(info) < 4:
                    info.append(("", "robot", True, playerLevel, self.getRate(playerLevel, playerLevel, True, stage)))

                return json.dumps({"Result":1, "ResultDesc":GlobalStrings[56], "Action": actionType, "Info": info})
            else:
                return Err_Invalid

        elif actionType == "plunder":
            pieID = data["Param0"]
            isRobot = data["Param1"]
            tarUUID = data["Param2"]
            isAuto = data["Param3"]
            curTime = time.time()
            curLTime = time.localtime(curTime)
            curMTime = curLTime.tm_hour * 60 + curLTime.tm_min
            if curMTime < 600:
                return Err_Cannot

            if isinstance(tarUUID, unicode):
                tarUUID = tarUUID.encode('utf-8')

            if isAuto:
                count = 0
                if player.getVipLevel() < AUTO_PLUNDER_VIP:
                    return Err_VipLevelLimitation
                get = False
                allextras = []
                win = False
                myBP = player.getBattlePoint()
                tarBP = 5
                while not get:
                    if pieID in self.mPieceInfo:
                        if player.getVigor() >= PLUNDER_COST:
                            count += 1
                            engine.Instance.invoke(MSG_PLAYER_JOIN_PLUDER, player, None)
                            self.removeReward(player, (REWARD_TYPE_VIGOR, PLUNDER_COST))
                            player.s_plunder[0] = 0
                        else:
                            return json.dumps({"Result":1, "ResultDesc":GlobalStrings[56], "Action": actionType, "Count": count, "Win": [win, myBP, tarBP], "Extra": allextras, "Reward": []})
                        stage = self.mPieceInfo[pieID][INDEX_STAGE]
                        if isRobot:
                            win = True
                            rate = self.getRate(playerLevel, playerLevel, True, stage)
                        else:
                            tarPlayer = MMain.getPlayerByUUID(tarUUID)
                            if tarPlayer:
                                myBP = random.randint(90, 110) * player.getBattlePoint() / 100
                                tarBP = random.randint(90, 110) * tarPlayer.getBattlePoint() / 100
                                if myBP >= tarBP:
                                    win = True
                                    rate = self.getRate(playerLevel, tarPlayer.getLevel(), False, stage)
                                else:
                                    win = False                    
                            else:
                                isRobot = True
                                win = True
                                rate = self.getRate(playerLevel, playerLevel, True, stage)

                        if win:
                            extras = self.getlootreward()
                            allextras = allextras + extras
                            for extra in extras:
                                self.addReward(player, extra)
                            if random.randint(0, 99) < rate:
                                ##get
                                get = True
                                if not isRobot:
                                    self.delPiece4Player(tarPlayer, (pieID, ))
                                    self.logPlunder(tarPlayer, player, pieID) 
                                self.addPiece2Player(player, (pieID, ))
                                                       
                                return json.dumps({"Result":1, "ResultDesc":GlobalStrings[56], "Action": actionType, "Count": count, "Win": [win, myBP, tarBP], "Extra": allextras, "Reward": [pieID,]})
                            else:
                                pass
                        else:
                            return json.dumps({"Result":1, "ResultDesc":GlobalStrings[56], "Action": actionType, "Count": count, "Win": [win, myBP, tarBP], "Extra": allextras, "Reward": []})
                    else:
                        return Err_Invalid
            else:
                if pieID in self.mPieceInfo:
                    if player.getVigor() >= PLUNDER_COST:
                        engine.Instance.invoke(MSG_PLAYER_JOIN_PLUDER, player, None)
                        self.removeReward(player, (REWARD_TYPE_VIGOR, PLUNDER_COST))
                        player.s_plunder[0] = 0
                    else:
                        return Err_NotEnoughRes
                    stage = self.mPieceInfo[pieID][INDEX_STAGE]
                    myBP = 5
                    tarBP = 5
                    if isRobot:
                        win = True
                        myBP = player.getBattlePoint()
                        rate = self.getRate(playerLevel, playerLevel, True, stage)
                    else:
                        tarPlayer = MMain.getPlayerByUUID(tarUUID)
                        if tarPlayer:
                            myBP = random.randint(90, 110) * player.getBattlePoint() / 100
                            tarBP = random.randint(90, 110) * tarPlayer.getBattlePoint() / 100
                            if myBP >= tarBP:
                                win = True
                                rate = self.getRate(playerLevel, tarPlayer.getLevel(), False, stage)
                            else:
                                win = False                    
                        else:
                            isRobot = True
                            win = True
                            rate = self.getRate(playerLevel, playerLevel, True, stage)

                    if win:
                        extras = self.getlootreward()
                        for extra in extras:
                            self.addReward(player, extra)
                        if random.randint(0, 99) < rate:
                            ##get
                            if not isRobot:
                                self.delPiece4Player(tarPlayer, (pieID, ))
                                self.logPlunder(tarPlayer, player, pieID) 
                            self.addPiece2Player(player, (pieID, ))                        
                            return json.dumps({"Result":1, "ResultDesc":GlobalStrings[56], "Action": actionType, "Count": 1, "Win": [win, myBP, tarBP], "Extra": extras, "Reward": [pieID,]})
                        else:
                            ##lose
                            return json.dumps({"Result":1, "ResultDesc":GlobalStrings[56], "Action": actionType, "Count": 1, "Win": [win, myBP, tarBP], "Extra": extras, "Reward": []})
                    else:
                        return json.dumps({"Result":1, "ResultDesc":GlobalStrings[56], "Action": actionType, "Count": 1, "Win": [win, myBP, tarBP], "Extra": [], "Reward": []})
                else:
                    return Err_Invalid

        elif actionType == "autoplunder":
            proID = data["Param0"]
            curTime = time.time()
            curLTime = time.localtime(curTime)
            if curLTime.tm_min < 600:
                return Err_Cannot
            reward = []
            if proID in self.mProductInfo:
                pieceList = self.mProductInfo[proID]
                pdata = player.s_plunder[2]

                extras = []
                for pieID in pieceList:
                    if pieID not in pdata or pdata[pieID] < 1:
                        ##plunder
                        if pieID in self.mPieceInfo:
                            stage = self.mPieceInfo[pieID][INDEX_STAGE]
                            rate = self.getRate(playerLevel, playerLevel, True, stage)
                            hasGet = False
                            while not hasGet:
                                ##todo cost
                                if player.getVigor() >= PLUNDER_COST:
                                    engine.Instance.invoke(MSG_PLAYER_JOIN_PLUDER, player, None)
                                    self.removeReward(player, [REWARD_TYPE_VIGOR, PLUNDER_COST])
                                    player.s_plunder[0] = 0
                                    extras += self.getlootreward()

                                    if random.randint(0, 99) < rate:
                                        self.addPiece2Player(player, (pieID,))
                                        reward.append(pieID)
                                        hasGet = True
                                else:
                                    break
                        else:
                            break
                for extra in extras:
                    self.addReward(player, extra)
                return json.dumps({"Result":1, "ResultDesc":GlobalStrings[56], "Action": actionType, "Win": [True, player.getBattlePoint(), 5], "Extra": extras, "Reward": reward})
            else:
                return Err_Invalid

        elif actionType == "combine":
            proID = data["Param0"]
            if proID in self.mProductInfo:
                pieceList = self.mProductInfo[proID]
                pdata = player.s_plunder[2]
                canCombine = True
                for i in pieceList:
                    if i not in pdata:
                        canCombine = False
                        break
                    elif pdata[i] < 1:
                        canCombine = False
                        break
                if canCombine:
                    self.delPiece4Player(player, pieceList)
                    itemID = proID
                    itemType = proID / 10000000
                    reward = [itemType, itemID, 1]
                    if self.canAddReward(player, reward):
                        self.addReward(player, reward)
                        item = player.getItemByType(itemType, itemID)
                        if item:
                            item.doUse(player)
                        leftpiece = []
                        pieceInfo = player.s_plunder[2]
                        for pieID in pieceInfo:
                            leftpiece.append((pieID, pieceInfo[pieID]))
                        return json.dumps({"Result":1, "ResultDesc":GlobalStrings[56], "Action": actionType, "PieceInfo": leftpiece})
                    else:
                        return Err_NotEnoughSpace
                else:
                    return Err_Cannot
            else:
                return Err_Invalid

        elif actionType == "info":
            return self.getInfo(player)

        elif actionType == "buy":
            prtID = data["Param0"]
            num = data["Param1"]
            if num > 0 and prtID in self.mProtectItem:
                itemInfo = self.mProtectItem[prtID]
                cost = num * itemInfo[ITEM_PRICE]
                if player.getGoldMoney() >= cost:
                    self.removeReward(player, [2, cost,])
                    pdata = player.s_plunder[1]
                    if prtID in pdata:
                        pdata[prtID] += num
                    else:
                        pdata[prtID] = num
                    return json.dumps({"Result":1, "ResultDesc":GlobalStrings[56], "Action": actionType, "Reward":[prtID, num,]})
                else:
                    return Err_NotEnoughGoldMoney
            else:
                return Err_Invalid

        elif actionType == "use":
            prtID = data["Param0"]
            if prtID in self.mProtectItem:
                itemInfo = self.mProtectItem[prtID]
                ptime = itemInfo[ITEM_PTIME]
                own = player.s_plunder[1]
                if prtID in own and own[prtID] >= 1:
                    curTime = int(time.time())
                    own[prtID] -= 1
                    if player.s_plunder[0] < curTime:
                        player.s_plunder[0] = curTime + ptime
                    else:
                        player.s_plunder[0] += ptime

                    if player.s_plunder[0] >= curTime + 3600 * 8:
                        player.s_plunder[0] = curTime + 3600 * 8                        
                    return json.dumps({"Result":1, "ResultDesc":GlobalStrings[56], "Action": actionType, "Reward":[prtID, own[prtID],], "ProtectTime": player.s_plunder[0]})
                else:
                    return Err_NotEnoughMaterial
            else:
                return Err_Invalid

        elif actionType == "log":
            plog = []
            if playerUUID in self.mMsg:
                plog = self.mMsg[playerUUID]
            return json.dumps({"Result":1, "ResultDesc":GlobalStrings[56], "Action": actionType, "Log": plog})

        elif actionType == "revenge":
            pieID = data["Param0"]
            tarUUID = data["Param1"]
            if isinstance(tarUUID, unicode):
                tarUUID = tarUUID.encode('utf-8')
            if player.getVigor() >= PLUNDER_COST:
                self.removeReward(player, (REWARD_TYPE_VIGOR, PLUNDER_COST))
            else:
                return Err_NotEnoughRes

            win = False       
            
            myBP = myBP = random.randint(90, 110) * player.getBattlePoint() / 100
            tarBP = 5
            tarPlayer = MMain.getPlayerByUUID(tarUUID)
            if tarPlayer:
                tarBP = random.randint(90, 110) * tarPlayer.getBattlePoint() / 100
            else:
                tarBP = random.randint(90, 110) * player.getBattlePoint() / 100

            if myBP >= tarBP:
                win = True 
            
            if win:
                self.addPiece2Player(player, (pieID, ))
                self.delLog(player, tarUUID, pieID)
                return json.dumps({"Result":1, "ResultDesc":GlobalStrings[56], "Action": actionType, "Count": 1, "Win": [win, myBP, tarBP], "Extra": [], "Reward": [pieID,]})
            else:
                return json.dumps({"Result":1, "ResultDesc":GlobalStrings[56], "Action": actionType, "Count": 1, "Win": [win, myBP, tarBP], "Extra": [], "Reward": []})
        else:
            return Err_Unknown

    def loadConfig(self, path):
        rewardsFilename = "%splunder.txt" % (path)
        itemfilename = "%smaterial.txt" % (path)
        lootfilename = "%sloot.txt" % (path)

        tb = TabFile()
        if tb.load(rewardsFilename):
            pieceList = []
            pieceRate = []
            pieceInfo = {}
            pieceOwner = {}
            prodtInfo = {}
            totalrate = 0
            for i in xrange(tb.mRowNum):

                pieceID           = tb.get(i, INDEX_PIECEID, 0, True)
                prodtID           = tb.get(i, INDEX_PRODTID, 0, True)
                stageID           = tb.get(i, INDEX_STAGE, 0, True)
                pieName           = tb.get(i, 6, "", False)
                quality           = tb.get(i, 7, 0, True)

                if pieceID not in pieceInfo:
                    pieceInfo[pieceID] = [pieceID, prodtID, stageID, pieName, quality,]
                    pieceOwner[pieceID] = []
                    pieceList.append(pieceID)
                    totalrate += quality
                    pieceRate.append(totalrate)
                else:
                    syserr("Load %s failed. PieceID %s is repeated" % (rewardsFilename, pieceID))

                if prodtID not in prodtInfo:
                    prodtInfo[prodtID] = []
                prodtInfo[prodtID].append(pieceID)

            self.mPieceInfo = pieceInfo
            self.mPieceOwner = pieceOwner
            self.mProductInfo = prodtInfo
            self.mPieceList = pieceList
            self.mPieceRate = pieceRate
        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False

        tb = TabFile()
        if tb.load(itemfilename):
            protectItem = {}
            for i in xrange(tb.mRowNum):

                itemID              = tb.get(i, ITEM_ID, 0, True)
                itemType            = tb.get(i, ITEM_TYPE, 0, True)
                price               = tb.get(i, ITEM_PRICE, 0, True)
                ptime               = tb.get(i, ITEM_PTIME, 0, True)

                protectItem[itemID] = [itemID, itemType, price, ptime,]
            self.mProtectItem = protectItem
        else:
            syserr("Load %s failed." % (itemfilename))
            return False    

        tb = TabFile()
        if tb.load(lootfilename):
            protectItem = {}
            totalrate = 0
            lootRate = []
            lootReward = []
            for i in xrange(tb.mRowNum):

                idx                 = tb.get(i, 0, 0, True)
                rewardstr           = tb.get(i, 1, "", False)
                rate                = tb.get(i, 2, 0, True)

                extrareward = [
                    [int(value) for value in reward.split(",")]
                        for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2)
                ]

                if rate > 0:
                    totalrate += rate
                    lootRate.append(totalrate)
                    lootReward.append(extrareward)
                else:
                    syserr("Load %s failed. at line %d" % (lootfilename, i + 1))
            self.mTotalRate = totalrate
            self.mLootRate = lootRate
            self.mLootReward = lootReward
        else:
            syserr("Load %s failed." % (lootfilename))
            return False  

        return True

    def onProtocol(self, player, data):
        result = self.doAction(player, data[0])

        response = (result, )
        MMain.sendTextProtocol(player, "S2C_Plunder", response)

    def buildBlackList(self, player):
        playerUUID = player.getUUID()
        blacklist = []
        for pid in self.mProductInfo:
            l = len(self.mProductInfo[pid])
            if l > 0:
                r = random.randint(0, l - 1)
                blacklist.append(self.mProductInfo[pid][r])
        self.mBlackList[playerUUID] = blacklist        

    def lootpiece(self, player):
        playerUUID = player.getUUID()
        if playerUUID not in self.mBlackList:
            self.buildBlackList(player)
        blacklist = self.mBlackList[playerUUID]

        pieceid = 0
        while pieceid == 0:
            maxRate = self.mPieceRate[-1]
            r = random.randint(0, maxRate - 1)
            idx = bisect.bisect_left(self.mPieceRate, r)
            ppid = self.mPieceList[idx]
            if ppid not in blacklist:
                pieceid = ppid
                break

        self.addPiece2Player(player, [pieceid,])
        self.mNeedSave = True

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_CREATED:
            player = param0
            if "s_plunder" not in player.__dict__:
                player.s_plunder = [0, {}, {},]            
            self.addPiece2Player(player, [55061011,55061011,55061012,55061031,55061031,55061032,])
            r = random.randint(0, 7)
            self.addPiece2Player(player, [55063037 + r, ])

        elif msg == MSG_PLAYER_DAY_CHANGED:
            player = param0
            self.buildBlackList(player)

        elif msg == MSG_PLAYER_FINISH_DUNGEON:
            player = param0
            dungeon, star, costTime = param1
            if player.getLevel() >= 10 and random.randint(0, 99) < 5:
                self.lootpiece(player)

        elif msg == MSG_PLAYER_ONLINE:
            player = param0
            if "s_plunder" not in player.__dict__:
                player.s_plunder = [0, {}, {},]
            for pieID in player.s_plunder[2]:
                if pieID not in self.mPieceOwner:
                    self.mPieceOwner[pieID] = []
                if player.getUUID() not in self.mPieceOwner[pieID]:
                    self.mPieceOwner[pieID].append(player.getUUID())

    def getMenu(self, player, npcID):
        return []

ModuleID = 55
Instance = Plunder(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_CREATED,
    MSG_PLAYER_DAY_CHANGED,
    MSG_PLAYER_FINISH_DUNGEON,
    MSG_PLAYER_ONLINE,
])