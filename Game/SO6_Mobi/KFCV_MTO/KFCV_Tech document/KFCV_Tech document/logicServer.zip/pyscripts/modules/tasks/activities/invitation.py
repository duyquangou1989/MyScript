#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

class Invitation(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mTables = {}
        self.mTask = []
        self.mContext = []        

    def getName(self):
        return "Invitation"

    def initInvitation(self, player):
        if "s_invitation" not in player.__dict__:
            account = player.getAccount()
            temp = []
            temp = account.split("_")
            if len(temp) == 2:
                player.s_invitation = [0, temp[1], "", {}, 0,]   #commit, mycode, upcode, gotlist, count
            else:
                player.s_invitation = [0, account, "", {}, 0,]

    def getInfo(self, player):
        result = {}
        rewards = []
        for i in self.mTables:
            canget = False
            got = False
            if i <= player.s_invitation[4]:
                if i in player.s_invitation[3]:
                    got = True
                else:
                    canget = True
            rewards.append((i, self.mTables[i], canget, got, ))
        result["Commit"] = player.s_invitation[0]
        result["MyCode"] = player.s_invitation[1]
        result["UpCode"] = player.s_invitation[2]
        result["Count"] = player.s_invitation[4]
        result["Reward"] = rewards
        result["MyReward"] = self.mTask[1]
        result["Context"] = self.mContext
        result["Extra"] = self.mTask[2]

        return json.dumps(result)

    def editInvitation(self, text, linkurl, name):
        self.mContext = [text, linkurl, name, ]
        MMain.setSetting("s_invitationcontext", self.mContext)

    def setInvitationCount(self, player, count, extra):
        self.initInvitation(player)
        player.s_invitation[4] = count
        if extra > 0:
            goldmoney = extra * self.mTask[2]
            mail = {}
            mail["RecvUUID"] = ""
            mail["RecvName"] = player.getName()
            mail["CreateTime"] = int(time.time())
            mail["ValidTime"] = int(time.time()) + 86400 * 7
            mail["Head"] = GlobalStrings[91]
            mail["Body"] = GlobalStrings[92] % (extra, goldmoney)
            mail["Res"] = [[REWARD_TYPE_GOLDMONEY, goldmoney], ]
            mail["Items"] = []
            MMain.sendMail(mail)

    def checkCode(self, player, code):
        MMain.checkInvitationCode(player, code)

    def checkCodeCallback(self, player, code, isvalid):
        if isvalid:
            data = player.s_invitation
            if data[0] == 0 and not data[2]:
                data[2] = code
                if player.getLevel() >= self.mTask[0]:
                    player.s_invitation[0] = 1
                response = (Err_Ok, )
                MMain.sendTextProtocol(player, "S2C_Invitation", response)
            else:
                response = (Err_Repetition, )
                MMain.sendTextProtocol(player, "S2C_Invitation", response)
        else:
            response = (Err_Invalid, )
            MMain.sendTextProtocol(player, "S2C_Invitation", response)

    def doAction(self, player, actData):
        actData = json.loads(actData)
        actionType = actData["Action"]
        data = player.s_invitation

        if actionType == "Get":
            idx = actData["Param0"]
            if idx in self.mTables:
                if idx <= data[4]:
                    if idx not in data[3]:
                        rewards = self.mTables[idx]
                        if self.canAddAllReward(player, rewards):
                            for reward in rewards:
                                self.addReward(player, reward)
                            data[3][idx] = 0
                            return Err_Ok
                        else:
                            return Err_NotEnoughSpace
                    else:
                        return Err_Repetition
                else:
                    return Err_Cannot
            else:
                return Err_Invalid

        elif actionType == "Commit":
            code = actData["Param0"]
            if isinstance(code, unicode):
                code = code.encode('utf-8')
            if code == data[1]:
                return Err_Cannot

            if data[0] == 0 and not data[2]:
                self.checkCode(player, code)
                return Err_Ok
            else:
                return Err_Repetition

        elif actionType == "Abc":
            if player.s_invitation[0] == 0:
                return Err_Cannot
            elif player.s_invitation[0] == 1:
                rewards = self.mTask[1]
                if self.canAddAllReward(player, rewards):
                    for reward in rewards:
                        self.addReward(player, reward)
                    player.s_invitation[0] = 2
                    MMain.commitInvitation(player, player.s_invitation[1], player.s_invitation[2])
                    return Err_Ok
                else:
                    return Err_NotEnoughSpace
            elif player.s_invitation[2] == 2:
                return Err_Repetition
        else:
            return Err_Invalid

    def loadConfig(self, path):
        tasksFilename = "%sinvitation.txt" % (path)
        rewardfilename = "%srewards.txt" % (path)
        tb = TabFile()
        if tb.load(tasksFilename):
            task = []
            for i in xrange(tb.mRowNum):
                level = tb.get(i, 0, 0, True)
                rewardstr = tb.get(i, 1, "", False).replace("\"", "")
                extra = tb.get(i, 2, 0, True)

                taskReward = []
                if rewardstr:
                    taskReward = [
                        [int(value) for value in reward.split(",")]
                            for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2) 
                    ]
                task = [level, taskReward, extra, ]
            self.mTask = task
        else:
            syserr("Load %s failed." % (tasksFilename))
            return False

        tb = TabFile()
        if tb.load(rewardfilename):
            tables = {}
            for i in xrange(tb.mRowNum):
                level = tb.get(i, 0, 0, True)
                rewardstr = tb.get(i, 1, "", False).replace("\"", "")
                taskReward = []
                if rewardstr:
                    taskReward = [
                        [int(value) for value in reward.split(",")]
                            for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2) 
                    ]
                tables[level] = taskReward
            self.mTables = tables
        else:
            syserr("Load %s failed." % (tasksFilename))
            return False

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)
            context = MMain.getSetting("s_invitationcontext")
            if context:
                self.mContext = context
            else:
                self.mContext = [GlobalStrings[93], "http://hyperurl.co/shaolin", GlobalStrings[94], ]

        elif msg == MSG_PLAYER_CREATED:
            player = param0
            self.initInvitation(player)

        elif msg == MSG_PLAYER_ONLINE: 
            player = param0
            self.initInvitation(player)
            MMain.getInvitationCount(player)
            
        elif msg == MSG_PLAYER_LEVELUP:
            player = param0
            self.initInvitation(player)

            if player.s_invitation[0] == 0 and player.s_invitation[2]:
                if player.getLevel() >= self.mTask[0]:
                    player.s_invitation[0] = 1


    def getMenu(self, player, npcID):
        return []

ModuleID = 80
Instance = Invitation(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_CREATED,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_LEVELUP,
])
