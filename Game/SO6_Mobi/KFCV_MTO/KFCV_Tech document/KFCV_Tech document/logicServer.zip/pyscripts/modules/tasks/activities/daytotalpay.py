#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

class DayTotalPay(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mInit = [0, [],]
        self.mRewards = {}

    def isActived(self, player):
        return ActivityBase.isActived(self, player)

    def getName(self):
        return "DayTotalPay"

    def getInfo(self, player):
        data = player.s_daytotalpay

        info = {}
        info["total"] = data[0]
        reward = []
        for i in self.mRewards:
            canGetReward = False
            alreadyGet = False
            rewards = self.mRewards[i]
            if data[0] >= i:
                canGetReward = True
            if i in data[1]:
                alreadyGet = True
            reward.append((i, canGetReward, alreadyGet, rewards,))
        info["Rewards"] = reward

        return json.dumps(info)

    def doAction(self, player, actData):
        if self.isActived(player):
            actData = json.loads(actData)
            data = player.s_daytotalpay

            idx = actData["Get"]
            if idx in self.mRewards:
                if idx <= data[0]:
                    if idx in data[1]:
                        return Err_Repetition
                    else:
                        rewards = self.mRewards[idx]
                        if self.canAddAllReward(player, rewards):
                            for reward in rewards:
                                self.addReward(player, reward)
                            data[1].append(idx)
                            return Err_Ok
                        else:
                            return Err_NotEnoughSpace
                else:
                    return Err_Cannot
            else:
                return Err_Invalid
        else:
            return Err_NotOpen

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)
        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = {}
            for i in xrange(tb.mRowNum):
                rewardType = tb.get(i, 0, 0, True)
                rewardstr = tb.get(i, 1, "", False).replace("\"", "")

                extrareward = [
                    [int(value) for value in reward.split(",")]
                        for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2)
                ]

                rewards[rewardType] = extrareward
            self.mRewards = rewards
            return True
        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_ONLINE:
            player = param0
            if "s_daytotalpay" not in player.__dict__:
                player.s_daytotalpay = copy.deepcopy(self.mInit)
            self.checkHasReward(player)

        elif msg == MSG_PLAYER_DAY_CHANGED:
            player = param0
            player.s_daytotalpay = copy.deepcopy(self.mInit)

        elif msg == MSG_PLAYER_GOLDMONEY_CHANGED:
            player = param0
            goldMoney, way, productId = param1
            if "s_daytotalpay" not in player.__dict__:
                player.s_daytotalpay = copy.deepcopy(self.mInit)
            if self.isActived(player):
                if way == 2:
                    data = player.s_daytotalpay
                    data[0] += goldMoney
                    self.checkHasReward(player)

    def getMenu(self, player, npcID):
        return []

    def checkHasReward(self, player):
        hasReward = False
        data = player.s_daytotalpay
        if self.isActived(player):
            for i in self.mRewards:
                if data[0] >= i and i not in data[1]:
                    hasReward = True

        self.notifyActReward(player, hasReward)

ModuleID = 42
Instance = DayTotalPay(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_DAY_CHANGED,
    MSG_PLAYER_GOLDMONEY_CHANGED,
])
