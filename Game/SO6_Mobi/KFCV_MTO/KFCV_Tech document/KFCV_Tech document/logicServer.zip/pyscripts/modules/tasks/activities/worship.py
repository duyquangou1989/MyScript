#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
import pdb
import copy 
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

INITWORSHIPNUM = 1
class Worship(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        self.mID = moduleID
        self.mArenaTop = []
        self.mRewards = {} #{weiget:[items]}
        self.mWRewards = {}
        self.mlWeight = []
        self.mLWTimes = [] 
        self.mWeight = 0
        self.mWorshipTime = 0
    def getName(self):
        return "Worship"

    def isActived(self, player):      
        return True

    def getInfo(self, player):
        if "s_worshipNum" not in player.__dict__:
            player.s_worshipNum = INITWORSHIPNUM

        if len(self.mArenaTop) > 0:
            info = {}
            rewards = []
            for weight in self.mRewards:
                temps = self.mRewards[weight]
                for reward in temps:
                    rewards.append(reward)
            tempTime = 0
            for time in self.mLWTimes:
                if self.mWorshipTime < time :
                    break
                tempTime = time

            info["Result"] = 1
            info["topplayer"] = self.mArenaTop
            info["rewards"] = rewards
            info["worshipnum"] = player.s_worshipNum
            info["wtime"] = self.mWorshipTime
            if tempTime == 0:
                info["wreward"] = []
            else:
                info["wreward"] = self.mWRewards[tempTime]
            return json.dumps(info)
        else:
            return Err_NotExist

    def getRewardForWeight(self):
        randomNum = random.randint(0,self.mWeight)
        for weight in self.mlWeight:
            if randomNum < weight:
                if weight in self.mRewards:
                    return self.mRewards[weight]
                else:
                    print "not find weight in config for reward"
                    return []

    def getRewardForTime(self):
        tempTime = 0
        for count in self.mWRewards:
            if self.mWorshipTime < count :
                break
            tempTime = count
        items = []
        ress = []
        if tempTime != 0:
            for reward in self.mWRewards[tempTime]:
                if len(reward) == 3:
                    items.append(reward)
                elif len(reward) == 2:
                    ress.append(reward)
            mail = {}
            mail["RecvUUID"] = ""
            mail["RecvName"] = self.mArenaTop[2]
            mail["CreateTime"] = int(time.time())
            mail["ValidTime"] = mail["CreateTime"] + 86400 * 3
            mail["Head"] = ""
            mail["Body"] = GlobalStrings[89]
            mail["Res"] = ress
            mail["Items"] = items
            MMain.sendMail(mail)

    def addWorshipPoint(self, player):
        if "s_worshipNum" not in player.__dict__:
            player.s_worshipNum = INITWORSHIPNUM
        player.s_worshipNum += 1  

    def doAction(self, player, actData):
        if "s_worshipNum" not in player.__dict__:
            player.s_worshipNum = INITWORSHIPNUM

        if len(self.mArenaTop) > 0:
            if player.s_worshipNum > 0:
                self.mWorshipTime += 1
                player.s_worshipNum -= 1
                rewards = self.getRewardForWeight()
                if self.canAddAllReward(player, rewards):
                    for reward in rewards:
                        self.addReward(player, reward)
                else:
                    res = []
                    item = []
                    for reward in rewards:
                        if len(reward) == 2:
                            res.append(reward)
                        elif len(reward) == 3:
                            item.append(reward)
                    mail = {}
                    mail["RecvUUID"] = player.getUUID()
                    mail["RecvName"] = player.getName()
                    mail["CreateTime"] = int(time.time())
                    mail["ValidTime"] = mail["CreateTime"] + 86400 * 3
                    mail["Head"] = GlobalStrings[90]
                    mail["Body"] = GlobalStrings[28]
                    mail["Res"] = res
                    mail["Items"] = item
                    MMain.sendMail(mail)
                return json.dumps({"Result":1, "ResultDesc":GlobalStrings[56],"reward":reward})
            else:
                return Err_NotEnoughCount
        else:
            return Err_NotExist


          
    def loadConfig(self, path):
        rewards = "%srewards.txt" % (path)

        tb = TabFile()   
        if tb.load(rewards):
            lweight = []
            weightnum = 0
            dicweight = {}
            for i in xrange(tb.mRowNum):
                rewardstr = tb.get(i, 0, "", False).replace("\"", "")
                weight = tb.get(i, 1, 0, True)
                extrareward = [
                    [int(value) for value in reward.split(",")]
                        for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2)
                ]
                weightnum += weight
                lweight.append(weightnum)
                dicweight[weightnum] = extrareward
            self.mlWeight = lweight
            self.mRewards = dicweight
            self.mWeight = weightnum
        else:
            syslog("Loading Worship config failed!")
            return False

        wfileName = "%swrewards.txt" % (path)
        syslog("Loading wWorship config...")
        if tb.load(wfileName):
            LWTimes = []
            WRewards = {}
            for i in xrange(tb.mRowNum):
                time = tb.get(i, 0, 0, True)
                rewardstr = tb.get(i, 1, "", False).replace("\"", "")
                extrareward = [
                    [int(value) for value in reward.split(",")]
                        for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2)
                ]
                LWTimes.append(time)
                WRewards[time] = extrareward
            self.mLWTimes = LWTimes
            self.mWRewards= WRewards
            return True
        else:
            syslog("Loading Worship config failed!!")
            return False

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)
            arenaTop = MMain.getSetting("arenaTop")
            if arenaTop:
                for data in arenaTop:
                    if data[0] == 1:
                        self.mArenaTop = copy.deepcopy(data) 
                        break

        elif msg == MSG_TIME_MINUTE:
            curTime = time.time()
            curLTime = time.localtime(curTime)
            curMin = curLTime.tm_hour * 60 + curLTime.tm_min
            if curMin == 1258:
                self.getRewardForTime()
                self.mWorshipTime = 0
                self.mArenaTop = []
            elif curMin == 1263:
                arenaTop = MMain.getSetting("arenaTop")
                if arenaTop:
                    for data in arenaTop:
                        if data[0] == 1:
                            self.mWorshipTime = 0
                            self.mArenaTop = copy.deepcopy(data) 
                            break
        elif msg == MSG_PLAYER_DAY_CHANGED:
            player = param0
            player.s_worshipNum = INITWORSHIPNUM
    def getMenu(self, player, npcID):
        return []

ModuleID = 48
Instance = Worship(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_TIME_MINUTE,
    MSG_PLAYER_DAY_CHANGED,
])
