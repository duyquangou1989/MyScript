#coding=utf8


import time

"""
guildbattle数据
需要存储的
self.mGuildData =
{"scoreRank":{
    guildName : score
}}

self.mPlayerData =
{"killRank":{
    "name1" : [3, 1,公会名] # 击杀，死亡
}}

self.mCitySaveData = {}
{
    "occupy" = {1:公会a, 2:公会b},      # key为据点编号
    "accution" = {1: {公会a:[出价, 时间], 公会b:[出价，时间]}}
}




不需要存储的
self.mTowerData = []
for i in range(26):
    data = [[], None]       # 人的列表，占领公会，
"""


# define
GUILD_BATTLE_PERIOD_NONE        = 0                 # 未开放
GUILD_BATTLE_PERIOD_AUCTION     = 1                 # 竞拍期
GUILD_BATTLE_PERIOD_SHOW        = 2                 # 展示期
GUILD_BATTLE_PERIOD_FIGHT       = 3                 # 战斗期
GUILD_BATTLE_PERIOD_OVER        = 4                 # 结算期

Period_Desc = {
    GUILD_BATTLE_PERIOD_NONE : "not_open",
    GUILD_BATTLE_PERIOD_AUCTION : "auction",
    GUILD_BATTLE_PERIOD_SHOW : "show",
    GUILD_BATTLE_PERIOD_FIGHT : "fight",
    GUILD_BATTLE_PERIOD_OVER : "over_info",
}


WeekdayDesc = [
    GlobalStrings[202],
    GlobalStrings[203],
    GlobalStrings[204],
    GlobalStrings[205],
    GlobalStrings[206],
    GlobalStrings[207],
    GlobalStrings[208],
    GlobalStrings[202],
]

def formatHourminute(t):
    lt = time.localtime(t)
    return time.strftime('%H时%M分', lt)

"""
N为0时获取时间戳ts当天的起始时间戳，N为负数时前数N天，N为正数是后数N天
"""
def get_day_begin(ts,N = 0):
    return int(time.mktime(time.strptime(time.strftime('%Y-%m-%d',time.localtime(ts)),'%Y-%m-%d'))) + 86400*N

"""
N为0时获取时间戳ts当周的开始时间戳，N为负数时前数N周，N为整数是后数N周，此函数将周一作为周的第一天
"""
def get_week_begin(ts,N = 0):
    w = int(time.strftime('%w',time.localtime(ts)))
    if w == 0:
        w = 7
    return get_day_begin(int(ts - (w-1)*86400)) + N*604800

# 根据周几，时间算offset
def cal_period_time(weekday, dayTime, minite = 0):
    return (weekday - 1) * 86400 + dayTime * 3600 + minite * 60


# settings\guild\activity\guildbattle\time.txt里面配置
Guild_Battle_Period_def = [

]

# period, 第几场
def calThisWeekPeriod(timeDef):
    ts = time.time()
    weekBeginTime = get_week_begin(ts)
    weekTime = ts -  weekBeginTime
    for i in range(len(timeDef)):
        periods = timeDef[i]
        for j in range(len(periods)):
            if weekTime >= periods[j]:
                continue
            else:
                return j, i

    return 0,0

def calNextPeriodTime(timeDef):
    ts = int(time.time())
    weekBeginTime = get_week_begin(ts)
    weekTime = ts -  weekBeginTime
    for i in range(len(timeDef)):
        periods = timeDef[i]
        for j in range(len(periods)):
            if weekTime >= periods[j]:
                continue
            else:
                return periods[j] - weekTime, periods[j] - periods[j-1]

    return 0,0

def calNextBattleTimeDesc(timeDef):
    ts = time.time()
    weekBeginTime = get_week_begin(ts)
    weekTime = ts -  weekBeginTime
    for i in range(len(timeDef)):
        periods = timeDef[i]
        for j in range(len(periods)):
            if weekTime < periods[0]:
                nextTime = periods[0] + weekBeginTime
                lt = time.localtime(nextTime)
                w = int(time.strftime('%w', lt))
                return WeekdayDesc[w], formatHourminute(nextTime)

    # 下周开启
    nextTime = timeDef[0][0] + weekBeginTime
    lt = time.localtime(nextTime)
    w = int(time.strftime('%w', lt))
    return GlobalStrings[209] + WeekdayDesc[w], formatHourminute(nextTime)



#calThisWeekTime()
#print(get_day_begin())
#print(get_week_begin())
#print(time.localtime(get_day_begin()))
#print(time.localtime(get_week_begin()))
#print(calThisWeekTime())


#print(calThisWeekTime(get_week_begin() + cal_period_time(0,0)))
#print(calThisWeekTime(get_week_begin() + cal_period_time(7,24)))







