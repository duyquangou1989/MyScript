#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

OPENLEVEL = 1
STATUS_NOTOPEN      = 0
STATUS_CANGET       = 1
STATUS_GOT          = 2

class LoginGift(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mRewards = {}                              #level:rewards

    def isActived(self, player):
        return True

    def getName(self):
        return "LoginGift"

    def getInfo(self, player):
        if "s_logingift" not in player.__dict__:
            player.s_logingift = STATUS_NOTOPEN
                        
        info = {}
        info["VipLevel"] = player.getVipLevel()
        info["Status"] = player.s_logingift
        info["Rewards"] = self.mRewards

        return json.dumps(info)

    def doAction(self, player, actData):
        if "s_logingift" not in player.__dict__:
            player.s_logingift = STATUS_NOTOPEN

        actData = json.loads(actData)
        level = actData["Get"]
        playerLevel = player.getVipLevel()

        if player.s_logingift == STATUS_NOTOPEN:
            return Err_NotOpen

        elif player.s_logingift == STATUS_GOT:
            return Err_Repetition

        elif player.s_logingift == STATUS_CANGET:
            rewards = []
            for viplevel in self.mRewards:
                if playerLevel >= viplevel:
                    data = self.mRewards[viplevel]
                    rewards += data

            if self.canAddAllReward(player, rewards):
                for reward in rewards:
                    self.addReward(player, reward)

                player.s_logingift = STATUS_GOT
                return Err_Ok
            else:
                return Err_NotEnoughSpace

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)
        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = {}
            for i in xrange(tb.mRowNum):

                level           = tb.get(i, 0, 0, True)
                rewardstr     = tb.get(i, 1, "", False).replace("\"", "")

                tmpItems = [
                    [int(value) for value in reward.split(",")]
                        for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2)
                ]

                rewardValue = tmpItems

                if level in rewards:
                    syserr("LoginGift Reward level %s already exists." % (level))
                    return False
                else:
                    rewards[level] = rewardValue

            self.mRewards = rewards
            return True

        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False

    def checkHasReward(self, player):
        hasReward = False
        playerLevel = player.getLevel()
        if playerLevel >= OPENLEVEL and player.s_logingift == STATUS_CANGET:
            hasReward = True

        self.notifyActReward(player, hasReward)

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_ONLINE:
            player = param0
            if "s_logingift" not in player.__dict__:
                player.s_logingift = STATUS_NOTOPEN                     
            if player.getLevel() >= OPENLEVEL and player.s_logingift != STATUS_GOT:
                player.s_logingift = STATUS_CANGET
            self.checkHasReward(player)

        elif msg == MSG_PLAYER_LEVELUP:
            player = param0
            playerLevel = player.getLevel()
            if playerLevel == 4:
                if "s_logingift" not in player.__dict__:
                    player.s_logingift = STATUS_CANGET
                if player.s_logingift == STATUS_CANGET:
                    self.checkHasReward(player)

        elif msg == MSG_PLAYER_DAY_CHANGED:
            player = param0
            if "s_logingift" not in player.__dict__:
                player.s_logingift = STATUS_NOTOPEN                     
            if player.getLevel() >= OPENLEVEL:
                player.s_logingift = STATUS_CANGET
            self.checkHasReward(player)



    def getMenu(self, player, npcID):
        return []

ModuleID = 33
Instance = LoginGift(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
    #MSG_PLAYER_LEVELUP,
    MSG_PLAYER_DAY_CHANGED,
])
