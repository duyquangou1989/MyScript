#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

DATA_INDEX_BUY_TIME         = 0
DATA_INDEX_DAY_GOLDMONEY    = 1
DATA_INDEX_DAY_GOT_TIME     = 2
DATA_INDEX_RECHARGE         = 3

CDATA_INDEX_PRICE           = 0
CDATA_INDEX_DAY_GOLDMONEY   = 1
CDATA_INDEX_DAY_NUM         = 2
CDATA_INDEX_COUNT           = 3

RESULT_NOT_ACTIVED = json.dumps({"Result":1, "ResultDesc":GlobalStrings[50]})
RESULT_CANNOT = json.dumps({"Result":2, "ResultDesc":GlobalStrings[247]})
RESULT_NOT_ENOUGH_GOLDMONEY = json.dumps({"Result":3, "ResultDesc":GlobalStrings[248]})
RESULT_NO_ACTION = json.dumps({"Result":4, "ResultDesc":GlobalStrings[249]})
RESULT_NO_REWARD = json.dumps({"Result":5, "ResultDesc":GlobalStrings[250]})
RESULT_NOT_FINISHED = json.dumps({"Result":6, "ResultDesc":GlobalStrings[251]})

class MonthlyReturn(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        
        self.mID = moduleID

        self.mInitData = [0, 0, 0, 0]
        self.mPriceInfo = []

    def getName(self):
        return "MonthlyReturn"

    def canGetReward(self, rewardTime):
        curLTime = time.localtime()
        lastLTime = time.localtime(rewardTime)

        if curLTime.tm_year == lastLTime.tm_year and curLTime.tm_mon == lastLTime.tm_mon and curLTime.tm_mday == lastLTime.tm_mday:
            return False
        else:
            return True

    def getLeftDay(self, buyTime):
        totalDay = self.mPriceInfo[CDATA_INDEX_DAY_NUM]

        tmpBuyLTime = time.localtime(buyTime)
        tmpCurLTime = time.localtime()

        rBuyTime = time.mktime((tmpBuyLTime.tm_year, tmpBuyLTime.tm_mon, tmpBuyLTime.tm_mday, 0, 0, 0, 0, 0, 0))
        rCurTime = time.mktime((tmpCurLTime.tm_year, tmpCurLTime.tm_mon, tmpCurLTime.tm_mday, 0, 0, 0, 0, 0, 0))

        deltaTime = rCurTime - rBuyTime
        deltaDay = (int)(deltaTime / (24 * 3600))

        if deltaDay >= totalDay:
            return 0
        else:
            return totalDay - deltaDay

    def getInfo(self, player):
        data = self.getPlayerData(player, self.mInitData)

        info = {}
        info["Price"] = self.mPriceInfo[CDATA_INDEX_PRICE]
        info["CanGetReward"] = self.canGetReward(data[DATA_INDEX_DAY_GOT_TIME])

        leftDay = self.getLeftDay(data[DATA_INDEX_BUY_TIME])
        if leftDay > 0:
            if not info["CanGetReward"]:
                leftDay -= 1
            info["HasReward"] = True
            info["LeftDay"] = leftDay
            info["DayReward"] = data[DATA_INDEX_DAY_GOLDMONEY]
        else:
            info["HasReward"] = False
            info["LeftDay"] = self.mPriceInfo[CDATA_INDEX_DAY_NUM]
            info["DayReward"] = self.mPriceInfo[CDATA_INDEX_DAY_GOLDMONEY]

        return json.dumps(info)

    def doAction(self, player, actData):
        if self.isActived(player):
            actData = json.loads(actData)
            action = actData["Action"]

            data = self.getPlayerData(player, self.mInitData)

            if action == "buy":
                leftDay = self.getLeftDay(data[DATA_INDEX_BUY_TIME])
                if leftDay <= 0:
                    goldMoney = self.mPriceInfo[CDATA_INDEX_PRICE]
                    data[DATA_INDEX_RECHARGE] = goldMoney
                    player.saveToDB()

                    return json.dumps({
                        "Result": 0,
                        "ResultDesc": GlobalStrings[253] % (goldMoney),
                        "GoldMoney": goldMoney,
                    })
                else:
                    return RESULT_NOT_FINISHED
            elif action == "reward":
                if self.canGetReward(data[DATA_INDEX_DAY_GOT_TIME]):
                    leftDay = self.getLeftDay(data[DATA_INDEX_BUY_TIME])
                    if leftDay > 0:
                        data[DATA_INDEX_DAY_GOT_TIME] = int(time.time())

                        goldMoney = data[DATA_INDEX_DAY_GOLDMONEY]
                        player.addGoldMoney(goldMoney)
                        MMain.dbLogActivityAddGoldMoney(player, self.mID, goldMoney)
                        player.saveToDB()
                        self.notifyActReward(player, False)
                        return json.dumps({
                            "Result": 0,
                            "ResultDesc": GlobalStrings[254] % (goldMoney),
                            "GoldMoney": goldMoney,
                        })
                    else:
                        return RESULT_NO_REWARD
                else:
                    return RESULT_CANNOT
            else:
                return RESULT_NO_ACTION
        else:
            return RESULT_NOT_ACTIVED

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)

        syslog("Loading MonthlyReturn config...")

        tb = TabFile()
        if tb.load(rewardsFilename):
            self.mPriceInfo = [0 for i in xrange(CDATA_INDEX_COUNT)]
            for i in xrange(tb.mRowNum):
                self.mPriceInfo[CDATA_INDEX_PRICE] = tb.get(i, CDATA_INDEX_PRICE, 0, True)
                self.mPriceInfo[CDATA_INDEX_DAY_GOLDMONEY] = tb.get(i, CDATA_INDEX_DAY_GOLDMONEY, 0, True)
                self.mPriceInfo[CDATA_INDEX_DAY_NUM] = tb.get(i, CDATA_INDEX_DAY_NUM, 0, True)
        else:
            syserr("Loading %s failed." % (npcTalkFilename))
            return False

        return True

    def checkHasReward(self, player):
        data = self.getPlayerData(player, self.mInitData)

        hasReward = False
        if self.canGetReward(data[DATA_INDEX_DAY_GOT_TIME]):
            leftDay = self.getLeftDay(data[DATA_INDEX_BUY_TIME])
            if leftDay > 0:
                hasReward = True

        self.notifyActReward(player, hasReward)

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        else:
            player = param0
            if player and self.isActived(player):
                if msg == MSG_PLAYER_ONLINE:
                    self.checkHasReward(player)

                elif msg == MSG_PLAYER_OFFLINE:
                    data = self.getPlayerData(player, self.mInitData)
                    data[DATA_INDEX_RECHARGE] = 0

                elif msg == MSG_PLAYER_DAY_CHANGED:
                    self.checkHasReward(player)

                elif msg == MSG_PLAYER_GOLDMONEY_CHANGED:
                    value, way, productID = param1

                    if way == GMCW_Pay:
                        data = self.getPlayerData(player, self.mInitData)
                        rechargeValue = data[DATA_INDEX_RECHARGE]
                        if rechargeValue > 0:
                            if value >= rechargeValue:
                                player.addGoldMoney(-rechargeValue)
                                data[DATA_INDEX_RECHARGE] = 0
                                MMain.dbLogActivityUseGoldMoney(player, self.mID, rechargeValue)
                            #else:
                            #    player.addGoldMoney(-value)
                            #    data[DATA_INDEX_RECHARGE] -= value
                            #    MMain.dbLogActivityUseGoldMoney(player, self.mID, value)

                            rechargeValue = data[DATA_INDEX_RECHARGE]
                            if rechargeValue <= 0:
                                data[DATA_INDEX_BUY_TIME] = int(time.time())
                                data[DATA_INDEX_DAY_GOLDMONEY] = self.mPriceInfo[CDATA_INDEX_DAY_GOLDMONEY]
                                data[DATA_INDEX_DAY_GOT_TIME] = 0
                                player.saveToDB()

                                self.notifyActReward(player, True)
                                MMain.sendBoxMessage(player, GlobalStrings[255])

    def getMenu(self, player, npcID):
        return []


ModuleID = 17
Instance = MonthlyReturn(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,

    MSG_PLAYER_ONLINE,
    MSG_PLAYER_OFFLINE,
    MSG_PLAYER_GOLDMONEY_CHANGED,
    MSG_PLAYER_DAY_CHANGED,
])
