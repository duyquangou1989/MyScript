#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

TYPE_LOGIN              = 1#  登录
TYPE_LEVEL              = 2#  达到等级
TYPE_VIP_LEVEL          = 3#  达到VIP等级
TYPE_GET_MONEY          = 4#  获得金币
TYPE_BATTLE_POINT       = 5#  达到战力
TYPE_THIS_DUNGEON       = 6#  完成指定副本
TYPE_DUNGEON_NUM        = 7#  完成副本数量
TYPE_HARD_DUNGEON       = 8#  完成困难副本数量
TYPE_THIS_TASK          = 9#  完成指定任务
TYPE_TASK_NUM           = 10#  完成任务数量
TYPE_DAILY_TASK         = 11#  完成日常任务
TYPE_ARENA              = 12#  挑战竞技场
TYPE_ARENA_WIN          = 13#  获得竞技场胜利次数
TYPE_ROLE_TRAIN         = 14#  角色强化
TYPE_ITEM_DROP          = 15#  道具分解
TYPE_ITEM_EXCHANGE      = 16#  道具兑换
TYPE_ITEM_ADVANCE       = 17#  道具进阶
TYPE_ITEM_UPGRADE       = 18#  道具升级
TYPE_ITEM_STRENGTH      = 19#  道具强化(进阶和升级都是强化)
TYPE_SKILL_ADVANCE      = 20#  技能进阶
TYPE_SKILL_UPGARDE      = 21#  技能升级
TYPE_SKILL_STRENGTH     = 22#  技能强化(进阶和升级都是强化)
TYPE_TALENT_ADVANCE     = 23#  心法进阶(备用) ==>解锁
TYPE_TALENT_UPGRADE     = 24#  心法升级
TYPE_TALENT_STRENGTH    = 25#  心法强化(备用)
TYPE_STONE_USE          = 26#  镶嵌石头
TYPE_STONE_COMBINE      = 27#  合成石头
TYPE_SINGLE_PVP         = 28#  单人PVP
TYPE_SINGLE_BOSS        = 29#  单人BOSS
TYPE_MULT_BOSS          = 30#  多人BOSS
TYPE_BUY_MONEY          = 31#  金币兑换
TYPE_LOTTERY            = 32#  抽奖
TYPE_JOIN_GUILD         = 33#  加入公会
TYPE_FRIEND             = 34#  好友
TYPE_EIGHTEEN           = 35#  十八摸
TYPE_ESCORT             = 36#  护送
TYPE_MONEYDUNGEON       = 37# 雪月密境，
TYPE_ENDLESS            = 38# 无尽之塔
TYPE_PROTECTATHENA      = 39# 守卫佛塔
TYPE_UPGRADEPET         = 40# 升级宠物
TYPE_INVOKEPET          = 41# 获得宠物
TYPE_ADVANCEPET         = 42# 升阶宠物
TYPE_FINISHTHREESTAR    = 43# 三星通关
TYPE_ARENATOSTEP        = 44# 擂台赛到达某段位
TYPE_ITEM_UPGRADELEVEL  = 45# 道具强化最小等级
TYPE_PLUNDER            = 46# 掠夺
TYPE_REFRESHSPARSHOP    = 47# 刷新神秘商店次数
TYPE_ITEM_UPGRADENUM    = 48# 道具强化到30级件数
TYPE_TALENT_INVOKE      = 49# 心法解锁(备用)
TYPE_STONE_USENUM       = 50# 镶嵌宝石个数
TYPE_PETLEVELTO25       = 51# 达到25级宠物个数
TYPE_EQUIPORANGE        = 52# 穿着橙装
TYPE_EQUIPPURPLE        = 53# 穿着紫装
TYPE_TRAINADVANCE       = 54# 筋脉突破

DATA_INDEX_POINT            = 0
DATA_INDEX_REWARD           = 1

DATA_TASK_INDEX_ID          = 0
DATA_TASK_INDEX_DAY         = 1
DATA_TASK_INDEX_DAY_DESC    = 2
DATA_TASK_INDEX_TYPE        = 3
DATA_TASK_INDEX_TYPE_DESC   = 4
DATA_TASK_INDEX_LEVEL       = 5
DATA_TASK_INDEX_DESC        = 6
DATA_TASK_INDEX_VALUE       = 7
DATA_TASK_INDEX_REWARD      = 8

STATUS_UNFINISH             = 0
STATUS_FINISHED             = 1
STATUS_GOT                  = 2

class Carnival(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mTasks = {}
        self.mRewards = {}
        self.mRewardsList = []
        self.mGloble = {}                   #playeruuid:[getAll, day, self.mInitData, endTime,]
        self.mInitData = {}                 #taskid:[realvalue, taskvalue, canget, got,]

    def getPlayerData(self, player):
        if "s_carnival" not in player.__dict__:
            if player.getUUID() in self.mGloble:
                data = self.mGloble[player.getUUID()]
            else:
                data = [0, 0, copy.deepcopy(self.mInitData), self.getZerotimestamp() + 86400 * 7,]
            player.s_carnival = data

        return player.s_carnival

    def getName(self):
        return "Carnival"

    def isActived(self, player):
        return True

    def getInfo(self, player):
        result = {}

        data = self.getPlayerData(player)
        taskData = data[2]
        curTime = int(time.time())
        if data[3] <= curTime:
            if data[0] == 0:
                data[0] = 1
        showTaskData = []
        for tid in taskData:
            detail = taskData[tid]
            if tid in self.mTasks:
                realValue = detail[0]
                task = self.mTasks[tid]

                taskID = task[DATA_TASK_INDEX_ID]
                taskDay = task[DATA_TASK_INDEX_DAY]
                taskDayDesc = task[DATA_TASK_INDEX_DAY_DESC]
                taskType = task[DATA_TASK_INDEX_TYPE]
                taskTypeDesc = task[DATA_TASK_INDEX_TYPE_DESC]
                taskLevel = task[DATA_TASK_INDEX_LEVEL]
                taskDesc = task[DATA_TASK_INDEX_DESC]
                taskValue = task[DATA_TASK_INDEX_VALUE]
                taskReward = task[DATA_TASK_INDEX_REWARD]
                
                if realValue >= taskValue:
                    realValue = taskValue
                canGetReward = detail[2]
                alreadyGet = detail[3]

                showTaskData.append((
                    taskID,
                    taskDay,
                    taskDayDesc,
                    taskType,
                    taskTypeDesc,
                    taskLevel,
                    taskDesc,
                    realValue,
                    taskValue,
                    taskReward,
                    canGetReward,
                    alreadyGet,
                ))

        result["Carnival"] = showTaskData
        result["CurDay"] = data[1]
        if len(data) < 4:
            data[3] = self.getZerotimestamp() + 86400 * 7
        result["EndTime"] = data[3]
        result["All"] = data[0]
        result["AllRewards"] = self.mRewardsList

        return json.dumps(result)

    def doAction(self, player, actData):
        actData = json.loads(actData)

        data = self.getPlayerData(player)
        day = data[1]
        taskData = data[2]
        taskID = actData["Complete"]
        if taskID == 0:
            if data[0] == 0:
                return Err_Cannot
            elif data[0] == 1:
                count = 0
                for i in taskData:
                    detail = taskData[i]
                    if detail[2]:
                        count += 1
                rewardid = 0
                # for s in self.mRewards:
                #     if count >= s:
                #         rewardid = s
                for i in xrange(len(self.mRewardsList) - 1, -1, -1):
                    t = self.mRewardsList[i]
                    if count >= t[0]:
                        rewardid = t[0]
                        break
                if rewardid == 0:
                    data[0] = 2
                    return Err_Ok
                    
                if rewardid in self.mRewards:
                    rewards = self.mRewards[rewardid]
                    if self.canAddAllReward(player, rewards):
                        data[0] = 2
                        for reward in rewards:
                            self.addReward(player, reward)
                        return Err_Ok
                    else:
                        return Err_NotEnoughSpace
                else:
                    return Err_Cannot

            else:
                return Err_Repetition

        elif taskID in taskData and taskID in self.mTasks:
            detail = taskData[taskID]
            realValue = detail[0]
            task = self.mTasks[taskID]
            taskDay = task[DATA_TASK_INDEX_DAY]
            taskValue = task[DATA_TASK_INDEX_VALUE]
            taskLevel = task[DATA_TASK_INDEX_LEVEL]
            if player.getLevel() >= taskLevel and day >= taskDay:
                if detail[2]:
                    if not detail[3]:
                        rewards = task[DATA_TASK_INDEX_REWARD]
                        if self.canAddAllReward(player, rewards):
                            detail[3] = True
                            al = True
                            for i in taskData:
                                t = taskData[i]
                                if not t[3]:
                                    al = False
                                    break
                            if al:
                                data[0] = 1                            
                            for reward in rewards:
                                self.addReward(player, reward)
                            return Err_Ok
                        else:
                            return Err_NotEnoughSpace
                    else:
                        return Err_Repetition
                else:
                    return Err_Cannot
            else:
                return Err_Cannot
        else:
            return Err_Invalid

    def loadConfig(self, path):
        tasksFilename = "%stasks.txt" % (path)
        rewardsFilename = "%srewards.txt" % (path)

        syslog("Loading Carnival config...")

        tb = TabFile()
        if tb.load(tasksFilename):
            tasks = {}
            initdata = {}
            for i in xrange(tb.mRowNum):
                task = []

                taskID = tb.get(i, DATA_TASK_INDEX_ID, 0, True)
                taskDay = tb.get(i, DATA_TASK_INDEX_DAY, 0, True)
                taskDayDesc = tb.get(i, DATA_TASK_INDEX_DAY_DESC, "", False).replace("\"", "")
                taskType = tb.get(i, DATA_TASK_INDEX_TYPE, 0, True)
                taskTypeDesc = tb.get(i, DATA_TASK_INDEX_TYPE_DESC, "", False).replace("\"", "")
                taskLevel = tb.get(i, DATA_TASK_INDEX_LEVEL, 0, True)
                taskDesc = tb.get(i, DATA_TASK_INDEX_DESC, "", False).replace("\"", "")               
                taskValue = tb.get(i, DATA_TASK_INDEX_VALUE, 0, True)
                tmpItems = tb.get(i, DATA_TASK_INDEX_REWARD, "", False).replace("\"", "")
                taskReward = []
                if tmpItems:
                    taskReward = [
                        [int(value) for value in reward.split(",")]
                            for reward in tmpItems.split(";") if reward and reward.count(',') in (1, 2)
                    ]
                task = [taskID, taskDay, taskDayDesc, taskType, taskTypeDesc, taskLevel, taskDesc, taskValue, taskReward,]

                tasks[taskID] = task
                initdata[taskID] = [0, taskValue, False, False,]
            self.mTasks = tasks
            self.mInitData = initdata
        else:
            syserr("Load %s failed." % (tasksFilename))
            return False

        tb = TabFile()
        if tb.load(rewardsFilename):
            rewardsList = []
            rewards = {}
            for i in xrange(tb.mRowNum):

                point = tb.get(i, 0, 0, True)
                tmpItems = tb.get(i, 1, "", False).replace("\"", "")
                pointReward = []
                if tmpItems:
                    pointReward = [
                        [int(value) for value in reward.split(",")]
                            for reward in tmpItems.split(";") if reward and reward.count(',') in (1, 2)
                    ]

                rewards[point] = pointReward
                rewardsList.append((point, pointReward,))
            self.mRewards = rewards
            self.mRewardsList = rewardsList
        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False

        return True

    def doTask(self, player, taskType, extra):
        data = self.getPlayerData(player)
        for taskID in data[2]:
            hasReward = False
            needNotify = False            
            detail = data[2][taskID]
            if detail[3]:
                continue

            task = self.mTasks[taskID]
            taskDay = task[DATA_TASK_INDEX_DAY]
            taskLevel = task[DATA_TASK_INDEX_LEVEL]
            curDay = data[1]
            if curDay >= taskDay and player.getLevel() >= taskLevel:
                needNotify = True
            else:
                needNotify = False

            if task[DATA_TASK_INDEX_TYPE] == taskType:
                if taskType == TYPE_LOGIN:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True

                elif taskType == TYPE_LEVEL:
                    detail[0] = extra
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True

                elif taskType == TYPE_VIP_LEVEL:
                    pass

                elif taskType == TYPE_GET_MONEY:
                    detail[0] += extra
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True

                elif taskType == TYPE_BATTLE_POINT:
                    detail[0] = extra
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True

                elif taskType == TYPE_THIS_DUNGEON and extra == detail[1]:
                    detail[0] = extra
                    detail[2] = True
                    hasReward = True
                        
                elif taskType == TYPE_DUNGEON_NUM:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True

                elif taskType == TYPE_HARD_DUNGEON:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True

                elif taskType == TYPE_THIS_TASK:
                    pass
                elif taskType == TYPE_TASK_NUM:
                    pass
                elif taskType == TYPE_DAILY_TASK:
                    pass
                elif taskType == TYPE_ARENA:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True

                elif taskType == TYPE_ARENA_WIN:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_ROLE_TRAIN:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_ITEM_DROP:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_ITEM_EXCHANGE:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_ITEM_ADVANCE:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_ITEM_UPGRADE:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_ITEM_STRENGTH:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                
                elif taskType == TYPE_SKILL_ADVANCE:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_SKILL_UPGARDE:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_SKILL_STRENGTH:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_TALENT_ADVANCE:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_TALENT_UPGRADE:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_TALENT_STRENGTH:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True

                elif taskType == TYPE_STONE_USE:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_STONE_COMBINE:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_SINGLE_PVP:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_SINGLE_BOSS:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_MULT_BOSS:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True

                elif taskType == TYPE_BUY_MONEY:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_LOTTERY:
                    detail[0] += extra
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_JOIN_GUILD:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_FRIEND:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_EIGHTEEN:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_ESCORT:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_MONEYDUNGEON:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_ENDLESS:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_PROTECTATHENA:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_UPGRADEPET:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_INVOKEPET:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_ADVANCEPET:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_FINISHTHREESTAR:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_ARENATOSTEP:
                    detail[0] = extra
                    if detail[0] <= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_ITEM_UPGRADELEVEL:
                    detail[0] = extra
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_REFRESHSPARSHOP:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_ITEM_UPGRADENUM:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_STONE_USENUM:
                    detail[0] = extra
                    if extra >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_PETLEVELTO25:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_EQUIPORANGE:
                    detail[0] = extra
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_EQUIPPURPLE:
                    detail[0] = extra
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
                elif taskType == TYPE_TRAINADVANCE:
                    detail[0] += 1
                    if detail[0] >= detail[1]:
                        detail[2] = True
                        hasReward = True
            else:
                continue

            if hasReward and needNotify:
                self.notifyActReward(player, hasReward)
                
        self.mGloble[player.getUUID()] = data
        player.s_carnival = data

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)
            
            carnival = MMain.getSetting("carnival")
            if carnival:
                self.mGloble = carnival

        # elif msg == MSG_TIME_MINUTE:
        #     curTime = time.time()
        #     curLTime = time.localtime(curTime)
        #     if curLTime.tm_min % 60 == 2:
        #         MMain.setSetting("carnival", self.mGloble)

        else:
            player = param0
            if player and self.isValid(player):
                if msg == MSG_PLAYER_ONLINE:
                    self.doTask(player, TYPE_LOGIN, 1)
                    hasReward = False
                    if self.isActived(player):
                        data = self.getPlayerData(player)
                        taskData = data[2]
                        day = data[1]
                        if data[0] == 2:
                            MMain.sendTextProtocol(player, "S2C_Carnival", [])
                        for taskID in taskData:
                            detail = taskData[taskID]
                            if detail[0] >= detail[1] and not detail[3]:
                                if taskID in self.mTasks:
                                    if day >= self.mTasks[taskID][DATA_TASK_INDEX_DAY] and player.getLevel() >= self.mTasks[taskID][DATA_TASK_INDEX_LEVEL]:
                                        hasReward = True
                    if hasReward:
                        self.notifyActReward(player, hasReward)

                elif msg == MSG_PLAYER_LEVELUP:
                    playerlevel = player.getLevel()
                    self.doTask(player, TYPE_LEVEL, playerlevel)

                elif msg == MSG_PLAYER_DAY_CHANGED:
                    data = self.getPlayerData(player)
                    data[1] += 1
                    self.doTask(player, TYPE_LOGIN, 1)

                elif msg == MSG_PLAYER_FINISH_DUNGEON:
                    dungeon, dungeonStar, costTime = param1
                    dungeonID = dungeon.getID()
                    dungeonType = int(dungeonID / 10000)
                    self.doTask(player, TYPE_THIS_DUNGEON, dungeonID)
                    if dungeonType == 2:
                        self.doTask(player, TYPE_DUNGEON_NUM, 1)
                        if int(dungeon.getDungeonDegree()) != 0:
                            self.doTask(player, TYPE_HARD_DUNGEON, 1)
                        if dungeonStar == 3:
                            self.doTask(player, TYPE_FINISHTHREESTAR, 1)
                    elif dungeonType == 11:
                        self.doTask(player, TYPE_MONEYDUNGEON, dungeonID)
                    elif dungeonType == 5:
                        self.doTask(player, TYPE_ENDLESS, dungeonID)
                    elif dungeonType == 9:
                        self.doTask(player, TYPE_PROTECTATHENA, dungeonID)

                elif msg == MSG_PLAYER_ITEM_UPGRADE:
                    itemLevel = param1
                    self.doTask(player, TYPE_ITEM_UPGRADE, 1)
                    rolelist = player.getRoleList()
                    minLevel = 0
                    for role in rolelist:
                        templevel = role.getMinCasketInfoLevel()
                        minLevel = minLevel if minLevel < templevel else templevel
                    self.doTask(player, TYPE_ITEM_UPGRADELEVEL, minLevel)

                    if itemLevel == 30:
                        self.doTask(player, TYPE_ITEM_UPGRADENUM, 1)


                elif msg == MSG_PLAYER_ITEM_ADVANCE:
                    self.doTask(player, TYPE_ITEM_ADVANCE, 1)

                elif msg == MSG_PLAYER_SINGLE_PVP:
                    self.doTask(player, TYPE_SINGLE_PVP, 1)

                elif msg == MSG_PLAYER_ENTER_ARENA:
                    result,rank = param1
                    if result == 0:
                        self.doTask(player, TYPE_ARENA, 1)
                        
                    if result == 1:
                        self.doTask(player, TYPE_ARENA_WIN, 1)
                        self.doTask(player,TYPE_ARENATOSTEP,rank) 

                elif msg == MSG_PLAYER_TRAIN_ROLE:
                    self.doTask(player, TYPE_ROLE_TRAIN, 1)

                elif msg == MSG_PLAYER_DROP_ITEM:
                    self.doTask(player, TYPE_ITEM_DROP, 1)

                elif msg == MSG_PLAYER_STONE_USE:
                    self.doTask(player, TYPE_STONE_USE, 1)
                    stoneNum = MMain.getStoneNumInPlayer(player)
                    self.doTask(player,TYPE_STONE_USENUM, stoneNum)

                elif msg == MSG_PLAYER_SINGLE_BOSS:
                    self.doTask(player, TYPE_SINGLE_BOSS, 1)

                elif msg == MSG_PLAYER_MULT_BOSS:
                    self.doTask(player, TYPE_MULT_BOSS, 1)

                elif msg == MSG_PLAYER_LOTTERY:
                    typ, action = param1
                    if typ == 2:
                        if action == 1:
                            self.doTask(player, TYPE_LOTTERY, 1)
                        elif action == 2:
                            self.doTask(player, TYPE_LOTTERY, 10)

                elif msg == MSG_PLAYER_JOIN_EIGHTEEN:
                    self.doTask(player, TYPE_EIGHTEEN, 1)
                elif msg == MSG_PLAYER_PET_UPGRADE:
                    pet = param1
                    self.doTask(player, TYPE_UPGRADEPET, 1)
                    petLevel = pet.getLevel()
                    if petLevel == 25:
                        self.doTask(player, TYPE_PETLEVELTO25, 1)
                elif msg == MSG_PLAYER_PET_INVOKE:
                    self.doTask(player, TYPE_INVOKEPET, 1)
                elif msg == MSG_PLAYER_PET_ADVANCE:
                    self.doTask(player, TYPE_ADVANCEPET, 1)
                elif msg == MSG_PLAYER_ADD_FRIEND:
                    self.doTask(player, TYPE_FRIEND, 1)
                elif msg == MSG_PLAYER_REFRESH_SPARSHOP:
                    self.doTask(player, TYPE_REFRESHSPARSHOP, 1)
                elif msg == MSG_PLAYER_TALENT_ADVANCE:
                    self.doTask(player, TYPE_TALENT_ADVANCE, 1)
                elif msg == MSG_PLAYER_EQUIP_ITEM:
                    role, item = param1
                    quality = item.getQuality();
                    if quality >= 9:
                        itemNum = MMain.getItemNumInPlayer(player, 9 )
                        self.doTask(player, TYPE_EQUIPORANGE, itemNum)
                    if quality >= 6 and quality < 9:
                        itemNum = MMain.getItemNumInPlayer(player, 6 )
                        self.doTask(player, TYPE_EQUIPPURPLE, itemNum)
                elif msg == MSG_PLAYER_TRAIN_ADVANCE:
                    self.doTask(player, TYPE_TRAINADVANCE, 1)
                elif msg == MSG_PLAYER_SKILL_ADVANCE:
                    self.doTask(player, TYPE_SKILL_ADVANCE, 1)

    def getMenu(self, player, npcID):
        return []

ModuleID = 13
Instance = Carnival(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_CREATED,
    MSG_TIME_MINUTE,
    MSG_PLAYER_DAY_CHANGED,
    MSG_PLAYER_LEVELUP,
    MSG_PLAYER_FINISH_DUNGEON,
    MSG_PLAYER_ITEM_UPGRADE,
    MSG_PLAYER_ITEM_ADVANCE,
    MSG_PLAYER_SINGLE_PVP,
    MSG_PLAYER_ENTER_ARENA,
    MSG_PLAYER_TRAIN_ROLE,
    MSG_PLAYER_DROP_ITEM,
    MSG_PLAYER_STONE_USE,
    MSG_PLAYER_SINGLE_BOSS,
    MSG_PLAYER_MULT_BOSS,
    MSG_PLAYER_LOTTERY,
    MSG_PLAYER_JOIN_EIGHTEEN,
    MSG_PLAYER_PET_INVOKE,
    MSG_PLAYER_PET_UPGRADE,
    MSG_PLAYER_PET_ADVANCE,
    MSG_PLAYER_ADD_FRIEND,
    MSG_PLAYER_REFRESH_SPARSHOP,
    MSG_PLAYER_TALENT_ADVANCE,
    MSG_PLAYER_EQUIP_ITEM,
    MSG_PLAYER_TRAIN_ADVANCE,
    MSG_PLAYER_SKILL_ADVANCE,
])
