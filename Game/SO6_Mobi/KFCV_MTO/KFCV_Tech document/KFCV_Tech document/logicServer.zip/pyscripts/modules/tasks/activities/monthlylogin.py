#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
import calendar
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

CDATA_INDEX_MONTH           = 0
CDATA_INDEX_DAY_NUM         = 1
CDATA_INDEX_REWARDS         = 2

PDATA_INDEX_DAY_NUM         = 0
PDATA_INDEX_REWARD_TIME     = 1
PDATA_INDEX_MONTH           = 2
PDATA_INDEX_ATTR_REWARD     = 3

RESULT_NOT_ACTIVED = json.dumps({"Result":1, "ResultDesc":GlobalStrings[50]})
RESULT_ALREADY = json.dumps({"Result":2, "ResultDesc":GlobalStrings[245]})
RESULT_BAG_FULL = json.dumps({"Result":3, "ResultDesc":GlobalStrings[178]})

class MonthlyLogin(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        
        self.mID = moduleID

        self.mInitData = [0, 0, 0, []]
        self.mRewards = {}
        self.mAttrRewardsExtra = {}
        self.mAttrRewards = []

        self.mCannotAdd = {
            2: MMain.convertMagicAttribute("AttackMag"),
            3: MMain.convertMagicAttribute("AttackMag"),
            4: MMain.convertMagicAttribute("AttackPsy"),
        }

    def getName(self):
        return GlobalStrings[246]

    def canGetReward(self, rewardTime):
        curLTime = time.localtime()
        lastLTime = time.localtime(rewardTime)

        if curLTime.tm_year == lastLTime.tm_year and curLTime.tm_mon == lastLTime.tm_mon and curLTime.tm_mday == lastLTime.tm_mday:
            return False
        else:
            return True

    def calAttrRewards(self, job):
        cannot = self.mCannotAdd[job]
        percent = 0
        randomPercent = random.randint(1, 10000)
        for reward in self.mAttrRewards:
            percent += reward[2]
            if randomPercent <= percent:
                if reward[0] != cannot:
                    return reward
        return None

    def getInfo(self, player):
        data = self.getPlayerData(player, self.mInitData)

        lenOfData = len(data)
        lenOfInitData = len(self.mInitData)
        if lenOfInitData > lenOfData:
            for i in xrange(lenOfInitData - lenOfData):
                data.append(self.mInitData[i + lenOfData])

        dayNum = data[0]
        canGetReward = self.canGetReward(data[1])
        if canGetReward:
            data[PDATA_INDEX_ATTR_REWARD] = [-1, 0]

        lTime = time.localtime()
        month = lTime.tm_mon

        rewards = []

        curMonthDayNum = calendar.monthrange(lTime.tm_year,lTime.tm_mon)[1]
        if month in self.mRewards:
            tmpRewards = self.mRewards[month]
            for day in tmpRewards:
                rewards.append((
                    day,
                    tmpRewards[day],
                    day <= dayNum,
                ))
            rewards.sort()
        else:
            for i in xrange(curMonthDayNum):
                rewards.append((
                    i + 1,
                    [],
                    i + 1 <= dayNum,
                ))

        info = {}
        info["Rewards"] = rewards
        info["DayNum"] = dayNum;
        info["CanGetReward"] = canGetReward
        info["AttrRewardsExtra"] = self.mAttrRewardsExtra
        info["TodayAttrReward"] = data[PDATA_INDEX_ATTR_REWARD]

        return json.dumps(info)

    def doAction(self, player, actData):
        if self.isActived(player):
            actData = json.loads(actData)

            curTime = time.time()
            lTime = time.localtime()
            month = lTime.tm_mon

            data = self.getPlayerData(player, self.mInitData)
            if self.canGetReward(data[PDATA_INDEX_REWARD_TIME]):
                if month in self.mRewards:
                    rewards = self.mRewards[month]
                else:
                    rewards = []
                dayNum = data[PDATA_INDEX_DAY_NUM]

                numOfRewards = len(rewards)
                if numOfRewards > 0:
                    if dayNum >= 0 and dayNum < numOfRewards:
                        dayRewards = rewards[dayNum]
                    else:
                        dayRewards = rewards[-1]
                else:
                    dayRewards = []

                if self.canAddAllReward(player, dayRewards):
                    data[PDATA_INDEX_DAY_NUM] += 1
                    data[PDATA_INDEX_REWARD_TIME] = curTime

                    attrReward = self.calAttrRewards(player.getJob())
                    if attrReward:
                        mainRole = player.getRoleByID(0)
                        mainRole.modifyMagicAttribute(attrReward[0], attrReward[1])
                    else:
                        attrReward = (-1, 0)

                    dayNum = data[PDATA_INDEX_DAY_NUM]
                    if dayNum in self.mAttrRewardsExtra:
                        attrRewardsExtra = self.mAttrRewardsExtra[dayNum]
                        mainRole = player.getRoleByID(0)
                        for attrInfo in attrRewardsExtra:
                            mainRole.modifyMagicAttribute(attrInfo[0], attrInfo[1])
                    else:
                        attrRewardsExtra = []

                    if numOfRewards:
                        message = GlobalStrings[172]
                        for reward in dayRewards:
                            self.addReward(player, reward)
                            message += self.getRewardDesc(reward)
                    else:
                        message = ""

                    data[PDATA_INDEX_ATTR_REWARD] = attrReward

                    self.notifyActReward(player, False)
                    player.saveToDB()

                    MMain.notifyModified(player, 13, 0, player.getBattlePoint())
                    return json.dumps({
                        "Result": 0,
                        "ResultDesc": message,
                        "Rewards": dayRewards,
                        "Attribute": (
                            attrReward[0], 
                            attrReward[1],
                        ),
                        "AttributeExtra": attrRewardsExtra,
                    })
                else:
                    return RESULT_BAG_FULL
            else:
                return RESULT_ALREADY
        else:
            return RESULT_NOT_ACTIVED

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)
        attrRewardsFilename = "%sattrrewards.txt" % (path)
        attrRewardsExtraFilename = "%sattrrewardsextra.txt" % (path)

        syslog("Loading MonthlyLogin config...")

        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = {}
            for i in xrange(tb.mRowNum):
                month = tb.get(i, 0, 0, True)
                day = tb.get(i, 1, 0, True)
                rewardType = tb.get(i, 2, 0, True)
                rewardValue = tb.get(i, 3, "", False).replace("\"", "")

                if rewardType == REWARD_TYPE_ITEM:
                    tmpItems = []
                    tmpBlocks = rewardValue.split(";")
                    for tmpBlock in tmpBlocks:
                        itemBlocks = tmpBlock.split(",")
                        if len(itemBlocks) == 3:
                            tmpItems.append((
                                int(itemBlocks[0]),
                                int(itemBlocks[1]),
                                int(itemBlocks[2]),
                            ))
                    rewardValue = tmpItems
                else:
                    rewardValue = int(rewardValue)

                if month in rewards:
                    if day in rewards[month]:
                        rewards[month][day].append((
                            rewardType,
                            rewardValue,
                        ))
                    else:
                        rewards[month][day] = [(
                            rewardType, 
                            rewardValue,
                        )]
                else:
                    rewards[month] = {
                        day: [(
                            rewardType,
                            rewardValue,
                        )]
                    }

            self.mRewards = rewards
        else:
            syserr("Loading %s failed." % (rewardsFilename))
            return False

        tb = TabFile()
        if tb.load(attrRewardsFilename):
            rewards = []
            for i in xrange(tb.mRowNum):
                attrName = tb.get(i, 0, "", False)
                attrValue = tb.get(i, 1, 0, True)
                attrPercent = tb.get(i, 2, 0, True)

                rewards.append((
                    MMain.convertMagicAttribute(attrName),
                    attrValue,
                    attrPercent,
                ))

            self.mAttrRewards = rewards
        else:
            syserr("Loading %s failed." % (attrRewardsFilename))
            return False

        tb = TabFile()
        if tb.load(attrRewardsExtraFilename):
            rewards = {}
            for i in xrange(tb.mRowNum):
                day = tb.get(i, 0, 0, True)
                attrName = tb.get(i, 1, "", False)
                attrValue = tb.get(i, 2, 0, True)

                if day in rewards:
                    rewards[day].append((
                        MMain.convertMagicAttribute(attrName),
                        attrValue,
                    ))
                else:
                    rewards[day] = [(
                        MMain.convertMagicAttribute(attrName),
                        attrValue,
                    )]

            self.mAttrRewardsExtra = rewards
        else:
            syserr("Loading %s failed." % (attrRewardsExtraFilename))
            return False

        return True

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_ONLINE:
            player = param0

            if self.isActived(player):
                data = self.getPlayerData(player, self.mInitData)
                if self.canGetReward(data[PDATA_INDEX_REWARD_TIME]):
                    self.notifyActReward(player, True)

        elif msg == MSG_PLAYER_DAY_CHANGED:
            player = param0

            if self.isActived(player):
                lTime = time.localtime()
                month = lTime.tm_mon

                data = self.getPlayerData(player, self.mInitData)
                if data[PDATA_INDEX_MONTH] != month:
                    data[PDATA_INDEX_DAY_NUM] = 0
                    data[PDATA_INDEX_REWARD_TIME] = 0
                    data[PDATA_INDEX_MONTH] = month

                if self.canGetReward(data[PDATA_INDEX_REWARD_TIME]):
                    self.notifyActReward(player, True)

    def getMenu(self, player, npcID):
        return []


ModuleID = 21
Instance = MonthlyLogin(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,

    MSG_PLAYER_ONLINE,
    MSG_PLAYER_DAY_CHANGED,
])
