#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
import bisect
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

WEIGHT1 = 5  # 权重1的商品个数
WEIGHT2 = 3
WEIGHT3 = 2

INDEX_IDX               = 0
INDEX_REWARD_TYPE       = 1
INDEX_REWARD_VALUE      = 2
INDEX_PRICE_TYPE        = 3
INDEX_PRICE             = 4
INDEX_WEIGHT            = 5
INDEX_RATE              = 6
INDEX_LIMIT_UPPER       = 7
INDEX_LIMIT_LOWER       = 8
INDEX_LIMIT_LEVEL       = 9
INDEX_NEEDMSG           = 10

RESULT_NOT_ACTIVED = json.dumps({"Result":1, "ResultDesc":GlobalStrings[50]})
RESULT_NOT_ENOUGH = json.dumps({"Result":2, "ResultDesc":GlobalStrings[81]})
RESULT_NO_SPACE = json.dumps({"Result":3, "ResultDesc":GlobalStrings[54]})

class MagicShop(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        
        self.mID = moduleID
        self.mBeginTime = 0
        self.mEndTime = 0

        self.mTableData = []
        self.mRefreshPrice = 10

        self.mCheckInterval = 4 * 60 * 60                                   #检查间隔   单位秒
        self.mNextRefreshTime = 0                                           #下次刷新时间

        engine.Instance.registerTextProtocol("C2S_MagicShop", self.onProtocol)

    def getName(self):
        return GlobalStrings[82]
        
    def checkPlayerData(self, player):
        if not "s_magicshop" in player.__dict__:
            player.s_magicshop=[0,#刷新次数             0
                                {},#已经购买的物品      1
                                [],#当前神秘商店物品    2
                                0, #下次刷新时间
                                ]
        if len(player.s_magicshop) != 4:
            player.s_magicshop=[0,#刷新次数             0
                                {},#已经购买的物品      1
                                [],#当前神秘商店物品    2
                                0, #下次刷新时间
                                ]
    def isOpened(self):
        curTime = int(time.time())
        if curTime >= self.mBeginTime and curTime <= self.mEndTime:
            return True
        else:
            return False

    def buildInitData(self, player):
        playerLevel = player.getLevel()
        refreshCount = player.s_magicshop[0]
        buyCount = player.s_magicshop[1]
        randomlist1 = []
        randomlist2 = []
        randomlist3 = []
        randomitem1 = []
        randomitem2 = []
        randomitem3 = []        
        randbase1 = 0
        randbase2 = 0
        randbase3 = 0
        player.s_magicshop[2] = []
        player.s_magicshop[3] = self.mNextRefreshTime
        for reward in self.mTableData:
            if reward[INDEX_LIMIT_LEVEL] <= playerLevel and reward[INDEX_LIMIT_LOWER] <= refreshCount:
                if reward[INDEX_LIMIT_UPPER] == -1 or reward[INDEX_LIMIT_UPPER] > buyCount.get(reward[INDEX_IDX], 0):
                    if reward[INDEX_WEIGHT] == 1:                        
                        randbase1 += reward[INDEX_RATE]
                        randomlist1.append(randbase1)
                        randomitem1.append(reward)
                    if reward[INDEX_WEIGHT] == 2:
                        randbase2 += reward[INDEX_RATE]
                        randomlist2.append(randbase2)
                        randomitem2.append(reward)
                    if reward[INDEX_WEIGHT] == 3:
                        randbase3 += reward[INDEX_RATE]
                        randomlist3.append(randbase3)
                        randomitem3.append(reward)
        # weight 1
        for i in xrange(WEIGHT1):
            thisrand = random.randint(0, randbase1)
            idx = bisect.bisect_left(randomlist1, thisrand)
            randitem = randomitem1[idx]

            buyCount[randitem[INDEX_IDX]] = buyCount.get(randitem[INDEX_IDX], 0) + 1

            if randitem[INDEX_LIMIT_UPPER] != -1 and randitem[INDEX_LIMIT_UPPER] <= buyCount.get(randitem[INDEX_IDX], 0):
                randomlist1.pop(idx)
                randomitem1.pop(idx)
                #重新构造随机列表
                randbase1 = 0
                randomlist1 = []
                for itr in randomitem1:
                    randbase1 += itr[INDEX_RATE]
                    randomlist1.append(randbase1)
            player.s_magicshop[2].append(randitem)
        # weight 2
        for i in xrange(WEIGHT2):
            thisrand = random.randint(0, randbase2)
            idx = bisect.bisect_left(randomlist2, thisrand)
            randitem = randomitem2[idx]

            buyCount[randitem[INDEX_IDX]] = buyCount.get(randitem[INDEX_IDX], 0) + 1

            if randitem[INDEX_LIMIT_UPPER] != -1 and randitem[INDEX_LIMIT_UPPER] <= buyCount.get(randitem[INDEX_IDX], 0):
                randomlist2.pop(idx)
                randomitem2.pop(idx)
                #重新构造随机列表
                randbase2 = 0
                randomlist2 = []
                for itr in randomitem2:
                    randbase2 += itr[INDEX_RATE]
                    randomlist2.append(randbase2)
            player.s_magicshop[2].append(randitem)          
        # weight 3
        for i in xrange(WEIGHT3):
            thisrand = random.randint(0, randbase3)
            idx = bisect.bisect_left(randomlist3, thisrand)
            randitem = randomitem3[idx]

            buyCount[randitem[INDEX_IDX]] = buyCount.get(randitem[INDEX_IDX], 0) + 1

            if randitem[INDEX_LIMIT_UPPER] != -1 and randitem[INDEX_LIMIT_UPPER] <= buyCount.get(randitem[INDEX_IDX], 0):
                randomlist3.pop(idx)
                randomitem3.pop(idx)
                #重新构造随机列表
                randbase3 = 0
                randomlist3 = []
                for itr in randomitem3:
                    randbase3 += itr[INDEX_RATE]
                    randomlist3.append(randbase3)
            player.s_magicshop[2].append(randitem)

        player.s_magicshop[1] = buyCount

    def getInfo(self, player):
        while time.time() >= self.mNextRefreshTime:
            self.mNextRefreshTime += self.mCheckInterval
        if player.s_magicshop[3] != self.mNextRefreshTime:
            self.buildInitData(player)

        data = player.s_magicshop[2]
            
        info = {}
        rewards = []
        for reward in data:
            rewards.append((
                reward[INDEX_REWARD_TYPE],
                reward[INDEX_REWARD_VALUE],
                reward[INDEX_PRICE_TYPE],
                reward[INDEX_PRICE],
                reward[INDEX_WEIGHT],
                reward[INDEX_IDX],
            ))
        info["Rewards"] = rewards
        
        return json.dumps({
            "Result": 0,
            "ResultDesc": "",
            "Action": "info",
            "NextRefreshTime": int(self.mNextRefreshTime - time.time()),
            "Info": info,
        })

    def doAction(self, player, actData):
        if not self.isOpened():
            return RESULT_NOT_ACTIVED

        data = json.loads(actData)
        pdata = player.s_magicshop[2]

        actionType = data["Action"]
        if actionType == "buy":
            index = data["Index"]
            idx = 0
            for reward in pdata:
                if index == reward[INDEX_IDX]:
                    if reward[INDEX_PRICE_TYPE] == 0:
                        if player.getMoney() < reward[INDEX_PRICE]:
                            return RESULT_NOT_ENOUGH
                    if reward[INDEX_PRICE_TYPE] == 1:
                        if player.getGoldMoney() < reward[INDEX_PRICE]:
                            return RESULT_NOT_ENOUGH

                    realReward = (reward[INDEX_REWARD_TYPE], reward[INDEX_REWARD_VALUE], )
                    if self.canAddReward(player, realReward):
                        if reward[INDEX_PRICE_TYPE] == 0:
                            player.addMoney(-reward[INDEX_PRICE])
                            MMain.dbLogActivityUseMoney(player, self.mID, reward[INDEX_PRICE])
                        if reward[INDEX_PRICE_TYPE] == 1:
                            player.addGoldMoney(-reward[INDEX_PRICE])
                            MMain.dbLogActivityUseGoldMoney(player, self.mID, reward[INDEX_PRICE])

                        self.addReward(player, realReward)
                        if reward[INDEX_NEEDMSG] == 1:
                            message = GlobalStrings[83] % (player.getName(), self.getRewardDesc(realReward))
                            MMain.sendHorseMessage(message)
                        player.s_magicshop[2].pop(idx)
                        player.saveToDB()
                        return json.dumps({
                            "Result": 0,
                            "ResultDesc": "",
                            "Action": "buy",
                            "Reward": realReward,
                        })

                    else:
                        return RESULT_NO_SPACE
                
                idx += 1
        elif actionType == "refresh":
            if player.getGoldMoney() < self.mRefreshPrice:
                return RESULT_NOT_ENOUGH

            player.addGoldMoney(-self.mRefreshPrice)
            MMain.dbLogActivityUseGoldMoney(player, self.mID, self.mRefreshPrice)

            player.s_magicshop[0] += 1
            self.buildInitData(player)

            return json.dumps({
                "Result": 0,
                "ResultDesc": "",
                "Action": "refresh",
            })

        elif actionType == "info":
            return self.getInfo(player)

        else:
            return RESULT_ACTION_ERROR

    def onProtocol(self, player, data):
        result = self.doAction(player, data[0])

        response = (result, )
        MMain.sendTextProtocol(player, "S2C_MagicShop", response)

    def loadConfig(self, path):
        rewardFilename = "%smagicshop.txt" % (path)
        optionFilename = "%soptions.txt" % (path)

        tb = TabFile()
        if tb.load(optionFilename):
            for i in xrange(tb.mRowNum):

                self.mBeginTime = MMain.buildTime(tb.get(i, 0, "", False).replace("\"", ""))
                self.mEndTime = MMain.buildTime(tb.get(i, 1, "", False).replace("\"", ""))
                curTime = int(time.time())
                i = 0
                while self.mBeginTime + i * self.mCheckInterval < curTime:
                    i += 1
                self.mNextRefreshTime = self.mBeginTime + self.mCheckInterval * i
        else:
            syserr("Loading %s failed." % (optionFilename))
            return False
        tb = TabFile()   
        if tb.load(rewardFilename):
            tables = []
            for i in xrange(tb.mRowNum):

                idx = tb.get(i, INDEX_IDX, 0, True)
                rewardType = tb.get(i, INDEX_REWARD_TYPE, 0, True)
                rewardValue = tb.get(i, INDEX_REWARD_VALUE, "", False).replace("\\n", "\n").replace("\"", "")
                priceType = tb.get(i, INDEX_PRICE_TYPE, 0, True)
                price = tb.get(i, INDEX_PRICE, 0, True)
                weight = tb.get(i, INDEX_WEIGHT, 0, True)
                rate = tb.get(i, INDEX_RATE, 0, True)
                limitUpper = tb.get(i, INDEX_LIMIT_UPPER, -1, True)
                limitLower = tb.get(i, INDEX_LIMIT_LOWER, 0, True)
                limitLevel = tb.get(i, INDEX_LIMIT_LEVEL, 0, True)
                needMsg = (tb.get(i, INDEX_NEEDMSG, 0, True) == 1)
                
                if rewardType == REWARD_TYPE_ITEM:
                    tmpItems = []
                    tmpBlocks = rewardValue.split(";")
                    for tmpBlock in tmpBlocks:
                        itemBlocks = tmpBlock.split(",")
                        if len(itemBlocks) == 3:
                            tmpItems.append((
                                int(itemBlocks[0]),
                                int(itemBlocks[1]),
                                int(itemBlocks[2]),
                            ))
                        elif len(itemBlocks) != 1:
                            syserr("Loading %s failed." % (rewardFilename))
                            return False
                    rewardValue = tmpItems
                else:
                    rewardValue = int(rewardValue)

                tables.append((
                    idx,
                    rewardType,
                    rewardValue,
                    priceType,
                    price,
                    weight,
                    rate,
                    limitUpper,
                    limitLower,
                    limitLevel,
                    needMsg,
                ))

            self.mTableData = tables
        else:
            syserr("Loading %s failed." % (rewardFilename))
            return False

        return True

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            self.loadConfig("settings/activity/magicshop/")
            syslog("Loading MagicShop config...")
            
        elif msg == MSG_PLAYER_ONLINE:
            player = param0
            self.checkPlayerData(player)
            if self.isOpened():
                if len(player.s_magicshop[2]) == 0 and player.s_magicshop[3] != self.mNextRefreshTime:
                    self.buildInitData(player)
        elif msg == MSG_PLAYER_DAY_CHANGED:
            player = param0
            self.checkPlayerData(player)
            player.s_magicshop[0] = 0
            player.s_magicshop[1] = {}

    def getMenu(self, player, npcID):
        return []


ModuleID = 24
Instance = MagicShop(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_DAY_CHANGED,
    MSG_PLAYER_ONLINE,
])
