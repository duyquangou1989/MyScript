#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

OPENLEVEL = 1
STATUS_NOTOPEN      = 0
STATUS_CANGET       = 1
STATUS_GOT          = 2

class MultReward(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mMultReward = {}                              #dungeonID:content

    def isActived(self, player):
        return True

    def getName(self):
        return "MultReward"

    def getInfo(self, player):
        info = {}
        data = []
        for dungeonid in self.mMultReward:
            temp = self.mMultReward[dungeonid]
            curTime = time.time()
            if temp[0] <= curTime and temp[1] >= curTime and temp[2] != 1:    
                data.append((dungeonid, temp[2]))
        info["dungeonids"] = data
        return json.dumps(info)

    def doAction(self, player, actData):
        return Err_Ok

    def getDungeonMuit(self, DungeonID):
        if DungeonID in self.mMultReward:
            data = self.mMultReward[DungeonID]
            curTime = int(time.time())
            if curTime >= data[0] and curTime <= data[1]:
                return data[2]
            else:
                return 1
        else:
            return 1

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)
        tb = TabFile()
        if tb.load(rewardsFilename):
            multreward = {}
            for i in xrange(tb.mRowNum):
                dungeonId   = tb.get(i, 0, 0, True)
                startTime   = MMain.buildTime(tb.get(i, 1, "", False).replace("\"", ""))
                endTime     = MMain.buildTime(tb.get(i, 2, "", False).replace("\"", ""))
                multi       = tb.get(i, 3, 0, True)
                multreward[dungeonId] = [startTime, endTime, multi,]

            self.mMultReward = multreward

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)
            
    def getMenu(self, player, npcID):
        return []

ModuleID = 22
Instance = MultReward(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
])
