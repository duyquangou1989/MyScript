#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

class DoubleSpar(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mTime = {}
        self.mIsDouble = 1
        self.mMinBeginTime = 0
        self.mMinEndTime = 0


    def isActived(self, player):
        return ActivityBase.isActived(self, player)

    def getDoubleSpar(self):
        if self.isActived([]):
            return self.mIsDouble
        else:
            return 1
        
    def getName(self):
        return "DoubleSpar"

    def getInfo(self, player):
        if self.isActived(player):
            return str(self.mIsDouble)
        return str(1)

    def doAction(self, player, actData):
        return Err_Ok

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)
        tb = TabFile()
        if tb.load(rewardsFilename):
            temp = {}
            for i in xrange(tb.mRowNum):
                btime = tb.get(i, 0, 0, True)
                etime = tb.get(i, 1, 0, True)
                temp[btime] = etime
            self.mTime = temp
            return True
        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)
            
        elif msg == MSG_PLAYER_ONLINE:
            player = param0
            if self.isActived(player):
                res = []
                for btime in self.mTime:
                    res.append((btime, self.mTime[btime])) 
                res1 = {}
                res1["times"] = res
                response = (json.dumps(res1),)
                MMain.sendTextProtocol(player, "S2C_DoubleSpar",response )

        elif msg == MSG_TIME_MINUTE:
            if self.isActived(param0):
                curTime = time.time()
                curLTime = time.localtime(curTime)
                curMin = curLTime.tm_hour * 60 + curLTime.tm_min
                isDouble = 1
                beginTime = 0
                endTime = 0
                for btime in self.mTime:
                    if curMin >= btime and curMin < self.mTime[btime]:
                        isDouble = 2
                        beginTime = btime
                        endTime = self.mTime[btime]
                        break

                self.mIsDouble = isDouble
                self.mMinBeginTime = beginTime
                self.mMinEndTime = endTime

    def getMenu(self, player, npcID):
        return []

ModuleID = 21
Instance = DoubleSpar(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
    MSG_TIME_MINUTE,
])
