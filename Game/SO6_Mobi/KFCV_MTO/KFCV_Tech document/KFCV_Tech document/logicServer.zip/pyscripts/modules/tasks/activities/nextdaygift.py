#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

OPENLEVEL       = 4

class NextDayGift(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mAddVip = 3
        self.mRewardDesc = []
        self.mRewards = []                             

    def isActived(self, player):
        return True

    def isShow(self, player):
        if "s_nextdaygift" not in player.__dict__:
            player.s_nextdaygift = 0
        if player.s_nextdaygift == -1:
            return False
        return True

    def getName(self):
        return "NextDayGift"

    def getInfo(self, player):
        if "s_nextdaygift" not in player.__dict__:
            player.s_nextdaygift = 0

        canGetReward = False
        alreadyGet = False
        timeLeft = 0
        if player.s_nextdaygift == 0:
            pass
        elif player.s_nextdaygift == -1:
            canGetReward = True
            alreadyGet = True
            timeLeft = 0
        else:
            curTime = int(time.time())
            if curTime >= player.s_nextdaygift:
                canGetReward = True
                timeLeft = 0
            else:
                timeLeft = player.s_nextdaygift - curTime

        info = {}
        info["AddVip"] = self.mAddVip
        info["CanGetReward"] = canGetReward
        info["AlreadyGet"] = alreadyGet
        info["TimeLeft"] = timeLeft
        info["UnixTime"] = player.s_nextdaygift
        info["Rewards"] = self.mRewardDesc
        
        return json.dumps(info)

    def doAction(self, player, actData):
        actData = json.loads(actData)
        level = actData["Get"]
        curTime = int(time.time())
        if "s_nextdaygift" not in player.__dict__:
            player.s_nextdaygift = 0
        if player.s_nextdaygift == 0:
            return Err_Cannot
        elif player.s_nextdaygift == -1:
            return Err_Repetition
        elif player.s_nextdaygift > curTime:
            return Err_Cannot
        elif player.s_nextdaygift <= curTime:
            rewards = self.mRewards
            if self.canAddAllReward(player, rewards):
                for reward in rewards:
                    self.addReward(player, reward)

                player.s_nextdaygift = -1
                MMain.invokeRole(player, 3)
                return Err_Ok
            else:
                return Err_NotEnoughSpace

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)

        syslog("Loading NextDayGift config...")

        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = []
            desc = []
            for i in xrange(tb.mRowNum):

                coDesc      = tb.get(i, 0, "", False).replace("\"", "")
                coValue     = tb.get(i, 1, "", False).replace("\"", "")

                reward = []
                tmpBlocks = coValue.split(";")
                for tmpBlock in tmpBlocks:
                    itemBlocks = tmpBlock.split(",")
                    if len(itemBlocks) == 3:
                        reward = (
                            int(itemBlocks[0]),
                            int(itemBlocks[1]),
                            int(itemBlocks[2]),
                        )
                    if len(itemBlocks) == 2:
                        reward = (
                            int(itemBlocks[0]),
                            int(itemBlocks[1]),
                            )

                rewards.append(reward)
                desc.append((coDesc, reward,))

            self.mRewards = rewards
            self.mRewardDesc = desc
            return True

        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False

    def checkHasReward(self, player):
        hasReward = False
        self.notifyActReward(player, hasReward)

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_LEVELUP:
            player = param0
            if "s_nextdaygift" not in player.__dict__:
                player.s_nextdaygift = 0        #0 = 未到领取等级 -1=已经领取 unixtime=可以领取时间

            if player.getLevel() == OPENLEVEL:
                t = time.localtime(time.time())
                time1 = time.mktime(time.strptime(time.strftime('%Y-%m-%d 00:00:00', t),'%Y-%m-%d %H:%M:%S'))
                player.s_nextdaygift = int(time1) + 86400

                self.checkHasReward(player)

        elif msg == MSG_PLAYER_ONLINE or msg == MSG_PLAYER_DAY_CHANGED:
            player = param0
            if "s_nextdaygift" not in player.__dict__:
                player.s_nextdaygift = 0        #0 = 未到领取等级 -1=已经领取 unixtime=可以领取时间
            curTime = int(time.time())
            if player.s_nextdaygift > 0 and player.s_nextdaygift <= curTime:
                self.notifyActReward(player, True)

    def getMenu(self, player, npcID):
        return []

ModuleID = 32
Instance = NextDayGift(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_LEVELUP,
    MSG_PLAYER_DAY_CHANGED,
])
