#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

MONEY       = 1
GOLDMONEY   = 2

class Festivalgift(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        self.mID = moduleID
        self.mRewards = {}
    def getName(self):
        return "Festivalgift"

    def getInfo(self, player):
        info = {}
        infodata = []
        for actId in self.mRewards:
            actData = self.mRewards[actId]
            actName = actData[0]
            consuItem = actData[1]
            getItem   = actData[2]
            iconstr   = actData[3]
            desc      = actData[4]
            actInfo = []
            for item in consuItem:
                if len(item) == 3:
                    itemtype = item[0]
                    itemId   = item[1]
                    itemNum  = item[2]
                    pitemNum = player.getItemNum(itemtype, itemId)
                    actInfo.append((itemtype, itemId, itemNum, pitemNum))
                elif len(item) == 2:
                    resId = item[0]
                    resNum = item[1]
                    presNum = 0
                    if resId == MONEY:
                        presNum = player.getMoney()
                    elif resId == GOLDMONEY:
                        presNum = player.getGoldMoney()
                    actInfo.append((resId, resNum, presNum))
            infodata.append((actId, actName, actInfo, getItem, iconstr, desc)) # 活动id 消耗材料列表  获得材料列表 icon  描述
        info["rewards"] = infodata
        info["starttime"] = self.mBeginTime
        info["endtime"] = self.mEndTime
        return json.dumps(info)

    def doAction(self, player, actData):
        jsonData = json.loads(actData)
        actId = int(jsonData["actId"])
        if actId in self.mRewards:
            actData = self.mRewards[actId]
            consuData = actData[1]
            getData = actData[2]
            if self.canAddAllReward(player, getData):
                hasEnough = False
                for item in consuData:
                    if self.checkHasEnough(player, item):
                        hasEnough = True
                    else:
                        hasEnough = False
                        break
                if hasEnough:
                    for reward in consuData:
                        self.removeReward(player, reward)
                    for reward in getData:
                        self.addReward(player, reward)
                    return Err_Ok
                else:
                    return Err_NotEnoughMaterial
            else:
                return Err_NotEnoughSpace
        else:
            return Err_Unknown


    def loadConfig(self, path):
        syslog("Loading Festivalgift config...")
        rewards = "%srewards.txt" %(path)
        tb = TabFile()
        if tb.load(rewards):
            rewards = {}
            for i in xrange(tb.mRowNum):
                activityID = tb.get(i, 0, 0, True)
                activityName = tb.get(i, 1, "", False).replace("\"", "")
                consustr   = tb.get(i, 2, "", False).replace("\"", "")
                giftstr    = tb.get(i, 3, "", False).replace("\"", "")
                iconstr = tb.get(i, 4, "", False).replace("\"", "")
                desc       = tb.get(i, 5, "", False).replace("\"", "")
                consus = [
                    [int(value) for value in reward.split(",")]
                        for reward in consustr.split(";") if reward and reward.count(',') in (1, 2)
                ]
                gifts = [
                    [int(value) for value in reward.split(",")]
                        for reward in giftstr.split(";") if reward and reward.count(',') in (1, 2)
                ]
                rewards[activityID] = (activityName, consus, gifts, iconstr,desc )
            self.mRewards = rewards
    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

ModuleID = 64
Instance = Festivalgift(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
])
