#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

class OnLineGift(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mGlobalData = {}
        self.mRewards = {}                              #onLineTime:reward
        self.mInitData = [0, 0, [], ]                   #CountTime, AlreadyGet, 

    def isActived(self, player):
        curTime = time.time()
        if curTime >= self.mBeginTime and curTime <= self.mEndTime:
            return True
        return False

    def isShow(self, player):
        count = len(self.mRewards)
        uuid = player.getUUID()
        if len(self.mGlobalData[uuid][2]) < count:
            return True
        return False
    def getName(self):
        return "OnLineGift"

    def getInfo(self, player):
        rewards = []
        uuid = player.getUUID()
        if uuid in self.mGlobalData:
            data = self.mGlobalData[uuid]
            curTime = int(time.time())
            onLineTime = curTime - data[0] + data[1]
            for t in self.mRewards:
                canGetReward = False
                alreadyGet = False
                timeLeft = 0
                if t in data[2]:
                    alreadyGet = True
                    continue;
                if onLineTime >= t:
                    canGetReward = True
                else:
                    timeLeft = t - onLineTime

                rewards.append((
                    t,
                    self.mRewards[t],
                    canGetReward,
                    alreadyGet,
                    timeLeft,
                ))
                
        info = {}
        info["Rewards"] = rewards

        return json.dumps(info)

    def doAction(self, player, actData):
        uuid = player.getUUID()
        if uuid in self.mGlobalData:
            data = self.mGlobalData[uuid]
            actData = json.loads(actData)
            level = actData["Get"]
            onLineTime = int(time.time()) - data[0] + data[1]
            if level in self.mRewards:
                if level not in data[2]:
                    if onLineTime >= level:
                        rewards = self.mRewards[level]
                        if self.canAddAllReward(player, rewards):
                            for reward in rewards:
                                self.addReward(player, reward)
                            data[2].append(level)
                            return Err_Ok
                        else:
                            return Err_NotEnoughSpace
                    else:
                        return Err_Cannot
                else:
                    return Err_Repetition
            else:
                return Err_Invalid
        else:
            return Err_Cannot

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)

        syslog("Loading OnLineGift config...")

        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = {}
            for i in xrange(tb.mRowNum):

                level           = tb.get(i, 0, 0, True)
                rewardstr = tb.get(i, 1, "", False).replace("\"", "")

                extrareward = [
                    [int(value) for value in reward.split(",")]
                        for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2)
                ]                

                if level in rewards:
                    syserr("OnLineGift Reward level %s already exists." % (level))
                    return False
                else:
                    rewards[level] = extrareward

            self.mRewards = rewards
            return True

        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False

    def checkHasReward(self, player):
        hasReward = False
        uuid = player.getUUID()
        if uuid in self.mGlobalData:
            data = self.mGlobalData[uuid]
            for level in self.mRewards:
                if level <= data[1] and level not in data[2]:
                    hasReward = True
                    break

        self.notifyActReward(player, hasReward)

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

            self.mGlobalData = MMain.getSetting("onlinegift")
            if not self.mGlobalData:
                self.mGlobalData = {}            #playerUUID:[loginTime,playedTime,[],]

        elif msg == MSG_PLAYER_ONLINE:
            player = param0
            uuid = player.getUUID()
            if uuid in self.mGlobalData:
                data = self.mGlobalData[uuid]
                data[0] = int(time.time())
            else:
                self.mGlobalData[uuid] = copy.deepcopy(self.mInitData)
                data = self.mGlobalData[uuid]
                data[0] = int(time.time())

            self.checkHasReward(player)

        elif msg == MSG_PLAYER_OFFLINE:
            player = param0
            uuid = player.getUUID()
            if uuid in self.mGlobalData:
                data = self.mGlobalData[uuid]
                data[1] += int(time.time()) - data[0]

        elif msg == MSG_DAY_CHANGED:
            self.mGlobalData = {}

        elif msg == MSG_PLAYER_DAY_CHANGED:
            player = param0
            uuid = player.getUUID()
            if uuid in self.mGlobalData:
                data = self.mGlobalData[uuid]
                data[0] = int(time.time())
            else:
                self.mGlobalData[uuid] = copy.deepcopy(self.mInitData)
                data = self.mGlobalData[uuid]
                data[0] = int(time.time())

        elif msg == MSG_TIME_MINUTE:
            curTime = time.time()
            curLTime = time.localtime(curTime)
            if (curLTime.tm_min % 5) == 1:
                MMain.setSetting("onlinegift", self.mGlobalData)      

    def getMenu(self, player, npcID):
        return []

ModuleID = 30
Instance = OnLineGift(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_OFFLINE,
    MSG_DAY_CHANGED,
    MSG_PLAYER_DAY_CHANGED,
    MSG_TIME_MINUTE,
])
