#coding=utf8

import MItem
import MMain
import item

class ItemPetSkill(item.Item):
    def __init__(self):
        item.Item.__init__(self)

    def canUse(self, player):
        if self.getID() > 0:
            skillID = self.getID()
            if MMain.getSkillName(skillID):
                return True
            else:
                return False
        else:
            return False

    def doUse(self, player):
        levelLimitation = self.getLevelLimitation()
        if player.getLevel() >= levelLimitation:
            pet = player.getPet()
            if pet:
                skillID = self.getID()
                petSkillID = pet.getSkillID()

                if skillID != petSkillID:
                    pet.setSkillID(skillID)

                    skillName = MMain.getSkillName(skillID)
                    MMain.sendBoxMessage(player, GlobalStrings[3] % (skillName))

                    self.changeNum(-1)
                    return True
                else:
                    MMain.sendCenterMessage(player, GlobalStrings[4])
            else:
                MMain.sendCenterMessage(player, GlobalStrings[5])
        else:
            MMain.sendCenterMessage(player, GlobalStrings[2])

        return False
        
item.gItemMgr.register(MItem.ItemType.PetSkill, ItemPetSkill)