#coding=utf8
import engine
import MMain
import sys
import time
import json
import random
import bisect
import copy
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

OPENGUILDLEVEL = 3
OPENGUILDNUM = 1
LEFTTIME = 10
GUILDINPIRE = 50
PERSONINPIRE = 20
GUILDINPIRELV = 20
PERSONINPIRELV = 20

STARTTIME =510
ENDTIME =1380

class GuildFire(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        self.mID = moduleID
        self.mOpenStatus = True#False
        self.mGlobalData = {}   # {guildName:[全体鼓舞(0,1),{memeberName:[个人鼓舞(0,1),轮次,剩余次数,积分,[],积分]}
        self.mStartTime = 0
        self.mFireData = {}
        self.mRankInitData = []
        self.mScoreInitData = {}
        self.mRewards = []
        self.mRank = {}
        self.mGuildRank = [[],[],]

    def getName(self):
        return "guildfire"

    def isActived(self, player):
        return True
        
    def getInfo(self, player):
        info = {}
        curTime = time.time()
        t = time.localtime(curTime)
        curMTime = t.tm_min + t.tm_hour * 60
        openTime = self.mStartTime
        playerName = player.getName()
        guildName = player.getGuildName()
        myGuild = MMain.getGuildByName(guildName)
        if myGuild:
            guildMember = myGuild.getMember(playerName)
            if guildMember:
                if True:#curTime - openTime >= 7 * 24 * 60 * 60:
                    if myGuild.getLevel() >= OPENGUILDLEVEL:
                        if curMTime >= STARTTIME and curMTime <= ENDTIME:
                            joinGuilds = self.mGlobalData
                            info["Result"] = 0
                            info["fightTime"] = (STARTTIME, ENDTIME)
                            if guildName in joinGuilds:
                                guildData = joinGuilds[guildName]
                                info["guildData"] = [guildData[0],guildData[2]]
                                if playerName not in guildData[1]:
                                    fightdata = self.randThreeFightPlayer(player, 1)
                                    guildData[1][playerName] = [0,1,LEFTTIME,0,fightdata,0]
                                info["playerdata"] = guildData[1][playerName]
                            else:
                                fightdata = self.randThreeFightPlayer(player, 1)
                                joinGuilds[guildName] = [0,{playerName:[0,1,LEFTTIME,0,fightdata,0]},0]
                                info["guildData"] = [0,0]
                                info["playerdata"] = [0,1,LEFTTIME,0,fightdata,0]
                            info["initdata"] = (GUILDINPIRE,GUILDINPIRELV,PERSONINPIRE, PERSONINPIRELV )
                            if guildName in self.mRank:
                                info["personrank"] = self.mRank[guildName]
                            else:
                                info["personrank"] = [[],[],]
                            info["guildrank"] = self.mGuildRank
                            info["rankRewards"] = self.mRewards
                            return json.dumps(info)
                        else:
                            message = GlobalStrings[118] % (int(STARTTIME/60),STARTTIME % 60, int(ENDTIME/60), ENDTIME % 60 )
                            return json.dumps({"Result":1,"ResultDesc":message})
                    else:
                        return json.dumps({"Result":2,"ResultDesc":GlobalStrings[119]}) 
                else:
                    return json.dumps({"Result":2,"ResultDesc":GlobalStrings[120]}) 
        return  json.dumps({"Result":-1,"ResultDesc":GlobalStrings[121]})   
       
    def InspireGuild(self, player):
        playerName = player.getName()
        guildName = player.getGuildName()
        joinGuilds = self.mGlobalData
        guild = MMain.getGuildByName(guildName)
        if guild:
            guildMember = guild.getMember(playerName)
            if guildMember:
                post = guildMember.getPost()
                if post == 5 or post == 4:
                    if guildName in joinGuilds:
                        if player.getGoldMoney() >= GUILDINPIRE:
                            player.addGoldMoney(-GUILDINPIRE)
                            MMain.dbLogActivityUseGoldMoney(player, self.mID, GUILDINPIRE)
                            joinGuilds[guildName][0] = 1
                            return json.dumps({"Result":0,"type":"guildinpire","ResultDesc":GlobalStrings[122]})
                        else:
                            return json.dumps({"Result":1,"type":"guildinpire","ResultDesc":GlobalStrings[74]})
        return json.dumps({"Result":-1,"type":"guildinpire","ResultDesc":GlobalStrings[121]})

    def InspirePerson(self, player):
        playerName = player.getName()
        guildName = player.getGuildName()
        globaldata = self.mGlobalData
        guild = MMain.getGuildByName(guildName)
        if guild:
            guildMember = guild.getMember(playerName)
            if guildMember:
                if guildName in globaldata:
                    guildData = globaldata[guildName]
                    if playerName in guildData[1]:
                        if player.getGoldMoney() >= PERSONINPIRE:
                            player.addGoldMoney(-PERSONINPIRE)
                            MMain.dbLogActivityUseGoldMoney(player, self.mID, PERSONINPIRE)
                            playerData = guildData[1][playerName]
                            playerData[0] = 1
                            return json.dumps({"Result":0,"type":"personinpire","ResultDesc":GlobalStrings[122]})
                        else:
                            return json.dumps({"Result":1,"type":"personinpire","ResultDesc":GlobalStrings[74]})
        return json.dumps({"Result":-1,"type":"personinpire","ResultDesc":GlobalStrings[121]})

    def calFireData(self):
        AllArenaData = MMain.getAllArenaData()
        self.mFireData = {}
        for data in AllArenaData:
            rank = data[1] + 1
            step = 0
            for rankdata in self.mRankInitData:
                if rank >= rankdata[1] and rank <= rankdata[2]:
                    step = rankdata[0]
                    break
            if step != 0:
                if step in self.mFireData:
                    self.mFireData[step].append(data[0])
                else:
                    self.mFireData[step] = [data[0],]
        for i in xrange(1,13):
            if i not in self.mFireData:
                self.mFireData[i] = []

    def randThreeFightPlayer(self, player, turn):
        result = []
        fireData = self.mFireData
        fdLength = len(fireData)
        if fdLength != 12:
            self.calFireData()
        for i in xrange(3):
            step = 13 - turn - i
            length = len(fireData[step])
            guildinpire = 0
            personinpire = 0 
            if length > 0:
                randNum = random.randint(1,length) - 1
                targetName = fireData[step][randNum]
                target = MMain.getPlayerByName(targetName)
                if target:
                    targetGuildName = target.getGuildName()
                    if targetGuildName in self.mGlobalData :
                        targetGuildData = self.mGlobalData[targetGuildName]
                        if targetGuildData[0] == 1:
                            guildinpire = 1
                        if targetName in targetGuildData[1]:
                            targetData = targetGuildData[1][targetName]
                            if targetData[0] == 1:
                                personinpire = 1
                    pi = self.getPlayerInfo(target)
                    score = self.mScoreInitData[turn][step]
                    # 公会鼓舞  个人鼓舞  战斗力 衣服id  武器id   积分,状态0，1
                    result.append([targetName, guildinpire, personinpire, pi[0], pi[1], pi[2], pi[3], score, 0])
            else:
                playerGuildName = player.getGuildName()
                playerName = player.getName()
                if playerGuildName in self.mGlobalData :
                    playerGuildData = self.mGlobalData[playerGuildName]
                    if playerGuildData[0] == 1:
                        guildinpire = 1
                    if playerName in playerGuildData[1]:
                        playerData = playerGuildData[1][playerName]
                        if playerData[0] == 1:
                            personinpire = 1
                pi = self.getPlayerInfo(player)
                score = self.mScoreInitData[turn][step]
                # 公会鼓舞  个人鼓舞  战斗力 衣服id  武器id ,角色 积分,状态0，1
                result.append([playerName, guildinpire, personinpire, pi[0], pi[1], pi[2], pi[3], score, 0])
        return result
    def getPlayerInfo(self, player):
        job = player.getTopRole()
        rolelist = player.getRoleList()
        weponid = 0
        clothid = 0 
        for role in rolelist:
            if role.getJob() == job:
                wepon = role.getEquipment(0)
                cloth = role.getEquipment(1)
                if wepon:
                    weponid = wepon.getID()
                if cloth:
                    clothid = cloth.getID()
        battlePoint = player.getBattlePoint()
        return (battlePoint, clothid, weponid, job)

    def calFightData(self, player, fightStatus, targetName, step):
        playerName = player.getName()
        guildName = player.getGuildName()
        if guildName in self.mGlobalData:
            guildData = self.mGlobalData[guildName]
            if playerName in guildData[1]:
                playerData = guildData[1][playerName]
                targetData = playerData[4][step]
                if targetName in targetData:
                    score = targetData[7]
                    targetStatus = targetData[8]
                    if targetStatus == 0:
                        if playerData[2] > 0:
                            if fightStatus == 1:
                                playerData[1]= 10 if 10 < playerData[1] + 1 else playerData[1] + 1
                                playerData[2] -= 1
                                playerData[3] += score
                                playerData[4] = self.randThreeFightPlayer(player, playerData[1])
                                guildData[2] += score

                                if guildName in self.mRank:
                                    guildPRank = self.mRank[guildName]    
                                    if playerName in guildPRank[1]:
                                        oldIdx = guildPRank[1].index(playerName)
                                        del guildPRank[0][oldIdx]
                                        del guildPRank[1][oldIdx]
                                    newIdx = bisect.bisect_right(guildPRank[0], playerData[3])
                                    guildPRank[0].insert(newIdx, playerData[3])
                                    guildPRank[1].insert(newIdx, playerName)
                                else:
                                    guildPRank = [[],[],]
                                    if guildPRank[0]:
                                        if playerName in guildPRank[1]:
                                            oldIdx = guildPRank[1].index(playerName)
                                            del guildPRank[0][oldIdx]
                                            del guildPRank[1][oldIdx]
                                        newIdx = bisect.bisect_right(guildPRank[0], playerData[3])
                                        guildPRank[0].insert(newIdx, playerData[3])
                                        guildPRank[1].insert(newIdx, playerName)
                                    else:
                                        guildPRank[0] = [playerData[3], ]
                                        guildPRank[1] = [playerName, ]
                                    self.mRank[guildName] = guildPRank
                                MMain.setSetting("personRank",self.mRank)
                                if self.mGuildRank[0]:
                                    if guildName in self.mGuildRank[1]:
                                        oldIdx = self.mGuildRank[1].index(guildName)
                                        del self.mGuildRank[0][oldIdx]
                                        del self.mGuildRank[1][oldIdx]
                                    newIdx = bisect.bisect_right(self.mGuildRank[0], guildData[2])
                                    self.mGuildRank[0].insert(newIdx, guildData[2])
                                    self.mGuildRank[1].insert(newIdx, guildName)
                                else:
                                    self.mGuildRank[0] = [guildData[2], ]
                                    self.mGuildRank[1] = [guildName, ]
                                MMain.setSetting("guildRank",self.mGuildRank)
                                message = GlobalStrings[123] % (score)
                                MMain.dbLogGuildArena(player, 1, score, playerData[3], guildData[2])
                                return json.dumps({"Result":0,"type":"fight","ResultDesc":message})
                            else:
                                playerData[2] -= 1
                                targetData[8] = 1
                                MMain.dbLogGuildArena(player, 0, 0, playerData[3], guildData[2])
                                return json.dumps({"Result":0,"type":"fight","ResultDesc":GlobalStrings[124]})
                        else:
                            return json.dumps({"Result":2,"type":"fight","ResultDesc":GlobalStrings[125]})
                    else:
                        return json.dumps({"Result":1,"type":"fight","ResultDesc":GlobalStrings[126]})
        return  json.dumps({"Result":-1,"type":"fight","ResultDesc":GlobalStrings[121]})

    def calFightRewards(self):
        guildRank = self.mGuildRank[1]
        lenGuildRank = len(guildRank)
        for guildName in guildRank:
            index = self.mGuildRank[1].index(guildName)
            rank = lenGuildRank - index
            if rank == 1:
                message = GlobalStrings[127] %(guildName)
                MMain.sendHorseMessage(message)
            #计算排名奖励
            resReward   = []
            itemReward  = []
            guildReward = 0
            for rewardInit in self.mRewards:
                if rank >= rewardInit[0] and rank < rewardInit[1]:
                    guildReward = rewardInit[3]
                    guildBattle = rewardInit[4]
                    for reward in rewardInit[2]:
                        if len(reward) == 2:
                            resReward.append(reward)
                        elif len(reward) == 3:
                            itemReward.append(reward)
            if guildName in self.mGlobalData:
                guildData = self.mGlobalData[guildName]          
                for playerName in guildData[1]:
                    print playerName,guildName
                    guild = MMain.getGuildByName(guildName)
                    if guild:
                        guild.addBattle(guildBattle)
                        guildMember = guild.getMember(playerName)
                        if guildMember:
                            guildMember.addMeritorious(guildReward)
                            guild.updatePost()
                    mail = {}
                    mail["RecvUUID"] = ""
                    mail["RecvName"] = playerName
                    mail["CreateTime"] = int(time.time())
                    mail["ValidTime"] = mail["CreateTime"] + 86400 * 3
                    mail["Head"] = GlobalStrings[128]
                    body = GlobalStrings[129] %(rank)
                    mail["Body"] = body
                    mail["Res"] = resReward
                    mail["Items"] = itemReward
                    MMain.sendMail(mail)
        self.mRank = {}
        self.mGuildRank = [[],[],]
        self.mFireData = {}
        self.mGlobalData = {}
        MMain.setSetting("personRank",self.mRank)
        MMain.setSetting("guildRank", self.mGuildRank)
        MMain.setSetting("guildfireData",self.mGlobalData)
    def doAction(self, player, actData):
        curTime = time.time()
        t = time.localtime(curTime)
        curMTime = t.tm_min + t.tm_hour * 60
        openTime = self.mStartTime
        if curMTime >= STARTTIME and curMTime <= ENDTIME:
            jdata = json.loads(actData)
            if jdata["type"] == "guildinpire":
                return self.InspireGuild(player)

            elif jdata["type"] == "personinpire":
                return self.InspirePerson(player)

            elif jdata["type"] == "fight":
                status = jdata["status"]
                targetName = jdata["targetName"]
                step = jdata["step"]
                if isinstance(targetName, unicode):
                    targetName = targetName.encode('utf-8')
                elif isinstance(targetName, int):
                    targetName = '%s'%(targetName)
                if step > 2 or step <0:
                    return json.dumps({"Result":3,"type":"fight","ResultDesc":GlobalStrings[130]})
                return self.calFightData(player, int(status), targetName, int(step))
                
            elif jdata["type"] == "reset":
                guildName = player.getGuildName()
                playerName = player.getName()
                if guildName in self.mGlobalData:
                    guildData = self.mGlobalData[guildName]
                    if playerName in guildData[1]:
                        playerData = guildData[1][playerName]
                        if playerData[5] == 0:
                            playerData[1] = 1
                            playerData[2] = LEFTTIME
                            playerData[4] = self.randThreeFightPlayer(player, playerData[1])
                            playerData[5] = 1
                            return json.dumps({"Result":0,"type":"reset","ResultDesc":GlobalStrings[131]})
                        else:
                            return json.dumps({"Result":1,"type":"reset","ResultDesc":GlobalStrings[132]})
            return json.dumps({"Result":-1,"type":"reset","ResultDesc":GlobalStrings[121]})
        else:
            return json.dumps({"Result":1,"ResultDesc":GlobalStrings[58]})

    def loadConfig(self, path):
        rankconfig = "%srankconfig.txt" %(path)
        scoreconfig = "%sscoreconfig.txt" %(path)
        rewardsfile = "%srewards.txt" %(path)

        tb = TabFile()   
        if tb.load(rankconfig):
            rankdata = []
            for i in xrange(tb.mRowNum):
                step      = tb.get(i, 0, 0, True)
                startRank = tb.get(i, 1, 0, True)
                endRank   = tb.get(i, 2, 0, True)
                rankdata.append((step, startRank, endRank))
            self.mRankInitData = rankdata
        else:
            syslog("Loading GuildFire config failed!")
            return False
        tb = TabFile() 
        if tb.load(scoreconfig):
            scoreData = {}
            for i in xrange(tb.mRowNum):
                turn    = tb.get(i, 0, 0, True)
                step1   = tb.get(i, 1, 0, True)
                data1   = tb.get(i, 2, 0, True)
                step2   = tb.get(i, 3, 0, True)
                data2   = tb.get(i, 4, 0, True)
                step3   = tb.get(i, 5, 0, True)
                data3   = tb.get(i, 6, 0, True)
                scoreData[turn] = {step1:data1,step2:data2,step3:data3}
            self.mScoreInitData = scoreData
        else:
            syslog("Loading GuildFire config failed!")
            return False
        tb = TabFile() 
        if tb.load(rewardsfile):
            rewards = []
            for i in xrange(tb.mRowNum):
                start       = tb.get(i, 0, 0, True)
                end         = tb.get(i, 1, 0, True)
                strrewards  = tb.get(i, 2, "", False).replace("\"", "")
                guildreward = tb.get(i, 3, 0, True)
                guildbattle = tb.get(i, 4, 0, True)
                lreward = [
                    [int(value) for value in reward.split(",")]
                        for reward in strrewards.split(";") if reward and reward.count(',') in (1, 2)
                ]
                rewards.append((start, end, lreward, guildreward, guildbattle))
            self.mRewards = rewards
            return True
        else:
            syslog("Loading GuildFire config failed!")
            return False

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerGuildActivity(self.mID, self)
            self.loadConfig("settings/guild/activity/guildfire/")
            # 获取开服时间
            startTime = MMain.getSetting("starttime")
            if startTime:
                self.mStartTime = startTime
            else:
                self.mStartTime = self.getZerotimestamp()
                MMain.setSetting("starttime", self.mStartTime)

            personRank = MMain.getSetting("personRank")
            if personRank:
                self.mRank = personRank
            else:
                self.mRank = {}
            guildRank = MMain.getSetting("guildRank")
            if guildRank:
                self.mGuildRank = guildRank
            else:
                self.mGuildRank = [[],[],]

            guildfireData = MMain.getSetting("guildfireData")
            if guildfireData:
                self.mGlobalData = guildfireData
            else:
                self.mGlobalData = {}
            # 初始化竞技场数据
            self.calFireData()

        elif msg == MSG_TIME_MINUTE:
            CurTime = time.time()
            t = time.localtime(CurTime)
            CurMTime = t.tm_hour * 60 + t.tm_min

            if CurMTime == 540 or CurMTime == 735 or CurMTime == 795 or CurMTime == 1095 or CurMTime == 1155 or CurMTime == 1215 or CurMTime == 1275 or CurMTime == 1335:
                message = GlobalStrings[133]
                MMain.sendHorseMessage(message)
            elif CurMTime == 1410:
                self.calFightRewards()
            elif CurMTime == 420:
                self.calFireData()   #活动准备期 取数据
            if CurMTime % 5 == 3:
                MMain.setSetting("guildfireData", self.mGlobalData)
        elif msg == MSG_PLAYER_ONLINE:
            player = param0
            hasReward = False
            curTime = time.time()
            t = time.localtime(curTime)
            curMTime = t.tm_min + t.tm_hour * 60
            openTime = self.mStartTime
            #if (curTime - openTime >= 7 * 24 * 60 * 60 ) and (curMTime >= STARTTIME and curMTime <= ENDTIME):
            if curMTime >= STARTTIME and curMTime <= ENDTIME:
                playerName = player.getName()
                guildName = player.getGuildName()
                guild = MMain.getGuildByName(guildName)
                if guild:
                    if guild.getLevel() >= 3:
                        if guildName in self.mGlobalData:
                            guildData = self.mGlobalData[guildName]
                            if playerName in guildData[1]:
                                playerData = guildData[1][playerName]
                                if playerData[5] == 0:
                                    hasReward = True
                                for targetData in playerData[4]:
                                    if targetData[8] == 0 and playerData[2] > 0:
                                        hasReward = True
                                        break
                            else:
                                hasReward = True
                        else:
                            hasReward = True
            if hasReward:
                self.notifyActReward(player, True)

ModuleID = 50
Instance = GuildFire(ModuleID)
engine.Instance.register(ModuleID , Instance,[
    MSG_SERVER_STARTUP,
    MSG_TIME_MINUTE,
    MSG_PLAYER_ONLINE,
])
