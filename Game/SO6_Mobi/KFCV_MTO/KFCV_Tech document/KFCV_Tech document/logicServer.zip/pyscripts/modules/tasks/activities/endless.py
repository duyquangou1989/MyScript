#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
import bisect
import pdb
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

OPENLEVEL                   = 20

EL_LEVEL                    = 0
EL_DUNGEON                  = 1
EL_FIRST_SCORE              = 2
EL_SECOND_SCORE             = 3
EL_THIRD_SCORE              = 4
EL_RAID_LEVEL               = 5
EL_RAID_COST                = 6

class Endless(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mGlobal = {}                                                   # playerUUID:{}
        self.mRank = [[], [],]                                              # rankvalue playerName
        self.mEndless = {}                                                  # level  :[]
        self.mDungeon = {}                                                  # dungeonID:level
        self.mRankReward = {}
        self.mShop = {}
        self.mLevellimit = {}

    def isActived(self, player):
        if player.getLevel() >= OPENLEVEL:
            if "s_endless" not in player.__dict__:
                player.s_endless = [0, 0, 0, 0,]
            return True
        else:
            return False

    def getName(self):
        return "Endless"

    def getInfo(self, player):
        if self.isActived(player):
            raid_level = 0
            raid_cost = 0
            cur_level = 0
            cur_cost = 0
            nextLevel = -1
            nextDungeonID = -1 
            if player.s_endless[1] in self.mEndless:
                rel = self.mEndless[player.s_endless[1]]
                raid_level = rel[EL_RAID_LEVEL]
                raid_cost = rel[EL_RAID_COST]
            if player.s_endless[3] in self.mEndless:
                cel = self.mEndless[player.s_endless[3]]
                cur_level = player.s_endless[3]
                cur_cost = cel[EL_RAID_COST]
            if player.s_endless[3] + 1 in self.mEndless:
                nextLevel = player.s_endless[3] + 1
                nextDungeonID = self.mEndless[nextLevel][EL_DUNGEON] 

            rank = self.getRank(player) + 1
            info = {}
            info["Result"] = 1
            info["TotalLevel"] = len(self.mEndless)
            info["TotalScore"] = player.s_endless[0]
            info["MaxLevel"] = player.s_endless[1]
            info["MaxNextLevelScore"] = self.getScore(player, player.s_endless[1] + 1)
            info["MaxLevelTime"] = player.s_endless[2]
            shop = []
            for i in self.mShop:
                shop.append(self.mShop[i])
            info["Shop"] = shop
            info["Rank"] = rank
            info["RankTime"] = 1290
            if rank in self.mRankReward:
                info["RankReward"] = self.mRankReward[rank]
            else:
                info["RankReward"] = []

            info["RaidLevel"] = raid_level
            info["RaidCost"] = raid_cost
            info["Level_1_Score"] = self.getScore(player, 1)
            info["CurLevel"] = cur_level
            info["CurScore"] = self.getScore(player, cur_level)
            info["NextLevel"] = nextLevel
            info["NextScore"] = self.getScore(player, nextLevel)
            info["NextDungeonID"] = nextDungeonID
            info["Msg"] = self.getRankMsg()
            return json.dumps(info)
        else:
            return Err_NotOpen

    def getRankMsg(self):
        result = []
        for i in xrange(len(self.mRank[0])):
            playerName = self.mRank[1][i]
            level = 10000 - int(self.mRank[0][i] / 1000)
            time = self.mRank[0][i] % 1000
            result.append((playerName, level, time))
        return result

    def getRank(self, player):
        if player.getName() in self.mRank[1]:
            return self.mRank[1].index(player.getName())
        return -1

    def setHis(self, player, level):
        playerUUID = player.getUUID()
        if level in self.mEndless:
            if playerUUID not in self.mGlobal:
                self.mGlobal[playerUUID] = {}
            his = self.mGlobal[playerUUID]
            if level in his:
                his[level] += 1
            else:
                his[level] = 1

    def getScore(self, player, level):
        if level in self.mEndless:
            if player.getUUID() in self.mGlobal:
                his = self.mGlobal[player.getUUID()]
                if level in his:
                    num = his[level]
                    if num == 0:
                        return self.mEndless[level][EL_FIRST_SCORE]
                    elif num == 1:
                        return self.mEndless[level][EL_SECOND_SCORE]
                    elif num == 2:
                        return self.mEndless[level][EL_THIRD_SCORE]
                else:
                    return self.mEndless[level][EL_FIRST_SCORE]
            else:
                return self.mEndless[level][EL_FIRST_SCORE]
        return 0

    def doAction(self, player, actData):
        if self.isActived(player):
            if "s_endless" not in player.__dict__:
                player.s_endless = [0, 0, 0, 0,]                #score,  level, time, curlevel

            data = json.loads(actData)
            actionType = data["Action"]
            if actionType == "buy":
                uid = data["Uid"]
                if uid in self.mShop:
                    realReward = self.mShop[uid][2]
                    cost = self.mShop[uid][1]
                    if player.s_endless[0] >= cost:
                        if self.canAddReward(player, realReward):
                            player.s_endless[0] -= cost
                            self.addReward(player, realReward)
                            
                            player.saveToDB()
                            return json.dumps({
                                "Result": 1,
                                "ResultDesc": "",
                                "Action": "buy",
                                "Uid": uid,
                                "Reward": realReward,
                            })

                        else:
                            return Err_NotEnoughSpace
                    else:
                        return Err_NotEnoughRes

            elif actionType == "raid":
                maxLevel = player.s_endless[1]
                if maxLevel in self.mEndless:
                    endless = self.mEndless[maxLevel]
                    raid_level = endless[EL_RAID_LEVEL]
                    raid_cost = endless[EL_RAID_COST]
                    if player.getGoldMoney() >= raid_cost:
                        player.addGoldMoney(-raid_cost)
                        MMain.dbLogActivityUseGoldMoney(player, self.mID, raid_cost)
                        totalScore = 0
                        for i in xrange(raid_level):
                            level = i + 1
                            player.s_endless[3] = level
                            totalScore += self.getScore(player, level)
                            self.setHis(player, level)

                        player.s_endless[0] += totalScore

                        return json.dumps({
                            "Result": 1,
                            "ResultDesc": "",
                            "Action": "raid",
                            "Score": totalScore,
                            "TotalScore": player.s_endless[0],
                        })
                    else:
                        return Err_NotEnoughGoldMoney

        else:
            return Err_NotOpen

    def loadConfig(self, path):
        endlessFilename = "%sendless.txt" % (path)
        rankFilename = "%srank.txt" % (path)
        shopFilename = "%sshop.txt" % (path)
        endlesslimitFilename = "%sendlesslimit.txt" % (path)

        syslog("Loading Endless config...")

        tb = TabFile()
        if tb.load(endlessFilename):
            rewards = {}
            dungeons = {}
            for i in xrange(tb.mRowNum):
                offset = 0;

                level = tb.get(i, EL_LEVEL, 0, True)
                dungeon = tb.get(i, EL_DUNGEON, 0, True)
                first = tb.get(i, EL_FIRST_SCORE, 0, True)
                second = tb.get(i, EL_SECOND_SCORE, 0, True)
                third = tb.get(i, EL_THIRD_SCORE, 0, True)
                raid_level = tb.get(i, EL_RAID_LEVEL, 0, True)
                raid_cost = tb.get(i, EL_RAID_COST, 0, True)

                if level in rewards:
                    syserr("Endless config level %s already exists." % (level))
                    return False
                else:
                    rewards[level] = [level, dungeon, first, second, third, raid_level, raid_cost,]
                    dungeons[dungeon] = level

            self.mEndless = rewards
            self.mDungeon = dungeons

        else:
            syserr("Load %s failed." % (endlessFilename))
            return False

        tb = TabFile()
        if tb.load(rankFilename):
            rewards = {}
            for i in xrange(tb.mRowNum):
                offset = 0;

                rank = tb.get(i, 0, 0, True)
                rewardstr = tb.get(i, 1, "", False)

                extrareward = [
                    [int(value) for value in reward.split(",")]
                        for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2)
                ]

                if rank in rewards:
                    syserr("Endless config rank %s already exists." % (rank))
                    return False
                else:
                    rewards[rank] = extrareward

            self.mRankReward = rewards
        else:
            syserr("Load %s failed." % (rankFilename))
            return False

        tb = TabFile()
        if tb.load(shopFilename):
            rewards = {}
            for i in xrange(tb.mRowNum):
                offset = 0;

                uid = tb.get(i, 0, 0, True)
                score = tb.get(i, 1, 0, True)
                rewardstr = tb.get(i, 2, "", False)

                extrareward = [
                    [int(value) for value in reward.split(",")]
                        for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2)
                ]

                if uid in rewards:
                    syserr("Endless config uid %s already exists." % (uid))
                    return False
                else:
                    rewards[uid] = [uid, score, extrareward[0],]

            self.mShop = rewards

        else:
            syserr("Load %s failed." % (shopFilename))
            return False

        tb = TabFile()
        if tb.load(endlesslimitFilename):
            levellimit = {}
            for i in xrange(tb.mRowNum):
                offset = 0;

                plevel = tb.get(i, 0, 0, True)
                emaxlevel = tb.get(i, 1, 0, True)

                levellimit[plevel] = emaxlevel

            self.mLevellimit = levellimit

        else:
            syserr("Load %s failed." % (endlesslimitFilename))
            return False

        return True

    def checkHasReward(self, player):
        pass

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)
            
            rank = MMain.getSetting("endless")
            if rank:
                self.mRank = rank
            else:
                self.mRank = [[], [],]

            his = MMain.getSetting("endlesshis")
            if his:
                self.mGlobal = his
            else:
                self.mGlobal = {}

        elif msg == MSG_DAY_CHANGED:
            self.mGlobal = {}
            
        elif msg == MSG_PLAYER_DAY_CHANGED:
            player = param0

            if self.isActived(player):
                if "s_endless" not in player.__dict__:
                    player.s_endless = [0, 0, 0, 0,]

        elif msg == MSG_TIME_MINUTE:
            MMain.setSetting("endlesshis", self.mGlobal)
            
            curTime = time.time()
            curLTime = time.localtime(curTime)
            curMinute = curLTime.tm_hour * 60 + curLTime.tm_min
            if curMinute == 1290:
                for i in xrange(len(self.mRank[1])):
                    name = self.mRank[1][i]
                    rewards = self.mRankReward[i + 1]
                    mail = {}
                    mail["RecvUUID"] = ""
                    mail["RecvName"] = name
                    mail["CreateTime"] = int(time.time())
                    mail["ValidTime"] = mail["CreateTime"] + 86400 * 3
                    mail["Head"] = ""
                    mail["Body"] = GlobalStrings[35] % (i + 1)
                    res = []
                    items = []
                    for reward in rewards:
                        if len(reward) == 2:
                            res.append(reward)
                        elif len(reward) == 3:
                            items.append(reward)
                    mail["Res"] = res
                    mail["Items"] = items
                    MMain.sendMail(mail)
                self.mRank = [[], [],]      

        elif msg == MSG_PLAYER_FINISH_DUNGEON:
            player = param0
            dungeon, star, costTime = param1
            playerName = player.getName()
            if costTime > 600:
                costTime = 600
            if self.isActived(player):
                dungeonID = dungeon.getID()
                dungeonType = int(dungeonID / 10000)
                if dungeonType == 5:
                    if dungeonID in self.mDungeon:
                        level = self.mDungeon[dungeonID]
                        emaxlevel = 30
                        if player.getLevel() in self.mLevellimit:
                            emaxlevel = self.mLevellimit[player.getLevel()]
                        if level <= emaxlevel:
                            player.s_endless[3] = level
                            player.s_endless[0] += self.getScore(player, level)
                            self.setHis(player, level)
                            if level > player.s_endless[1]:
                                player.s_endless[1] = level
                                player.s_endless[2] = costTime
                            elif level == player.s_endless[1]:
                                if costTime < player.s_endless[2]:
                                    player.s_endless[2] = costTime

                            rankValue = (10000 - player.s_endless[1]) * 1000 + player.s_endless[2]
                            if self.mRank[0]:
                                if playerName in self.mRank[1]:
                                    oldIdx = self.mRank[1].index(playerName)
                                    oldValue = self.mRank[0][oldIdx]
                                    if oldValue > rankValue:
                                        ##update
                                        del self.mRank[0][oldIdx]
                                        del self.mRank[1][oldIdx]
                                        newIdx = bisect.bisect_right(self.mRank[0], rankValue)
                                        self.mRank[0].insert(newIdx, rankValue)
                                        self.mRank[1].insert(newIdx, playerName)
                                        MMain.setSetting("endless", self.mRank)
                                else:
                                    newIdx = bisect.bisect_right(self.mRank[0], rankValue)
                                    self.mRank[0].insert(newIdx, rankValue)
                                    self.mRank[1].insert(newIdx, playerName)
                                    if len(self.mRank[0]) > 100:
                                        self.mRank[0].pop()
                                        self.mRank[1].pop()
                                    MMain.setSetting("endless", self.mRank)

                            else:
                                self.mRank[0] = [rankValue, ]
                                self.mRank[1] = [player.getName(), ]
                                MMain.setSetting("endless", self.mRank)

    def getMenu(self, player, npcID):
        return []

ModuleID = 34
Instance = Endless(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_DAY_CHANGED,
    MSG_TIME_MINUTE,
    MSG_PLAYER_DAY_CHANGED,
    MSG_PLAYER_FINISH_DUNGEON,
])
