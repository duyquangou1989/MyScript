#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
import bisect
import pdb
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

WEIGHT1 = 1  # 权重1的商品个数
WEIGHT2 = 1
WEIGHT3 = 1
WEIGHT4 = 1
WEIGHT5 = 1

INDEX_IDX               = 0
INDEX_REWARD_VALUE      = 1
INDEX_WEIGHT            = 2
INDEX_RATE              = 3
INDEX_ORDER_RATE        = 4
INDEX_LIMIT_LEVEL       = 5

INFO_INDEX              = 0
INFO_COST               = 1
INFO_REWARD             = 2
INFO_USED               = 3

class DungeonCard(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        
        self.mID = moduleID

        self.mTableDatas = {}                ##cardID:[]
        self.mCommon = {}
        self.mPrice = [0, 10, 20, 30, 40,]
        self.mTempleCard = {}               ##playeruuid:[card order]

        engine.Instance.registerTextProtocol("C2S_DungeonCard", self.onProtocol)

    def getName(self):
        return "DungeonCard"
        
    def isOpened(self):
        return True

    def buildInitData(self, player, commID):
        result = []
        rewardlist = []
        playerLevel = player.getLevel()
        playerUUID = player.getUUID()
        tempCardOrder = []
        tempCardList = []
        tempCardBase = 0

        randomlist1 = []
        randomlist2 = []
        randomlist3 = []
        randomlist4 = []
        randomlist5 = []
        randomitem1 = []
        randomitem2 = []
        randomitem3 = []
        randomitem4 = []
        randomitem5 = []
        randbase1 = 0
        randbase2 = 0
        randbase3 = 0
        randbase4 = 0
        randbase5 = 0
        if commID in self.mCommon:
            cardID = self.mCommon[commID]
        else:
            cardID = 0

        if cardID in self.mTableDatas:
            rewards = self.mTableDatas[cardID]
            for reward in rewards:
                if reward[INDEX_LIMIT_LEVEL] <= playerLevel:
                    if reward[INDEX_WEIGHT] == 1:                        
                        randbase1 += reward[INDEX_RATE]
                        randomlist1.append(randbase1)
                        randomitem1.append(reward)
                    if reward[INDEX_WEIGHT] == 2:
                        randbase2 += reward[INDEX_RATE]
                        randomlist2.append(randbase2)
                        randomitem2.append(reward)
                    if reward[INDEX_WEIGHT] == 3:
                        randbase3 += reward[INDEX_RATE]
                        randomlist3.append(randbase3)
                        randomitem3.append(reward)
                    if reward[INDEX_WEIGHT] == 4:
                        randbase4 += reward[INDEX_RATE]
                        randomlist4.append(randbase4)
                        randomitem4.append(reward)
                    if reward[INDEX_WEIGHT] == 5:
                        randbase5 += reward[INDEX_RATE]
                        randomlist5.append(randbase5)
                        randomitem5.append(reward)

            # weight 1
            for i in xrange(WEIGHT1):
                thisrand = random.randint(0, randbase1)
                idx = bisect.bisect_left(randomlist1, thisrand)
                randitem = randomitem1[idx]

                tempCardBase += randitem[INDEX_ORDER_RATE]
                tempCardList.append(tempCardBase)
                tempCardOrder.append(randitem)
            # weight 2
            for i in xrange(WEIGHT2):
                thisrand = random.randint(0, randbase2)
                idx = bisect.bisect_left(randomlist2, thisrand)
                randitem = randomitem2[idx]

                tempCardBase += randitem[INDEX_ORDER_RATE]
                tempCardList.append(tempCardBase)
                tempCardOrder.append(randitem)          
            # weight 3
            for i in xrange(WEIGHT3):
                thisrand = random.randint(0, randbase3)
                idx = bisect.bisect_left(randomlist3, thisrand)
                randitem = randomitem3[idx]

                tempCardBase += randitem[INDEX_ORDER_RATE]
                tempCardList.append(tempCardBase)
                tempCardOrder.append(randitem)
            # weight 4
            for i in xrange(WEIGHT4):
                thisrand = random.randint(0, randbase4)
                idx = bisect.bisect_left(randomlist4, thisrand)
                randitem = randomitem4[idx]

                tempCardBase += randitem[INDEX_ORDER_RATE]
                tempCardList.append(tempCardBase)
                tempCardOrder.append(randitem)          
            # weight 5
            for i in xrange(WEIGHT5):
                thisrand = random.randint(0, randbase5)
                idx = bisect.bisect_left(randomlist5, thisrand)
                randitem = randomitem5[idx]

                tempCardBase += randitem[INDEX_ORDER_RATE]
                tempCardList.append(tempCardBase)
                tempCardOrder.append(randitem)

            for i in xrange(5):
                thisrand = random.randint(0, tempCardBase)
                idx = bisect.bisect_left(tempCardList, thisrand)
                randitem = tempCardOrder[idx]

                result.append([i, self.mPrice[i], randitem[INDEX_REWARD_VALUE], False,])
                rewardlist.append(randitem[INDEX_REWARD_VALUE])
                
                tempCardBase = 0
                tempCardOrder.pop(idx)
                tempCardList = []
                for itr in tempCardOrder:
                    tempCardBase += itr[INDEX_ORDER_RATE]
                    tempCardList.append(tempCardBase)

            self.mTempleCard[playerUUID] = result
        return rewardlist

    def getInfo(self, player):
        playerUUID = player.getUUID()
        if playerUUID not in self.mTempleCard:
            data = []
        else:
            data = self.mTempleCard[playerUUID]
        
        info = {}
        info["Rewards"] = data
        return json.dumps({
            "Result": 1,
            "ResultDesc": "",
            "Action": "info",
            "Info": info,
        })

    def initCardReward(self, player, commID):
        return self.buildInitData(player, commID)

    def doAction(self, player, actData):
        if not self.isOpened():
            return Err_NotOpen

        data = json.loads(actData)
        playerUUID = player.getUUID()

        actionType = data["Action"]
        if actionType == "buy":
            index = data["Index"]
            if playerUUID in self.mTempleCard:
                pdata = self.mTempleCard[playerUUID]
                if index >= 0 and index < len(pdata):
                    reward = pdata[index]
                    if not reward[INFO_USED]:
                        if player.getGoldMoney() < reward[INFO_COST]:
                            return Err_NotEnoughGoldMoney
                        realReward = reward[INFO_REWARD]
                        if self.canAddReward(player, realReward):
                            player.addGoldMoney(-reward[INFO_COST])
                            MMain.dbLogActivityUseGoldMoney(player, self.mID, reward[INFO_COST])

                            self.addReward(player, realReward)
                            reward[INFO_USED] = True

                            return json.dumps({
                                "Result": 1,
                                "ResultDesc": "",
                                "Action": "buy",
                                "Reward": realReward,
                            })

                        else:
                            player.addGoldMoney(-reward[INFO_COST])
                            MMain.dbLogActivityUseGoldMoney(player, self.mID, reward[INFO_COST])
                            mail = {}
                            mail["RecvUUID"] = ""
                            mail["RecvName"] = player.getName()
                            mail["CreateTime"] = int(time.time())
                            mail["ValidTime"] = int(time.time()) + 86400 * 3
                            mail["Head"] = ""
                            mail["Body"] = GlobalStrings[9]
                            mail["Items"] = []
                            mail["Res"] = []
                            if len(realReward) == 3:
                                mail["Items"] = [realReward,]
                            elif len(realReward) == 2:
                                mail["Res"] = [realReward,]
                            
                            MMain.sendMail(mail)
                            reward[INFO_USED] = True
                            return json.dumps({
                                "Result": 1,
                                "ResultDesc": "",
                                "Action": "buy",
                                "Reward": realReward,
                            })
                    else:
                        return Err_Used
                else:
                    return Err_Unknown
            else:
                return Err_Unknown

        elif actionType == "info":
            return self.getInfo(player)

        elif actionType == "over":
            if playerUUID in self.mTempleCard:
                del self.mTempleCard[playerUUID]
            return Err_Ok
        else:
            return Err_Unknown

    def onProtocol(self, player, data):
        result = self.doAction(player, data[0])

        response = (result, )
        MMain.sendTextProtocol(player, "S2C_DungeonCard", response)

    def loadConfig(self, path):
        rewardFilename = "%scommonReward.txt" % (path)
        tb = TabFile()   
        if tb.load(rewardFilename):
            for i in xrange(tb.mRowNum):

                commRewardID                                    = tb.get(i, 0, 0, True)
                cardID                                          = tb.get(i, 8, 0, True)
                
                if cardID:
                    self.mCommon[commRewardID] = cardID
                if cardID and cardID not in self.mTableDatas:
                    cardfile = "settings/assistLoot/%s.txt" % (cardID)

                    cardtb = TabFile()
                    if cardtb.load(cardfile):
                        tables = []
                        for j in xrange(cardtb.mRowNum):

                            idx                     = cardtb.get(j, INDEX_IDX, 0, True)
                            rewardValue             = cardtb.get(j, INDEX_REWARD_VALUE, "", False).replace("\\n", "\n").replace("\"", "")
                            weight                  = cardtb.get(j, INDEX_WEIGHT, 0, True)
                            rate                    = cardtb.get(j, INDEX_RATE, 0, True)
                            orderRate               = cardtb.get(j, INDEX_ORDER_RATE, 0, True)
                            limitLevel              = cardtb.get(j, INDEX_LIMIT_LEVEL, 0, True)
                            
                            tmpItem = []
                            tmpBlocks = rewardValue.split(";")
                            if tmpBlocks:
                                itemBlocks = tmpBlocks[0].split(",")
                                if len(itemBlocks) == 3:
                                    tmpItem = (
                                        int(itemBlocks[0]),
                                        int(itemBlocks[1]),
                                        int(itemBlocks[2]),
                                    )
                                elif len(itemBlocks) == 2:
                                    tmpItem = (
                                        int(itemBlocks[0]),
                                        int(itemBlocks[1]),
                                    )

                            rewardValue = tmpItem

                            tables.append((
                                idx,
                                rewardValue,
                                weight,
                                rate,
                                orderRate,
                                limitLevel,
                            ))

                        self.mTableDatas[cardID] = tables
        else:
            syserr("Loading %s failed." % (rewardFilename))
            return False
        return True

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            self.loadConfig("settings/assistLoot/")
            syslog("Loading DungeonCard config...")

        elif msg == MSG_PLAYER_LEAVE_DUNGEON:
            player = param0
            playerUUID = player.getUUID()
            if playerUUID in self.mTempleCard:
                del self.mTempleCard[playerUUID]
   
    def getMenu(self, player, npcID):
        return []

ModuleID = 19
Instance = DungeonCard(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_LEAVE_DUNGEON,
])
