#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *
import dailyactivity
from traceback import print_exc
import math

LIMIT_LEVEL                 = 0
LIMIT_VIPLEVEL              = 1
LIMIT_NUM                   = 2
LIMIT_GLOBAL_NUM            = 3
LIMIT_VIP_NUM               = 4

DATA_INDEX_MALL_TYPE        = 0
DATA_INDEX_UUID             = 1
DATA_INDEX_SORT_INDEX       = 2
DATA_INDEX_VALUE            = 3
DATA_INDEX_PRICE            = 4
DATA_INDEX_PRICE_OFF        = 5
DATA_INDEX_BEGIN_TIME       = 6
DATA_INDEX_END_TIME         = 7
DATA_INDEX_LIMITS           = 8
DATA_INDEX_CLASS            = 9

MALL_TYPE_NORMAL            = 0
MALL_TYPE_WRAP              = 1
MALL_TYPE_VIP               = 2
MALL_TYPE_OFF               = 3
MALL_TYPE_FIND              = 4
MALL_TYPE_COUNT             = 5

class Mall(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        
        self.mID = moduleID
        self.mServerLimitation = {}
        self.mPlayerLimitation = {}
        self.mCommodities = [{}, {}, {}, {}, {},]
        self.mLimits = {}
        self.mMallName = [
            "Normal",
            "Wrap",
            "Vip",
            "Off",
            "Find",
        ]

        self.mLimitationModified = False
        self.HasDiscount = False
        engine.Instance.registerTextProtocol("C2S_Mall", self.onProtocol)

    def getCommoditySortIndex(self, commodity):
        # if len(commodity) > DATA_INDEX_SORT_INDEX:
        #     return commodity[DATA_INDEX_SORT_INDEX]
        # else:
        #     return 0
        return 0
            
    def getCommodityClass(self, commodity):
        if len(commodity) > DATA_INDEX_CLASS:
            return commodity[DATA_INDEX_CLASS]
        else:
            return ""

    def getCommodities(self, mallType, isGM = False):
        if mallType >= 0 and mallType < len(self.mCommodities):
            result = []
            modified = False

            curTime = time.time()

            mall = self.mCommodities[mallType]
            commodities = []
            for uuid in mall.keys():
                commodity = mall[uuid]
                if isGM or commodity[DATA_INDEX_BEGIN_TIME] == -1 or (curTime >= commodity[DATA_INDEX_BEGIN_TIME] and curTime <= commodity[DATA_INDEX_END_TIME]):
                    isOk = True
                    if uuid in self.mServerLimitation:
                        if self.mServerLimitation[uuid] <= 0:
                            isOk = False
                    if isOk:
                        commodities.append((self.getCommoditySortIndex(commodity), commodity))
                    else:
                        del mall[uuid]
                        if uuid in self.mServerLimitation:
                            del self.mServerLimitation[uuid]
                        for playerUUID in self.mPlayerLimitation:
                            playerLimits = self.mPlayerLimitation[playerUUID]
                            if uuid in playerLimits:
                                del playerLimits[uuid]
                        modified = True

            commodities.sort()
            tmpCommodities = []
            for commodity in commodities:
                tmpCommodities.append(commodity[1])

            result = tmpCommodities

            if modified:
                MMain.setSetting("MallC", self.mCommodities)
                MMain.setSetting("MallSL", self.mServerLimitation)
                MMain.setSetting("MallPL", self.mPlayerLimitation)

            return result
        else:
            return []

    def addCommodity(self, commodity):
        mallType = commodity[DATA_INDEX_MALL_TYPE]
        if mallType >= 0 and mallType < len(self.mCommodities):
            coUUID = commodity[DATA_INDEX_UUID]

            beginTime = commodity[DATA_INDEX_BEGIN_TIME]
            endTime = commodity[DATA_INDEX_END_TIME]

            blTime = time.localtime(beginTime)
            beginTime = time.mktime((
                blTime.tm_year,
                blTime.tm_mon,
                blTime.tm_mday,
                blTime.tm_hour,
                blTime.tm_min,
                0, 0, 0, 0,
            ))

            elTime = time.localtime(endTime)
            endTime = time.mktime((
                elTime.tm_year,
                elTime.tm_mon,
                elTime.tm_mday,
                elTime.tm_hour,
                elTime.tm_min,
                0, 0, 0, 0,
            ))

            commodity[DATA_INDEX_BEGIN_TIME] = beginTime
            commodity[DATA_INDEX_END_TIME] = endTime
            
            self.mCommodities[mallType][coUUID] = commodity
            return True
        else:
            syserr("Mall type %s is invalid." % (mallType))
            return False

    def getInfo(self, player):
        
        realInfo = []
        playerUUID = player.getUUID()
        playerLimits = {}
        if playerUUID in self.mPlayerLimitation:
            playerLimits = self.mPlayerLimitation[playerUUID]
        else:
            self.mPlayerLimitation[playerUUID] = playerLimits

        playerLevel = player.getLevel()
        playerVipLevel = player.getVipLevel()
        discountNum = 0
        for mallType in xrange(len(self.mCommodities)):
            coTemp = self.getCommodities(mallType)
            commodities = []
            info = {}
            for commodity in coTemp:
                coValue = commodity[DATA_INDEX_VALUE]
                coSortIndex = commodity[DATA_INDEX_SORT_INDEX]
                coPrice = commodity[DATA_INDEX_PRICE]
                coPriceOff = commodity[DATA_INDEX_PRICE_OFF]
                coBeginTime = commodity[DATA_INDEX_BEGIN_TIME]
                coEndTime = commodity[DATA_INDEX_END_TIME]
                coLimits = commodity[DATA_INDEX_LIMITS]
                coUUID = commodity[DATA_INDEX_UUID]
                coClass = self.getCommodityClass(commodity)
                if coPriceOff != -1:
                    discountNum += 1
                coRealLimits = []
                for limit in coLimits:
                    limitType = limit[0]
                    limitValue = limit[1]
                    MaxlimitValue = limit[1]
                    if limitType == LIMIT_GLOBAL_NUM:
                        if coUUID in self.mServerLimitation:
                            limitValue = self.mServerLimitation[coUUID]
                        else:
                            self.mServerLimitation[coUUID] = limitValue

                    elif limitType == LIMIT_NUM:
                        if coUUID in playerLimits:
                            limitValue = playerLimits[coUUID]
                        else:
                            playerLimits[coUUID] = limitValue

                    elif limitType == LIMIT_VIP_NUM:
                        if coUUID in playerLimits:
                            limitValue = playerLimits[coUUID]
                        else:
                            limitValue = self.mLimits[limit[1]][playerVipLevel]
                            playerLimits[coUUID] = limitValue
                        MaxlimitValue = self.mLimits[limit[1]][playerVipLevel]
                    coRealLimits.append((
                        limitType,
                        limitValue,
                        MaxlimitValue,
                    ))

                commodities.append((
                    coValue,
                    coPrice,
                    coPriceOff,
                    coBeginTime,
                    coEndTime,
                    coRealLimits,
                    coUUID,
                    coSortIndex,
                    coClass,
                ))
            if discountNum > 0:
                self.HasDiscount = True
            else:
                self.HasDiscount = False
            info["CurTime"] = int(time.time())
            info["MallType"] = mallType
            info["Commodities"] = commodities
            info["GoldMoney"] = player.getGoldMoney()
            realInfo.append(info)
        return realInfo

    def handlePlayerBuy(self, player, mallType, coUUID , coNum):
        if mallType >= 0 and mallType < len(self.mCommodities) and coNum > 0:
            mall = self.mCommodities[mallType]
            coUUID = int(coUUID)
            if coUUID in mall:
                commodity = mall[coUUID]

                isOk = True

                playerUUID = player.getUUID()
                playerLimits = {}
                if playerUUID in self.mPlayerLimitation:
                    playerLimits = self.mPlayerLimitation[playerUUID]

                playerLevel = player.getLevel()
                playerVipLevel = player.getVipLevel()

                coValue = commodity[DATA_INDEX_VALUE]
                #coValue = [coValue[0] , coValue[1] , coValue[2] * coNum,]
                coPrice = commodity[DATA_INDEX_PRICE]
                coPriceOff = commodity[DATA_INDEX_PRICE_OFF]
                coBeginTime = commodity[DATA_INDEX_BEGIN_TIME]
                coEndTime = commodity[DATA_INDEX_END_TIME]
                coLimits = commodity[DATA_INDEX_LIMITS]
                coUUID = commodity[DATA_INDEX_UUID]
                coSortIndex = commodity[DATA_INDEX_SORT_INDEX]
                coClass = self.getCommodityClass(commodity)

                for limit in coLimits:
                    limitType = limit[0]
                    limitValue = limit[1]

                    if limitType == LIMIT_LEVEL:
                        if player.getLevel() < limitValue:
                            MMain.sendBoxMessage(player, GlobalStrings[39])
                            isOk = False
                            break

                    elif limitType == LIMIT_VIPLEVEL:
                        if player.getVipLevel() < limitValue:
                            MMain.sendBoxMessage(player, GlobalStrings[40])
                            response = [
                                "mallFailed",
                                mallType,
                                2,
                            ]
                            MMain.sendTextProtocol(player, "S2C_Mall", response)
                            isOk = False
                            return

                    elif limitType == LIMIT_NUM:
                        if coUUID in playerLimits:
                            if playerLimits[coUUID] - coNum < 0:
                                MMain.sendBoxMessage(player, GlobalStrings[41])
                                isOk = False
                                break

                    elif limitType == LIMIT_GLOBAL_NUM:
                        if coUUID in self.mServerLimitation:
                            if self.mServerLimitation[coUUID] - coNum < 0:
                                MMain.sendBoxMessage(player, GlobalStrings[42])
                                isOk = False
                                break

                    elif limitType == LIMIT_VIP_NUM:
                        if coUUID in playerLimits:
                            if playerLimits[coUUID] - coNum < 0:
                                MMain.sendBoxMessage(player, GlobalStrings[43])
                                isOk = False
                                break

                if isOk:
                    curTime = time.time()
                    if coBeginTime == -1 or (curTime >= coBeginTime and curTime <= coEndTime):

                        isPriceOk = False
                        coRealPrice = coPrice * coNum
                        if coPriceOff > 0:
                            coRealPrice = coPriceOff * coNum
                        if player.getGoldMoney() >= coRealPrice:
                            isPriceOk = True

                        if isPriceOk:
                            goods = [coValue[0],coValue[1],coValue[2] * coNum]
                            if self.canAddReward(player, goods):
                                player.addGoldMoney(-coRealPrice)
                                MMain.dbLogActivityUseGoldMoney(player, self.mID, coRealPrice)

                                self.addReward(player, goods)

                                isSoldOut = False
                                coRealLimits = []
                                for limit in coLimits:
                                    limitType = limit[0]
                                    limitValue = limit[1]
                                    MaxlimitValue = limit[1]
                                    if limitType == LIMIT_NUM:
                                        if coUUID in playerLimits:
                                            playerLimits[coUUID] -= coNum
                                        else:
                                            playerLimits[coUUID] = limitValue - coNum

                                        limitValue = playerLimits[coUUID]

                                        self.mPlayerLimitation[playerUUID] = playerLimits
                                        self.mLimitationModified = True

                                    elif limitType == LIMIT_GLOBAL_NUM:
                                        if coUUID in self.mServerLimitation:
                                            self.mServerLimitation[coUUID] -= coNum
                                        else:
                                            self.mServerLimitation[coUUID] = limitValue - coNum

                                        limitValue = self.mServerLimitation[coUUID]

                                        self.mLimitationModified = True

                                        if limitValue <= 0:
                                            isSoldOut = True

                                    elif limitType == LIMIT_VIP_NUM:
                                        if coUUID in playerLimits:
                                            playerLimits[coUUID] -= coNum
                                        else:
                                            playerLimits[coUUID] = self.mLimits[limit[1]][playerVipLevel] - coNum

                                        limitValue = playerLimits[coUUID]
                                        MaxlimitValue = self.mLimits[limit[1]][playerVipLevel]
                                        self.mPlayerLimitation[playerUUID] = playerLimits
                                        self.mLimitationModified = True

                                    coRealLimits.append((
                                        limitType,
                                        limitValue,
                                        MaxlimitValue,
                                    ))

                                coLeft = []
                                coLeft = (
                                    coValue,
                                    coPrice,
                                    coPriceOff,
                                    coBeginTime,
                                    coEndTime,
                                    coRealLimits,
                                    coUUID,
                                    coSortIndex,
                                    coClass
                                )
                                response = [
                                    "mallSuccess",
                                    mallType,
                                    json.dumps({
                                        "Commodity": coLeft
                                    })
                                ]
                                MMain.sendTextProtocol(player, "S2C_Mall", response)

                            else:
                                MMain.sendBoxMessage(player, GlobalStrings[7])

                                response = [
                                    "mallFailed",
                                    mallType,
                                    0,
                                ]
                                MMain.sendTextProtocol(player, "S2C_Mall", response)

                        else:
                            MMain.sendBoxMessage(player, GlobalStrings[44])

                            response = [
                                "mallFailed",
                                mallType,
                                1,
                            ]
                            MMain.sendTextProtocol(player, "S2C_Mall", response)
                    else:
                        MMain.sendBoxMessage(player, GlobalStrings[45])

                        response = [
                            "mallFailed",
                            mallType,
                            0,
                        ]
                        MMain.sendTextProtocol(player, "S2C_Mall", response)
                else:
                    response = [
                        "mallFailed",
                        mallType,
                        0,
                    ]
                    MMain.sendTextProtocol(player, "S2C_Mall", response)
            else:
                MMain.sendBoxMessage(player, GlobalStrings[46])

                response = [
                    "mallFailed",
                    mallType,
                    0,
                ]
                MMain.sendTextProtocol(player, "S2C_Mall", response)
        else:
            MMain.sendBoxMessage(player, GlobalStrings[47])

            response = [
                "mallFailed",
                mallType,
                0,
            ]
            MMain.sendTextProtocol(player, "S2C_Mall", response)

    def onProtocol(self, player, data):
        action = data[0]

        if action == "mallType":
            result = []
            for i in xrange(MALL_TYPE_COUNT):
                commodities = self.getCommodities(i)
                if len(commodities) > 0:
                    result.append((
                        i,
                        self.mMallName[i],
                    ))

            response = [
                "mallType",
                json.dumps({"MallTypes": result}),
            ]
            MMain.sendTextProtocol(player, "S2C_Mall", response)

        elif action == "mall":
           # mallType = data[1]

            response = [
                "mall",
                json.dumps({"Mall": self.getInfo(player)})
            ]
            MMain.sendTextProtocol(player, "S2C_Mall", response)

        elif action == "buy":
            mallType = data[1]
            coUUID = data[2]
            coNum = data[3]

            self.handlePlayerBuy(player, mallType, coUUID , coNum)

    def loadConfig(self, path):
        cofilename = "%scommodities.txt" % (path)
        limitfilename = "%smallviplimit.txt" % (path)

        syslog("Loading Mall config...")

        tb = TabFile()
        if tb.load(cofilename):
            for i in xrange(tb.mRowNum):
                coMallType = tb.get(i, DATA_INDEX_MALL_TYPE, 0, True)
                coUUID = tb.get(i, DATA_INDEX_UUID, 0, True)
                coSortIndex = tb.get(i, DATA_INDEX_SORT_INDEX, 0, True)
                coValue = tb.get(i, DATA_INDEX_VALUE, "", False).replace("\"", "")
                coPrice = tb.get(i, DATA_INDEX_PRICE, 0, True)
                coPriceOff = tb.get(i, DATA_INDEX_PRICE_OFF, 0, True)
                coBeginTime = MMain.buildTime(tb.get(i, DATA_INDEX_BEGIN_TIME, "", False).replace("\"", ""))
                coEndTime = MMain.buildTime(tb.get(i, DATA_INDEX_END_TIME, "", False).replace("\"", ""))
                coLimits = tb.get(i, DATA_INDEX_LIMITS, "", False).replace("\"", "")
                coClass = ""

                reward = []
                tmpBlocks = coValue.split(";")
                for tmpBlock in tmpBlocks:
                    itemBlocks = tmpBlock.split(",")
                    if len(itemBlocks) == 3:
                        reward = (
                            int(itemBlocks[0]),
                            int(itemBlocks[1]),
                            int(itemBlocks[2]),
                        )
                    if len(itemBlocks) == 2:
                        reward = (
                            int(itemBlocks[0]),
                            int(itemBlocks[1]),
                            )
                coValue = reward

                tmpLimits = []
                tmpBlocks = coLimits.split(";")
                for tmpBlock in tmpBlocks:
                    limitBlocks = tmpBlock.split(",")
                    if len(limitBlocks) == 2:
                        tmpLimits.append((
                            int(limitBlocks[0]),
                            int(limitBlocks[1]),
                        ))
                coLimits = tmpLimits

                commodity = [
                    coMallType,
                    coUUID,
                    coSortIndex,
                    coValue,
                    coPrice,
                    coPriceOff,
                    coBeginTime,
                    coEndTime,
                    coLimits,
                    0,
                    coClass,
                ]

                self.addCommodity(commodity)
                
        else:
            syserr("Load %s failed." % (cofilename))
            return False

        tb = TabFile()
        if tb.load(limitfilename):
            for i in xrange(tb.mRowNum):
                limitid = tb.get(i, 0, 0, True)
                vip0 = tb.get(i, 1, 0, True)
                vip1 = tb.get(i, 2, 0, True)
                vip2 = tb.get(i, 3, 0, True)
                vip3 = tb.get(i, 4, 0, True)
                vip4 = tb.get(i, 5, 0, True)
                vip5 = tb.get(i, 6, 0, True)
                vip6 = tb.get(i, 7, 0, True)
                vip7 = tb.get(i, 8, 0, True)
                vip8 = tb.get(i, 9, 0, True)
                vip9 = tb.get(i, 10, 0, True)
                vip10 = tb.get(i, 11, 0, True)
                vip11 = tb.get(i, 12, 0, True)
                vip12 = tb.get(i, 13, 0, True)
                vip13 = tb.get(i, 14, 0, True)
                vip14 = tb.get(i, 15, 0, True)
                vip15 = tb.get(i, 16, 0, True)

                limit = [vip0, vip1, vip2, vip3, vip4, vip5, vip6, vip7, vip8, vip9, vip10, vip11, vip12, vip13, vip14, vip15,]

                self.mLimits[limitid] = limit
                
        else:
            syserr("Load %s failed." % (limitfilename))
            return False

        return True

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)
            
            serverLimitation = MMain.getSetting("MallSL")
            playerLimitation = MMain.getSetting("MallPL")

            if serverLimitation:
                self.mServerLimitation = serverLimitation
            if playerLimitation:
                self.mPlayerLimitation = playerLimitation          

        elif msg == MSG_DAY_CHANGED:
            self.mServerLimitation = {}
            self.mPlayerLimitation = {}
        elif msg == MSG_PLAYER_ONLINE:
            player = param0
            response= []
            if self.HasDiscount:
                response = ["hasdiscount",1]
            else:
                response = ["hasdiscount",0]
            MMain.sendTextProtocol(player, "S2C_Mall", response)
            
        elif msg == MSG_PLAYER_VIPLEVEL_CHANGED:
            player = param0
            oldVipLevel = param1
            playerVipLevel = player.getVipLevel()
            playerUUID = player.getUUID()
            
            if playerUUID in self.mPlayerLimitation:
                playerLimits = self.mPlayerLimitation[playerUUID]
                mall = self.mCommodities[MALL_TYPE_VIP]
                for uuid in mall.keys():
                    if uuid in playerLimits:
                        commodity = mall[uuid]
                        coLimits = commodity[DATA_INDEX_LIMITS]
                        for limit in coLimits:
                            limitType = limit[0]
                            limitValue = limit[1]
                            if limitType == LIMIT_VIP_NUM:
                                limitValue = self.mLimits[limit[1]][playerVipLevel]
                                oldMax = self.mLimits[limit[1]][oldVipLevel]
                                add = limitValue - oldMax

                        playerLimits[uuid] += add

    def getMenu(self, player, npcID):
        return []


ModuleID = 23
Instance = Mall(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,

    MSG_DAY_CHANGED,
    MSG_PLAYER_VIPLEVEL_CHANGED,
    MSG_PLAYER_ONLINE,
])
