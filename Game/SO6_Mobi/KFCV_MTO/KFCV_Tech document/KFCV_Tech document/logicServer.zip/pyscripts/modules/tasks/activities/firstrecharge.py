#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

class FirstRecharge(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID

        self.mRewards = []

    def isActived(self, player):
        return ActivityBase.isActived(self, player)

    def isShow(self, player):
        if "s_Purchased" not in player.__dict__:
            player.s_Purchased = 0
        if player.s_Purchased != 2:
                return True
        return False
        
    def getName(self):
        return "FirstRecharge"

    def getInfo(self, player):
        canGetReward = False
        alreadyGet = False
        if player.s_Purchased == 1:
            canGetReward = True
        elif player.s_Purchased == 2:
            canGetReward = True
            alreadyGet = True

        info = {}
        info["CanGetReward"] = canGetReward
        info["AlreadyGet"] = alreadyGet
        info["Rewards"] = self.mRewards
        info["BeginTime"] = self.mBeginTime
        info["EndTime"] = self.mEndTime

        return json.dumps(info)

    def doAction(self, player, actData):
        if self.isActived(player):
            actData = json.loads(actData)

            if player.s_Purchased == 0:
                return Err_Cannot
            elif player.s_Purchased == 1:
                if self.canAddAllReward(player, self.mRewards):
                    for reward in self.mRewards:
                        self.addReward(player, reward)
                    player.s_Purchased = 2
                    return Err_Ok
                else:
                    return Err_NotEnoughSpace
            elif player.s_Purchased == 2:
                return Err_Repetition
        else:
            return Err_NotOpen

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)
        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = []
            for i in xrange(tb.mRowNum):
                offset = 0;

                rewardstr = tb.get(i, 0, "", False).replace("\"", "")

                extrareward = [
                    [int(value) for value in reward.split(",")]
                        for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2)
                ]

            self.mRewards = extrareward
            return True
        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_ONLINE:
            player = param0
            if "s_Purchased" not in player.__dict__:
                player.s_Purchased = 0
            if player.s_Purchased == 1:
                self.notifyActReward(player, True)

        elif msg == MSG_PLAYER_GOLDMONEY_CHANGED:
            player = param0
            goldMoney, way, productId = param1
            if "s_Purchased" not in player.__dict__:
                player.s_Purchased = 0
            if way == 2:
                if player.s_Purchased == 0:
                    player.s_Purchased = 1
                    self.notifyActReward(player, True)
        elif msg == MSG_PLAYER_LEVELUP:
            player = param0
            if player.getLevel() == 4:
                if "s_Purchased" not in player.__dict__:
                    player.s_Purchased = 0
                if player.s_Purchased != 2:
                    self.notifyActReward(player, False)

    def getMenu(self, player, npcID):
        return []

ModuleID = 14
Instance = FirstRecharge(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_GOLDMONEY_CHANGED,
    MSG_PLAYER_LEVELUP,
])
