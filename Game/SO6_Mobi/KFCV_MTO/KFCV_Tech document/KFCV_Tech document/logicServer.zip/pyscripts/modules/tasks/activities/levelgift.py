#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

class LevelGift(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mRewards = {}                              #level:rewards

    def isActived(self, player):
        return True

    def getName(self):
        return "LevelGift"

    def getInfo(self, player):
        rewards = []
        uuid = player.getUUID()
        playerLevel = player.getLevel()
        if "s_levelgift" not in player.__dict__:
            player.s_levelgift = []
        data = player.s_levelgift
        for level in self.mRewards:
            canGetReward = False
            alreadyGet = False
            if level in data:
                alreadyGet = True
            if playerLevel >= level:
                canGetReward = True

            rewards.append((
                level,
                self.mRewards[level],
                canGetReward,
                alreadyGet,
            ))
                
        info = {}
        info["Rewards"] = rewards

        return json.dumps(info)

    def doAction(self, player, actData):
        if "s_levelgift" not in player.__dict__:
            player.s_levelgift = []
        data = player.s_levelgift

        actData = json.loads(actData)
        level = actData["Get"]
        if player.getLevel() < level:
            return Err_LevelLimitation
            
        if level in self.mRewards:
            if level not in data:
                rewards = self.mRewards[level]
                if self.canAddAllReward(player, rewards):
                    for reward in rewards:
                        self.addReward(player, reward)
                    data.append(level)
                    return Err_Ok
                else:
                    return Err_NotEnoughSpace
            else:
                return Err_Repetition
        else:
            return Err_Invalid

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)
        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = {}
            for i in xrange(tb.mRowNum):

                level           = tb.get(i, 0, 0, True)
                rewardstr     = tb.get(i, 1, "", False).replace("\"", "")

                tmpItems = [
                    [int(value) for value in reward.split(",")]
                        for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2)
                ]

                rewardValue = tmpItems

                if level in rewards:
                    syserr("LevelGift Reward level %s already exists." % (level))
                    return False
                else:
                    rewards[level] = rewardValue

            self.mRewards = rewards
            return True

        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False

    def checkHasReward(self, player):
        hasReward = False
        uuid = player.getUUID()
        playerLevel = player.getLevel()
        for level in self.mRewards:
            if level <= playerLevel and level not in player.s_levelgift:
                hasReward = True
                break

        self.notifyActReward(player, hasReward)

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_ONLINE:
            player = param0
            if "s_levelgift" not in player.__dict__:
                player.s_levelgift = []

            self.checkHasReward(player)

        elif msg == MSG_PLAYER_LEVELUP:
            player = param0
            uuid = player.getUUID()
            playerLevel = player.getLevel()
            if "s_levelgift" not in player.__dict__:
                player.s_levelgift = []
            if playerLevel in self.mRewards and playerLevel not in player.s_levelgift:
                self.checkHasReward(player)

    def getMenu(self, player, npcID):
        return []

ModuleID = 31
Instance = LevelGift(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_LEVELUP,
])
