#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
import bisect
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

class WorldLoot(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mTables = {}
        self.mIndexs = []
        self.mRates = []
        self.mTotalRate = 0

    def getName(self):
        return "WorldLoot"

    def getInfo(self, player):
        result = {}
        return json.dumps(result)

    def doAction(self, player, actData):
        return Err_Ok

    def loadConfig(self, path):
        tasksFilename = "%sworldloot.txt" % (path)
        tb = TabFile()
        if tb.load(tasksFilename):
            tables = {}
            idxs = []
            rates = []
            totalrate = 0
            for i in xrange(tb.mRowNum):
                idx = tb.get(i, 0, 0, True)
                rewardstr = tb.get(i, 1, "", False).replace("\"", "")
                rate = tb.get(i, 2, 0, True)
                taskReward = []
                if rewardstr:
                    taskReward = [
                        [int(value) for value in reward.split(",")]
                            for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2) 
                    ]
                totalrate += rate
                idxs.append(idx)
                rates.append(totalrate)
                tables[idx] = [idx, taskReward[0], rate]
            self.mTables = tables
            self.mIndexs = idxs
            self.mRates = rates
            self.mTotalRate = totalrate
            return True
        else:
            syserr("Load %s failed." % (tasksFilename))
            return False

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_FINISH_DUNGEON:
            player = param0
            if self.isActived(player):
                if self.mTotalRate > 0 and len(self.mRates) > 0 and len(self.mIndexs) > 0 and random.randint(0, 99) < 5:
                    thisrand = random.randint(0, self.mTotalRate - 1)
                    thisidx = bisect.bisect_left(self.mRates, thisrand)
                    idx = self.mIndexs[thisidx]
                    realReward = self.mTables[idx][1]
                    if self.canAddReward(player, realReward):
                        self.addReward(player, realReward)
                        message = GlobalStrings[59] % (self.getRewardDesc(realReward))
                        MMain.sendCenterMessage(player, message)

    def getMenu(self, player, npcID):
        return []

ModuleID = 65
Instance = WorldLoot(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_FINISH_DUNGEON,
])
