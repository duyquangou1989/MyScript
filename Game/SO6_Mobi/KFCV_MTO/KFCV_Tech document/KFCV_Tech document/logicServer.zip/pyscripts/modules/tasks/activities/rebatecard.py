#coding=utf8

import engine
import MMain
import sys
import time
import calendar
import json
import random
import bisect
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

MONTHCARD = "sl_tw_yk_300"
FORERVERCARD = "sl_tw_zsk_2090"

class RebateCard(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        self.mID = moduleID
        self.mRewards = {}

    def getName(self):
        return "RebateCard"
        
    def isActived(self, player):
        return True

    def sendMailToPlayer(self, player, productId, emailType):
        mail = {}
        mail["RecvUUID"] = ""
        mail["RecvName"] = player.getName()
        mail["CreateTime"] = int(time.time())
        mail["ValidTime"] = mail["CreateTime"] + 86400 * 3
        mail["Head"] = ""
        if emailType == 1:
            if productId in self.mRewards:
                baseReward = self.mRewards[productId][0]
                dayReward = self.mRewards[productId][1]
                message = ""
                if productId == MONTHCARD:
                    leftday = (player.s_RCMonthInfo[0] - player.s_RCMonthInfo[1]) / 86400
                    message = GlobalStrings[112] %(dayReward, leftday)
                elif productId == FORERVERCARD:
                    message = GlobalStrings[113]%(dayReward)
                mail["Body"] = message
                mail["Res"] = [(2, dayReward)]
                mail["Items"] = []
        elif emailType == 2:   
            message = ""
            if productId == MONTHCARD:
                leftday = (player.s_RCMonthInfo[0] - player.s_RCMonthInfo[1]) / 86400
                message = GlobalStrings[114] %(leftday)
            elif productId == FORERVERCARD:
                message = GlobalStrings[115]
            mail["Body"] = message
            mail["Res"] = []
            mail["Items"] = []
        MMain.sendMail(mail)

    def doSetOrUpInfo(self, player, productId):
        curTime = int(time.time())
        t = time.localtime(time.time())
        timedayend = int(time.mktime(time.strptime(time.strftime('%Y-%m-%d 23:59:59', t),'%Y-%m-%d %H:%M:%S')))  
        if productId == MONTHCARD:
            sendEmailType = 1
            endTime = timedayend + 29 * 86400
            if "s_RCMonthInfo" not in player.__dict__:
                player.s_RCMonthInfo = [endTime,0]
            elif player.s_RCMonthInfo[0] == -1:
                player.s_RCMonthInfo[0] = endTime
            else:
                player.s_RCMonthInfo[0] +=  30 * 86400
                sendEmailType = 2
            player.addGoldMoney(self.mRewards[productId][0])
            player.s_RCMonthInfo[1] = curTime
            self.sendMailToPlayer(player, productId, sendEmailType)

        elif productId == FORERVERCARD:
            if "s_RCForeverInfo" not in player.__dict__:
                player.s_RCForeverInfo = [curTime,0]
                player.addGoldMoney(self.mRewards[productId][0])
                player.s_RCForeverInfo[1] = curTime
                self.sendMailToPlayer(player, productId, 1)

            elif player.s_RCForeverInfo[0] == -1:
                player.s_RCForeverInfo[0] = endTime
                player.addGoldMoney(self.mRewards[productId][0])
                player.s_RCForeverInfo[1] = curTime
                self.sendMailToPlayer(player, productId, 1)
            else:
                pass
        else:
            pass

    def getInfo(self, player):
        playerdata = []
        if "s_RCMonthInfo" not in player.__dict__:
            leftday = -1
            playerdata.append((300, leftday))
        else:
            monData = player.s_RCMonthInfo
            if monData[0] > monData[1]:
                leftday = (monData[0] - monData[1]) / 86400
            else:
                leftday = -1
            playerdata.append((300, leftday))
        if "s_RCForeverInfo" not in player.__dict__:
            leftday = -1
            playerdata.append((2090, leftday))
        else:
            leftday = 9999
            playerdata.append((2090, leftday))
        rewardInfo = []
        for productId in self.mRewards:
            if productId == MONTHCARD:
                rewardInfo.append((300, self.mRewards[productId][0], self.mRewards[productId][1]))
            elif productId == FORERVERCARD:
                rewardInfo.append((2090, self.mRewards[productId][0], self.mRewards[productId][1]))
        info = {}
        info["playerdata"] = playerdata
        info["rewarddata"] = rewardInfo
        return json.dumps(info)

    def doAction(self, player, actData):
        pass

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)
        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = {}
            for i in xrange(tb.mRowNum):
                rewardType = tb.get(i, 0, "", False).replace("\n", "")
                baseReward = tb.get(i, 1, 0, True)
                dayReward = tb.get(i, 2, 0, True)
                
                rewards[rewardType] = [baseReward,dayReward, ]
            self.mRewards = rewards
        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False
        return True

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
           MMain.registerActivity(self.mID, self)
           
        elif msg == MSG_PLAYER_GOLDMONEY_CHANGED:
            player = param0
            goldMoney = param1[0]
            payWay = param1[1]
            productId = param1[2]
            if payWay == GMCW_Pay:
                if productId == "sl_tw_yk_300" or productId =="sl_tw_zsk_2090":
                    #player.addGoldMoney(-goldMoney)
                    self.doSetOrUpInfo(player, productId)

        elif msg == MSG_PLAYER_ONLINE or msg == MSG_PLAYER_DAY_CHANGED:
            player = param0
            if "s_RCMonthInfo" in player.__dict__:
                monData = player.s_RCMonthInfo
                if monData[0] > monData[1]:
                    last = time.localtime(monData[1])
                    now = time.localtime(time.time())
                    if last.tm_year != now.tm_year or last.tm_mon != now.tm_mon or last.tm_mday != now.tm_mday:
                        player.s_RCMonthInfo[1] = int(time.time())
                        leftday = (monData[0] - monData[1]) / 86400
                        message = GlobalStrings[116] %(leftday)
                        dayReward = self.mRewards[MONTHCARD][1]
                        mail = {}
                        mail["RecvUUID"] = ""
                        mail["RecvName"] = player.getName()
                        mail["CreateTime"] = int(time.time())
                        mail["ValidTime"] = mail["CreateTime"] + 86400 * 7
                        mail["Head"] = ""
                        mail["Body"] = message
                        mail["Res"] = [(2,dayReward)]
                        mail["Items"] = []
                        MMain.sendMail(mail)

            if "s_RCForeverInfo" in player.__dict__:
                feData = player.s_RCForeverInfo
                last = time.localtime(feData[1])
                now = time.localtime(time.time())
                if last.tm_year != now.tm_year or last.tm_mon != now.tm_mon or last.tm_mday != now.tm_mday:
                    player.s_RCForeverInfo[1] = int(time.time())
                    message = GlobalStrings[117]
                    dayReward = self.mRewards[MONTHCARD][1]
                    mail = {}
                    mail["RecvUUID"] = ""
                    mail["RecvName"] = player.getName()
                    mail["CreateTime"] = int(time.time())
                    mail["ValidTime"] = mail["CreateTime"] + 86400 * 7
                    mail["Head"] = ""
                    mail["Body"] = message
                    mail["Res"] = [(2,dayReward)]
                    mail["Items"] = []
                    MMain.sendMail(mail)

    def getMenu(self, player, npcID):
        return []


ModuleID = 35
Instance = RebateCard(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_GOLDMONEY_CHANGED,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_DAY_CHANGED,
])
