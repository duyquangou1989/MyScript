#coding=utf8

from tabfile import TabFile

LevelRankRewards = {
# 城ID	城名字	占用普通奖励	贡献奖励	每日普通奖励	每日贡献奖励
    1 : [GlobalStrings[210], [[GlobalStrings[211]], [GlobalStrings[212]]], GlobalStrings[213], [[GlobalStrings[211]], [GlobalStrings[212]]], GlobalStrings[213]],

# 据点ID	据点名字	占用普通奖励	时间间隔

    2 : [GlobalStrings[214], [], 5, 130000]
}

City_Config = {}
Tower_Config = {}


def LoadCfgs():
    global LevelRankRewards
    global City_Config
    global Tower_Config

    City_Config = LoadCityCfg("settings/guild/activity/guildbattle/city.txt")
    Tower_Config = LoadTowerCfg("settings/guild/activity/guildbattle/tower.txt")

# [
#   [1,100],[2,100]],               # 资源奖励
#   [[3,33020167,1], [4,44310022]   # 道具奖励
# ]
def loadStrToRewards(strTableValue):
    resRewards = []
    itemRewards = []
    strSingle = strTableValue.split(';')
    for str in strSingle:
        if str != "":
            strList = str.split(",")
            strList_n = []
            for strN in strList:
                strList_n.append(int(strN))

            if len(strList) == 2:
                resRewards.append(strList_n)
            elif len(strList) == 3:
                itemRewards.append(strList_n)
            else:
                print("error reward!")

    return [resRewards,itemRewards]


def LoadCityCfg(filename):
    cfg = {}
    tb = TabFile()
    if tb.load(filename):
        for i in xrange(tb.mRowNum):

            cityId = tb.get(i, 0, "", True)
            cityName = tb.get(i, 1, "", False)
            strOccupyAwards = tb.get(i, 2, "", False)
            guildAward = tb.get(i, 3, "", True)
            strDayAwards = tb.get(i, 4, "", False)
            dayGuildAward = tb.get(i, 5, "", True)

            datas = []
            datas.append(cityName)
            resAwards = []
            itemAwards = []
            awards = loadStrToRewards(strOccupyAwards)
            datas.append(awards)
            datas.append(guildAward)
            dayAwards = loadStrToRewards(strDayAwards)
            datas.append(dayAwards)
            datas.append(dayGuildAward)

            cfg[cityId] = datas
    else:
        print("load cfg filded : " + filename)

    return cfg

def LoadTowerCfg(filename):
    cfg = {}
    tb = TabFile()
    if tb.load(filename):
        for i in xrange(tb.mRowNum):

            towerId = tb.get(i, 0, "", True)
            towerName = tb.get(i, 1, "", False)
            strOccupyAwards = tb.get(i, 2, "", False)
            intervalTime = tb.get(i, 3, "", True)
            mapId = tb.get(i, 4, "", True)

            datas = []
            datas.append(towerName)
            awards = []
            strOccupyAward = strOccupyAwards.split(';')
            for str in strOccupyAward:
                if str != "":
                    strList = str.split(",")
                    strList_n = []
                    for strN in strList:
                        strList_n.append(int(strN))

                    awards.append(strList_n)
            datas.append(awards)
            datas.append(intervalTime)
            datas.append(mapId)

            cfg[towerId] = datas

    else:
        print("load cfg filded : " + filename)

    return cfg


LoadCfgs()

