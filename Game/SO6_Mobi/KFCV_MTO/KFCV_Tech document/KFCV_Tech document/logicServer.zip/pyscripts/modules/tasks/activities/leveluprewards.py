#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
import copy
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

RESULT_NOT_ACTIVED = json.dumps({"Result":1, "ResultDesc":GlobalStrings[50]})
RESULT_FINISHED = json.dumps({"Result":2, "ResultDesc":GlobalStrings[219]})
RESULT_NOT_FINISHED = json.dumps({"Result":3, "ResultDesc":GlobalStrings[220]})
RESULT_INDEX_ERROR = json.dumps({"Result":4, "ResultDesc":GlobalStrings[221]})
RESULT_NO_TIME = json.dumps({"Result":5, "ResultDesc":GlobalStrings[222]})
RESULT_BAG_FULL = json.dumps({"Result":6, "ResultDesc":GlobalStrings[223]})

class LevelUpRewards(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID

        self.mRewards = []
        self.mMaxRewards = 0
        self.mInitData = {}

    def isActived(self, player):
        return True

    def getName(self):
        return GlobalStrings[224]

    def getInfo(self, player):
        pdata = self.getPlayerData(player, self.mInitData)
        level = player.getLevel()

        for tmpLevel in pdata:
            info = pdata[tmpLevel]
            if info[0] == 0:
                info[0] = level

        tmpData = []
        curTime = time.time()
        for rewardLevel in self.mRewards:
            rewards = self.mRewards[rewardLevel]

            displayLevel = level

            if rewardLevel in pdata:
                displayLevel = pdata[rewardLevel][0]
                isFinished = (displayLevel >= rewardLevel)
            else:
                isFinished = False

            if isFinished:
                displayLevel = rewardLevel

            isGot = (pdata[rewardLevel][1] == 1)
            desc = GlobalStrings[225] % (displayLevel, rewardLevel)
            oneData = {
                "Level": rewardLevel,
                "CurLevel": displayLevel,
                "IsFinished": isFinished,
                "IsGot": isGot,
                "Rewards": rewards,
                "Desc": desc,
            }

            tmpData.append((rewardLevel, oneData))

        tmpData.sort()
        data = []
        for td in tmpData:
            data.append(td[1])

        return json.dumps({"Rewards":data})

    def doAction(self, player, actData):
        if self.isActived(player):
            pdata = self.getPlayerData(player, {})
            adata = json.loads(actData)

            rewardLevel = adata["Level"]

            if rewardLevel in self.mRewards:
                rewards = self.mRewards[rewardLevel]
                level = player.getLevel()

                if rewardLevel in pdata:
                    if pdata[rewardLevel][1] != 1:
                        if level >= rewardLevel:
                            if self.canAddAllReward(player, rewards):
                                pdata[rewardLevel][1] = 1
                                message = GlobalStrings[172]
                                for reward in rewards:
                                    self.addReward(player, reward)
                                    message += self.getRewardDesc(reward)

                                self.checkHasReward(player)
                                player.saveToDB()
                                return json.dumps({
                                    "Result":0, 
                                    "ResultDesc":message, 
                                    "Level":rewardLevel
                                })
                            else:
                                return RESULT_BAG_FULL
                        else:
                            return RESULT_NOT_FINISHED
                    else:
                        return RESULT_FINISHED
                else:
                    return RESULT_INDEX_ERROR
            else:
                return RESULT_INDEX_ERROR
        else:
            return RESULT_NOT_ACTIVED

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)

        syslog("Loading LevelUpRewards config...")

        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = {}
            initData = {}
            for i in xrange(tb.mRowNum):
                offset = 0;

                level = tb.get(i, 0, 0, True)
                rewardType = tb.get(i, 1, 0, True)
                rewardValue = tb.get(i, 2, "", False).replace("\"", "")

                if rewardType == REWARD_TYPE_ITEM:
                    tmpItems = []
                    tmpBlocks = rewardValue.split(";")
                    for tmpBlock in tmpBlocks:
                        itemBlocks = tmpBlock.split(",")
                        if len(itemBlocks) == 3:
                            tmpItems.append((
                                int(itemBlocks[0]),
                                int(itemBlocks[1]),
                                int(itemBlocks[2]),
                            ))
                    rewardValue = tmpItems
                else:
                    rewardValue = int(rewardValue)

                if level in rewards:
                    rewards[level].append((
                        rewardType,
                        rewardValue,
                    ))
                else:
                    rewards[level] = [(
                        rewardType,
                        rewardValue,
                    ),]

                initData[level] = [0, 0]

            self.mRewards = rewards
            self.mMaxRewards = len(self.mRewards)
            self.mInitData = initData

        else:
            syserr("Loading %s failed." % (rewardsFilename))
            return False

        return True

    def checkHasReward(self, player):
        data = self.getPlayerData(player, self.mInitData)

        level = player.getLevel()

        hasReward = False
        for rewardLevel in self.mRewards:
            if rewardLevel in data:
                if data[rewardLevel][1] != 1:
                    if level >= rewardLevel:
                        hasReward = True
                        break

        self.notifyActReward(player, hasReward)

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_ONLINE:
            player = param0

            if self.isActived(player):
                pdata = self.getPlayerData(player, self.mInitData)
                for level in self.mInitData:
                    if level not in pdata:
                        pdata[level] = copy.deepcopy(self.mInitData[level])

                level = player.getLevel()

                for l in self.mRewards:
                    if l in pdata:
                        pdata[l][0] = level
                    else:
                        pdata[l] = [level, 0]

                self.checkHasReward(player)

        elif msg == MSG_PLAYER_LEVELUP:
            player = param0

            if self.isActived(player):
                level = player.getLevel()

                pdata = self.getPlayerData(player, self.mInitData)
                curTime = time.time()

                for l in self.mRewards:
                    if l in pdata:
                        pdata[l][0] = level
                    else:
                        pdata[l] = [level, 0]

                self.checkHasReward(player)

    def getMenu(self, player, npcID):
        return []

ModuleID = 6
Instance = LevelUpRewards(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,

    MSG_PLAYER_ONLINE,
    MSG_PLAYER_LEVELUP,
])