#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

class AccumulativeLogin5(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mRewards = {}

    def isActived(self, player):
        if ActivityBase.isActived(self, player):
            if "s_accumulativelogin5" not in player.__dict__:
                t = time.localtime(time.time())
                time1 = int(time.mktime(time.strptime(time.strftime('%Y-%m-%d 00:00:00', t),'%Y-%m-%d %H:%M:%S'))) + 86400
                time2 = time1 + 86400
                player.s_accumulativelogin5 = [1, time1, time2, False,]
            return True            
        else:
            return False

    def getName(self):
        return "AccumulativeLogin5"

    def getInfo(self, player):
        if self.isActived(player):
            data = player.s_accumulativelogin5

            info = {}
            info["LoginCount"] = data[0]
            info["gotRewardAlready"] = data[3]
            rewards = []
            for i in self.mRewards:
                rewards.append(self.mRewards[i])
            info["Rewards"] = rewards

            return json.dumps(info)

    def doAction(self, player, actData):
        if self.isActived(player):
            data = player.s_accumulativelogin5

            actData = json.loads(actData)
            day = actData["Get"]
            realrewards = []
            if data[3] == False:
                count = data[0]
                for d in self.mRewards:
                    if count >= d:
                        rewards = self.mRewards[d]
                        for reward in rewards:
                            realrewards.append(reward)

                if self.canAddAllReward(player, realrewards):
                    for realreward in realrewards:
                        self.addReward(player, realreward)
                    data[3] = True
                    return Err_Ok
                else:
                    return Err_NotEnoughSpace
            else:
                return Err_Repetition
        else:
            return Err_NotOpen

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)
        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = {}
            for i in xrange(tb.mRowNum):

                day         = tb.get(i, 0, 0, True)
                rewardstr   = tb.get(i, 1, "", False).replace("\"", "")

                extrareward = [
                    [int(value) for value in reward.split(",")]
                        for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2)
                ]

                rewards[day] = extrareward

            self.mRewards = rewards
            return True
        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False

    def checkHasReward(self, player):
        data = player.s_accumulativelogin5

        if not data[3]:
            self.notifyActReward(player, True)
        else:
            self.notifyActReward(player, False)

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)    

        elif msg == MSG_PLAYER_CREATED:
            player = param0
            self.isActived(player)

        elif msg == MSG_PLAYER_ONLINE or msg == MSG_PLAYER_DAY_CHANGED:
            player = param0

            if self.isActived(player):
                data = player.s_accumulativelogin5
                loginCount = data[0]
                nextTime0 = data[1]
                nextTime1 = data[2]

                curLoginTime = int(time.time())

                if curLoginTime >= nextTime0 and curLoginTime < nextTime1:
                    data[0] += 1
                    if data[0] > 5:
                        data[0] = 5
                    data[1] += 86400
                    data[2] += 86400
                    data[3] = False

                elif curLoginTime >= nextTime1:
                    data[0] = 1
                    t = time.localtime(time.time())
                    time1 = int(time.mktime(time.strptime(time.strftime('%Y-%m-%d 00:00:00', t),'%Y-%m-%d %H:%M:%S'))) + 86400
                    data[1] = time1
                    data[2] = time1 + 86400
                    data[3] = False

                self.checkHasReward(player)

    def getMenu(self, player, npcID):
        return []

ModuleID = 24
Instance = AccumulativeLogin5(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_DAY_CHANGED,
])