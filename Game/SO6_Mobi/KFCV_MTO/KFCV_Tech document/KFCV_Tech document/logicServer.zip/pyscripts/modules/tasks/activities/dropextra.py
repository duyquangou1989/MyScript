#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

class DropExtra(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mExtraRewards = {}

    def isActived(self, player):
        return True

    def getName(self):
        return "DropExtra"

    def doAction(self, player, actData):
        return Err_Ok

    def loadConfig(self, path):
        itemRewardsFileName = "%sitemrewards.txt" %(path)
        syslog("Loading DropExtra config...")
        tb = TabFile()
        if tb.load(itemRewardsFileName):
            sumweight = 0
            for i in xrange(tb.mRowNum):
                quality = tb.get(i, 0, 0, True)
                weight = tb.get(i, 1, 0, True)
                items = tb.get(i,2,"",False)
                listItems = items.split(";")
                tempItem = []
                for item in listItems:
                    data = item.split(",")
                    if len(data) == 2:
                        tempItem.append((
                            int(data[0]),
                            int(data[1])
                            ))
                    elif len(data) == 3:
                        tempItem.append((
                            int(data[0]),
                            int(data[1]),
                            int(data[2])
                            ))
                if quality in self.mExtraRewards:
                    self.mExtraRewards[quality][weight] = tempItem
                else:
                    tempdata = {}
                    tempdata[weight] = tempItem
                    self.mExtraRewards[quality] =tempdata

            return True
        else:
            syserr("Load %s failed." % (itemRewardsFileName))
            return False
                #self.mTime[btime] = etime
    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)
            
        elif msg == MSG_PLAYER_DROP_ITEM:
            player = param0
            itemQuality = param1
            if itemQuality in self.mExtraRewards:
                rewards = self.mExtraRewards[itemQuality]
                randata = random.randint(1,10000)
                for key in rewards:
                    if key == 0:
                        pass
                    elif randata <= key:
                        data = rewards[key]
                        ran = random.randint(0,len(data)-1)
                        item = data[ran]
                        if len(item) == 2:
                            self.addReward(player, item)
                        elif len(item) == 3:
                            if self.canAddReward(player, item):
                                self.addReward(player, item)
                                message = GlobalStrings[55] %(self.getRewardDesc(item))
                                MMain.sendCenterMessage(player, message)
                            else:
                                pass

    def getMenu(self, player, npcID):
        return []

ModuleID = 49
Instance = DropExtra(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_DROP_ITEM,
])
