#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
import copy
from tabfile import TabFile
from messages import *
from gamedefines import *

REWARD_TYPE_MONEY               = 1     # 银币
REWARD_TYPE_GOLDMONEY           = 2     # 金币
REWARD_TYPE_GOLDMONEY_PURCHASED = 3     # 真金
REWARD_TYPE_VITALITY            = 4     # 体力
REWARD_TYPE_EXPERIENCE          = 5     # 经验
REWARD_TYPE_ENERGY              = 6     # 真气
REWARD_TYPE_SPAR                = 7     # 晶石
REWARD_TYPE_VIGOR               = 8     # 精力
REWARD_TYPE_TITLE               = 9     # 头衔

BNT_Vitality                    = 0     # 体力
BNT_Money                       = 1     # 银币
BNT_ArenaPoint                  = 2     # 竞技场点数
BNT_MaxFriendNum                = 3     # 最大好友数量
BNT_SparFree                    = 4     # 晶石免费重置次数
BNT_SingleBoss                  = 5     # 单人boss
BNT_MultiBoss                   = 6     # 多人boss
BNT_ProtectAthena               = 7     # 守卫雅典娜
BNT_Eighteen                    = 8     # 十八摸
BNT_DungeonNormal               = 9     # 普通副本
BNT_DungeonHard                 = 10    # 困难副本
BNT_DungeonEpic                 = 11    # 史诗副本
BNT_Count                       = 12    # 个数


Err_Unknown             = json.dumps({"Result":-1, "ResultDesc":GlobalStrings[66]})
Err_Failed              = json.dumps({"Result":0, "ResultDesc":GlobalStrings[67]})
Err_Ok                  = json.dumps({"Result":1, "ResultDesc":GlobalStrings[56]})
Err_LevelLimitation     = json.dumps({"Result":2, "ResultDesc":GlobalStrings[68]})
Err_VipLevelLimitation  = json.dumps({"Result":3, "ResultDesc":GlobalStrings[69]})
Err_JobLimitation       = json.dumps({"Result":4, "ResultDesc":GlobalStrings[70]})
Err_Max                 = json.dumps({"Result":5, "ResultDesc":GlobalStrings[71]})
Err_NotEnoughSpace      = json.dumps({"Result":6, "ResultDesc":GlobalStrings[72]})
Err_NotEnoughMoney      = json.dumps({"Result":7, "ResultDesc":GlobalStrings[73]})
Err_NotEnoughGoldMoney  = json.dumps({"Result":8, "ResultDesc":GlobalStrings[74]})
Err_NotEnoughMaterial   = json.dumps({"Result":9, "ResultDesc":GlobalStrings[75]})
Err_NotEnoughCount      = json.dumps({"Result":10, "ResultDesc":GlobalStrings[57]})
Err_NotOwner            = json.dumps({"Result":11, "ResultDesc":GlobalStrings[76]})
Err_NotExist            = json.dumps({"Result":12, "ResultDesc":GlobalStrings[77]})
Err_Used                = json.dumps({"Result":13, "ResultDesc":GlobalStrings[78]})
Err_Repetition          = json.dumps({"Result":14, "ResultDesc":GlobalStrings[79]})
Err_Invalid             = json.dumps({"Result":15, "ResultDesc":GlobalStrings[80]})
Err_Double              = json.dumps({"Result":16, "ResultDesc":GlobalStrings[81]})
Err_NoFee               = json.dumps({"Result":17, "ResultDesc":GlobalStrings[82]})
Err_Cannot              = json.dumps({"Result":18, "ResultDesc":GlobalStrings[83]})
Err_NotOpen             = json.dumps({"Result":19, "ResultDesc":GlobalStrings[84]})
Err_ColdDown            = json.dumps({"Result":20, "ResultDesc":GlobalStrings[85]})
Err_HaveThis            = json.dumps({"Result":21, "ResultDesc":GlobalStrings[86]})
Err_PermissionLimitation= json.dumps({"Result":22, "ResultDesc":GlobalStrings[87]})
Err_NotEnoughRes        = json.dumps({"Result":23, "ResultDesc":GlobalStrings[88]})

FINISHED_COLOR      = "[00FF00]"
UNFINISH_COLOR      = "[FF0000]"

class ActivityBase:
    def __init__(self):
        self.mBeginTime = 0
        self.mEndTime = 0
        self.mValidTime = 0
        self.mColor = ["2EE43E","2EE43E","2EE43E","13b1ff","13b1ff","13b1ff","AE2DE6","AE2DE6","AE2DE6","E68D2D","E68D2D","E68D2D","FF4141", "FF4141", "FF4141"]

    def getZerotimestamp(self):
        t = time.localtime(time.time())
        time1 = time.mktime(time.strptime(time.strftime('%Y-%m-%d 00:00:00', t),'%Y-%m-%d %H:%M:%S'))
        return int(time1)

    def getPlayerData(self, player, defaultValue):
        data = getModuleData(player, self.mID, {})
        for k in data.keys():
            if k != self.mBeginTime:
                del data[k]

        if self.mBeginTime not in data:
            if type(defaultValue) == type([]) or type(defaultValue) == type({}):
                data[self.mBeginTime] = copy.deepcopy(defaultValue)
            else:
                data[self.mBeginTime] = defaultValue

        return data[self.mBeginTime]
        
    def getPlayerForeverData(self, player, defaultValue):
        data = getModuleData(player, self.mID, {})
        for begintime in data:
            datavalue = data[begintime]
            return datavalue
        if type(defaultValue) == type([]) or type(defaultValue) == type({}):
                data[self.mBeginTime] = copy.deepcopy(defaultValue)
        else:
            data[self.mBeginTime] = defaultValue
        return data[self.mBeginTime]
    def setPlayerForeverData(self, player, defaultValue):
        data = getModuleData(player, self.mID, {})
        status = True
        for begintime in data:
            status =False
            if type(defaultValue) == type([]) or type(defaultValue) == type({}):
                data[begintime] = copy.deepcopy(defaultValue)
            else:
                data[begintime] = defaultValue
            break
        if status:
            if type(defaultValue) == type([]) or type(defaultValue) == type({}):
                data[self.mBeginTime] = copy.deepcopy(defaultValue)
            else:
                data[self.mBeginTime] = defaultValue

    def setPlayerData(self, player, defaultValue):
        data = getModuleData(player, self.mID, {})
        if type(defaultValue) == type([]) or type(defaultValue) == type({}):
            data[self.mBeginTime] = copy.deepcopy(defaultValue)
        else:
            data[self.mBeginTime] = defaultValue
            
    def isActived(self, player):
        curTime = time.time()
        if curTime >= self.mBeginTime and curTime <= self.mEndTime:
            return True

        return False

    def isShow(self, player):
        return True

    def isValid(self, player):
        curTime = time.time()
        if curTime >= self.mBeginTime and curTime <= self.mValidTime:
            return True

        return False

    def setConfig(self, configData):
        data = json.loads(configData)
        self.mBeginTime = data["BeginTime"]
        self.mEndTime = data["EndTime"]
        self.mValidTime = data["ValidTime"]

        self.loadConfig(data["ConfigPath"])

    def getName(self):
        return ""

    def loadConfig(self, path):
        pass

    def getInfo(self, player):
        pass

    def doAction(self, player, actData):
        pass    

    def getItemColor(self, itemQuality):
        if itemQuality >= 0 and itemQuality <= 14:
            return self.mColor[itemQuality]
        else:
            return "FFFFFF"

    def getRewardDesc(self, reward):
        if len(reward) == 3:
            itemName = MMain.getItemName(reward[0], reward[1])
            itemQuality = MMain.getItemQuality(reward[0], reward[1])
            return "[%s]%s[-]x%s" % (self.getItemColor(itemQuality), itemName, reward[2])
        else:
            return ""

    def canAddReward(self, player, reward):
        if len(reward) == 3:
            if player.canAddSingleToBag(reward[0], reward[1], reward[2]):
                return True
            else:
                return False
        else:
            return True

    def canAddAllReward(self, player, rewards):
        items = {}
        for reward in rewards:
            if len(reward) == 3:
                itemType = reward[0]
                itemID = reward[1]
                itemNum = reward[2]

                if itemType in items:
                    if itemID in items[itemType]:
                        items[itemType][itemID] += itemNum
                    else:
                        items[itemType][itemID] = itemNum
                else:
                    items[itemType] = {
                        itemID: itemNum
                    }

        if len(items):
            realItems = []
            for itemType in items:
                for itemID in items[itemType]:
                    itemNum = items[itemType][itemID]
                    realItems.append((
                        itemType,
                        itemID,
                        itemNum,
                    ))
            if player.canAddToBag(realItems):
                return True
            else:
                return False
        else:
            return True

    def checkHasEnough(self, player, reward):
        if len(reward) == 3:
            if reward[2] > player.getItemNum(reward[0], reward[1]):
                return False
            else:
                return True
        elif len(reward) == 2:
            rewardType = reward[0]
            rewardValue = reward[1]

            if rewardType == REWARD_TYPE_MONEY:
                return player.getMoney() >= rewardValue

            elif rewardType == REWARD_TYPE_GOLDMONEY:
                return player.getGoldMoney() >= rewardValue

            elif rewardType == REWARD_TYPE_GOLDMONEY_PURCHASED:
                return False

            elif rewardType == REWARD_TYPE_VITALITY:
                return player.getVitality() >= rewardValue

            elif rewardType == REWARD_TYPE_EXPERIENCE:
                return player.getExperience() >= rewardValue

            elif rewardType == REWARD_TYPE_ENERGY:
                return player.getEnergy() >= rewardValue

            elif rewardType == REWARD_TYPE_SPAR:
                return player.getSpar() >= rewardValue

            elif rewardType == REWARD_TYPE_VIGOR:
                return player.getVigor() >= rewardValue
        else:
            return False

    def removeReward(self, player, reward):
        if len(reward) == 3:
            player.removeItemAndDestroy(reward[0], reward[1], reward[2])
            MMain.dbLogActivityUseItem(player, self.mID, reward[0], reward[1], reward[2])

        elif len(reward) == 2:
            rewardType = reward[0]
            rewardValue = reward[1]

            if rewardType == REWARD_TYPE_MONEY:
                player.addMoney(-rewardValue)
                MMain.dbLogActivityUseMoney(player, self.mID, rewardValue)

            elif rewardType == REWARD_TYPE_GOLDMONEY:
                player.addGoldMoney(-rewardValue)
                MMain.dbLogActivityUseGoldMoney(player, self.mID, rewardValue)

            elif rewardType == REWARD_TYPE_GOLDMONEY_PURCHASED:
                pass

            elif rewardType == REWARD_TYPE_VITALITY:
                player.addVitality(-rewardValue)
                MMain.dbLogActivityUseVitality(player, self.mID, rewardValue)

            elif rewardType == REWARD_TYPE_EXPERIENCE:
                player.addExperience(-rewardValue)
                MMain.dbLogActivityUseExperience(player, self.mID, rewardValue)            

            elif rewardType == REWARD_TYPE_ENERGY:
                player.addEnergy(-rewardValue)
                MMain.dbLogActivityUseEnergy(player, self.mID, rewardValue)

            elif rewardType == REWARD_TYPE_SPAR:
                player.addSpar(-rewardValue)
                MMain.dbLogActivityUseSpar(player, self.mID, rewardValue)   

            elif rewardType == REWARD_TYPE_VIGOR:
                player.addVigor(-rewardValue)
                MMain.dbLogActivityUseVigor(player, self.mID, rewardValue)                                

    def addReward(self, player, reward):
        if len(reward) == 3:
                MMain.addItemToPlayer(player, MMain.createItem(reward[0], reward[1], reward[2]))
                MMain.dbLogActivityAddItem(player, self.mID, reward[0], reward[1], reward[2])

        elif len(reward) == 2:
            rewardType = reward[0]
            rewardValue = reward[1]

            if rewardType == REWARD_TYPE_MONEY:
                player.addMoney(rewardValue)
                MMain.dbLogActivityAddMoney(player, self.mID, rewardValue)

            elif rewardType == REWARD_TYPE_GOLDMONEY:
                player.addGoldMoney(rewardValue)
                MMain.dbLogActivityAddGoldMoney(player, self.mID, rewardValue)

            elif rewardType == REWARD_TYPE_GOLDMONEY_PURCHASED:
                pass

            elif rewardType == REWARD_TYPE_VITALITY:
                player.addVitality(rewardValue)
                MMain.dbLogActivityAddVitality(player, self.mID, rewardValue)

            elif rewardType == REWARD_TYPE_EXPERIENCE:
                player.addExperience(rewardValue)
                MMain.dbLogActivityAddExperience(player, self.mID, rewardValue)

            elif rewardType == REWARD_TYPE_ENERGY:
                player.addEnergy(rewardValue)
                MMain.dbLogActivityAddEnergy(player, self.mID, rewardValue)

            elif rewardType == REWARD_TYPE_SPAR:
                player.addSpar(rewardValue)
                MMain.dbLogActivityAddSpar(player, self.mID, rewardValue)

            elif rewardType == REWARD_TYPE_VIGOR:
                player.addVigor(rewardValue)
                MMain.dbLogActivityAddVigor(player, self.mID, rewardValue)
                
            elif rewardType == REWARD_TYPE_TITLE:
                if "s_myTitles" not in player.__dict__:
                    player.s_myTitles = []
                player.s_myTitles.append(rewardValue)

    def notifyActReward(self, player, hasReward):
        if hasReward:
            response = (
                self.mID,
                1,
            )
        else:
            response = (
                self.mID,
                0,
            )
        MMain.sendTextProtocol(player, "S2C_NotifyActReward", response)
