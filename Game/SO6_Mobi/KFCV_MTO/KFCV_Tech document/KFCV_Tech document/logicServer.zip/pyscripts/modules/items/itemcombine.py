#coding=utf8

import MItem
import item

class ItemCombine(item.Item):
    def __init__(self):
        item.Item.__init__(self)
        
item.gItemMgr.register(MItem.ItemType.Combine, ItemCombine)