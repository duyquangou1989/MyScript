#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
import copy
import util
import guildscience
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *
from traceback import print_exc
from guildbattletime import *
from guildbattlecfg import *
from guildbattlemsghandler import *
from guildbattle_reward import *


# 战斗期间
class GuildBattleHandler_Fight(GuildBattleHandler):
    def onEnterPeriod(self):
        print("onEnterPeriod Fight")
        self.mBattle.mGuildFightData = {}
        MMain.sendHorseMessage(Announce_Msg_Fight)
        self.notifyAllPlayerPeriod()
        self.requestBattleField()

        # 初始化占领方
        occupyInfo = self.mBattle.mCitySaveData["occupy"]
        for cityNo in occupyInfo:
            for towerNo in Battle_Citys[cityNo]:
                self.mBattle.mTowerData[towerNo][1] = occupyInfo[cityNo]

    def onExitPeriod(self):
        print("onExitPeriod Fight")

        # 遍历key，key为id
        for id in self.mBattle.mBattleFieldIndexs:
            MMain.rtEndGame(id)

        # 据点数量哪个公会多，城就属于哪个公会
        for cityNo in Battle_Citys:
            occupyNames = {}
            for towerNo in Battle_Citys[cityNo]:
                name = self.mBattle.mTowerData[towerNo][1]
                occupyNames[name] = occupyNames.get(name, 0) + 1

            rank = sorted(occupyNames.items(), key=lambda occupyNames:occupyNames[1], reverse=True)
            newOccupy = rank[0][0]
            if newOccupy:
                oldOccupy = self.mBattle.mCitySaveData["occupy"].get(cityNo)
                self.mBattle.mCitySaveData["occupy"][cityNo] = newOccupy
                print("newOccupy %s:%s" % (cityNo,  newOccupy))

                if oldOccupy != newOccupy:
                    if newOccupy not in self.mBattle.mCityOccupyResult:
                        self.mBattle.mCityOccupyResult[newOccupy] = []
                    self.mBattle.mCityOccupyResult[newOccupy].append([cityNo, oldOccupy])

                    if oldOccupy not in self.mBattle.mCityOccupyedResult:
                        self.mBattle.mCityOccupyedResult[oldOccupy] = []
                    self.mBattle.mCityOccupyedResult[oldOccupy].append([cityNo, newOccupy])

                # 第一公会
                if cityNo == 1:
                    if not oldOccupy or newOccupy == oldOccupy:
                        msg = End_Annouce["big2"] % newOccupy
                    else:
                        msg = End_Annouce["big1"] % (newOccupy, oldOccupy)

                    MMain.sendHorseMessage(msg)
                    victoryInfo = self.mBattle.mGuildData["victory"]
                    if victoryInfo[0] == newOccupy:
                        victoryInfo[1] += 1
                    else:
                        victoryInfo[1] = 1
                        victoryInfo[0] = newOccupy

                elif cityNo in [2,3,4,5]:
                    cityName = City_Config[cityNo][0]

                    if not oldOccupy or newOccupy == oldOccupy:
                        msg = End_Annouce["mid2"] % (newOccupy, cityName)
                    else:
                        msg = End_Annouce["mid1"] % (newOccupy, oldOccupy, cityName)

                    MMain.sendHorseMessage(msg)

        # 个人奖励发奖
        for playerName in self.mBattle.mRewardData:
            mail = {}
            mail["RecvUUID"] = ""
            mail["RecvName"] = playerName
            mail["CreateTime"] = int(time.time())
            mail["ValidTime"] = mail["CreateTime"] + 86400 * 16
            mail["Head"] = GlobalStrings[188]
            mail["Body"] = GlobalStrings[189]
            mail["Res"] = self.mBattle.mRewardData[playerName].items()
            mail["Items"] = []
            MMain.sendMail(mail)
        # 发奖
        cityInfo = self.mBattle.mCitySaveData["occupy"]
        for cityNo in cityInfo:
            guildName = cityInfo[cityNo]
            if not guildName:
                continue
            print("guild battle reward :" + guildName)
            guild = MMain.getGuildByName(guildName)
            if guild:
                guildMembers = guild.getAllMembers()
                for name in guildMembers:
                    if name in self.mBattle.mPlayerData["killRank"]:
                        mail = {}
                        mail["RecvUUID"] = ""
                        mail["RecvName"] = name
                        mail["CreateTime"] = int(time.time())
                        mail["ValidTime"] = mail["CreateTime"] + 86400 * 16
                        mail["Head"] = GlobalStrings[190]
                        mail["Body"] = GlobalStrings[191] % City_Config[cityNo][0]
                        mail["Res"] = City_Config[cityNo][1][0]
                        mail["Items"] = City_Config[cityNo][1][1]
                        MMain.sendMail(mail)


        self.mBattle.dataSaveToDB()

        # 通知所有客户端结束
        allPlayers = MMain.getAllPlayers()
        for tmpPlayer in allPlayers:
            # and tmpPlayer.getName in self.mBattle.mPlayerData["killRank"]
            if tmpPlayer.getClientID() != -1 and self.mBattle.canJoin(tmpPlayer) and tmpPlayer.getName() in self.mBattle.mPlayerData["killRank"]:
                msg = self.formatOverMsg(tmpPlayer.getGuildName(), tmpPlayer.getName())
                if self.mBattle.mGuildData["victory"][0]:
                    MMain.sendTextProtocol(tmpPlayer, "S2C_NotifyGuildBattleOver", (msg, self.mBattle.mGuildData["victory"][0]))
                else:
                    MMain.sendTextProtocol(tmpPlayer, "S2C_NotifyGuildBattleOver", (msg,))


    # 申请战场
    def requestBattleField(self):
        # 遍历key，key为id
        for id in self.mBattle.mBattleFieldIndexs:
            MMain.rtEndGame(id)

        self.mBattle.mBattleFieldIds = {}
        self.mBattle.mBattleFieldIndexs = {}

        for i in Battle_Towers_List:
            campId = -1
            cityNo = towerToCity(i)
            occupyGuild = self.mBattle.mCitySaveData["occupy"].get(cityNo)
            if occupyGuild:
                campId = self.mBattle.getCampId(occupyGuild)

            #print("campId:" + str(campId))
            id = MMain.rtStartGame(Tower_Config[i][3], campId)
            #print(Tower_Config[i][3])
            #print(id)
            #id = MMain.rtStartGame(130002)
            self.mBattle.mBattleFieldIds[i] = id
            self.mBattle.mBattleFieldIndexs[id] = i


    def onRequestBattleField(self):
        pass

    def processTime(self, param0, param1):
        # 战斗期间每分钟存储
        self.mBattle.dataSaveToDB()
        # 开启失败，反复尝试
        if len(self.mBattle.mBattleFieldIds) == 0:
            self.requestBattleField()

    def processSecond(self):
        self.mBattle.mTimer += 1
        # 定时占领奖励
        if self.mBattle.mTimer % 30 == 0:
            for towerNo in Battle_Towers_List:
                guildName = self.mBattle.mTowerData[towerNo][1]
                awards = Tower_Config[towerNo][1]
                if guildName:
                    guild = MMain.getGuildByName(guildName)
                    if guild:
                        guildMembers = guild.getAllMembers()
                        for name in guildMembers:
                            memPlayer = MMain.getPlayerByName(name)
                            # 在线且打过战场
                            if memPlayer and memPlayer.getClientID() != -1 and \
                                            name in self.mBattle.mPlayerData["killRank"]:
                                self.mBattle.mRewardData[name] = self.mBattle.mRewardData.get(name, {})
                                rewardData = self.mBattle.mRewardData[name]

                                for award in awards:
                                    type = award[0]
                                    num = award[1]
                                    rewardData[type] = rewardData.get(type, 0) + num
                                    if type in Personal_Reward_Max:
                                        rewardData[type] = min(rewardData[type], Personal_Reward_Max[type])


    def processClient(self, player, jsonData):
        actType = jsonData["type"]
        ret = {"type": actType}

        if actType == "main_info":
            ret["state"] = "fight"

            if self.canRevive(player) and self.isAllDie(player):
                playerGuildData = self.checkPlayerData(player.getName())
                playerGuildData["data"][0] = [100,100,100]
                playerGuildData["data"][1] = 0


            leftTime,periodTime = self.mBattle.calNextPeriodTime()
            guild = MMain.getGuildByName(player.getGuildName())
            guildFeats = guild.getBattle()    # 公会战功
            # cityInfo = self.mBattle.mCitySaveData["occupy"]
            cityInfo = self.getCityRealOccupy()

            # player信息
            playerInfo = self.getPlayerInfo(player, guild)
            awards = self.getPersonalAwardsInfo(player.getName())
            ret["data"] = [leftTime, cityInfo, guildFeats, playerInfo, awards,
                [self.getReviveCost(player),Inspire_Single_Cost, Inspire_All_Cost,BuffOther_Cost,
                 Inspire_Single_Time,Inspire_All_Time, BuffOther_Time,
                 Inspire_Single_Buff, Inspire_All_Buff,BuffOther_Buff * self.mBattle.mGuildData["victory"][1]]]
            ret["city"] = self.getCityRealSituation(player)
            return json.dumps(ret)

        elif actType == "enter_battle":
            playerName = player.getName()
            guildName = player.getGuildName()
            towerNo = jsonData["data"]
            cityNo = towerToCity(towerNo)
            #guildName = player.getGuildName()

            if towerNo not in self.mBattle.mBattleFieldIds:
                MMain.sendCenterMessage(player, GlobalStrings[192])
                return "{}"

            if "GuildBattleEnterTime" not in player.__dict__:
                player.GuildBattleEnterTime = time.time()
            else:
                if time.time() - player.GuildBattleEnterTime < 5:
                    MMain.sendCenterMessage(player, GlobalStrings[193])
                    return "{}"

            if not self.mBattle.canJoin(player, True):
                 return "{}"

            allDie = self.isAllDie(player)
            if allDie:
                leftTime = int(self.getReviveLeftTime(player))
                MMain.sendCenterMessage(player, GlobalStrings[194] % leftTime)
                return "{}"

            #if towerNo <= 0 or towerNo >= len(self.mBattle.mTowerData):
            if not towerNo in Battle_Towers_List:
                MMain.sendCenterMessage(player, GlobalStrings[195])
                return "{}"

            import guildbattle
            if not guildbattle.EnterNoLimt:
                if cityNo < 6 and not self.mBattle.mCityFight.get(cityNo):
                    MMain.sendCenterMessage(player, GlobalStrings[196])
                    return "{}"

                if not self.isQualified(player, towerToCity(towerNo)):
                    MMain.sendCenterMessage(player, GlobalStrings[197])
                    return "{}"

                if not self.canEnterBattle(player, towerNo):
                    return "{}"

            # 进入战场
            towerData = self.mBattle.mTowerData[towerNo][0]
            names = towerData.get(guildName)
            if not names:
                towerData[guildName] = [playerName]
            else:
                if not playerName in names:
                    names.append(playerName)

            # 只要参与就进入排行
            killRanks = self.mBattle.mPlayerData["killRank"]
            killRanks[playerName] = killRanks.get(playerName, [0,0,""])

            # 记录公会名
            if len(killRanks[playerName]) == 2:
                killRanks[playerName].append("")

            if killRanks[playerName][2] == "":
                killRanks[playerName][2] = player.getGuildName()

            campID = self.mBattle.getCampId(player.getGuildName())
            #print("campID:" + str(campID))
            #print("towerNo id:" + str(self.mBattle.mBattleFieldIds[towerNo]))

            playerBuffs = guildscience.Instance.getPlayerScienceBuff(player)
            buffs = []
            if playerBuffs:
                buffs = [[buf[1], buf[2], buf[3]] for buf in playerBuffs]

            playerGuildData = self.checkPlayerData(player.getName())
            hpDatas = playerGuildData["data"][0]
            curHPs = [(1, hpDatas[0]/100.0), (2, hpDatas[1]/100.0), (3, hpDatas[2]/100.0)]
            #print(curHPs)
            MMain.rtPlayerJoinGame(self.mBattle.mBattleFieldIds[towerNo], campID, player.getUUID(), buffs, curHPs)

            player.GuildBattleEnterTime = time.time()
            ret["result"] = "ok"
            occupy = self.mBattle.mCitySaveData["occupy"].get(cityNo)

            realOccupyInfo = self.getCityRealOccupy()
            occupy = realOccupyInfo.get(cityNo)
            if occupy:
                ret["occupy"] = [occupy, self.mBattle.getCampId(occupy)]
            else:
                ret["occupy"] = ["", -1]

            return json.dumps(ret)

        elif actType == "revive":

            playerGuildData = self.checkPlayerData(player.getName())
            curTime =time.time()

            if not self.canRevive(player):
                reviceCost = self.getReviveCost(player)
                if player.getGoldMoney() >= reviceCost:
                    player.addGoldMoney(-reviceCost)
                    MMain.dbLogActivityUseGoldMoney(player, self.mBattle.mID, reviceCost)
                    playerGuildData["data"][0] = [100,100,100]
                    ret["result"] = "ok"
                    playerGuildData = self.checkPlayerData(player.getName())
                    playerGuildData["data"][5] += 1
                    playerGuildData["data"][1] = 0
                else:
                    MMain.sendCenterMessage(player, GlobalStrings[198])
            else:
                ret["result"] = "colding"

            return json.dumps(ret)

        elif actType == "inspire_single":
            if player.getGoldMoney() < Inspire_Single_Cost:
                MMain.sendCenterMessage(player, GlobalStrings[198])
                return "{}"

            player.addGoldMoney(-Inspire_Single_Cost)
            MMain.dbLogActivityUseGoldMoney(player, self.mBattle.mID, Inspire_Single_Cost)

            playerGuildData = self.checkPlayerData(player.getName())
            curTime =time.time()

            canAdd = False
            if playerGuildData["data"][2] < curTime:
                playerGuildData["data"][2] = curTime + Inspire_Single_Time
                canAdd = True
            elif playerGuildData["data"][2] > curTime + Inspire_Single_Time_Max:
                ret["result"] = "full"
            else:
                playerGuildData["data"][2] += Inspire_Single_Time
                canAdd = True

            if canAdd:
                ret["result"] = "ok"

            ret["time"] = playerGuildData["data"][2] - curTime
            return json.dumps(ret)
        elif actType == "inspire_all":
            if player.getGoldMoney() < Inspire_All_Cost:
                MMain.sendCenterMessage(player, GlobalStrings[198])
                return "{}"
            player.addGoldMoney(-Inspire_All_Cost)
            MMain.dbLogActivityUseGoldMoney(player, self.mBattle.mID, Inspire_All_Cost)
            guildName = player.getGuildName()
            guildTmpData = self.mBattle.mFightData.get(guildName)
            curTime =time.time()
            if not guildTmpData:
                self.mBattle.mFightData[guildName] = [0]
                guildTmpData = self.mBattle.mFightData.get(guildName)

            if guildTmpData[0] < curTime:
                guildTmpData[0] = curTime + Inspire_All_Time
                ret["result"] = "ok"
            elif guildTmpData[0] > curTime + Inspire_All_Time_Max:
                ret["result"] = "full"
            else:
                guildTmpData[0] += Inspire_All_Time
                ret["result"] = "ok"

            ret["time"] = guildTmpData[0] - curTime
            return json.dumps(ret)

        elif actType == "inspire_attack":

            playerGuildData = self.checkPlayerData(player.getName())["data"]

            if player.getGoldMoney() < BuffOther_Cost:
                MMain.sendCenterMessage(player, GlobalStrings[198])
                return "{}"

            player.addGoldMoney(-BuffOther_Cost)
            MMain.dbLogActivityUseGoldMoney(player, self.mBattle.mID, BuffOther_Cost)

            playerGuildData = self.checkPlayerData(player.getName())
            curTime =time.time()

            canAdd = False
            if playerGuildData["data"][4] < curTime:
                playerGuildData["data"][4] = curTime + BuffOther_Time
                canAdd = True
            elif playerGuildData["data"][4] > curTime + BuffOther_Time_Max:
                ret["result"] = "full"
            else:
                playerGuildData["data"][4] += BuffOther_Time
                canAdd = True

            if canAdd:
                ret["result"] = "ok"

            ret["time"] = playerGuildData["data"][4] - curTime
            return json.dumps(ret)

        elif actType == "tower_info":
            cityNo = jsonData["data"]

            towerList = Battle_Citys.get(cityNo)
            if not towerList:
                MMain.sendCenterMessage(player, GlobalStrings[199])
                return "{}"

            if cityNo < 6 and not self.mBattle.mCityFight.get(cityNo):
                MMain.sendCenterMessage(player, GlobalStrings[196])
                return "{}"

            if not self.isQualified(player, cityNo):
                MMain.sendCenterMessage(player, GlobalStrings[197])
                return "{}"

            guildName = player.getGuildName()
            qualified = self.isQualified(player, cityNo)
            ret["join"]= qualified
            ret["tower"] = {}

            for towerNo in towerList:
                towerData = self.mBattle.mTowerData[towerNo][0]
                opyName = self.mBattle.mTowerData[towerNo][1]

                friendCount = 0
                enemyCount = 0
                for name in towerData:
                    if name == guildName:
                        friendCount += len(towerData[name])
                    else:
                        enemyCount += len(towerData[name])
                # 友方数，敌方数，占领公会
                ret["tower"][towerNo] = [friendCount, enemyCount, opyName ]

            fightInfo = self.mBattle.mCityFight.get(cityNo)
            if fightInfo:
                ret["fight"] = [fightInfo[1], fightInfo[0]]
            return json.dumps(ret)


        else:
            return GuildBattleHandler.processClient(self, player, jsonData)

    def canRevive(self, player):
        return self.getReviveLeftTime(player) <= 0

    def getReviveLeftTime(self, player):
        playerGuildData = self.checkPlayerData(player.getName())
        if playerGuildData["data"][1] == 0:
            return 0

        curTime = time.time()
        leftTime = playerGuildData["data"][1] - curTime
        if leftTime < 0:
            leftTime = 0

        return leftTime

    # 复活需要等待的时间
    def getTotalReviveTime(self, player):
        playerBuffs = guildscience.Instance.getPlayerScienceBuff(player)
        buffTime = 0
        if playerBuffs:
            for buf in playerBuffs:
                buffTime += buf[4]

        reviveTime = Revive_Cold_Time - buffTime
        if reviveTime < 0:
            reviveTime = 0

        return reviveTime

    def getReviveCost(self, player):
        playerGuildData = self.checkPlayerData(player.getName())
        dieTimes = playerGuildData["data"][5]
        return Revive_Cost_Up.get(dieTimes, Revive_Cost)

    # 大中城实时战况
    def getCityRealSituation(self, player):
        situation = {}

        for cityNo in Battle_City_Connect:
            attackNum = 0
            defenceNum = 0
            attckInfo = self.mBattle.mCityFight.get(cityNo)
            if not attckInfo:
                defenceNum = len(Battle_Citys[cityNo])
            else:
                for towerNo in  Battle_Citys[cityNo]:
                    if self.mBattle.mTowerData[towerNo][1] == attckInfo[0]:
                        defenceNum += 1

            attackNum = len(Battle_Citys[cityNo]) - defenceNum
            oldOccupy = self.mBattle.mCitySaveData["occupy"].get(cityNo)

            qualify = False
            if self.mBattle.mCitySaveData["occupy"].get(cityNo) == player.getGuildName():
                qualify = True
            else:
                qualify = self.isQualified(player, cityNo)

            situation[cityNo] = [attackNum, defenceNum, qualify]

        return  situation

    # 实时占领情况
    def getCityRealOccupy(self):
        realOccupyInfo = {}
        for cityNo in Battle_Citys:
            occupyNames = {}
            for towerNo in Battle_Citys[cityNo]:
                name = self.mBattle.mTowerData[towerNo][1]
                occupyNames[name] = occupyNames.get(name, 0) + 1

            rank = sorted(occupyNames.items(), key=lambda occupyNames:occupyNames[1], reverse=True)
            realOccupyInfo[cityNo] = rank[0][0]

        return realOccupyInfo


    #[[血量1，血量2，血量3],复活剩余时间, 个人鼓舞剩余时间，公会鼓舞时间，个人复活时间，进攻buf时间]
    def getPlayerInfo(self, player, guild=None):
        curTime = time.time()
        guildName = player.getGuildName()
        if not guild:
            guild = MMain.getGuildByName(guildName)

        playerGuildData = self.checkPlayerData(player.getName())
        guildInspireTime = 0
        guildTmpData = self.mBattle.mFightData.get(guildName)
        if guildTmpData:
            guildInspireTime = guildTmpData[0]

        guildInspireTime -= curTime
        if guildInspireTime < 0:
            guildInspireTime = 0

        #copyData = copy.deepcopy(playerGuildData["data"])
        copyData = []
        copyData.append(playerGuildData["data"][0]) # 血量
        copyData.append(playerGuildData["data"][1]) # 复活剩余时间
        copyData.append(playerGuildData["data"][2]) # 个人鼓舞剩余时间
        copyData.append(guildInspireTime)           # 公会鼓舞时间
        copyData.append(playerGuildData["data"][3]) # 个人复活时间
        copyData.append(playerGuildData["data"][4]) # 进攻buf剩余时间

        # 取剩余时间
        copyData[1] -= curTime
        if copyData[1] < 0:
            copyData[1] = 0
        copyData[2] -= curTime
        if copyData[2] < 0:
            copyData[2] = 0

        copyData[4] -= curTime
        if copyData[4] < 0:
            copyData[4] = 0

        copyData[5] -= curTime
        if copyData[5] < 0:
            copyData[5] = 0

        #[[血量1，血量2，血量3],复活剩余时间, 个人鼓舞剩余时间，公会鼓舞时间，个人复活时间，进攻buf时间]
        return copyData


    def canEnterBattle(self, player, towerNo):
        if not towerNo in Battle_Towers_List:
            MMain.sendCenterMessage(player, GlobalStrings[195])
            return False

        guildName = player.getGuildName()
        towerData = self.mBattle.mTowerData[towerNo][0]
        friendCount = 0
        enemyCount = 0
        for name in towerData:
            if name == guildName:
                friendCount += len(towerData[name])
            else:
                enemyCount += len(towerData[name])


        if friendCount + enemyCount >= 10:
            MMain.sendCenterMessage(player, GlobalStrings[200])
            return False

        if friendCount >= 5:
            MMain.sendCenterMessage(player, GlobalStrings[201])
            return False

        return True

    def checkPlayerData(self, name):
        if name not in self.mBattle.mPlayerData:
            self.mBattle.mPlayerData[name] = {"data" : [[100,100,100], 0,0,0,0,1]}
            #[血量1，血量2，血量3],复活剩余时间, 个人鼓舞剩余时间，免费复活一次时间，进攻buf剩余时间，战斗外复活第几次

        #if "s_GuildBattle" not in player.__dict__:
            #player.s_GuildBattle = {"data" : [[100,100,100], 0,0,0,0]}

        return self.mBattle.mPlayerData[name]

    def processBattleMsg(self, msg, param0, param1):
        if msg == MSG_BATTLEGAME_PLAYER_JOINED:
            gameID = param0
            playerUUID = param1[0]
            result = param1[1]
            print("MSG_BATTLEGAME_PLAYER_JOINED " + str(result))


            battleFieldIndex = self.mBattle.mBattleFieldIndexs.get(gameID)
            if not battleFieldIndex:
                print("error battle gameID")
                return

            if result == 1:
                player = MMain.getPlayerByUUID(playerUUID)
                if player:
                    player.GuildBattle_Index = battleFieldIndex

                    guildName = player.getGuildName()

                    # 加buf
                    curTime = time.time()
                    playerGuildData = self.checkPlayerData(player.getName())
                    bufTime = int(playerGuildData["data"][2] - curTime)
                    if bufTime > 0:
                        MMain.rtPlayerBuff(
                            gameID, 
                            player.getUUID(), 
                            Inspire_Single_Buff_ID,
                            Inspire_Single_Buff,
                            bufTime)

                    fightData = self.mBattle.mFightData.get(guildName, [0])
                    bufTime = int(fightData[0] - curTime)
                    if bufTime > 0:
                        MMain.rtPlayerBuff(
                            gameID, 
                            player.getUUID(),
                            Inspire_All_Buff_ID,
                            Inspire_All_Buff,
                            bufTime)

                    bufTime = int(playerGuildData["data"][4] - curTime)
                    if bufTime > 0:
                        buff = BuffOther_Buff * self.mBattle.mGuildData["victory"][1]
                        if buff > 100:
                            buff = 100
                        MMain.rtPlayerBuff(
                            gameID,
                            player.getUUID(),
                            BuffOther_ID,
                            buff,
                            bufTime)

            else:
                towerData = self.mBattle.mTowerData[battleFieldIndex]
                playerName = MMain.getPlayerNameByUUID(playerUUID)
                peoples = towerData[0]
                for guildName in peoples:
                    if playerName in peoples[guildName]:
                        peoples[guildName].remove(playerName)

            syslog("Player %s joined game %s" % (playerUUID, gameID))
            player = MMain.getPlayerByUUID(playerUUID)
            if player:
                MMain.sendTextProtocol(player, "S2C_GuildBattleJoinResult", (result,))
        elif msg == MSG_BATTLEGAME_PLAYER_QUIT:
            gameID = param0
            playerUUID = param1[0]
            result = param1[1]
            hps = param1[2] # [(1, 1.0), (2, 1.0), (3, 1.0)])
            print("MSG_BATTLEGAME_PLAYER_QUIT")
            print(param1)

            battleFieldIndex = self.mBattle.mBattleFieldIndexs.get(gameID)
            if not battleFieldIndex:
                return
            # 退出时这边战场数据可能已经清空了
            towerData = self.mBattle.mTowerData[battleFieldIndex]
            if not towerData:
                return

            playerName = MMain.getPlayerNameByUUID(playerUUID)
            player = MMain.getPlayerByUUID(playerUUID)
            if playerName:
                playerGuildData = self.checkPlayerData(playerName)
                playerHps = playerGuildData["data"][0]
                allDie = True
                for hpData in hps:
                    playerHps[hpData[0]-1] = int(hpData[1]*100)
                    if hpData[1] > 0:
                        allDie = False

                if allDie:
                    waitTime = Revive_Cold_Time
                    if player:
                        waitTime = self.getTotalReviveTime(player)

                    playerGuildData["data"][1] = time.time() + waitTime

            if player:
                player.GuildBattle_Index = -1
            else:
                print("error player!")

            peoples = towerData[0]
            for guildName in peoples:
                if playerName in peoples[guildName]:
                    peoples[guildName].remove(playerName)
            """
            for _,names in enumerate(towerData[0]):
                if playerName in names:
                    names.remove(playerName)
            """

            syslog("Player %s quit game %s" % (playerUUID, gameID))
        elif msg == MSG_BATTLEGAME_ACTOR_DEAD:
            gameIndex = param0
            uuid, killerUUID, actorClass = param1

            self.onRoleDead(param0, param1)

            syslog("Player(%s)'s actor %d is killed by %s in game %d" % (uuid, actorClass, killerUUID, gameIndex))

        elif msg == MSG_BATTLEGAME_GAME_DATA_SYNC:
            gameId = param0
            data = json.loads(param1)

            # 已关闭？？？？
            if gameId not in self.mBattle.mBattleFieldIndexs:
                return

            occupyCampID = data.get("CurOccupationalCampID")
            guildName = self.mBattle.getGuildNameById(occupyCampID)
            if not guildName:
                ##print("MSG_BATTLEGAME_GAME_DATA_SYNC error id")
                return

            towerNo = self.mBattle.mBattleFieldIndexs[gameId]
            oldGuildName = self.mBattle.mTowerData[towerNo][1]
            self.mBattle.mTowerData[towerNo][1] = guildName

            # 被占了通知
            if oldGuildName != guildName:
                guild = MMain.getGuildByName(oldGuildName)
                if guild:
                    guildMembers = guild.getAllMembers()
                    for name in guildMembers:
                        memPlayer = MMain.getPlayerByName(name)
                        if memPlayer and memPlayer.getClientID() != -1:
                            MMain.sendTextProtocol(memPlayer, "S2C_GuildBattleNotifyTowerOccupy", (guildName,towerNo))



        elif msg == MSG_BATTLEGAME_PLAYER_DEAD:
            gameID = param0
            playerUUID = param1
            print("MSG_BATTLEGAME_PLAYER_DEAD")
            syslog("Player %s dead in game %s" % (playerUUID, gameID))

        elif msg == MSG_BATTLEGAME_PLAYER_REVIVE:
            print("MSG_BATTLEGAME_PLAYER_REVIVE")
            gameIndex = param0
            uuid, result = param1

            if result == 1:
                syslog("Player %s revived in game %d" % (uuid, gameIndex))
            else:
                syslog("Player %s revive failed in game %d" % (uuid, gameIndex))

        elif msg == MSG_BATTLEGAME_PLAYER_NEED_REVIVE:
            print("MSG_BATTLEGAME_PLAYER_NEED_REVIVE")
            gameIndex = param0
            uuid, killerName, killerGuildName,timeLeft = param1

            player = MMain.getPlayerByUUID(uuid)
            if player:
                cost = ReviveInBattle_Cost
                if self.checkCanFreeRevive(player):
                    cost = 0
                MMain.rtShowRevive(player, killerName, killerGuildName, cost, timeLeft)

        elif msg == MSG_BATTLEGAME_PLAYER_REQUEST_REVIVE:
            print("MSG_BATTLEGAME_PLAYER_REQUEST_REVIVE")
            gameIndex = param0
            uuid = param1

            # 判断扣钱之类的

            player = MMain.getPlayerByUUID(uuid)
            if player:
                cost = ReviveInBattle_Cost
                if self.checkCanFreeRevive(player, True):
                    cost = 0

                if player.getGoldMoney() >= cost:
                    player.addGoldMoney(-cost)
                    MMain.rtPlayerRevive(gameIndex, uuid)
                    MMain.dbLogActivityUseGoldMoney(player, self.mBattle.mID, cost)
            else:
                print("MSG_BATTLEGAME_PLAYER_REQUEST_REVIVE get player error")

    def checkCanFreeRevive(self, player, set=False):
        playerGuildData = self.checkPlayerData(player.getName())

        if time.time() - playerGuildData["data"][3] > 3600:
            if set:
                playerGuildData["data"][3] = time.time()
            return True
        else:
            return False


    def onRoleDead(self, gameIndex, param):
        uuid, killerUUID, actorClass = param
        name = MMain.getPlayerNameByUUID(uuid)

        # 需要刷新排行榜
        self.mBattle.mPersonalRankTime = 0
        killRanks = self.mBattle.mPlayerData["killRank"]

        if name:
            data = killRanks.get(name)
            if not data:
                killRanks[name] = [0,1]
            else:
                data[1] += 1
        else:
            print("error dead uuid")

        killerName = MMain.getPlayerNameByUUID(killerUUID)
        if killerName:
            data = killRanks.get(killerName)
            if not data:
                killRanks[killerName] = [1,0]
            else:
                data[0] += 1

            # 发跑马灯
            killNum = killRanks[killerName][0]
            dieNum = killRanks[killerName][1]
            announce = Kill_Announce.get(killNum)
            if announce:
                MMain.sendHorseMessage(announce % killerName)

            # 一个未死，连杀
            if dieNum == 0:
                announce = Combo_Kill_Announce.get(killNum)
                if announce:
                    MMain.sendHorseMessage(announce % killerName)

            killer = MMain.getPlayerByUUID(killerUUID)
            if killer:
                guild = MMain.getGuildByName(killer.getGuildName())
                if guild:
                    towerId = 1
                    for i in Battle_Towers_List:
                        lstName = self.mBattle.mTowerData[i][0].get(killer.getGuildName())
                        if lstName and killerName in lstName:
                            towerId = i
                            #print("towerId=%d" % towerId)
                            break
                    MMain.dbLogGuildBattle(killer, guild.getLevel(), killNum, dieNum, towerId)
        else:
            print("error killer uuid")


    # 检测是否全部死完了
    def isAllDie(self, player):
        playerGuildData = self.checkPlayerData(player.getName())
        hps = playerGuildData["data"][0]
        allDie = True

        roleNum = len(player.getRoleList())
        for i,hp in enumerate(hps):
            if i + 1 > roleNum:
                break
            if hp > 0:
                allDie = False
                break

        return allDie

# 结束期
class GuildBattleHandler_Over(GuildBattleHandler):
    def onEnterPeriod(self):
        self.notifyAllPlayerPeriod()
        print("onEnterPeriod Over")

    def onExitPeriod(self):
        print("onExitPeriod Over")
        self.mBattle.resetFightData()

    def processTime(self, param0, param1):
        pass

    def processClient(self, player, jsonData):
        actType = jsonData["type"]
        ret = {"type": actType}

        if actType == "main_info":
            ret["state"] = "over_info"

            leftTime,periodTime = self.mBattle.calNextPeriodTime()
            guild = MMain.getGuildByName(player.getGuildName())
            guildFeats = guild.getBattle()    # 公会战功
            cityInfo = self.getCityInfo()
            ret["data"] = [leftTime, cityInfo, guildFeats]

            return json.dumps(ret)
        elif actType == "over_info":
            guildName = player.getGuildName()
            return self.formatOverMsg(guildName, player.getName())

        return GuildBattleHandler.processClient(self, player, jsonData)

