#coding=utf8
import engine
import MMain
import sys
import time
import json
import random
import bisect
import copy
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

SC_SCIENCE_ID       =   0
SC_SCIENCE_NAME     =   1
SC_SCIENCE_ICON     =   2
SC_SCIENCE_TYPE     =   3
SC_SCIENCE_OLEVEL   =   4

LEVEL_SCIENCE_ID        =   0
LEVEL_SCIENCE_MARK      =   1
LEVEL_SCIENCE_LEVEL     =   2
LEVEL_SCIENCE_CONSU     =   3
LEVEL_SCIENCE_DESC      =   4
LEVEL_SCIENCE_ATTR1     =   5
LEVEL_SCIENCE_ATTRNUM1  =   6
LEVEL_SCIENCE_ATTR2     =   7
LEVEL_SCIENCE_ATTRNUM2  =   8
LEVEL_SCIENCE_ATTR3     =   9
LEVEL_SCIENCE_ATTRNUM3  =   10
LEVEL_SCIENCE_BUFFS     =   11

BUFF_SCIENCE_ID         =   0
BUFF_SCIENCE_ATTR       =   1
BUFF_SCIENCE_ATTRNUM    =   2
BUFF_SCIENCE_ATTRPPH    =   3
BUFF_SCIENCE_DECCD      =   4


class GuildScience:
    def __init__(self, moduleID):
        self.mID = moduleID
        self.mScience = {}
        self.mScienceLevel = {}
        self.mScienceBuff  = {}
        self.mInitData = {} #科技ID:[等级,获得状态]

    def getPlayerData(self, player):
        if "s_guildscidata" not in player.__dict__:
            player.s_guildscidata = copy.deepcopy(self.mInitData)
        else:
            for sciId in self.mScience:
                if sciId not in player.s_guildscidata:
                    player.s_guildscidata[sciId] = [0,0]
        return player.s_guildscidata
    def getName(self):
        return "GuildScience"

    def getInfo(self, player):
        # 科技图标  科技等级 科技id  科技名称 科技描述  消耗 状态 类别
        playerName = player.getName()
        guildName = player.getGuildName()
        playerData = self.getPlayerData(player)
        sciences = self.mScience
        levelDatas = self.mScienceLevel
        info = {}
        scienceData = []
        guild = MMain.getGuildByName(guildName)
        if guild:
            info["guildlevel"] = guild.getLevel()
            info["guildmeri"] = 0
            guildMember = guild.getMember(playerName)
            if guildMember:
                info["guildmeri"] = guildMember.getMeritorious()
        else:
            info["guildlevel"] = 0
            info["guildmeri"] = 0
        for scienceId in playerData:
            scienceLevel = playerData[scienceId][0]
            if scienceId in sciences and scienceId in levelDatas:
                sciName = sciences[scienceId][SC_SCIENCE_NAME]
                sciIcon = sciences[scienceId][SC_SCIENCE_ICON]
                sciType = sciences[scienceId][SC_SCIENCE_TYPE]
                sciOLevel = sciences[scienceId][SC_SCIENCE_OLEVEL]
                tempLevel = scienceLevel + 1
                if tempLevel in levelDatas[scienceId]:
                    sciConsu = levelDatas[scienceId][tempLevel][LEVEL_SCIENCE_CONSU]
                    if scienceLevel == 0:
                        sciDesc = levelDatas[scienceId][tempLevel][LEVEL_SCIENCE_DESC]
                    else:
                        sciDesc = levelDatas[scienceId][scienceLevel][LEVEL_SCIENCE_DESC]
                    nextLevel = scienceLevel + 1
                    scienceData.append((
                        scienceId,
                        sciName,
                        scienceLevel,
                        sciIcon,
                        sciType,
                        sciOLevel,
                        sciConsu,
                        sciDesc,
                        False
                        ))
                else:
                    sciConsu = levelDatas[scienceId][scienceLevel][LEVEL_SCIENCE_CONSU]
                    sciDesc = levelDatas[scienceId][scienceLevel][LEVEL_SCIENCE_DESC]
                    scienceData.append((
                        scienceId,
                        sciName,
                        scienceLevel,
                        sciIcon,
                        sciType,
                        sciOLevel,
                        0,
                        sciDesc,
                        True
                        ))
        info["science"] = scienceData
        return json.dumps(info)

    def doAction(self, player, actData):
        jsonData = json.loads(actData)
        
        if jsonData["type"] == "invoke":
            sciId = int(jsonData["sciId"])
            return self.invokeScience(player, sciId)
        elif jsonData["type"] == "upgrade":
            sciId = int(jsonData["sciId"])
            return self.upgradeScience(player, sciId)
        elif jsonData["type"] == "getbuff":
            return Err_Ok

    #==========================作用函数=========================
    def invokeScience(self, player, sciId):
        playerData = self.getPlayerData(player)
        playerName = player.getName()
        guildName = player.getGuildName()
        guild = MMain.getGuildByName(guildName)
        if guild:
            guildLevel = guild.getLevel()
            guildMember = guild.getMember(playerName)
            if guildMember:
                meri = guildMember.getMeritorious()
                if sciId in playerData:
                    sciLevel = playerData[sciId][0]
                    if sciLevel == 0:
                        if sciId in self.mScience and sciId in self.mScienceLevel:
                            sciData = self.mScience[sciId]
                            levelData = self.mScienceLevel[sciId]
                            openLevel = sciData[SC_SCIENCE_OLEVEL]
                            consu = levelData[1][LEVEL_SCIENCE_CONSU]
                            if guildLevel >= openLevel:
                                if meri >= consu:
                                    guildMember.addMeritorious(-consu)
                                    playerData[sciId][0] += 1
                                    info = {}
                                    info["Result"] = 0
                                    info["scidata"] = (sciId, 1, levelData[1][LEVEL_SCIENCE_DESC], levelData[2][LEVEL_SCIENCE_CONSU])
                                    info["guildmeri"] = guildMember.getMeritorious()
                                    info["type"] = "invoke"
                                    self.getGuildSciNormalBuff(player)
                                    MMain.refreshScienceAttr(player)
                                    MMain.dbLogGuildScience(player, guildLevel, sciId, 1, 1, consu, guildMember.getMeritorious())
                                    return json.dumps(info)
                                else:
                                    return json.dumps({"Result":1,"ResultDesc":GlobalStrings[142],"type":"invoke"})
                            else:
                                return json.dumps({"Result":2,"ResultDesc":GlobalStrings[143],"type":"invoke"})
        return Err_Unknown

    def upgradeScience(self, player, sciId):
        playerData = self.getPlayerData(player)
        playerName = player.getName()
        guildName = player.getGuildName()
        guild = MMain.getGuildByName(guildName)
        if guild:
            guildLevel = guild.getLevel()
            guildMember = guild.getMember(playerName)
            if guildMember:
                meri = guildMember.getMeritorious()
                if sciId in playerData:
                    sciLevel = playerData[sciId][0]
                    if sciId in self.mScience and sciId in self.mScienceLevel:
                        sciData = self.mScience[sciId]
                        levelData = self.mScienceLevel[sciId]
                        openLevel = sciData[SC_SCIENCE_OLEVEL]
                        if (sciLevel + 1) in levelData:
                            consu = levelData[sciLevel + 1][LEVEL_SCIENCE_CONSU]
                            if guildLevel > sciLevel:
                                if meri >= consu:
                                    guildMember.addMeritorious(-consu)
                                    sciLevel += 1
                                    playerData[sciId][0] = sciLevel
                                    need = 0
                                    imax = True
                                    if (sciLevel + 1) in levelData:
                                        imax = False
                                        need = levelData[sciLevel + 1][LEVEL_SCIENCE_CONSU]
                                    info = {}
                                    info["Result"] = 0
                                    info["scidata"] = (sciId, sciLevel, levelData[sciLevel][LEVEL_SCIENCE_DESC], need,imax)
                                    info["guildmeri"] = guildMember.getMeritorious()
                                    info["type"] = "upgrade"
                                    self.getGuildSciNormalBuff(player)
                                    MMain.refreshScienceAttr(player)
                                    MMain.dbLogGuildScience(player, guildLevel, sciId, 2, sciLevel, consu, guildMember.getMeritorious())
                                    return json.dumps(info)
                                else:
                                    return json.dumps({"Result":1,"ResultDesc":GlobalStrings[142],"type":"upgrade"})
                            else:
                                return json.dumps({"Result":2,"ResultDesc":GlobalStrings[143],"type":"upgrade"})
                        else:
                            return json.dumps({"Result":2,"ResultDesc":GlobalStrings[144],"type":"upgrade"})
        return Err_Unknown

    def getPlayerScienceBuff(self, player):
        playerData = self.getPlayerData(player)
        rebuff = []
        for sciId in playerData:
            if playerData[sciId][0] != 0:
                level = playerData[sciId][0]
                if sciId in self.mScienceLevel:
                    levelData = self.mScienceLevel[sciId]
                    if level in levelData:
                        buffids = levelData[level][LEVEL_SCIENCE_BUFFS]
                        if len(buffids) > 0:
                            for buffid in buffids:
                                if buffid in self.mScienceBuff:
                                    buffdata = self.mScienceBuff[buffid]
                                    rebuff.append((
                                        buffid,
                                        buffdata[BUFF_SCIENCE_ATTR],
                                        buffdata[BUFF_SCIENCE_ATTRNUM],
                                        buffdata[BUFF_SCIENCE_ATTRPPH],
                                        buffdata[BUFF_SCIENCE_DECCD]))
        return rebuff
    def getGuildSciNormalBuff(self, player):
        playerData = self.getPlayerData(player)
        buffs = []
        for sciId in playerData:
            sciLevel = playerData[sciId][0]
            if sciLevel != 0 and sciId in self.mScience and sciId in self.mScienceLevel:
                sciType = self.mScience[sciId][SC_SCIENCE_TYPE]
                if sciType == 1:
                    if sciLevel in self.mScienceLevel[sciId]:
                        sciLevelData = self.mScienceLevel[sciId][sciLevel]
                        attr1    = sciLevelData[LEVEL_SCIENCE_ATTR1]
                        attrNum1 = sciLevelData[LEVEL_SCIENCE_ATTRNUM1]
                        attr2    = sciLevelData[LEVEL_SCIENCE_ATTR2]
                        attrNum2 = sciLevelData[LEVEL_SCIENCE_ATTRNUM2]
                        attr3    = sciLevelData[LEVEL_SCIENCE_ATTR3]
                        attrNum3 = sciLevelData[LEVEL_SCIENCE_ATTRNUM3]
                        buffs.append((attr1, attrNum1))
                        buffs.append((attr2, attrNum2))
                        buffs.append((attr3, attrNum3))
        MMain.getGuildScienceBuff(player, buffs)
        
    def loadConfig(self, path):
        scienceconfig = "%sscienceconfig.txt" %(path)
        sciencebuffconfig = "%ssciencebuffconfig.txt" %(path)
        sciencelevelconfig = "%ssciencelevelconfig.txt" %(path)
        syslog("Loading GuildScience config...")
        tb = TabFile() 
        if tb.load(scienceconfig):
            science = {}
            for i in xrange(tb.mRowNum):
                science_id      = tb.get(i, SC_SCIENCE_ID, 0, True)
                science_name    = tb.get(i, SC_SCIENCE_NAME, "", False)
                science_icon    = tb.get(i, SC_SCIENCE_ICON, "", False)
                science_type    = tb.get(i, SC_SCIENCE_TYPE, 0, True)
                science_olevel  = tb.get(i, SC_SCIENCE_OLEVEL, 0, True)
                self.mInitData[science_id] = [0, 0]
                science[science_id] = (science_id, science_name, science_icon, science_type, science_olevel)
            self.mScience = science
        else:
            syslog("Loading %s config failed!" %(scienceconfig))
        tb = TabFile() 
        if tb.load(sciencelevelconfig):
            level = {}
            for i in xrange(tb.mRowNum):
                science_id          = tb.get(i, LEVEL_SCIENCE_ID, 0, True)
                science_mark        = tb.get(i, LEVEL_SCIENCE_ID, 0, True)
                science_level       = tb.get(i, LEVEL_SCIENCE_LEVEL, 0, True)
                science_consu       = tb.get(i, LEVEL_SCIENCE_CONSU, 0, True)
                science_desc        = tb.get(i, LEVEL_SCIENCE_DESC, "", False)
                science_attr1       = tb.get(i, LEVEL_SCIENCE_ATTR1, 0, True)
                science_attrnum1    = tb.get(i, LEVEL_SCIENCE_ATTRNUM1, 0, True)
                science_attr2       = tb.get(i, LEVEL_SCIENCE_ATTR2, 0, True)
                science_attrnum2    = tb.get(i, LEVEL_SCIENCE_ATTRNUM2, 0, True)
                science_attr3       = tb.get(i, LEVEL_SCIENCE_ATTR3, 0, True)
                science_attrnum3    = tb.get(i, LEVEL_SCIENCE_ATTRNUM3, 0, True)
                science_buffs       = tb.get(i, LEVEL_SCIENCE_BUFFS, "", False)
                listscience_buffs = []
                tempbuffs = science_buffs.split(";")
                if len(tempbuffs) > 0:
                    for buff in tempbuffs:
                        if buff == '':
                            continue
                        listscience_buffs.append(int(buff))
                if science_id in self.mScience:
                    if science_id in level:
                        level[science_id][science_level] = (science_id, science_mark,science_level, science_consu, science_desc, science_attr1, science_attrnum1, science_attr2, science_attrnum2, science_attr3, science_attrnum3, listscience_buffs)
                    else:
                        temp = {}
                        temp[science_level] =  (science_id, science_mark, science_level, science_consu, science_desc, science_attr1, science_attrnum1, science_attr2, science_attrnum2, science_attr3, science_attrnum3, listscience_buffs)
                        level[science_id] = temp
                else:
                    syslog("Loading %s config failed!" %(sciencelevelconfig))
            self.mScienceLevel = level
        else:
            syslog("Loading %s config failed!" %(sciencelevelconfig))
        tb = TabFile() 
        if tb.load(sciencebuffconfig):
            buffs = {}
            for i in xrange(tb.mRowNum):
                science_id = tb.get(i, BUFF_SCIENCE_ID, 0, True)
                science_attr = tb.get(i, BUFF_SCIENCE_ATTR, 0, True)
                science_attrnum = tb.get(i, BUFF_SCIENCE_ATTRNUM, 0, True)
                science_attrpph = tb.get(i, BUFF_SCIENCE_ATTRPPH, 0, True)
                science_deccd = tb.get(i, BUFF_SCIENCE_DECCD, 0, True)
                if science_id in buffs:
                    buffs[science_id].append((int(science_id), int(science_attr), int(science_attrnum), int(science_attrpph), int(science_deccd)))
                else:
                    temp = (int(science_id), int(science_attr), int(science_attrnum), int(science_attrpph), int(science_deccd))
                    buffs[science_id] = temp
            self.mScienceBuff = buffs
        else:
            syslog("Loading %s config failed!" %(sciencebuffconfig))

    def getGuildBattleTopOne(self):
        import guildbattle
        name = guildbattle.Instance.getTopOne()
        if name:
            return  name
        else:
            return ""

    def onBuyGuildBattle(self, player, buyNum):
        guild = MMain.getGuildByName(player.getGuildName())
        if guild:
            guildMember = guild.getMember(player.getName())
            if guildMember:
                import  guildbattlecfg
                guildMember.addMeritorious(buyNum * guildbattlecfg.Battle_Meritorious_Buy_Ratio)
                guild.updatePost()

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerGuildActivity(self.mID, self)
            self.loadConfig("settings/guild/activity/guildscience/")

ModuleID = 62
Instance = GuildScience(ModuleID)
engine.Instance.register(ModuleID , Instance,[
    MSG_SERVER_STARTUP,
])
