#coding=utf8

import MItem
import item
import random
import time
import MMain
from traceback import print_exc

class ItemLottery(item.Item):
    def __init__(self):
        item.Item.__init__(self)

    def canUse(self, player):
        if self.getID() > 0:
            return True
        else:
            return False

    def doUse(self, player):
        levelLimitation = self.getLevelLimitation()
        mainRole = player.getRoleByID(0)
        if mainRole and mainRole.getLevel() >= levelLimitation:
            seed = 0
            if "s_LotterySeed" not in self.__dict__:
                seed = random.randint(0, int(time.time()))
                self.s_LotterySeed = seed
            else:
                seed = self.s_LotterySeed

            try:
                import lotteryboard
                return lotteryboard.Instance.onUseItem(player, self)
            except:
                print_exc()
                return False
        else:
            MMain.sendCenterMessage(player, GlobalStrings[2])

        return False
        
item.gItemMgr.register(MItem.ItemType.Lottery, ItemLottery)
