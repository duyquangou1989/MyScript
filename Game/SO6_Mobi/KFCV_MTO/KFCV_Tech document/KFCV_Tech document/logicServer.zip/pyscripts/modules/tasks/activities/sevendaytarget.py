#coding=utf8
import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *



class SevenDayTarget(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        self.mID = moduleID
        self.InitData = []

    def isActived(self, player):
        return True

    def getName(self):
        return "SevenDayTarget"

    def getday(self , player):
        t1 = time.localtime(time.time())
        t2 = time.localtime(player.s_createtime)
        time1 = time.mktime(time.strptime(time.strftime('%Y-%m-%d 00:00:00', t1),'%Y-%m-%d %H:%M:%S'))
        time2 = time.mktime(time.strptime(time.strftime('%Y-%m-%d 00:00:00', t2),'%Y-%m-%d %H:%M:%S'))
        nowday = (time1 -time2) / 86400
        return int(nowday)

    def getInfo(self, player):
        curTime = time.time()
        if "s_createtime" not in player.__dict__:
            player.s_createtime = time.time()
        if "s_sdtcangetrecord" not in player.__dict__:
            player.s_sdtcangetrecord = [0,0,0,0,0,0,0]
        day = self.getday(player)

        datainfo = []
        for data in self.InitData:
            if data[0] == 1:
                datainfo.append((data[0],data[1],data[2],data[3]+data[4]))
            elif data[0] == 3:
                datainfo.append((data[0],data[1],data[2],data[3]+data[4]))
            else:
                datainfo.append((data[0],data[1],data[2],data[3]+data[4]))
        info = {}
        info["level"] = player.getLevel()
        info["battlepoint"] = player.getBattlePoint()
        info["cangetstatus"] = player.s_sdtcangetrecord
        info["config"] = datainfo
        info["day"] = day
        return json.dumps(info)

    def doAction(self, player, actData):
        jdata = json.loads(actData)
        day = jdata["Day"]
        if day in player.s_sdtcangetrecord:
            if player.s_sdtcangetrecord[day] == 1:
                mail = {}
                mail["RecvUUID"] = player.getUUID()
                mail["RecvName"] = player.getName()
                mail["CreateTime"] = int(time.time())
                mail["ValidTime"] = mail["CreateTime"] + 86400 * 3
                mail["Head"] = ""
                mail["Body"] = GlobalStrings[38] % (day+1)
                mail["Res"] = self.InitData[day][4]
                mail["Items"] = self.InitData[day][3]
                MMain.sendMail(mail)
                player.s_sdtcangetrecord[day] = 2
                return Err_Ok
            else:
                return Err_Cannot
        else:
            return Err_Cannot

    def loadConfig(self, path):
        rewardsFilename = "%ssevendaytarget.txt" % (path)
        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = {}
            initData = []
            for i in xrange(tb.mRowNum):
                day             = tb.get(i, 0, 0, True)
                tasktype        = tb.get(i, 1, "", True)
                taskvalue       = tb.get(i, 2, "", True)
                taskrewards     = tb.get(i, 3, "", False).replace("\\n", "\n").replace("\"", "")
                taskdesc        = tb.get(i, 4, "", False).replace("\\n", "\n").replace("\"", "")
                taskreward      = taskrewards.split(";")
                rewardres = []
                rewarditem = []
                for reward in taskreward:
                    temp = reward.split(",")
                    if len(temp) == 3:
                        rewarditem.append((
                        int(temp[0]),
                        int(temp[1]),
                        int(temp[2])
                    ))
                    if len(temp) == 2:
                        rewardres.append((
                        int(temp[0]),
                        int(temp[1])
                    ))
                initData.append((day , tasktype , taskvalue , rewarditem , rewardres , taskdesc))
            self.InitData = initData
        else:
            syserr("Loading %s failed." % (rewardsFilename))
            return False

        return True

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_CREATED:
            player = param0
            player.s_sdtcangetrecord = [0,0,0,0,0,0,0]
            player.s_createtime = time.time()

        elif msg == MSG_PLAYER_LEVELUP:
            player = param0
            if "s_createtime" not in player.__dict__:
                player.s_createtime = time.time()
            if "s_sdtcangetrecord" not in player.__dict__:
                player.s_sdtcangetrecord = [0,0,0,0,0,0,0]
            
            day = self.getday(player)
            if day < 7 and day >= 0 :
                if self.InitData[day][1] == 1:
                    if player.s_sdtcangetrecord[day] == 0:
                        if player.getLevel() >= self.InitData[day][2]:
                            player.s_sdtcangetrecord[day] = 1
                            self.notifyActReward(player , True)
        elif msg == MSG_PLAYER_BATTLEPOINT_CHANGED:
            player = param0
            if "s_createtime" not in player.__dict__:
                player.s_createtime = time.time()
            if "s_sdtcangetrecord" not in player.__dict__:
                player.s_sdtcangetrecord = [0,0,0,0,0,0,0]

            day = self.getday(player)
            if day < 7 and day >= 0 :
                if self.InitData[day][1] == 2:
                    if player.s_sdtcangetrecord[day] == 0:
                        if player.getBattlePoint() >= self.InitData[day][2]:
                            player.s_sdtcangetrecord[day] = 1
                            self.notifyActReward(player , True)
        elif msg == MSG_PLAYER_ONLINE or msg == MSG_PLAYER_DAY_CHANGED:
            player = param0
            if "s_createtime" not in player.__dict__:
                player.s_createtime = time.time()
            if "s_sdtcangetrecord" not in player.__dict__:
                player.s_sdtcangetrecord = [0,0,0,0,0,0,0]
            
            day = self.getday(player)
            if day < 7 and day >= 0 :
                if self.InitData[day][1] == 1:
                    if player.s_sdtcangetrecord[day] == 0:
                        if player.getLevel() >= self.InitData[day][2]:
                            player.s_sdtcangetrecord[day] = 1
                elif self.InitData[day][1] == 2:
                    if player.s_sdtcangetrecord[day] == 0:
                        if player.getBattlePoint() >= self.InitData[day][2]:
                            player.s_sdtcangetrecord[day] = 1
            if player.s_sdtcangetrecord.count(1) != 0:
                self.notifyActReward(player , True)

    def getMenu(self, player, npcID):
        return []

ModuleID = 7
Instance = SevenDayTarget(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_CREATED,
    MSG_PLAYER_LEVELUP,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_BATTLEPOINT_CHANGED,
    MSG_PLAYER_DAY_CHANGED,
])