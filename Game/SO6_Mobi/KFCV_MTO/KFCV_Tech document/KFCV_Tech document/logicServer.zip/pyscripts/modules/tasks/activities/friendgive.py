# coding=utf-8
import engine
import MMain
import sys
import time
import json
import random
import bisect
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

VEVILALITY = 3
MAXGOTTIME = 40

class FriendGive(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        self.mID = moduleID
        self.mGlobal = {}
        self.mGotTime = {}
        self.mGiveData = {}
        self.mFriendData = []
    def getName(self):
        return "FriendGive"

    def isActived(self, player):
        return True

    def getInfo(self, player):
        playerName = player.getName()
        info = {}
        if playerName in self.mGlobal:
            temp = []
            playerData = self.mGlobal[playerName]
            for name in playerData:
                temp.append((name, playerData[name]))
            info["rewards"] = temp
        else:
            info["rewards"] = []
        info["onepoint"] = VEVILALITY
        if playerName in self.mGotTime:
            info["lefttime"] = MAXGOTTIME - self.mGotTime[playerName]
        else:
            info["lefttime"] = MAXGOTTIME
        return json.dumps(info)

    def doAction(self, player , actData):
        jdata = json.loads(actData)
        playerName = player.getName()
        if jdata["do"] == "give":
            targetName = jdata["name"]
            if isinstance(targetName, unicode):
                targetName = targetName.encode('utf-8')
            elif isinstance(targetName, int):
                targetName = "%s" % (targetName)
            playerGiveData = []
            if playerName in self.mGiveData:
                playerGiveData = self.mGiveData[playerName]
            if targetName in self.mGlobal:
                targetData = self.mGlobal[targetName]
                targetData[playerName] = time.time()
            else:
                targetData = {}
                targetData[playerName] = time.time()
                self.mGlobal[targetName] = targetData
            targetPlayer = MMain.getPlayerByName(targetName)
            if targetPlayer:
                self.notifyActReward(targetPlayer, True)
            playerGiveData.append(targetName)
            self.mGiveData[playerName] = playerGiveData
            return json.dumps({"Result":0,"do":"give","name":targetName,"ResultDesc":GlobalStrings[103]})

        elif jdata["do"] == "get":
            if playerName in self.mGlobal:
                playerData = self.mGlobal[playerName]
                playerTime = 0
                if playerName in self.mGotTime:
                    playerTime = self.mGotTime[playerName]
                if playerTime < MAXGOTTIME:
                    if jdata["gettype"] == 1:
                        temp = []
                        for targetName in playerData:
                            if playerTime < MAXGOTTIME:
                                temp.append(targetName)
                                player.addVitality(VEVILALITY)
                                MMain.dbLogActivityAddVitality(player, self.mID, VEVILALITY)
                                playerTime += 1
                            else:
                                break                        
                        for name in temp:
                            if name in playerData:
                                del playerData[name]
                        self.mGotTime[playerName] = playerTime
                        return json.dumps({"Result":0,"do":"get","gettype":jdata["gettype"],"ResultDesc":GlobalStrings[104]})
                    elif jdata["gettype"] == 0:
                        targetName = jdata["name"]
                        if isinstance(targetName, unicode):
                            targetName = targetName.encode('utf-8')
                        elif isinstance(targetName, int):
                            targetName = '%s'%(targetName)
                        if targetName in playerData:
                            player.addVitality(VEVILALITY)
                            MMain.dbLogActivityAddVitality(player, self.mID, VEVILALITY)
                            playerTime += 1
                            del playerData[targetName]
                        self.mGotTime[playerName] = playerTime
                        return json.dumps({"Result":0,"do":"get","name":targetName,"gettype":jdata["gettype"],"ResultDesc":GlobalStrings[104]})
                else:
                    return json.dumps({"Result":1,"do":"get","gettype":jdata["gettype"],"ResultDesc":GlobalStrings[105]})
            else:
                return json.dumps({"Result":-1,"do":"get","gettype":jdata["gettype"],"ResultDesc":"Unknow"})
    def getFriendGiveData(self, player):
        playerName = player.getName()
        if playerName in self.mGiveData:
            self.mFriendData = []
            for friendName in self.mGiveData[playerName]:
                if isinstance(friendName, unicode):
                    friendName = friendName.encode('utf-8')
                elif isinstance(friendName, int):
                    friendName = "%s" %(friendName)
                self.mFriendData.append(friendName)
            return self.mFriendData
        return []
    def loadConfig(self, path):
        return True

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)
            
            Globaldata = MMain.getSetting("FriendGiveGlobal")
            if Globaldata:
                self.mGlobal = Globaldata
            GotTimedata = MMain.getSetting("FriendGiveGotTime")
            if GotTimedata:
                self.mGotTime = GotTimedata
            GiveData = MMain.getSetting("FriendGiveGiveData")
            if GiveData:
                self.mGiveData = GiveData

        elif msg == MSG_PLAYER_ONLINE:
            player = param0
            playerName = player.getName()
            if playerName in self.mGlobal:
                if len(self.mGlobal[playerName]) > 0:
                    self.notifyActReward(player, True)
        elif msg == MSG_DAY_CHANGED:
            self.mGiveData = {}
            self.mGotTime = {}
        elif msg == MSG_TIME_MINUTE:
            curTime = time.time()
            curLTime = time.localtime(curTime)
            if (curLTime.tm_min % 5) == 2:
                MMain.setSetting("FriendGiveGlobal", self.mGlobal)
                MMain.setSetting("FriendGiveGotTime", self.mGotTime)
                MMain.setSetting("FriendGiveGiveData", self.mGiveData)
ModuleID = 46
Instance = FriendGive(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
    MSG_DAY_CHANGED,
    MSG_TIME_MINUTE,
])