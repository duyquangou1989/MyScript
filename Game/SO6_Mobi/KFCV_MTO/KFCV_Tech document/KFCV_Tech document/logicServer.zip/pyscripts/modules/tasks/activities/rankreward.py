#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

class RankReward(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        self.mID = moduleID
        self.mStartTime = 0

    def getName(self):
        return "RankReward"

    def isActived(self, player):
        return True

    def getCurDay(self):
        nowZero = self.getZerotimestamp()
        return int((nowZero - self.mStartTime) / 86400) + 1 

    def getInfo(self, player):
        result = {}
        result["ServerDay"] = self.getCurDay()
        result["StartTime"] = self.mStartTime
        result["EndTime"] = self.mStartTime + 7 * 86400
        return json.dumps(result)

    def doAction(self, player, actData):
        return Err_Ok

    def loadConfig(self, path):
        return True

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)
            startTime = MMain.getSetting("starttime")
            if startTime:
                self.mStartTime = startTime
            else:
                t = time.localtime(time.time())
                time1 = time.mktime(time.strptime(time.strftime('%Y-%m-%d 00:00:00', t),'%Y-%m-%d %H:%M:%S'))
                self.mStartTime = int(time1)
                MMain.setSetting("starttime", self.mStartTime)

ModuleID = 56
Instance = RankReward(ModuleID)

engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
])