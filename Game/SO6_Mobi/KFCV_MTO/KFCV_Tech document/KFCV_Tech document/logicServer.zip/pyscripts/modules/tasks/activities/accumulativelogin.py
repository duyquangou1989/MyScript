#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

class AccumulativeLogin(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID

        self.mRewards = {}
        self.mInitData = [0, 0, {}]                 #lastLoginTime, loginCount, GotRewardDay

    def isActived(self, player):
        return True

    def getName(self):
        return "AccumulativeLogin"

    def getInfo(self, player):
        data = self.getPlayerForeverData(player, self.mInitData)
        lastLoginTime = data[0]
        loginCount = data[1]

        rewards = []
        for day in self.mRewards:
            canGetReward = False
            gotRewardAlready = False
            if loginCount >= day:
                canGetReward = True
                if day in data[2]:
                    gotRewardAlready = True
            elif day in data[2]:
                gotRewardAlready = True

            rewards.append((
                day,
                self.mRewards[day][0],
                self.mRewards[day][1],
                canGetReward,
                gotRewardAlready,
            ))
        rewards.sort()

        info = {}
        info["LoginCount"] = loginCount
        info["Rewards"] = rewards

        return json.dumps(info)

    def doAction(self, player, actData):
        data = self.getPlayerForeverData(player, self.mInitData)

        actData = json.loads(actData)
        day = actData["Day"]

        if day in self.mRewards:
            if day not in data[2]:
                if data[1] >= day:
                    vipl = player.getVipLevel()
                    viplevel = self.mRewards[day][0]
                    rewards = self.mRewards[day][1]
                    doubrewards = []
                    if vipl >= viplevel and viplevel != 0:
                        for reward in rewards:
                            if len(reward) == 2:
                                doubrewards.append((reward[0],reward[1] * 2))
                            elif len(reward) == 3:
                                doubrewards.append((reward[0], reward[1], reward[2] * 2))
                    if len(doubrewards) > 0:
                        rewards = doubrewards
                    if self.canAddAllReward(player, rewards):
                        data[2][day] = True
                        for reward in rewards:
                            self.addReward(player, reward)
                        self.checkHasReward(player)
                        if day == 15:
                            #setModuleData(player, self.mID, self.mInitData)
                            self.setPlayerForeverData(player, self.mInitData)
                        player.saveToDB()
                        return Err_Ok
                    else:
                        return Err_NotEnoughSpace
                else:
                    return Err_Cannot
            else:
                return Err_Repetition
        else:
            return Err_Invalid

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)

        syslog("Loading AccumulativeLogin config...")

        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = {}
            for i in xrange(tb.mRowNum):
                offset = 0;

                day = tb.get(i, 0, 0, True)
                viplevel = tb.get(i, 1, 0, True)
                rewardValue = tb.get(i, 2, "", False).replace("\"", "").replace(";", "")

                tmpItems = []
                itemBlocks = rewardValue.split(",")
                if len(itemBlocks) == 3:
                    tmpItems.append((
                        int(itemBlocks[0]),
                        int(itemBlocks[1]),
                        int(itemBlocks[2]),
                    ))
                if len(itemBlocks) == 2:
                    tmpItems.append((
                        int(itemBlocks[0]),
                        int(itemBlocks[1]),
                    ))
                rewardValue = tmpItems

                if day in rewards:
                    syserr("AccumulativeLogin Reward day %s already exists." % (day))
                    return False
                else:
                    rewards[day] = (viplevel, rewardValue)

            self.mRewards = rewards
            return True

        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False

    def checkHasReward(self, player):
        data = self.getPlayerForeverData(player, self.mInitData)

        hasReward = False
        for i in xrange(data[1]):
            day = i + 1
            if day not in data[2] and day <= 15:
                hasReward = True
                break

        self.notifyActReward(player, hasReward)

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_ONLINE or msg == MSG_PLAYER_DAY_CHANGED:
            player = param0

            data = self.getPlayerForeverData(player, self.mInitData)

            lastLoginTime = data[0]
            loginCount = data[1]

            curLoginTime = int(time.time())

            lastLTime = time.localtime(lastLoginTime)
            curLTime = time.localtime(curLoginTime) 

            if lastLTime.tm_year == curLTime.tm_year and lastLTime.tm_mon == curLTime.tm_mon and lastLTime.tm_mday == curLTime.tm_mday:
                pass
            else:
                data[0] = curLoginTime
                data[1] += 1

            self.checkHasReward(player)

    def getMenu(self, player, npcID):
        return []

ModuleID = 15
Instance = AccumulativeLogin(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_DAY_CHANGED,
])
