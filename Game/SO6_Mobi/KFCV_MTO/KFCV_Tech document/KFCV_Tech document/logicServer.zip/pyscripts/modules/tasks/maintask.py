#coding=utf8

import engine
import MMain
import sys
import random
import time
from tabfile import TabFile
from messages import *
from gamedefines import *

REWARD_TYPE_MONEY               = 1     # 银币
REWARD_TYPE_GOLDMONEY           = 2     # 金币
REWARD_TYPE_GOLDMONEY_PURCHASED = 3     # 真金
REWARD_TYPE_VITALITY            = 4     # 体力
REWARD_TYPE_EXPERIENCE          = 5     # 经验
REWARD_TYPE_ENERGY              = 6     # 真气
REWARD_TYPE_SPAR                = 7     # 晶石

# MMain.sendTaskNotify - 修改客户端的任务跟踪
# 第二个参数：
# 0 = 修改
# 1 = 删除
# 第三个参数：信息内容

#任务条件类型
TYPE_LOGIN              = 1#  登录
TYPE_LEVEL              = 2#  达到等级
TYPE_VIP_LEVEL          = 3#  达到VIP等级
TYPE_GET_MONEY          = 4#  获得金币
TYPE_BATTLE_POINT       = 5#  达到战力
TYPE_THIS_DUNGEON       = 6#  完成指定副本
TYPE_DUNGEON_NUM        = 7#  完成副本数量
TYPE_HARD_DUNGEON       = 8#  完成困难副本数量
TYPE_THIS_TASK          = 9#  完成指定任务
TYPE_TASK_NUM           = 10#  完成任务数量
TYPE_DAILY_TASK         = 11#  完成日常任务
TYPE_ARENA              = 12#  挑战竞技场
TYPE_ARENA_WIN          = 13#  获得竞技场胜利次数
TYPE_ROLE_TRAIN         = 14#  角色强化
TYPE_ITEM_DROP          = 15#  道具分解
TYPE_ITEM_EXCHANGE      = 16#  道具兑换
TYPE_ITEM_ADVANCE       = 17#  道具进阶
TYPE_ITEM_UPGRADE       = 18#  道具升级
TYPE_ITEM_STRENGTH      = 19#  道具强化(进阶和升级都是强化)
TYPE_SKILL_ADVANCE      = 20#  技能进阶
TYPE_SKILL_UPGARDE      = 21#  技能升级
TYPE_SKILL_STRENGTH     = 22#  技能强化(进阶和升级都是强化)
TYPE_TALENT_ADVANCE     = 23#  心法进阶(备用)
TYPE_TALENT_UPGRADE     = 24#  心法升级
TYPE_TALENT_STRENGTH    = 25#  心法强化(备用)
TYPE_STONE_USE          = 26#  镶嵌石头
TYPE_STONE_COMBINE      = 27#  合成石头
TYPE_SINGLE_PVP         = 28#  单人PVP
TYPE_SINGLE_BOSS        = 29#  单人BOSS
TYPE_MULT_BOSS          = 30#  多人BOSS
TYPE_BUY_MONEY          = 31#  金币兑换
TYPE_LOTTERY            = 32#  抽奖
TYPE_JOIN_GUILD         = 33#  加入公会
TYPE_FRIEND             = 34#  好友
TYPE_EIGHTEEN           = 35#  十八摸
TYPE_ESCORT             = 36#  护送
TYPE_MONEYDUNGEON       = 37#  雪月密境，
TYPE_ENDLESS            = 38#  无尽之塔
TYPE_PROTECTATHENA      = 39#  守卫佛塔
TYPE_UPGRADEPET         = 40#  升级宠物

TASK_STATUS_ACCEPTED            = 1
TASK_STATUS_COMPLETED           = 2
TASK_STATUS_OVER                = 3

TASK_TYPE_MAIN                  = 1 #主线
TASK_TYPE_BRANCH                = 2 #支线

#任务表结构
TASK_DATA_ID                    = 0
TASK_DATA_TYPE                  = 1
TASK_DATA_NAME                  = 2
TASK_DATA_TALK_BEGIN            = 3
TASK_DATA_TALK_END              = 4
TASK_DATA_PRETASK               = 5
TASK_DATA_LEVELLIMITATION       = 6
TASK_DATA_JOB                   = 7
TASK_DATA_REWARD_EXP            = 8
TASK_DATA_REWARD_MONEY          = 9
TASK_DATA_REWARD_ITEMS          = 10
TASK_DATA_DESC                  = 11
TASK_DATA_DUNGEONID             = 12
TASK_DATA_OPERATION             = 13
TASK_DATA_PARAM_1               = 14
TASK_DATA_PARAM_2               = 15
TASK_DATA_PARAM_3               = 16
TASK_DATA_COUNT                 = 17

#战役奖励表结构
BR_BATTLEID                     = 0
BR_DEGREE                       = 1
BR_NAME                         = 2
BR_STAGE1                       = 3
BR_REWARD1                      = 4
BR_STAGE2                       = 5
BR_REWARD2                      = 6
BR_STAGE3                       = 7
BR_REWARD3                      = 8
BR_COUNT                        = 9

#初始数据
InitDungeonID                   = 20100
InitTaskID                      = 100001
BossDungeonNum                  = 7

TASK_DETAIL_STATUS              = 0
TASK_DETAIL_DATA                = 1

SECOND_DUNGEONID                  = 20109
THIRD_VIPLEVEL                    = 4
THIRD_DUNGEONID                   = 20329
THIRD_LEVEL                       = 40

class MainTask:
    def __init__(self, moduleID):
        self.mID = moduleID
        self.mColor = ["2EE43E","2EE43E","2EE43E","13b1ff","13b1ff","13b1ff","AE2DE6","AE2DE6","AE2DE6","E68D2D","E68D2D","E68D2D"]
        self.mArenaTop = []
        self.mArenaTop3Name = {}
        self.mTaskTables = {}
        self.mTaskByDungeon = {}     #dungeonid:taskid
        self.mPreTask = {}
        self.mInitTask = {InitTaskID:[0,0,],}           #taskid:[status,data]

        self.mTaskData =  [
            {},             # 未完成的任务id:[status,data]
            {},             # 完成了的任务id:[status,data]
            {},             # 解锁但等级限制的任务id:level
        ]

        isLoadOk = True
        isLoadOk &= self.loadTask("settings/task.txt")

        if not isLoadOk:
            syserr("Load settings/task.txt failed.")
            sys.exit(1)

        self.mDungeon = {}          #dungeonID:[preDungeonID, battleID,]
        self.mBattle = {}           #battleID:[dungeonID,]
        self.mBattleDegree = {}     #battleID:[degree:[dungeonID, ],]
        self.mBattleRewards = {}    #battleID:[]
        self.mPreDungeon = {}       #preDungeonID:[dungeonID,]
        self.mBattleFirstDungeon = {} #battleID:fdungeonID

        self.mBossDungeon = {}      #level:[dungeonID,]
        self.mBossDungeonNum = BossDungeonNum
        self.mBoss = {}             #wday:[index,]
        self.mCurBossIndex = []

        isLoadOk &= self.loadDungeon("settings/dungeon.txt")
        if not isLoadOk:
            syserr("Load settings/dungeon.txt failed")
            sys.exit(1)

        isLoadOk &= self.loadSingleBoss("settings/activity/singleboss/singleboss.txt")
        if not isLoadOk:
            syserr("Load settings/activity/singleboss/singleboss.txt failed")
            sys.exit(1)

        isLoadOk &= self.loadBattleReward("settings/battles.txt")
        if not isLoadOk:
            syserr("Load settings/battles.txt failed")
            sys.exit(1)

        self.mStartTime = 0
        self.m7Day = {}
        # isLoadOk &= self.load7days("settings/activity/accumulativelogin7/rewards.txt")
        # if not isLoadOk:
        #     syserr("Load settings/activity/accumulativelogin7/rewards.txt failed")
        #     sys.exit(1)

    def getItemColor(self, itemQuality):
        if itemQuality >= 0 and itemQuality < len(self.mColor):
            return self.mColor[itemQuality]
        else:
            return "FFFFFF"

    def loadDungeon(self, filename):
        syslog("Loading dungeon...")

        tb = TabFile()
        if tb.load(filename):
            for i in xrange(tb.mRowNum):

                dungeonID               = tb.get(i, 0, -1, True)
                level                   = tb.get(i, 9, -1, True)
                prestr                  = tb.get(i, 11, "", False)
                preDungeons = []
                if prestr:
                    preDungeons = [int(value) for value in prestr.split(";") if value]
                degree                  = tb.get(i, 14, -1, True)
                battleID                = tb.get(i, 19, -1, True)

                t = dungeonID / 10000
                if t == 2:
                    self.mDungeon[dungeonID] = [preDungeons, battleID, degree,]

                if t == 3:
                    if level in self.mBossDungeon:
                        self.mBossDungeon[level].append(dungeonID)
                    else:
                        self.mBossDungeon[level] = []
                        self.mBossDungeon[level].append(dungeonID)

            # check pretask valid
            for dungeonID in self.mDungeon:
                battleID = self.mDungeon[dungeonID][1]
                if battleID in self.mBattle:
                    self.mBattle[battleID].append(dungeonID)
                else:
                    self.mBattle[battleID] = []
                    self.mBattle[battleID].append(dungeonID)

                if battleID in self.mBattleFirstDungeon:
                    if self.mBattleFirstDungeon[battleID] > dungeonID:
                        self.mBattleFirstDungeon[battleID] = dungeonID
                else:
                    self.mBattleFirstDungeon[battleID] = dungeonID

                preDungeons = self.mDungeon[dungeonID][0]
                for preDungeonID in preDungeons:
                    if preDungeonID != 0 and preDungeonID not in self.mDungeon:
                        syserr("DungeonID's %s preDungeonID %s is invalid" % (dungeonID, preDungeonID))
                        return False

                    if preDungeonID in self.mPreDungeon:
                        self.mPreDungeon[preDungeonID].append(dungeonID)
                    else:
                        self.mPreDungeon[preDungeonID] = [dungeonID, ]

            # check boss dungeon len
            for level in self.mBossDungeon:
                if len(self.mBossDungeon[level]) != self.mBossDungeonNum:
                    syserr("Load boss dungeon config failed...")
                    return False

            return True
        else:
            syserr("Load dungeon config failed...")
            return False

    def loadSingleBoss(self, filename):
        syslog("Loading single Boss...")

        tb = TabFile()
        if tb.load(filename):
            for i in xrange(tb.mRowNum):

                wday                    = tb.get(i, 0, -1, True)
                boss1                   = tb.get(i, 1, 0, True)
                boss2                   = tb.get(i, 2, 0, True)
                boss3                   = tb.get(i, 3, 0, True)

                if wday in self.mBoss:
                    return False

                self.mBoss[wday] = (boss1, boss2, boss3)

            return True
        else:
            syserr("Load single Boss failed...")
            return False

    def loadBattleReward(self, filename):
        syslog("Loading battleReward...")

        tb = TabFile()
        if tb.load(filename):
            for i in xrange(tb.mRowNum):
                br = [None for j in xrange(BR_COUNT)]

                br[BR_BATTLEID]                     = tb.get(i, BR_BATTLEID, 0, True)
                br[BR_DEGREE]                       = tb.get(i, BR_DEGREE, 0, True)
                br[BR_NAME]                         = tb.get(i, BR_NAME, "", False)
                br[BR_STAGE1]                       = tb.get(i, BR_STAGE1, 0, True)
                tempreward1                         = tb.get(i, BR_REWARD1, "", False).replace("\"", "")
                if tempreward1:
                    br[BR_REWARD1]                  = [
                        [int(value) for value in reward.split(",")]
                            for reward in tempreward1.split(";") if reward and reward.count(',') in (1, 2)
                    ]
                else:
                    br[BR_REWARD1]                  = []

                br[BR_STAGE2]                       = tb.get(i, BR_STAGE2, 0, True)
                tempreward2                         = tb.get(i, BR_REWARD2, "", False).replace("\"", "")
                if tempreward2:
                    br[BR_REWARD2]                  = [
                        [int(value) for value in reward.split(",")]
                            for reward in tempreward2.split(";") if reward and reward.count(',') in (1, 2)
                    ]
                else:
                    br[BR_REWARD2]                  = []

                br[BR_STAGE3]                       = tb.get(i, BR_STAGE3, 0, True)
                tempreward3                         = tb.get(i, BR_REWARD3, "", False).replace("\"", "")
                if tempreward3:
                    br[BR_REWARD3]                  = [
                        [int(value) for value in reward.split(",")]
                            for reward in tempreward3.split(";") if reward and reward.count(',') in (1, 2)
                    ]
                else:
                    br[BR_REWARD3]                  = [] 

                battleID = br[BR_BATTLEID]
                if battleID in self.mBattleRewards:
                    self.mBattleRewards[battleID].append(br)
                else:
                    self.mBattleRewards[battleID] = [br, ]
            
            return True
        else:
            syserr("Load BattleReward failed...")
            return False

    def loadTask(self, filename):
        syslog("Loading task...")

        tb = TabFile()
        if tb.load(filename):
            for i in xrange(tb.mRowNum):
                task = [None for j in xrange(TASK_DATA_COUNT)]

                task[TASK_DATA_ID]                  = tb.get(i, TASK_DATA_ID, -1, True)
                task[TASK_DATA_TYPE]                = tb.get(i, TASK_DATA_TYPE, -1, True)
                task[TASK_DATA_NAME]                = tb.get(i, TASK_DATA_NAME, "", False)
                task[TASK_DATA_TALK_BEGIN]          = tb.get(i, TASK_DATA_TALK_BEGIN, "", False)
                task[TASK_DATA_TALK_END]            = tb.get(i, TASK_DATA_TALK_END, "", False)
                task[TASK_DATA_PRETASK]             = tb.get(i, TASK_DATA_PRETASK, 0, True)
                task[TASK_DATA_LEVELLIMITATION]     = tb.get(i, TASK_DATA_LEVELLIMITATION, -1, True)
                task[TASK_DATA_JOB]                 = tb.get(i, TASK_DATA_JOB, -1, True)
                task[TASK_DATA_REWARD_EXP]          = tb.get(i, TASK_DATA_REWARD_EXP, 0, True)
                task[TASK_DATA_REWARD_MONEY]        = tb.get(i, TASK_DATA_REWARD_MONEY, 0, True)
                tmpItems                            = tb.get(i, TASK_DATA_REWARD_ITEMS, "", False).replace("\"", "")
                if tmpItems:
                    task[TASK_DATA_REWARD_ITEMS]    = [
                        [int(value) for value in reward.split(",")] 
                            for reward in tmpItems.split(";") if reward and reward.count(',') in (1, 2)
                    ]
                else:
                    task[TASK_DATA_REWARD_ITEMS]    = []
                task[TASK_DATA_OPERATION]           = tb.get(i, TASK_DATA_OPERATION, 0, True)
                task[TASK_DATA_PARAM_1]             = tb.get(i, TASK_DATA_PARAM_1, 0, True)
                task[TASK_DATA_PARAM_2]             = tb.get(i, TASK_DATA_PARAM_2, 0, True)
                task[TASK_DATA_PARAM_3]             = tb.get(i, TASK_DATA_PARAM_3, 0, True)

                self.mTaskTables[task[TASK_DATA_ID]] = task

            # check pretask valid
            for taskID in self.mTaskTables:
                task = self.mTaskTables[taskID]
                preTaskID = task[TASK_DATA_PRETASK]
                if preTaskID != 0 and preTaskID not in self.mTaskTables:
                    syserr("Task %s pretaskID %s is invalid" % (taskID, preTaskID))
                    return False
                if preTaskID != 0 and preTaskID in self.mTaskTables:
                    if preTaskID in self.mPreTask:
                        self.mPreTask[preTaskID].append(taskID)
                    else:
                        self.mPreTask[preTaskID] = [taskID, ]

                if task[TASK_DATA_OPERATION] == 6:
                    self.mTaskByDungeon[task[TASK_DATA_PARAM_1]] = taskID

            return True
        else:
            syserr("Load task config failed...")
            return False

    def load7days(self, filename):
        syslog("Loading 7day...")

        tb = TabFile()
        if tb.load(filename):
            for i in xrange(tb.mRowNum):

                day                                 = tb.get(i, 0, 0, True)
                tempreward1                         = tb.get(i, 1, "", False).replace("\"", "")
                if tempreward1:
                    reward                          = [
                        [int(value) for value in reward.split(",")]
                            for reward in tempreward1.split(";") if reward and reward.count(',') in (1, 2)
                    ]
                else:
                    reward                          = []

                self.m7Day[day] = reward

            return True
        else:
            syserr("Load 7day failed...")
            return False

    def initTask(self, player):
        moduleData = getModuleData(player, self.mID, self.mTaskData)
        moduleData[0] = self.mInitTask
        setModuleData(player, self.mID, moduleData)
        
        # 任务在玩家身上的结构[当前状态（0=未完成，1=完成）, 任务数据]
    
    def isTaskValid(self, taskID):
        if taskID in self.mTasks:
            return True
        else:
            return False

    def buildTaskList(self, player):
        taskList = []                   ##(taskID, valid, finished, data)
        moduleData = getModuleData(player, self.mID, self.mTaskData)
        if len(moduleData) != 3:
            return taskList
        #-ing task
        for taskID in moduleData[0]:
            taskdetail = moduleData[0][taskID]
            if taskID in self.mTaskTables:
                task = self.mTaskTables[taskID]
                taskList.append((
                    taskID,
                    1,
                    0,
                    taskdetail[TASK_DETAIL_DATA],
                ))
        #-finished task
        for taskID in moduleData[1]:
            taskdetail = moduleData[1][taskID]
            if taskID in self.mTaskTables:
                task = self.mTaskTables[taskID]
                taskList.append((
                    taskID,
                    1,
                    1,
                    taskdetail[TASK_DETAIL_DATA],
                ))
        #-valid task
        for taskID in moduleData[2]:
            if taskID in self.mTaskTables:
                taskList.append((
                    taskID,
                    0,
                    0,
                    0,
                ))
        return taskList
    
    def doTask(self, player, taskType, extra):
        moduleData = getModuleData(player, self.mID, self.mTaskData)
        for taskID in moduleData[0]:
            task = self.mTaskTables[taskID]
            if task[TASK_DATA_OPERATION] == taskType:
                if taskType == TYPE_LOGIN:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_LEVEL:
                    moduleData[0][taskID][TASK_DETAIL_DATA] = extra
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_VIP_LEVEL:
                    moduleData[0][taskID][TASK_DETAIL_DATA] = extra
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_GET_MONEY:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += extra
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1  
                elif taskType == TYPE_BATTLE_POINT:
                    moduleData[0][taskID][TASK_DETAIL_DATA] = extra
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_THIS_DUNGEON and extra == task[TASK_DATA_PARAM_1]:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                        
                elif taskType == TYPE_DUNGEON_NUM:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_HARD_DUNGEON:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_THIS_TASK:
                    pass
                elif taskType == TYPE_TASK_NUM:
                    pass
                elif taskType == TYPE_DAILY_TASK:
                    pass
                elif taskType == TYPE_ARENA:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_ARENA_WIN:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_ROLE_TRAIN:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_ITEM_DROP:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_ITEM_EXCHANGE:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_ITEM_ADVANCE:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_ITEM_UPGRADE:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_ITEM_STRENGTH:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                
                elif taskType == TYPE_SKILL_ADVANCE:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_SKILL_UPGARDE:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_SKILL_STRENGTH:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_TALENT_ADVANCE:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_TALENT_UPGRADE:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_TALENT_STRENGTH:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1

                elif taskType == TYPE_STONE_USE:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_STONE_COMBINE:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_SINGLE_PVP:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_SINGLE_BOSS:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_MULT_BOSS:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1  

                elif taskType == TYPE_BUY_MONEY:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_LOTTERY:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_JOIN_GUILD:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_FRIEND:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1
                elif taskType == TYPE_EIGHTEEN:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1  
                elif taskType == TYPE_ESCORT:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1  
                elif taskType == TYPE_MONEYDUNGEON:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1 
                elif taskType == TYPE_ENDLESS:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1 
                elif taskType == TYPE_PROTECTATHENA:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1 
                elif taskType == TYPE_UPGRADEPET:
                    moduleData[0][taskID][TASK_DETAIL_DATA] += 1
                    if moduleData[0][taskID][TASK_DETAIL_DATA] >= task[TASK_DATA_PARAM_1]:
                        moduleData[0][taskID][TASK_DETAIL_STATUS] = 1 

        self.checkCompleteTask(player)            

    def checkCompleteTask(self, player):
        moduleData = getModuleData(player, self.mID, self.mTaskData)
        for taskID in moduleData[0]:
            taskData = moduleData[0][taskID]
            if taskData[TASK_DETAIL_STATUS] == 1:
                moduleData[1][taskID] = taskData
                self.sendTaskNotify(player, taskID, 1, taskData[TASK_DETAIL_STATUS], taskData[TASK_DETAIL_DATA])
        for taskID in moduleData[1]:
            if taskID in moduleData[0]:
                del moduleData[0][taskID]

    def completeTask(self, player, taskID):
        moduleData = getModuleData(player, self.mID, self.mTaskData)
        if taskID in moduleData[1]:
            MMain.completeTask(player, taskID, 1)
            #getReward
            self.getRewardByTask(player, taskID)
            player.s_task[taskID] = 0

            nextTaskIDList = self.getNextTaskID(taskID)
            for i in nextTaskIDList:
                self.invokeTask(player, i)
            del moduleData[1][taskID]
            return True

        MMain.completeTask(player, taskID, 0)
        return False

    def getRewardByTask(self, player, taskID):
        if taskID in self.mTaskTables:
            task = self.mTaskTables[taskID]
            money = task[TASK_DATA_REWARD_MONEY]
            exp = task[TASK_DATA_REWARD_EXP]
            items = task[TASK_DATA_REWARD_ITEMS]
            if money > 0:
                player.addMoney(money)
                MMain.dbLogTaskAddMoney(player, taskID, money)
            if exp > 0:
                player.addExperience(exp)
                MMain.dbLogTaskAddExperience(player, taskID, money)
            if items:
                for reward in items:
                    if len(reward) == 3:
                            MMain.addItemToPlayer(player, MMain.createItem(reward[0], reward[1], reward[2]))
                            MMain.dbLogActivityAddItem(player, self.mID, reward[0], reward[1], reward[2])

                    elif len(reward) == 2:
                        rewardType = reward[0]
                        rewardValue = reward[1]

                        if rewardType == REWARD_TYPE_MONEY:
                            player.addMoney(rewardValue)
                            MMain.dbLogActivityAddMoney(player, self.mID, rewardValue)

                        elif rewardType == REWARD_TYPE_GOLDMONEY:
                            player.addGoldMoney(rewardValue)
                            MMain.dbLogActivityAddGoldMoney(player, self.mID, rewardValue)

                        elif rewardType == REWARD_TYPE_GOLDMONEY_PURCHASED:
                            pass

                        elif rewardType == REWARD_TYPE_VITALITY:
                            player.addVitality(rewardValue)
                            MMain.dbLogActivityAddVitality(player, self.mID, rewardValue)

                        elif rewardType == REWARD_TYPE_EXPERIENCE:
                            player.addExperience(rewardValue)
                            MMain.dbLogActivityAddExperience(player, self.mID, rewardValue)

                        elif rewardType == REWARD_TYPE_ENERGY:
                            player.addEnergy(rewardValue)
                            MMain.dbLogActivityAddEnergy(player, self.mID, rewardValue)

                        elif rewardType == REWARD_TYPE_SPAR:
                            player.addSpar(rewardValue)
                            MMain.dbLogActivityAddSpar(player, self.mID, rewardValue)
                        
    def getNextTaskID(self, preTaskID):
        if preTaskID in self.mPreTask:
            return self.mPreTask[preTaskID]
        else:
            return []

    def invokeTask(self, player, taskID):
        moduleData = getModuleData(player, self.mID, self.mTaskData)

        if taskID in self.mTaskTables and taskID not in moduleData[0] and taskID not in moduleData[1]:
            task = self.mTaskTables[taskID]
            taskData = []
            if player.getLevel() >= task[TASK_DATA_LEVELLIMITATION]:
                taskData = [0, 0]
                moduleData[0][taskID] = taskData
                self.sendTaskNotify(player, taskID, 1, 0, 0)
            else:
                moduleData[2][taskID] = task[TASK_DATA_LEVELLIMITATION]
                self.sendTaskNotify(player, taskID, 0, 0, 0)
        
    def initDungeon(self, player):
        self.checkInit(player)

        # unLock first dungeon
        if InitDungeonID not in player.s_Dungeon:
            player.s_Dungeon[InitDungeonID] = 0

    def buildDungeonList(self, player, battleID):
        self.checkInit(player)
        if battleID <= 0:
            battleID = 1

        dungeonList = []
        if battleID in self.mBattle:
            dungeonIDList = self.mBattle[battleID]
            for dungeonID in dungeonIDList:
                lock = 0
                star = 0
                count = 0
                if dungeonID not in player.s_Dungeon:
                    lock = 1
                if dungeonID in player.s_Dungeon:
                    star = player.s_Dungeon[dungeonID]
                if dungeonID in player.s_DungeonCount:
                    count = player.s_DungeonCount[dungeonID]
                dungeonList.append((
                    dungeonID,
                    lock,
                    star,
                    count
                ))

        return dungeonList                            
        
    def buildBossDungeonList(self):
        if not self.mCurBossIndex:
            t = time.localtime(time.time())
            self.mCurBossIndex = self.mBoss[t.tm_wday]
            ##self.mCurBossIndex = random.sample(range(BossDungeonNum), 3)
        dungeonList = []
        for level in self.mBossDungeon:
            for i in self.mCurBossIndex:
                dungeonList.append((
                    self.mBossDungeon[level][i],
                    level,
                    ))
        return dungeonList

    def invokeDungeon(self, player, dungeonID):
        if dungeonID in self.mPreDungeon:
            invokeDungeons = self.mPreDungeon[dungeonID]
            for dunid in invokeDungeons:
                if dunid in self.mDungeon:
                    caninvoke = True
                    tPres = self.mDungeon[dunid][0]
                    for i in tPres:
                        if self.isLockDungeon(player, i) or self.getDungeonStar(player, i) == 0:
                            caninvoke = False
                            break
                    if caninvoke:
                        self.unLockDungeon(player, dunid)

    def completeDungeon(self, player, dungeonID, star):
        if dungeonID in player.s_Dungeon:
            if player.s_Dungeon[dungeonID] < star:
                player.s_Dungeon[dungeonID] = star
        else:
            player.s_Dungeon[dungeonID] = star
            
        if dungeonID in player.s_DungeonCount:
            player.s_DungeonCount[dungeonID] += 1
        else:
            player.s_DungeonCount[dungeonID] = 1
        self.invokeDungeon(player, dungeonID)

    def isLockDungeon(self, player, dungeonID):
        if "s_Dungeon" in player.__dict__:
            if dungeonID not in player.s_Dungeon:
                return True
            return False
        return True

    def unLockDungeon(self, player, dungeonID):
        self.checkInit(player)

        if dungeonID in self.mDungeon and dungeonID not in player.s_Dungeon:
            battleID = self.mDungeon[dungeonID][1]
            if battleID > player.getBattleID():
                player.setBattleID(battleID)
                self.sendBattleNotify(player)
            self.sendDungeonNotify(player, dungeonID, 1)
            player.s_Dungeon[dungeonID] = 0

    def getDungeonReset(self, player, dungeonID):
        if "s_DungeonReset" in player.__dict__:
            if dungeonID in player.s_DungeonReset:
                return player.s_DungeonReset[dungeonID]
        return 0

    def resetDungeon(self, player, dungeonID):
        self.checkInit(player)
        
        if dungeonID == 0:
            player.s_DungeonCount = {}
            player.s_DungeonReset = {}
        else:
            player.s_DungeonCount[dungeonID] = 0
            if dungeonID in player.s_DungeonReset:
                player.s_DungeonReset[dungeonID] += 1
            else:
                player.s_DungeonReset[dungeonID] = 1
        
    def getDungeonStar(self, player, dungeonID):
        if "s_Dungeon" in player.__dict__:
            if dungeonID in player.s_Dungeon:
                return player.s_Dungeon[dungeonID]
        return 0
    
    def getBattleRewardOver(self, player, battleID):
        if "s_BattleReward" not in player.__dict__:
            player.s_BattleReward = []

        result = []
        for battleReward in player.s_BattleReward:
            if battleReward[0] == battleID:
                result.append(battleReward)

        return result

    def getBattleReward(self, player, battleID, degree, stage):
        if "s_BattleReward" not in player.__dict__:
            player.s_BattleReward = []

        alreadyGet = False
        result = -1
        for battleReward in player.s_BattleReward:
            if battleReward[0] == battleID and battleReward[1] == degree and battleReward[2] == stage:
                alreadyGet = True
                break
        if not alreadyGet:
            sNum = 0
            needNum = 0
            rewards = []
            if battleID in self.mBattleRewards:
                for battleReward in self.mBattleRewards[battleID]:
                    if battleReward[BR_DEGREE] == degree:
                        if stage == 1:
                            needNum = battleReward[BR_STAGE1]
                            rewards = battleReward[BR_REWARD1]
                        elif stage == 2:
                            needNum = battleReward[BR_STAGE2]
                            rewards = battleReward[BR_REWARD2]
                        elif stage == 3:
                            needNum = battleReward[BR_STAGE3]
                            rewards = battleReward[BR_REWARD3]
                        break

                for dungeonID in self.mBattle[battleID]:
                    if degree == self.mDungeon[dungeonID][2]:
                        if 3 == self.getDungeonStar(player, dungeonID):
                            sNum += 1
                if sNum >= needNum:
                    player.s_BattleReward.append((battleID, degree, stage))
                    
                    for reward in rewards:
                        if len(reward) == 3:
                                MMain.addItemToPlayer(player, MMain.createItem(reward[0], reward[1], reward[2]))
                                MMain.dbLogActivityAddItem(player, self.mID, reward[0], reward[1], reward[2])

                        elif len(reward) == 2:
                            rewardType = reward[0]
                            rewardValue = reward[1]

                            if rewardType == REWARD_TYPE_MONEY:
                                player.addMoney(rewardValue)
                                MMain.dbLogActivityAddMoney(player, self.mID, rewardValue)

                            elif rewardType == REWARD_TYPE_GOLDMONEY:
                                player.addGoldMoney(rewardValue)
                                MMain.dbLogActivityAddGoldMoney(player, self.mID, rewardValue)

                            elif rewardType == REWARD_TYPE_GOLDMONEY_PURCHASED:
                                pass

                            elif rewardType == REWARD_TYPE_VITALITY:
                                player.addVitality(rewardValue)
                                MMain.dbLogActivityAddVitality(player, self.mID, rewardValue)

                            elif rewardType == REWARD_TYPE_EXPERIENCE:
                                player.addExperience(rewardValue)
                                MMain.dbLogActivityAddExperience(player, self.mID, rewardValue)

                            elif rewardType == REWARD_TYPE_ENERGY:
                                player.addEnergy(rewardValue)
                                MMain.dbLogActivityAddEnergy(player, self.mID, rewardValue)

                            elif rewardType == REWARD_TYPE_SPAR:
                                player.addSpar(rewardValue)
                                MMain.dbLogActivityAddSpar(player, self.mID, rewardValue) 
                                
                    player.saveToDB()
                    result = 1
                else:
                    result = 18
        else:
            result = 14

        return result

    def getDungeonCount(self, player, dungeonID):
        if "s_DungeonCount" in player.__dict__:
            if dungeonID in player.s_DungeonCount:
                return player.s_DungeonCount[dungeonID]
        return 0

    def getDungeonPPH(self, player, dungeonID):
        if "s_DungeonPPH" in player.__dict__:
            if dungeonID in player.s_DungeonPPH:
                return player.s_DungeonPPH[dungeonID]
        return 0

    def setDungeonPPH(self, player, dungeonID, hit):
        if "s_DungeonPPH" in player.__dict__:
            if hit == 1:
                player.s_DungeonPPH[dungeonID] = 0
            else:
                if dungeonID in player.s_DungeonPPH:
                    player.s_DungeonPPH[dungeonID] += 1
                else:
                    player.s_DungeonPPH[dungeonID] = 1

    def setJoinGuildCD(self, player):
        player.s_JoinGuildCD = True

    def getJoinGuildCD(self, player):
        if "s_JoinGuildCD" not in player.__dict__:
            player.s_JoinGuildCD = False
        return player.s_JoinGuildCD
        
    ###公会建设数据存储
    def getBuildProgress(self, guild):
        if "s_guildprogress" not in guild.__dict__:
           guild.s_guildprogress = 0
        return guild.s_guildprogress

    def setBuildProgress(self, guild,value):
        if "s_guildprogress" not in guild.__dict__:
           guild.s_guildprogress = 0
        guild.s_guildprogress += value

    def getBuildTimes(self, guild, uuid, btype):
        if "s_guildbuildtimes" not in guild.__dict__:
            guild.s_guildbuildtimes = {}
        if uuid not in  guild.s_guildbuildtimes:
            guild.s_guildbuildtimes[uuid] = [0,0]
        if btype == 1:
            return guild.s_guildbuildtimes[uuid][0]
        elif btype == 2:
            return guild.s_guildbuildtimes[uuid][1]
        else:
            return -1

    def setBuildTimes(self, guild, uuid, btype):
        if "s_guildbuildtimes" not in guild.__dict__:
            guild.s_guildbuildtimes = {}
        if uuid not in  guild.s_guildbuildtimes:
            guild.s_guildbuildtimes[uuid] = [0,0]
        if btype == 1:
            guild.s_guildbuildtimes[uuid][0] = guild.s_guildbuildtimes[uuid][0] + 1
        elif btype == 2:
            guild.s_guildbuildtimes[uuid][1] = guild.s_guildbuildtimes[uuid][1] + 1

    def resetBuildInfo(self, guild):
        if "s_guildprogress" in guild.__dict__:
            guild.s_guildprogress = 0
        if "s_guildbuildtimes" in guild.__dict__:
            guild.s_guildbuildtimes = {}
        
    def sendTaskNotify(self, player, taskID, valid, completed, count):
        MMain.sendTaskNotify(player, taskID, valid, completed, count)
    
    def sendBattleNotify(self, player):
        MMain.sendBattleNotify(player)

    def sendDungeonNotify(self, player, dungeonID, sign):
        MMain.sendDungeonNotify(player, dungeonID, sign)

    def processArenaReward(self, arenaRewards):
        self.mArenaTop = []
        self.mArenaTop3Name = {}
        if len(arenaRewards) > 0:
            createTime = int(time.time())
            for reward in arenaRewards:
                if len(reward) == 7:
                    rank = reward[1] + 1
                    mail = {}
                    mail["RecvUUID"] = ""
                    mail["RecvName"] = reward[0]
                    mail["CreateTime"] = createTime
                    mail["ValidTime"] = createTime + 86400 * 3
                    mail["Head"] = ""
                    mail["Body"] = GlobalStrings[10] % (self.getArenaRankDesc(rank))
                    mail["Res"] = [[REWARD_TYPE_GOLDMONEY, reward[2]], [REWARD_TYPE_MONEY, reward[3]],]
                    mail["Items"] = []
                    if reward[5] != 0:
                        mail["Items"] = [(reward[4], reward[5], reward[6]),]
                    MMain.sendMail(mail)

                    if rank <= 3:
                        player = MMain.getPlayerByName(reward[0])
                        if player:
                            name = reward[0]
                            bottlepoint = player.getBattlePoint()
                            job = player.getTopRole()
                            level = player.getLevel()
                            guildName = player.getGuildName()
                            rolelist = player.getRoleList()
                            Viplevel = player.getVipLevel()
                            weponid = 0
                            clothid = 0 
                            for role in rolelist:
                                if role.getJob() == job:
                                    wepon = role.getEquipment(0)
                                    cloth = role.getEquipment(1)
                                    if wepon:
                                       weponid = wepon.getID()
                                    if cloth:
                                        clothid = cloth.getID()
                            self.mArenaTop.append((rank, job, name, guildName, level, Viplevel, bottlepoint, weponid, clothid))
                            self.mArenaTop3Name[name] = rank
                            print self.mArenaTop
                        else:
                            print "arenaTop log failed"
        MMain.setSetting("arenaTop", self.mArenaTop)
        MMain.setSetting("g_ArenaTop3Name", self.mArenaTop3Name)

    def getArenaRankDesc(self, rank):
        if rank > 0 and rank <= 200:
            return GlobalStrings[11] %(rank - 0)
        elif rank > 200 and rank <= 1000:
            return GlobalStrings[12] %(rank - 200)
        elif rank > 1000 and rank <= 3000:
            return GlobalStrings[13] %(rank - 1000)
        elif rank > 3000 and rank <= 5000:
            return GlobalStrings[14] %(rank - 3000)
        elif rank > 5000 and rank <= 7000:
            return GlobalStrings[15] %(rank - 5000)
        elif rank > 7000 and rank <= 10000: 
            return GlobalStrings[16] %(rank - 7000)   
        return ""

    def getArenaTop(self, data):
        return self.mArenaTop

    def addArenaMaxRankReward(self, player, up, goldMoney):
        if goldMoney > 0:
            msg = GlobalStrings[17] % (up, goldMoney)
            player.addGoldMoney(goldMoney)
            MMain.dbLogActivityAddGoldMoney(player, 12, goldMoney)
            MMain.sendBoxMessage(player, msg)
            MMain.sendCenterMessage(player, msg)            

    def winArenaNo1(self, player):
        msg = GlobalStrings[18] % (player.getName())
        MMain.sendHorseMessage(msg)

    def checkIsValid(self):
        for taskID in self.mTaskTables:
            task = self.mTaskTables[taskID]
            # 检测奖励道具
            for itemInfo in task[TASK_DATA_REWARD_ITEMS]:
                if len(itemInfo) == 3:
                    itemName = MMain.getItemName(itemInfo[0], itemInfo[1])
                    if not itemName:
                        syserr("Task Reward item %s:%s error." % (itemInfo[0], itemInfo[1]))
                        return False
        return True

    def checkInit(self, player):
        if "s_Dungeon" not in player.__dict__:
            player.s_Dungeon = {}               #dungeonid:star
        if "s_DungeonCount" not in player.__dict__:
            player.s_DungeonCount = {}             #dungeonid:count
        if "s_DungeonReset" not in player.__dict__:
            player.s_DungeonReset = {}
        if "s_DungeonPPH" not in player.__dict__:
            player.s_DungeonPPH = {}
        if "s_BattleReward" not in player.__dict__:
            player.s_BattleReward = []

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            isLoadOk = True
            isLoadOk &= self.checkIsValid()
            
            if not isLoadOk:
                syslog("Task system initialize failed, exit.")
                sys.exit(1)

            # if not self.mCurBossIndex:
            #     self.mCurBossIndex = random.sample(range(BossDungeonNum), 3)
            t = time.localtime(time.time())
            self.mCurBossIndex = self.mBoss[t.tm_wday]
            startTime = MMain.getSetting("starttime")
            if startTime:
                self.mStartTime = startTime
            else:
                time1 = time.mktime(time.strptime(time.strftime('%Y-%m-%d 00:00:00', t),'%Y-%m-%d %H:%M:%S'))
                self.mStartTime = int(time1)
                MMain.setSetting("starttime", self.mStartTime)
                
            arenaTop = MMain.getSetting("arenaTop")
            if arenaTop:
                self.mArenaTop = arenaTop
            else:
                self.mArenaTop = []
            arenaTop3Name = MMain.getSetting("g_ArenaTop3Name")
            if arenaTop3Name:
                self.mArenaTop3Name = arenaTop3Name
            else:
                self.mArenaTop3Name = {}

            arenaTop3Name = MMain.getSetting("arenaTop3Name")
            if arenaTop3Name:
                self.mArenaTop3Name = arenaTop3Name
            else:
                self.mArenaTop3Name = {}

        elif msg == MSG_DAY_CHANGED:
            t = time.localtime(time.time())
            self.mCurBossIndex = self.mBoss[t.tm_wday]            
            print "-------------------------Day Changed-------------------------"

        elif msg == MSG_TIME_MINUTE:
            curTime = time.time()
            curLTime = time.localtime(curTime)
            curMin = curLTime.tm_hour * 60 + curLTime.tm_min
            if curMin % 5 == 2:
                msg1 = GlobalStrings[19]
                msg5 = GlobalStrings[20]
                msg6 = GlobalStrings[21]
                MMain.sendHorseMessage(msg1)
                #MMain.sendHorseMessage(msg2)
                #MMain.sendHorseMessage(msg4)
                MMain.sendHorseMessage(msg5)
                MMain.sendHorseMessage(msg6)

        elif msg == MSG_PLAYER_CREATED:
            player = param0

            self.checkInit(player)
            self.initTask(player)
            self.initDungeon(player)

        elif msg == MSG_PLAYER_ONLINE:
            player = param0
            moduleData = getModuleData(player, self.mID, self.mTaskData)
            if "s_task" not in player.__dict__:
                player.s_task = {}
            if "s_task_fix" not in player.__dict__:
                player.s_task_fix = 0
            ##print "---------ClearData---------"
            if player.s_task_fix == 0:
                for dungeonid in self.mTaskByDungeon:
                    if dungeonid in player.s_Dungeon and player.s_Dungeon[dungeonid] > 0:
                        player.s_task[self.mTaskByDungeon[dungeonid]] = 0
                for tid in player.s_task:
                    nextTaskIDList = self.getNextTaskID(tid)
                    for i in nextTaskIDList:
                        if i not in player.s_task:
                            self.invokeTask(player, i)
                player.s_task_fix = 1

            for taskID in moduleData[1]:
                if taskID in moduleData[0]:
                    del moduleData[0][taskID]
            
            # 发送任务
            for taskID in moduleData[2]:
                if taskID in self.mTaskTables:
                    task = self.mTaskTables[taskID]
                    if player.getLevel() >= task[TASK_DATA_LEVELLIMITATION]:
                        self.invokeTask(player, taskID)

            for taskID in moduleData[0]:
                if taskID in moduleData[2]:
                    del moduleData[2][taskID]

            for taskID in moduleData[1]:
                if taskID in moduleData[2]:
                    del moduleData[2][taskID]

            MMain.sendTaskList(player, self.buildTaskList(player))
            self.doTask(player, TYPE_LOGIN, 0)
            if player.getGuildName():
                self.doTask(player, TYPE_JOIN_GUILD, 0)

            #check top3 for led
            if player.getName() in self.mArenaTop3Name:
                rank = self.mArenaTop3Name[player.getName()]
                if rank == 1:
                    msg = GlobalStrings[22] % (player.getName())
                    MMain.sendHorseMessage(msg)
                elif rank == 2:
                    msg = GlobalStrings[23] % (player.getName())
                    MMain.sendHorseMessage(msg)
                elif rank == 3:
                    msg = GlobalStrings[24] % (player.getName())
                    MMain.sendHorseMessage(msg)

            nextbattleid = player.getBattleID() + 1
            if nextbattleid in self.mBattleFirstDungeon:
                dunid = self.mBattleFirstDungeon[nextbattleid]

                if dunid in self.mDungeon:
                    caninvoke = True
                    tPres = self.mDungeon[dunid][0]
                    for i in tPres:
                        if self.isLockDungeon(player, i) or self.getDungeonStar(player, i) == 0:
                            caninvoke = False
                            break
                    if caninvoke:
                        self.unLockDungeon(player, dunid)    
                                                
        elif msg == MSG_PLAYER_DAY_CHANGED:
            player = param0
            player.s_JoinGuildCD = False            

        elif msg == MSG_PLAYER_LEVELUP:
            player = param0
            moduleData = getModuleData(player, self.mID, self.mTaskData)

            ##levelup and invoke task
            for taskID in moduleData[2]:
                if taskID in self.mTaskTables:
                    task = self.mTaskTables[taskID]
                    if player.getLevel() >= task[TASK_DATA_LEVELLIMITATION]:
                        self.invokeTask(player, taskID)

            for taskID in moduleData[0]:
                if taskID in moduleData[2]:
                    del moduleData[2][taskID]

            for taskID in moduleData[1]:
                if taskID in moduleData[2]:
                    del moduleData[2][taskID]
            self.doTask(player, TYPE_LEVEL, player.getLevel())

        elif msg == MSG_PLAYER_VIPLEVEL_CHANGED:
            player = param0
            self.doTask(player, TYPE_VIP_LEVEL, player.getVipLevel())

        elif msg == MSG_PLAYER_MONEY_CHANGED:
            player = param0
            money = param1
            if money > 0:
                self.doTask(player, TYPE_GET_MONEY, money)

        elif msg == MSG_PLAYER_GOLDMONEY_CHANGED:
            pass
        elif msg == MSG_PLAYER_ENERGY_CHANGED:
            pass
        elif msg == MSG_PLAYER_SPAR_CHANGED:
            pass
        elif msg == MSG_PLAYER_TRAIN_ROLE:
            player = param0
            self.doTask(player, TYPE_ROLE_TRAIN, 0)

        elif msg == MSG_PLAYER_FINISH_DUNGEON:
            player = param0
            dungeon, star, costTime = param1
            dungeonID = dungeon.getID()
            dungeonType = int(dungeonID / 10000)

            self.completeDungeon(player, dungeonID, star)
            if dungeonType == 2:          
                self.doTask(player, TYPE_DUNGEON_NUM, dungeonID)
                self.doTask(player, TYPE_THIS_DUNGEON, dungeonID)
                dungeonDegree = int(dungeon.getDungeonDegree())
                if dungeonDegree != 0:              #normal
                    self.doTask(player, TYPE_HARD_DUNGEON, dungeonID)
            elif dungeonType == 11:
                self.doTask(player, TYPE_MONEYDUNGEON, dungeonID)
            elif dungeonType == 5:
                self.doTask(player, TYPE_ENDLESS, dungeonID)
            elif dungeonType == 9:
                self.doTask(player, TYPE_PROTECTATHENA, dungeonID)
            else:
                pass
                    

        elif msg == MSG_PLAYER_DROP_ITEM:
            player = param0
            self.doTask(player, TYPE_ITEM_DROP, 0)

        elif msg == MSG_PLAYER_EXCHANGE_ITEM:
            player = param0
            self.doTask(player, TYPE_ITEM_EXCHANGE, 0)
                        
        elif msg == MSG_PLAYER_COMBINE_ITEM:
            player = param0
            self.doTask(player, TYPE_ROLE_TRAIN, 0)
            
        elif msg == MSG_PLAYER_ENTER_ARENA:
            player = param0
            result,rank = param1
            if result == 0:
                self.doTask(player, TYPE_ARENA, 0)
            if result == 1:
                self.doTask(player, TYPE_ARENA_WIN, 0)
            
        elif msg == MSG_PLAYER_JOIN_GUILD:
            player = param0
            self.doTask(player, TYPE_JOIN_GUILD, 0)
            
        elif msg == MSG_PLAYER_BATTLEPOINT_CHANGED:
            player = param0
            self.doTask(player, TYPE_BATTLE_POINT, player.getBattlePoint())
            
        elif msg == MSG_PLAYER_ITEM_UPGRADE:
            player = param0
            self.doTask(player, TYPE_ITEM_UPGRADE, 0)
            self.doTask(player, TYPE_ITEM_STRENGTH, 0)
            
        elif msg == MSG_PLAYER_ITEM_ADVANCE:
            player = param0
            self.doTask(player, TYPE_ITEM_ADVANCE, 0)
            self.doTask(player, TYPE_ITEM_STRENGTH, 0)
            
        elif msg == MSG_PLAYER_SKILL_UPGRADE:
            player = param0
            self.doTask(player, TYPE_SKILL_UPGARDE, 0)
            self.doTask(player, TYPE_SKILL_STRENGTH, 0)

        elif msg == MSG_PLAYER_SKILL_ADVANCE:
            player = param0
            self.doTask(player, TYPE_SKILL_ADVANCE, 0)
            self.doTask(player, TYPE_SKILL_STRENGTH, 0)
            
        elif msg == MSG_PLAYER_TALENT_UPGRADE:
            player = param0
            self.doTask(player, TYPE_TALENT_UPGRADE, 0)
            self.doTask(player, TYPE_TALENT_STRENGTH, 0)
            
        elif msg == MSG_PLAYER_TALENT_ADVANCE:
            player = param0
            self.doTask(player, TYPE_TALENT_ADVANCE, 0)
            self.doTask(player, TYPE_TALENT_STRENGTH, 0)
            
        elif msg == MSG_PLAYER_FINISH_TASK:
            pass
            
        elif msg == MSG_PLAYER_FINISH_DAILY_TASK:
            pass
            
        elif msg == MSG_PLAYER_STONE_USE:
            player = param0
            self.doTask(player, TYPE_STONE_USE, 0)
            
        elif msg == MSG_PLAYER_STONE_COMBINE:
            player = param0
            self.doTask(player, TYPE_STONE_COMBINE, 0)
            
        elif msg == MSG_PLAYER_SINGLE_PVP:
            player = param0
            self.doTask(player, TYPE_SINGLE_PVP, 0)
            
        elif msg == MSG_PLAYER_SINGLE_BOSS:
            player = param0
            self.doTask(player, TYPE_SINGLE_BOSS, 0)
            
        elif msg == MSG_PLAYER_MULT_BOSS:
            player = param0
            self.doTask(player, TYPE_MULT_BOSS, 0)
            
        elif msg == MSG_PLAYER_BUY_MONEY:
            player = param0
            self.doTask(player, TYPE_BUY_MONEY, 0)
            
        elif msg == MSG_PLAYER_LOTTERY:
            player = param0
            self.doTask(player, TYPE_LOTTERY, 0)
            
        elif msg == MSG_PLAYER_ADD_FRIEND:
            player = param0
            targetName = param1
            self.doTask(player, TYPE_FRIEND, 0)
            self.notifyAddFriend(player, targetName)
            
        elif msg == MSG_PLAYER_JOIN_EIGHTEEN:
            player = param0
            self.doTask(player, TYPE_EIGHTEEN, 0)
            
        elif msg == MSG_PLAYER_JOIN_ESCORT:
            player = param0
            self.doTask(player, TYPE_ESCORT, 0)
        elif msg == MSG_PLAYER_PET_UPGRADE:
            player = param0
            self.doTask(player, TYPE_UPGRADEPET, 0)
            
    def isPlayerPurchased(self, player):
        if "s_Purchased" in player.__dict__:
            return player.s_Purchased
        return False

    def isFirstLottery(self, player, typ):
        #typ=0 as item
        #typ=1 as pet
        if "s_firstlottery" not in player.__dict__:
            player.s_firstlottery = [True, True]
        return player.s_firstlottery[typ]

    def setFirstLottery(self, player, typ, isFirst):
        if "s_firstlottery" in player.__dict__:
            player.s_firstlottery[typ] = isFirst

    def isFirstMustOrange(self, player):
        if "s_firstmustorange" not in player.__dict__:
            player.s_firstmustorange = True
        return player.s_firstmustorange

    def setFirstMustOrange(self, player):
            player.s_firstmustorange = False

    def noticeNotOpen(self, player):
        message = GlobalStrings[25]
        MMain.sendCenterMessage(player,message)

    def getRobotNameByRank(self, rank):
        return GlobalStrings[26] % (rank)

    def getGuildRefuseMailDesc(self, guildName):
        return GlobalStrings[27] % (guildName)

    def getLostLootDesc(self):
        return GlobalStrings[28]

    def getGuildRewardMailDesc(self, guildName, rewardType):
        return GlobalStrings[29] % (guildName, rewardType)
        
    def sendItemHorseMsg(self, player, items):
        for reward in items:
            if len(reward) == 3:
                itemName = MMain.getItemName(reward[0], reward[1])
                itemQuality = MMain.getItemQuality(reward[0], reward[1])
                msg = GlobalStrings[30] % (player.getName(), self.getItemColor(itemQuality), itemName, reward[2])
                MMain.sendHorseMessage(msg)
    
    def notifyAddFriend(self, player, targetName):
        playerName = player.getName()
        targetplayer = MMain.getPlayerByName(targetName)
        if targetplayer:
            response = (playerName, )
            MMain.sendTextProtocol(targetplayer, "S2C_AddFriendNotice", response)

    def notifyTopRank(self, respon):
        import openrankreward
        if openrankreward.Instance:
            openrankreward.Instance.onNotifyTopRank(respon)

ModuleID = 1
Instance = MainTask(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_DAY_CHANGED,
    MSG_TIME_MINUTE,
    MSG_PLAYER_CREATED,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_LEVELUP,
    MSG_PLAYER_DAY_CHANGED,
    MSG_PLAYER_VIPLEVEL_CHANGED,
    MSG_PLAYER_MONEY_CHANGED,
    MSG_PLAYER_GOLDMONEY_CHANGED,
    MSG_PLAYER_ENERGY_CHANGED,
    MSG_PLAYER_SPAR_CHANGED,
    MSG_PLAYER_TRAIN_ROLE,
    MSG_PLAYER_FINISH_DUNGEON,
    MSG_PLAYER_DROP_ITEM,
    MSG_PLAYER_EXCHANGE_ITEM,
    MSG_PLAYER_COMBINE_ITEM,
    MSG_PLAYER_ENTER_ARENA,
    MSG_PLAYER_JOIN_GUILD,
    MSG_PLAYER_BATTLEPOINT_CHANGED,
    MSG_PLAYER_ITEM_UPGRADE,
    MSG_PLAYER_ITEM_ADVANCE,
    MSG_PLAYER_SKILL_UPGRADE,
    MSG_PLAYER_SKILL_ADVANCE,
    MSG_PLAYER_TALENT_UPGRADE,
    MSG_PLAYER_TALENT_ADVANCE,
    MSG_PLAYER_FINISH_TASK,
    MSG_PLAYER_FINISH_DAILY_TASK,
    MSG_PLAYER_STONE_USE,
    MSG_PLAYER_STONE_COMBINE,
    MSG_PLAYER_SINGLE_PVP,
    MSG_PLAYER_SINGLE_BOSS,
    MSG_PLAYER_MULT_BOSS,
    MSG_PLAYER_BUY_MONEY,
    MSG_PLAYER_LOTTERY,
    MSG_PLAYER_ADD_FRIEND,
    MSG_PLAYER_JOIN_EIGHTEEN,
    MSG_PLAYER_JOIN_ESCORT,
])
