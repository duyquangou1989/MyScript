#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
import copy
import util
import guildscience
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *
from traceback import print_exc
from guildbattletime import *
from guildbattlecfg import *




class GuildBattleHandler:
    def __init__(self, instance):
        self.mBattle = instance

    def processMsg(self, msg, param0, param1):
        pass

    def processTime(self, param0, param1):
        pass

    def processSecond(self):
        pass

    def processClient(self, player, jsonData):
        actType = jsonData["type"]
        ret = {"type" : actType}

        if actType == "personal_data":
            rank = self.mBattle.getPersonalRank(player)
            if rank:
                ret.update(rank)
            return json.dumps(ret)
        elif actType == "guild_personal":
            rank = self.mBattle.getGuildPersonalRank(player)
            if rank:
                ret.update(rank)
            return json.dumps(ret)
        elif actType == "main_info":
            self.noticeNextBattle(player)
            ret["state"] = "not_open"
            return json.dumps(ret)
        elif actType == "pet_info":
            ret["data"] = player.getPetBattleBuf()
            return json.dumps(ret)
        else:
            #print("error client msg!")
            self.noticeNextBattle(player)
            return json.dumps({})

    def noticeNextBattle(self, player):
            week, t = self.mBattle.calNextBattleTimeDesc()
            if week:
                msg = GlobalStrings[151] % (week, t)
            else:
                msg = GlobalStrings[152]
            #print(msg)
            MMain.sendCenterMessage(player, msg)

    def processBattleMsg(self, msg, param0, param1):
        #print("processBattleMsg error:" + str(msg))
        pass

    def processPlayerOnline(self, player):
        self.mBattle.sendInfoToPlayer(player)

    # 公用函数
    def getMyPrice(self, player, cityNo):
        auctionInfo = self.mBattle.mCitySaveData["auction"].get(cityNo)
        if not auctionInfo:
            return 0

        myPrice = auctionInfo.get(player.getGuildName(), [0,0])
        return myPrice[0]

    # 返回[(1, 100), (2, 200)]
    def getPersonalAwardsInfo(self, playerName):
        return self.mBattle.mRewardData.get(playerName, {}).items()

    def formatOverMsg(self,guildName, playerName):
        ret = {}
        ret["awards"] = self.getPersonalAwardsInfo(playerName)
        ret["occupyInfo"] = self.mBattle.mCityOccupyResult.get(guildName, [])
        ret["occupyedInfo"] = self.mBattle.mCityOccupyedResult.get(guildName, [])

        return json.dumps(ret)

    def canAuction(self, player, cityNo, sendMsg = False):
        guildName = player.getGuildName()
        connect = False
        occupyInfo = self.mBattle.mCitySaveData["occupy"]
        if cityNo in Battle_City_Connect:
            for city in Battle_City_Connect[cityNo]:
                if occupyInfo.get(city) == guildName:
                    connect = True
                    break

        # 无人占领，可以竞拍
        if not occupyInfo.get(cityNo) and cityNo != 1:
            connect = True

        if not connect:
            if sendMsg:
                MMain.sendCenterMessage(player, GlobalStrings[153])
            return False

        return True

    def isQualified(self, player, cityNo):
        # 小城池都可以进攻
        if cityNo >= 6:
            return True

        guildName = player.getGuildName()
        cityFight = self.mBattle.mCityFight.get(cityNo, [])
        qualified = False
        if guildName in cityFight:
            qualified = True

        return qualified

    def getCityInfo(self):
        cityInfo = {}
        for cityNo in Battle_Citys:
            cityInfo[cityNo] = self.mBattle.mCitySaveData["occupy"].get(cityNo,"")

        return cityInfo

    def notifyAllPlayerPeriod(self):
        # 通知所有客户端开始
        allPlayers = MMain.getAllPlayers()
        for tmpPlayer in allPlayers:
            if tmpPlayer.getClientID() != -1 and self.mBattle.canJoin(tmpPlayer):
                nextTime, periodTime = self.mBattle.calNextPeriodTime()
                MMain.sendTextProtocol(tmpPlayer, "S2C_NotifyGuildBattleBegin", (self.mBattle.mPeriod,nextTime, periodTime))


class GuildBattleHandler_None(GuildBattleHandler):
    def onEnterPeriod(self):
        print("onEnterPeriod None")

    def onExitPeriod(self):
        print("onExitPeriod None")

    def processTime(self, param0, param1):
        pass


class GuildBattleHandler_Auction(GuildBattleHandler):
    def onEnterPeriod(self):
        print("onEnterPeriod Auction")
        self.mBattle.newRound()
        MMain.sendHorseMessage(Announce_Msg_Acution)
        self.notifyAllPlayerPeriod()

    def onExitPeriod(self):
        print("onExitPeriod Auction")
        self.mBattle.dataSaveToDB()

    def processClient(self, player, jsonData):
        actType = jsonData["type"]
        ret = {"type" : actType}
        if actType == "main_info":
            #print("get main info in auction period")
            ret = {}
            ret["state"] = "auction"

            guildName = player.getGuildName()
            leftTime,periodTime = self.mBattle.calNextPeriodTime()
            guild = MMain.getGuildByName(player.getGuildName())
            guildFeats = guild.getBattle()    # 公会战功

            cityInfo = self.getCityInfo()

            #cityInfo = self.mBattle.mCitySaveData["occupy"]
            ret["data"] = [leftTime, cityInfo, guildFeats, periodTime]
            ret["city"] = {}
            for cityNo in Battle_City_Connect:
                if not self.mBattle.mCitySaveData["occupy"].get(cityNo) == guildName:
                    ret["city"][cityNo] = [0,0,self.canAuction(player, cityNo)]
                else:
                    ret["city"][cityNo] = [0,0,True]

            return json.dumps(ret)
        elif actType == "auction_info":
            cityNo = jsonData["no"]
            if cityNo not in Battle_City_Connect:
                MMain.sendCenterMessage(player, GlobalStrings[154])
                return "{}"

            ret["data"] = self.mBattle.mCityAucRank[cityNo]
            ret["myPrice"] = self.getMyPrice(player, cityNo)

            return json.dumps(ret)
        elif actType == "auction_price":
            cityNo = jsonData["data"][0]
            price = jsonData["data"][1]

            ret["data"] = self.auctionPrice(player, cityNo, price)
            ret["myPrice"] = self.getMyPrice(player, cityNo)
            return json.dumps(ret)
        else:
            return GuildBattleHandler.processClient(self, player, jsonData)

    def auctionPrice(self, player, cityNo, price):
        if price < Auction_Min_Price:
            return None

        guildName = player.getGuildName()
        if not self.mBattle.isMaster(player):
            MMain.sendCenterMessage(player, GlobalStrings[155])
            return None

        if self.mBattle.mCitySaveData["occupy"].get(cityNo) == guildName:
            MMain.sendCenterMessage(player, GlobalStrings[156])
            return None

        if not self.canAuction(player, cityNo, True):
            return None

        # 扣除战功
        # todo oooooooooooooooooooooooooooooooooooooo
        guild = MMain.getGuildByName(player.getGuildName())
        if guild.getBattle() < price:
            MMain.sendCenterMessage(player, GlobalStrings[157])
            return None

        guild.addBattle(-price)
        guild.addBattleAuc(price)

        lastTopOneGuild = ""
        if len(self.mBattle.mCityAucRank[cityNo]) > 0:
            lastTopOneGuild = self.mBattle.mCityAucRank[cityNo][0][0]

        if self.mBattle.mCitySaveData["auction"].get(cityNo) == None:
            self.mBattle.mCitySaveData["auction"][cityNo] = {}
        auctionInfo = self.mBattle.mCitySaveData["auction"][cityNo]
        auctionInfo[guildName] = util.vec_add(auctionInfo.get(guildName, [0, 0]), [price, 0])
        auctionInfo[guildName][1] = time.time()
        self.mBattle.refreshAuctionRank(cityNo)
        MMain.sendCenterMessage(player, GlobalStrings[158] + str(price))

        MMain.dbLogGuildAcution(player, guild.getLevel(), cityNo, price, guild.getBattle())

        # 通知被顶下去的会长
        newTopOneGuild = self.mBattle.mCityAucRank[cityNo][0][0]
        if newTopOneGuild != lastTopOneGuild:
            guild = MMain.getGuildByName(lastTopOneGuild)
            if guild:
                msg = Auction_Notify_Msg % (self.mBattle.getCityName(cityNo), newTopOneGuild)

                master = MMain.getPlayerByName(guild.getMasterName())
                # 在线
                if master and master.getClientID() != -1:
                    MMain.sendTextProtocol(master, "S2C_ButtomMessage", (msg,))

                else:
                    mail = {}
                    mail["RecvUUID"] = ""
                    mail["RecvName"] = guild.getMasterName()
                    mail["CreateTime"] = int(time.time())
                    mail["ValidTime"] = mail["CreateTime"] + 86400 * 16
                    mail["Head"] = GlobalStrings[159]
                    mail["Body"] = "    " + msg
                    mail["Res"] = []
                    mail["Items"] = []
                    MMain.sendMail(mail)

        return self.mBattle.mCityAucRank[cityNo]

    def processTime(self, param0, param1):
        # 每分钟存储
        #if self.needSave:
        self.mBattle.dataSaveToDB()


class GuildBattleHandler_Show(GuildBattleHandler):
    def onEnterPeriod(self):
        print("onEnterPeriod Show")
        MMain.sendHorseMessage(Announce_Msg_Show)
        self.notifyAllPlayerPeriod()

        self.mBattle.refreshAuctionRank()
        occupyInfo = self.mBattle.mCitySaveData["occupy"]

        for i in self.mBattle.mCityAucRank:
            rankInfo = self.mBattle.mCityAucRank[i]
            if len(rankInfo) > 0 :
                # 如果无人占领，则竞拍第一名公会直接占领
                if not occupyInfo.get(i):
                    occupyInfo[i] = rankInfo[0][0]
                # 竞拍失败返还战功，先把竞拍成功的返回战功扣掉
                for name, data in self.mBattle.mCitySaveData["auction"][i].items():
                    if name ==  rankInfo[0][0]:
                        guild = MMain.getGuildByName(name)
                        if guild:
                            guild.addBattleAuc(-rankInfo[0][1])
                        continue

                # 然后全部返还
                for name, data in self.mBattle.mCitySaveData["auction"][i].items():
                    if name !=  rankInfo[0][0]:
                        aucPrice = data[0]
                        guild = MMain.getGuildByName(name)
                        if guild:
                            if guild.getBattleAuc() > 0 :
                                guild.addBattle(guild.getBattleAuc())
                                guild.setBattleAuc(0)



        for i in Battle_City_Connect:
            self.mBattle.mCityFight[i] = []
            defent = occupyInfo.get(i)
            attack = None
            attackInfo = self.mBattle.mCityAucRank.get(i)
            if attackInfo:
                attack = attackInfo[0][0]
            if defent and attack and defent != attack:  # 自己竞拍下来直接占领了也不加入（未发生战斗）
                self.mBattle.mCityFight[i] += [defent, attack]




    def onExitPeriod(self):
        print("onExitPeriod Show")

    def processClient(self, player, jsonData):
        actType = jsonData["type"]

        ret = {"type" : actType}
        if actType == "main_info":
            #print("get main info in Show period")

            ret["state"] = "show"

            guildName = player.getGuildName()
            leftTime,periodTime = self.mBattle.calNextPeriodTime()
            guild = MMain.getGuildByName(player.getGuildName())
            guildFeats = guild.getBattle()    # 公会战功
            cityInfo = self.getCityInfo()
            ret["data"] = [leftTime, cityInfo, guildFeats, periodTime]
            ret["city"] = {}
            for cityNo in Battle_City_Connect:
                qualify = False
                if self.mBattle.mCitySaveData["occupy"].get(cityNo) == player.getGuildName():
                    qualify = True
                else:
                    qualify = self.isQualified(player, cityNo)

                if not qualify:
                    ret["city"][cityNo] = [0,0,False]


            return json.dumps(ret)
        elif actType == "auction_info":
            cityNo = jsonData["no"]
            if cityNo not in Battle_City_Connect:
                MMain.sendCenterMessage(player, GlobalStrings[160])
                return "{}"

            #auctionInfo = self.mBattle.mCitySaveData["auction"]
            ret["data"] = self.mBattle.mCityAucRank[cityNo]
            ret["myPrice"] = self.getMyPrice(player, cityNo)
            return json.dumps(ret)

        else:
            return GuildBattleHandler.processClient(self, player, jsonData)

