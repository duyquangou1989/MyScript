#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

CDT_GOLDMONEY    = 0
CDT_CHARGE       = 1
CDT_OPENACTIVITY = 2
CDT_ROLELEVEL    = 3
CDT_VIPLEVEL     = 4


class PersonReward(ActivityBase):

    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        self.mID = moduleID
        self.mConfigData = []
        self.mTaskData = {}

    def isActived(self, player):
        if "s_prOpen" not in player.__dict__:
            player.s_prOpen = -1
        if player.s_prOpen == -1:
            return False
        else:
            if player.s_prOpen - time.time() > 0:
                return True
            else:
                player.s_prOpen = -1
                return False

    def getInfo(self, player):
        info = {}
        info["Result"] = 0
        if self.isActived(player):
            info["Result"] = 1
            taskdata = []
            for actid in self.mTaskData:
                taskdata.append(self.mTaskData[actid])
            info["task"] = taskdata
            info["lefttime"] = player.s_prOpen - time.time()
            #self.checkOpenAcitvity(player, CDT_OPENACTIVITY)
            player.s_prOpenactTime = time.time()
        return json.dumps(info)

    def doAction(self, player, actData):
        jsonData = json.loads(actData)
        actId = int(jsonData["actId"])
        if self.isActived(player):
            if actId in self.mTaskData:
                taskData = self.mTaskData[actId]
                needGoldMoney = taskData[2]
                taskReward = taskData[3]
                if needGoldMoney <= player.getGoldMoney():
                    if self.canAddAllReward(player, taskReward):
                        for reward in taskReward:
                            self.addReward(player, reward)
                            if len(reward) == 3:
                                message = GlobalStrings[32]%self.getRewardDesc(reward)
                                MMain.sendCenterMessage(player, message)
                        player.addGoldMoney(-needGoldMoney)
                        player.s_prOpen = -1
                        player.s_condition = 0
                        return Err_Ok
                    else:
                        return Err_NotEnoughSpace
                else:
                    return Err_NotEnoughGoldMoney
            else:
                return Err_Unknown
        else:
            return Err_NotOpen

    def checkOpenAcitvity(self, player, conditiontype):
        level = player.getLevel()
        vipLevel = player.getVipLevel()
        
        if not self.isActived(player):
            if "s_condition" not in player.__dict__:
                player.s_condition = 0
            player.s_condition |= (1<<conditiontype)

            if "s_prOpenactTime" not in player.__dict__:
                player.s_prOpenactTime = 0
            if time.time() - player.s_prOpenactTime >= self.mConfigData[CDT_OPENACTIVITY] * 86400:
                player.s_condition |= (1<<CDT_OPENACTIVITY)
            if level >= self.mConfigData[CDT_ROLELEVEL]:
                player.s_condition |= (1<<CDT_ROLELEVEL)
            if vipLevel >= self.mConfigData[CDT_VIPLEVEL]:
                player.s_condition |= (1<<CDT_VIPLEVEL)
            if player.s_condition == 31:
                player.s_prOpen = time.time() + 86400
                self.notifyActReward(player, player.s_prOpen)
        else:
            if player.s_prOpen - time.time() <= 0:
                player.s_prOpen = -1
                player.s_condition = 0

    def loadConfig(self, path):
        config = "%sconfig.txt" % (path)
        taskfile = "%stask.txt" % (path)
        tb = TabFile()
        if tb.load(config):
            cfg = []
            cdtGoldMoney = tb.get(0, 0, 0, True)
            cdtChargeDay = tb.get(0, 1, 0, True)
            cdtOpenActivity = tb.get(0, 2, 0, True)
            cdtPlayerLevel = tb.get(0, 3, 0, True)
            cdtVipLevel = tb.get(0, 4, 0, True)

            cfg = [cdtGoldMoney, cdtChargeDay, cdtOpenActivity,  cdtPlayerLevel, cdtVipLevel]
            self.mConfigData = cfg
        else:
            syserr("Load %s failed." % (config))
            return False
        tb = TabFile()
        if tb.load(taskfile):
            task = {}
            for i in xrange(tb.mRowNum):
                taskID          = tb.get(i, 0, 0, True)
                taskName        = tb.get(i, 1, "", False).replace("\n", "")
                taskGoldMoney   = tb.get(i, 2, 0, True)
                taskRewardstr     = tb.get(i, 3, 0, False).replace("\n", "")
                taskVipLevel    = tb.get(i, 4, 0, True)
                taskIcon        = tb.get(i, 5, 0, False).replace("\n", "")
                taskReward = [
                    [int(value) for value in reward.split(",")]
                        for reward in taskRewardstr.split(";") if reward and reward.count(',') in (1, 2)
                ]
                task[taskID] = [taskID, taskName, taskGoldMoney, taskReward, taskVipLevel, taskIcon]
            self.mTaskData = task
        else:
            syserr("Load %s failed." % (taskfile))
            return False
        return True
    def notifyActReward(self, player, lefttime):
        response = (int(lefttime), )
        MMain.sendTextProtocol(player, "S2C_PersonReward", response)

    def invoke(self, msg , param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)
        else:
            player = param0
            if msg == MSG_PLAYER_GOLDMONEY_CHANGED:
                way = param1[1]
                goldmoney = player.getGoldMoney()
                if goldmoney <= self.mConfigData[CDT_GOLDMONEY]:
                    self.checkOpenAcitvity(player, CDT_GOLDMONEY)
                if way == 2:
                    if "s_prchargetime" not in player.__dict__:
                        player.s_prchargetime = time.time()
                    if time.time() - player.s_prchargetime >= self.mConfigData[CDT_CHARGE] * 86400:
                        self.checkOpenAcitvity(player, CDT_CHARGE)
                    player.s_prchargetime = time.time()
            elif msg == MSG_PLAYER_ONLINE:
                if self.isActived(player):
                    self.notifyActReward(player, player.s_prOpen)
                goldmoney = player.getGoldMoney()
                if goldmoney <= self.mConfigData[CDT_GOLDMONEY]:
                    self.checkOpenAcitvity(player, CDT_GOLDMONEY)
                if "s_prchargetime" not in player.__dict__:
                    player.s_prchargetime = time.time()
                if time.time() - player.s_prchargetime >= self.mConfigData[CDT_CHARGE] * 86400:
                    self.checkOpenAcitvity(player, CDT_CHARGE)
ModuleID = 51
Instance = PersonReward(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_GOLDMONEY_CHANGED,
    MSG_PLAYER_ONLINE,
])
