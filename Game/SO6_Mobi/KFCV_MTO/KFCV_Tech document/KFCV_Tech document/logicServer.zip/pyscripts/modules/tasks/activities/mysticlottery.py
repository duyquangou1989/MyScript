#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

MLottery_Type_1     = 1 # 普通抽取
MLottery_Type_2     = 2 # 高级抽取

Info_Index_Per_Cost = 0 # 单次抽取消耗
Info_Index_Ten_Cost = 1 # 10次抽取消耗
Info_Index_Get_Score= 2 # 每次抽取获得积分
Info_Index_BaseGoldPoolNum = 3 # 基础元宝奖池的金额
Info_Index_GotGold_SvrTotalTimes = 4 # 下个玩家必然可以获得元宝的服务器抽取次数
Info_Index_UseOtherRatio = 5 # 使用特殊概率的玩家抽取次数
Info_Index_JoinGoldPoolPercmet = 6 # 玩家消耗元宝加入百分之多少到元宝池中

Item_Index_ID           = 0 # 道具编号
Item_Index_Info         = 1 # 道具信息(type,id,num或type,num)--通过长度来确定
Item_Index_Condition    = 2 # 抽取次数条件
Item_Index_HorseMsg     = 3 # 是否跑马灯公告
Item_Index_Player_Limit = 4 # 玩家限制次数，获得道具的次数
Item_Index_SvrDay_Limit = 5 # 服务器日限制，当前服务器每天只会出现多少个该道具
Item_Index_SvrTotal_Limit= 6 # 服务器总限制，当前服务器在活动期间只会产出多少个该道具
Item_Index_PersonDay_Limit= 7 # 个人日限制，当前个人每天只会出现多少个该道具
Item_Index_PersonMustGet = 8 # 个人抽奖次数达到逼得
Item_Index_ServerMustGet = 9 # 服务器抽奖次数达到逼得
Item_Pool_Num       = 8 # 奖池数量

class MysticLottery(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID

        self.mInfo = {} # {type: [单次消耗，10次消耗，每次获得积分，获得元宝奖池的百分比]}
        self.mNormalRatio = {} # 通用奖池概率信息 {type: [0号奖池概率,...]}
        self.mTop3Ratio = {} # 排行榜前3奖池概率信息 {type: [0号奖池概率,...]}
        self.mOtherRatio = {} # 其他特殊概率 {type: [0号奖池概率,...]}

        self.mItemPool = {} # 奖池信息 {type: [[id, (type,id,number), limit, horse, plrGotTimes, SvrDayLmtTimes, SvrTotalLmtTimes], ...]}

        self.mRankRewards = [] # [第一名奖励，...]

        # 玩家数据，[积分，获取积分时间] "t": [普通单次抽取次数，普通抽取总次数,高级单次抽取次数，高级抽取总次数],"r3": 使用概率3的次数 limit: {id: times}
        self.mInitData = {"m": [0, 0], "t": [0, 0, 0, 0], "r3": [0, 0], "limit": {1: {}, 2: {}}, "dayLimit":{1:{}, 2:{}}}

        self.mGoldMoneyPool = {MLottery_Type_1: 0, MLottery_Type_2: 0} # 奖池元宝总数
        self.mTopRank10 = [] # [[name, score, time, uuid], ...]

        self.mServerLimitInfo = {"times": [0, 0], "dayLimit": {1: {}, 2: {}}, "totalLimit": {1: {}, 2: {}}} # 服务器购买限制信息
        self.mServerLimitInfoUpdated = False

        self.mTopRankUpdated = False
        self.mGoldMoneyPoolUpdated = False
        self.mPoolGoldMoney = 0 # 元宝奖池中获得的元宝数--抽中元宝奖池

        self.mDispatchedReward = False
        self.mSavedActInfo = False

        self.mRecordEndTime = 0

    def getName(self):
        return "MysticLottery"

    def getInfo(self, player):
        ''' info格式
        {
        "Result": 1,
        "ResultDesc": "",
        "Action": "Info",
        "Info":
            {
            1: [每次抽取获得积分，单抽消耗，10连抽消耗，总奖池元宝, 奖池信息（[[type,id,num],...]）], # 普通抽取
            2: [每次抽取获得积分，单抽消耗，10连抽消耗，总奖池元宝, 奖池信息（[[type,id,num],...]）], # 高级抽取
            "t": [活动开始时间，结束时间], # 活动信息
            "r": [[rank, name, score, rewards[[type,id,num], ...]], ...], # 活动排名信息
            "m": [自己的积分, 排名, 普通转盘单次是否免费, 高级单次是否免费], # 如果排名是-1，表示未上榜，转盘每天第一次抽取免费
            }
        }
        '''

        myData = self.getPlayerData(player, self.mInitData)

        normalFree = 0
        highFree = 0
        if myData["t"][0] == 0:
            normalFree = 1
        if myData["t"][2] == 0:
            highFree = 1

        info = {
                MLottery_Type_1: self.formatInfoData(MLottery_Type_1),
                MLottery_Type_2: self.formatInfoData(MLottery_Type_2),
                "t": [self.mBeginTime, self.mEndTime, self.mEndTime - int(time.time())],
                "m": [myData["m"][0], self.getRank(player), normalFree, highFree],
                "r": self.getTop10()
                }

        return json.dumps({
                           "Result": 1,
                           "ResultDesc": "",
                           "Action": "Info",
                           "info": info,
                           "rankreward":self.mRankRewards
                           })

    def formatInfoData(self, typ):
        if typ in self.mInfo and typ in self.mItemPool and typ in self.mGoldMoneyPool:
            data = self.mInfo[typ]
            rewards = []
            for reward in self.mItemPool[typ]:
                rewards.append(reward[Item_Index_Info])
            return [
                    data[Info_Index_Get_Score], # 每次抽取获得积分
                    data[Info_Index_Per_Cost], # 单抽消耗
                    data[Info_Index_Ten_Cost], # 10连抽消耗
                    self.mGoldMoneyPool[typ], # 总奖池元宝
                    #data[Info_Index_Percent], # 获得总奖池的百分比（百分比表示）
                    rewards # 奖池信息，奖池道具中，如果len(rewards[i]) == 2 and rewards[i][0] == 2,则rewards[i][1]为显示的可以获得元宝池的元宝百分比
                    ]
        else:
            return []

    def updateRank(self, player, myData):
        name = player.getName()

        rankSize = len(self.mTopRank10)

        if rankSize == 0:
            self.mTopRank10.append([name, myData["m"][0], myData["m"][1], player.getUUID()])
            return True

        # 检测是否在前10的榜单中
        for i in xrange(rankSize):
            topItem = self.mTopRank10[i]
            if topItem[0] == name:
                topItem[1] = myData["m"][0]
                topItem[2] = myData["m"][1]

                index = i
                for j in xrange(i - 1, -1, -1):
                    other = self.mTopRank10[j]
                    if other[1] < topItem[1] or (other[1] == topItem[1] and other[2] > topItem[2]):
                        self.mTopRank10[index] = other
                        self.mTopRank10[j] = topItem
                        index = j

                return True

        # 榜单中没有自己
        for i in xrange(rankSize):
            topItem = self.mTopRank10[i]
            if myData["m"][0] > topItem[1]: # 后进入榜单的，时间肯定比先进入的大，所以这里就不再判断时间
                self.mTopRank10.insert(i, [name, myData["m"][0], myData["m"][1], player.getUUID()])
                if rankSize == 10: # 已经存够10个数据
                    self.mTopRank10.pop(rankSize)
                return True

        if len(self.mTopRank10) < 10:
            self.mTopRank10.append([name, myData["m"][0], myData["m"][1], player.getUUID()])
            return True

        return False

    def getRank(self, player):
        rank = -1
        name = player.getName()
        for i in xrange(len(self.mTopRank10)):
            topItem = self.mTopRank10[i]
            if topItem[0] == name:
                rank = i
                break

        return rank

    def getTop10(self):
        topInfo = [] #  [[rank, name, score, rewards[[type,id,num], ...]], ...]

        for i in xrange(len(self.mTopRank10)):
            topItem = self.mTopRank10[i]
            if i < len(self.mRankRewards):
                topInfo.append([i + 1, topItem[0], topItem[1], self.mRankRewards[i]])

        return topInfo

    def isInTop3(self, player):
        flag = False
        name = player.getName()

        for i in xrange(len(self.mTopRank10)):
            if i >= 3:
                break

            if self.mTopRank10[i][0] == name:
                flag = True
                break

        return flag

    def getRatioInfo(self, t, player, useOtherRatio):
        if useOtherRatio:
            return self.mOtherRatio[t]
        else:
            if self.isInTop3(player):
                return self.mTop3Ratio[t]
            else:
                return self.mNormalRatio[t]
    def canAddToRandomPool(self, item, lmtInfo, daylmtInfo, lotteryTimes, typ):
        idx = item[Item_Index_ID]
        if item[Item_Index_Condition] <= 0 or lotteryTimes >= item[Item_Index_Condition]: # 加入奖池的抽取次数限制
            if item[Item_Index_PersonDay_Limit] != -1:# 玩家每天产出道具次数限制
                if idx in daylmtInfo:
                    if daylmtInfo[idx] >= item[Item_Index_PersonDay_Limit]:
                        return False
            if item[Item_Index_Player_Limit] != -1: # 玩家有获得道具次数限制
                if idx in lmtInfo:
                    if lmtInfo[idx] >= item[Item_Index_Player_Limit]:
                        return False
            if item[Item_Index_SvrDay_Limit] != -1: # 服务器每天产出道具次数限制
                if idx in self.mServerLimitInfo["dayLimit"][typ]:
                    if self.mServerLimitInfo["dayLimit"][typ][idx] >= item[Item_Index_SvrDay_Limit]:
                        return False
            if item[Item_Index_SvrTotal_Limit] != -1: # 服务器活动期间总产出道具次数限制
                if idx in self.mServerLimitInfo["totalLimit"][typ]:
                    if self.mServerLimitInfo["totalLimit"][typ][idx] >= item[Item_Index_SvrTotal_Limit]:
                        return False
            return True
        else:
            return False

    def addRecord(self, myData, typ, item):
        flag = False
        idx = item[Item_Index_ID]
        if item[Item_Index_Player_Limit] != -1: # 玩家有获得道具次数限制
            #flag = True
            if idx in myData["limit"][typ]:
                myData["limit"][typ][idx] += 1
            else:
                myData["limit"][typ][idx] = 1
            # 个人日限制
            if idx in myData["dayLimit"][typ]:
                myData["dayLimit"][typ][idx] += 1
            else:
                myData["dayLimit"][typ][idx] = 1
        if item[Item_Index_SvrDay_Limit] != -1:
            flag = True
            if idx in self.mServerLimitInfo["dayLimit"][typ]:
                self.mServerLimitInfo["dayLimit"][typ][idx] += 1
            else:
                self.mServerLimitInfo["dayLimit"][typ][idx] = 1
        if item[Item_Index_SvrTotal_Limit] != -1:
            flag = True
            if idx in self.mServerLimitInfo["totalLimit"][typ]:
                self.mServerLimitInfo["totalLimit"][typ][idx] += 1
            else:
                self.mServerLimitInfo["totalLimit"][typ][idx] = 1

        return flag

    # 是否可以使用特殊规则，随机元宝（必中）
    def canRandGoldDirectly(self, t, myData, delta):
        condTimes = self.mInfo[t][Info_Index_GotGold_SvrTotalTimes]
        svrTimes = self.mServerLimitInfo["times"][t - 1] + delta
        return ((svrTimes != 0) and (svrTimes % condTimes == 0))

    def randItem(self, player, t, myData, delta, useOtherRatio):
        lotteryTimes = myData["t"][1 + (t - 1) * 2] + delta
        ratioInfo = self.getRatioInfo(t, player, useOtherRatio)

        items = []
        totalRatio = 0

        # 是否可以直接加元宝，服务器抽取次数累计到一定次数
        enableRandGoldDirectly = self.canRandGoldDirectly(t, myData, delta)
        servercount = self.mServerLimitInfo["times"][t - 1]
        cfgItems = self.mItemPool[t]
        for i in xrange(len(cfgItems)):
            item = cfgItems[i]
            # 达到服务器多少次
            if item[Item_Index_ServerMustGet] != -1:
                if item[Item_Index_ServerMustGet] == servercount:
                    flag = self.addRecord(myData, t, item)
                    if flag:
                        self.mServerLimitInfoUpdated = True
                    return item
            # 达到个人多少次
            if item[Item_Index_PersonMustGet] != -1:
                if item[Item_Index_PersonMustGet] == lotteryTimes:
                    flag = self.addRecord(myData, t, item)
                    if flag:
                        self.mServerLimitInfoUpdated = True
                    return item

            if enableRandGoldDirectly:
                if len(item[Item_Index_Info]) == 2 and item[Item_Index_Info][0] == REWARD_TYPE_GOLDMONEY:
                    items.append(item)
                    totalRatio += ratioInfo[item[Item_Index_ID]]
            elif self.canAddToRandomPool(item, myData["limit"][t], myData["dayLimit"][t], lotteryTimes, t):
                items.append(item)
                totalRatio += ratioInfo[item[Item_Index_ID]]

        if totalRatio == 0  and not enableRandGoldDirectly:
            return None

        if totalRatio == 0 and enableRandGoldDirectly and len(items) > 0:
            gold = (self.mGoldMoneyPool[t] - self.mPoolGoldMoney) * items[i][Item_Index_Info][1] / 100
            self.mPoolGoldMoney += gold
            gotItem = copy.deepcopy(items[0])
            gotItem[Item_Index_Info][1] = gold
            flag = self.addRecord(myData, t, gotItem)
            if flag:
                self.mServerLimitInfoUpdated = True
            return gotItem

        val = 0
        seed = random.randint(0, totalRatio) + 1
        for i in xrange(len(items)):
            val += ratioInfo[items[i][Item_Index_ID]]
            if seed <= val:
                if len(items[i][Item_Index_Info]) == 2 and items[i][Item_Index_Info][0] == REWARD_TYPE_GOLDMONEY: # 抽到元宝
                    gold = (self.mGoldMoneyPool[t] - self.mPoolGoldMoney) * items[i][Item_Index_Info][1] / 100
                    self.mPoolGoldMoney += gold
                    gotItem = copy.deepcopy(items[i])
                    gotItem[Item_Index_Info][1] = gold
                    flag = self.addRecord(myData, t, gotItem)
                    if flag:
                        self.mServerLimitInfoUpdated = True
                    return gotItem
                else:
                    flag = self.addRecord(myData, t, items[i])
                    if flag:
                        self.mServerLimitInfoUpdated = True
                    return items[i]
        return None

    def canUseOtherRatio(self, typ, delta, myData):
        r3times = myData["r3"][typ - 1]
        if (r3times + delta) != 0 and \
            self.mInfo[typ][Info_Index_UseOtherRatio] != 0 and\
             (r3times + delta) % self.mInfo[typ][Info_Index_UseOtherRatio] == 0:
                return True
        return False

    def doAction(self, player, actData):
        if not self.isActived(player):
            return Err_NotOpen

        request = json.loads(actData)

        if "Lottery" in request: # {"Lottery": [type, times]}
            typ = request["Lottery"][0]
            times = request["Lottery"][1]

            if typ not in self.mInfo: # 类型是否有效
                return Err_Invalid

            if times != 1 and times != 10: # 抽取次数是否有效
                return Err_Invalid

            myData = self.getPlayerData(player, self.mInitData)

            cost = 0
            if times == 1:
                if myData["t"][(typ - 1) * 2] > 0: # 第一次免费
                    cost = self.mInfo[typ][Info_Index_Per_Cost]
            else:
                cost = self.mInfo[typ][Info_Index_Ten_Cost]

            if cost > 0 and player.getGoldMoney() < cost:
                return Err_NotEnoughGoldMoney

            data = []
            stopIdx = []
            randedItems = []

            self.mPoolGoldMoney = 0

            useOtherRatio = False
            leftCountTimes = 0

            for i in xrange(times):
                tempFlag = self.canUseOtherRatio(typ, i, myData)
                if tempFlag:
                    useOtherRatio = True
                    leftCountTimes = times - i - 1

                item = self.randItem(player, typ, myData, i, tempFlag)
                if item:
                    randedItems.append(item)
                    data.append(item[Item_Index_Info])
                    stopIdx.append(item[Item_Index_ID])
                else:
                    return Err_Unknown

            if not self.canAddAllReward(player, data):
                return Err_NotEnoughSpace

            needClearR3Times = False

            for i in xrange(len(data)):
                self.addReward(player, data[i])
                gotItem = randedItems[i]
                #flag = self.addRecord(myData, typ, gotItem)
                #if flag:
                #    self.mServerLimitInfoUpdated = True

                if gotItem[Item_Index_HorseMsg] == 1: # 是否跑马灯公告
                    if len(data[i]) == 2:
                        if data[i][0] == REWARD_TYPE_GOLDMONEY:
                            MMain.sendHorseMessage(GlobalStrings[96] %(player.getName(), self.getLotteryName(typ), data[i][1]))
                            if useOtherRatio: # 使用规则其他规则抽到的大奖，清除次数
                                needClearR3Times = True
                    else:
                        itemName = MMain.getItemName(data[i][0], data[i][1])
                        MMain.sendHorseMessage(GlobalStrings[97] %(player.getName(), self.getLotteryName(typ), itemName))
                else:
                    if len(data[i]) == 2 and data[i][0] == REWARD_TYPE_GOLDMONEY:
                        if useOtherRatio: # 使用规则其他规则抽到的大奖，清除次数
                            needClearR3Times = True

            if needClearR3Times:
                myData["r3"][typ - 1] = leftCountTimes
            else:
                myData["r3"][typ - 1] += times

            if self.mPoolGoldMoney > 0: # 扣除奖池的元宝
                if self.mGoldMoneyPool[typ] < self.mPoolGoldMoney: # 元宝奖池配置获得的百分比高于100%
                    self.mGoldMoneyPool[typ] = 0
                else:
                    self.mGoldMoneyPool[typ] -= self.mPoolGoldMoney

            # add server record lottery times
            self.mServerLimitInfo["times"][typ - 1] += times

            if cost > 0:
                self.mGoldMoneyPoolUpdated = True
                joinGold = cost * self.mInfo[typ][Info_Index_JoinGoldPoolPercmet] / 100 # 通过配置来决定加入百分之多少到奖池中
                if joinGold > 0:
                    self.mGoldMoneyPool[typ] += joinGold

                    msg = GlobalStrings[98] %(cost, joinGold)
                    MMain.sendCenterMessage(player, msg)

                # 扣除元宝
                player.addGoldMoney(-cost)
                MMain.dbLogActivityUseGoldMoney(player, self.mID, cost)

            # update self data
            score = self.mInfo[typ][Info_Index_Get_Score] * times
            myData["m"][0] += score
            myData["m"][1] = int(time.time())

            offset = 0
            if typ == MLottery_Type_2:
                offset = 2

            myData["t"][1 + offset] += times
            if times == 1:
                myData["t"][0 + offset] += times

            flag = self.updateRank(player, myData)

            free = 0
            if times == 10:
                verfifyIndex = 0
                if typ == MLottery_Type_2:
                    verfifyIndex = 2
                if myData["t"][verfifyIndex] == 0:
                    free = 1

            result = {
                       "Result": 1,
                       "ResultDesc": "",
                       "Action": "Lottery",
                       "Lottery": {
                                   "request": request["Lottery"],
                                   "m": [myData["m"][0], self.getRank(player), myData["t"], free],
                                   "data": data,
                                   "stop": stopIdx,
                                   }
                       }

            if flag:
                self.mTopRankUpdated = True # 标记排行数据被修改
                result["r"] = self.getTop10()

            return json.dumps(result)

        return Err_Ok

    def getLotteryName(self, typ):
        if typ == MLottery_Type_1:
            return GlobalStrings[99]
        else:
            return GlobalStrings[100]

    def loadBaseInfo(self, path):
        filename = "%slotteryInfo.txt" % (path)

        tb = TabFile()
        if tb.load(filename):
            info = {}

            for i in xrange(tb.mRowNum):
                typ = tb.get(i, 0, 0, True)
                percost = tb.get(i, 1, 0, True)
                tencost = tb.get(i, 2, 0, True)
                perscore = tb.get(i, 3, 0, True)
                percent = tb.get(i, 4, 0, True)
                gotgoldmusttimes = tb.get(i, 5, 0, True)
                use3ratiotimes = tb.get(i, 6, 0, True)
                joinPercent = tb.get(i, 7, 0, True)

                info[typ] = [percost, tencost, perscore, percent, gotgoldmusttimes, use3ratiotimes, joinPercent]

            self.mInfo = info

            return True

        syserr("load mystic lottery info failed,%s" %(filename))
        return False

    def loadItemPool(self, path):
        filename = "%slotteryPool.txt" % (path)

        tb = TabFile()
        if tb.load(filename):
            itemPool = {}
            normalRatioInfo = {}
            top3RatioInfo = {}
            otherRatioInfo = {}

            for i in xrange(tb.mRowNum):
                typ           = tb.get(i, 0, 0, True)
                mid           = tb.get(i, 1, 0, True)
                itemStr       = tb.get(i, 2, "", False).replace("\"", "")
                ratio         = tb.get(i, 3, 0, True)
                top3Ratio     = tb.get(i, 4, 0, True)
                lmt           = tb.get(i, 5, 0, True)
                horse         = tb.get(i, 6, 0, True)
                limitTimes    = tb.get(i, 7, 0, True) # 个人总限制
                svrDayLmt     = tb.get(i, 8, 0, True) # 每天重置
                svrTotalLmt   = tb.get(i, 9, 0, True)
                otherRatio    = tb.get(i, 10, 0, True)
                personLmt     = tb.get(i, 11, 0, True)
                personMustGet = tb.get(i, 12, 0, True)
                serverMustGet = tb.get(i, 13, 0, True)
                if typ not in normalRatioInfo:
                    normalRatioInfo[typ] = [ratio]
                else:
                    normalRatioInfo[typ].append(ratio)

                if typ not in top3RatioInfo:
                    top3RatioInfo[typ] = [top3Ratio]
                else:
                    top3RatioInfo[typ].append(top3Ratio)

                if typ not in otherRatioInfo:
                    otherRatioInfo[typ] = [otherRatio]
                else:
                    otherRatioInfo[typ].append(otherRatio)

                if itemStr:
                    itemInfo = []
                    for reward in itemStr.split(";"):
                        if reward:
                            itemInfo = [int(value) for value in reward.split(",")]

                    if typ not in itemPool:
                        pool = []
                        pool.append([mid, itemInfo, lmt, horse, limitTimes, svrDayLmt, svrTotalLmt, personLmt, personMustGet, serverMustGet])
                        itemPool[typ] = pool
                    else:
                        itemPool[typ].append([mid, itemInfo, lmt, horse, limitTimes, svrDayLmt, svrTotalLmt, personLmt, personMustGet, serverMustGet])

            self.mTop3Ratio = top3RatioInfo
            self.mOtherRatio = otherRatioInfo
            self.mNormalRatio = normalRatioInfo
            self.mItemPool = itemPool

            return True

        syserr("load mystic lottery pool item failed,%s" %(filename))
        return False

    def loadRankRewards(self, path):
        filename = "%srankRewards.txt" % (path)

        tb = TabFile()
        if tb.load(filename):
            rewardsInfo = []

            for i in xrange(tb.mRowNum):
                rank = tb.get(i, 0, 0, True)
                itemStr = tb.get(i, 1, "", False).replace("\"", "")
                if itemStr:
                    itemInfo = [
                                    [int(value) for value in reward.split(",")]
                                        for reward in itemStr.split(";") if reward and reward.count(',') in (1, 2)
                                ]
                    rewardsInfo.append(itemInfo)
                else:
                    return False

            self.mRankRewards = rewardsInfo

            return True

        syserr("load mystic lottery rank rewards failed,%s" %(filename))
        return False

    def loadConfig(self, path):
        if not self.loadBaseInfo(path):
            return False

        if not self.loadRankRewards(path):
            return False

        if not self.loadItemPool(path):
            return False

        if self.mRecordEndTime != self.mEndTime: # 活动重新开始，清除旧的活动数据
            print "different mystic lottery end time load, reset data"
            self.clearSaveSetting() # 清理存储的数据

            self.mServerLimitInfoUpdated = False
            self.mTopRankUpdated = False
            self.mGoldMoneyPoolUpdated = False
            self.mDispatchedReward = False
            self.mSavedActInfo = False

            self.mRecordEndTime = self.mEndTime
            self.mGoldMoneyPool = {1: self.mInfo[1][Info_Index_BaseGoldPoolNum], 2: self.mInfo[2][Info_Index_BaseGoldPoolNum]}

        return True

    def dispatchRankReward(self, topData):
        now = int(time.time())
        for i in xrange(len(topData)):
            topItem = topData[i]

            # 发奖励
            head = GlobalStrings[101]
            body = GlobalStrings[102] %(topItem[0], i + 1)

            mail = {}
            mail["RecvUUID"] = topItem[3]
            mail["RecvName"] = topItem[0]
            mail["ValidTime"] = now + 86400 * 3
            mail["Head"] = head
            mail["Body"] = body
            mail["Res"] = []
            mail["Items"] = []

            if i >= len(self.mRankRewards):
                syserr("unknow rank in rank rewards configure")
                continue

            for reward in self.mRankRewards[i]:
                if len(reward) == 2:
                    mail["Res"].append(reward)
                elif len(reward) == 3:
                    mail["Items"].append(reward)

            MMain.sendMail(mail)

    def clearSaveSetting(self):
        MMain.setSetting("mysticlottery_pool", None)
        MMain.setSetting("mysticlottery_top10", None)
        MMain.setSetting("server_limit", None)

        self.mTopRank10 = []
        self.mGoldMoneyPool = {1: 0, 2: 0}
        self.mServerLimitInfo = {"times": [0, 0], "dayLimit": {1: {}, 2: {}}, "totalLimit": {1: {}, 2: {}}}

    def onLoadSetting(self):
        data1 = MMain.getSetting("mysticlottery_pool")
        if data1 and len(data1) == 2:
            self.mRecordEndTime = data1[0]
            self.mGoldMoneyPool = copy.deepcopy(data1[1])

            topData = MMain.getSetting("mysticlottery_top10")
            if topData and len(topData) > 0:
                self.mTopRank10 = copy.deepcopy(topData)

            svrLmt = MMain.getSetting("server_limit")
            if svrLmt:
                self.mServerLimitInfo = copy.deepcopy(svrLmt)

    def onSaveSetting(self):
        if self.mTopRankUpdated:
            MMain.setSetting("mysticlottery_top10", self.mTopRank10)
            self.mTopRankUpdated = False
        if self.mGoldMoneyPoolUpdated or not self.mSavedActInfo:
            MMain.setSetting("mysticlottery_pool", (self.mRecordEndTime, self.mGoldMoneyPool))
            self.mGoldMoneyPoolUpdated = False
            self.mSavedActInfo = True
        if self.mServerLimitInfoUpdated:
            MMain.setSetting("server_limit", self.mServerLimitInfo)
            self.mServerLimitInfoUpdated = False

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)
            self.onLoadSetting()
        elif msg == MSG_PLAYER_DAY_CHANGED:
            myData = self.getPlayerData(param0, self.mInitData)
            myData["t"][0] = 0
            myData["t"][2] = 0
            myData["dayLimit"] = {1: {}, 2: {}}
        elif msg == MSG_TIME_MINUTE: # 每分钟存储一次数据
            now = int(time.time())
            if now >= self.mRecordEndTime:
                if not self.mDispatchedReward:
                    self.dispatchRankReward(self.mTopRank10)
                    self.mDispatchedReward = True

                    self.clearSaveSetting() # 清空所有关联数据
            else:
                self.onSaveSetting()
        elif msg == MSG_DAY_CHANGED:
            self.mServerLimitInfo["dayLimit"] = {1: {}, 2: {}}
            self.mServerLimitInfoUpdated = True

    def getMenu(self, player, npcID):
        return []

ModuleID = 61
Instance = MysticLottery(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_DAY_CHANGED,
    MSG_TIME_MINUTE,
    MSG_DAY_CHANGED,
])
