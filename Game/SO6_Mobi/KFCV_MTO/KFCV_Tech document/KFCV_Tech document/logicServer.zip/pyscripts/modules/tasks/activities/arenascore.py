#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

class ArenaScore(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mGloble = {}
        self.mScore = {}
        self.mRewards = {}
        self.mArenaRecord = {}
    def isActived(self, player):
        return ActivityBase.isActived(self, player)

    def getName(self):
        return "ArenaScore"

    def getInfo(self, player):
        if player.getUUID() in self.mGloble:
            data = self.mGloble[player.getUUID()]
        else:
            data = []
        if player.getUUID() in self.mScore:
            score = self.mScore[player.getUUID()]
        else:
            score = 0

        info = {}
        info["Score"] = score
        reward = []
        for i in self.mRewards:
            canGetReward = False
            alreadyGet = False
            rewards = self.mRewards[i]
            if score >= i:
                canGetReward = True
            if i in data:
                alreadyGet = True
            reward.append((i, canGetReward, alreadyGet, rewards,))
        info["Rewards"] = reward

        return json.dumps(info)

    def doAction(self, player, actData):
        if self.isActived(player):
            actData = json.loads(actData)
            if player.getUUID() in self.mGloble:
                data = self.mGloble[player.getUUID()]
            else:
                data = []
            if player.getUUID() in self.mScore:
                score = self.mScore[player.getUUID()]
            else:
                score = 0

            idx = actData["Get"]
            if idx in self.mRewards:
                if score >= idx:
                    if idx in data:
                        return Err_Repetition
                    else:
                        rewards = self.mRewards[idx]
                        if self.canAddAllReward(player, rewards):
                            for reward in rewards:
                                self.addReward(player, reward)
                            data.append(idx)
                            self.mGloble[player.getUUID()] = data
                            return Err_Ok
                        else:
                            return Err_NotEnoughSpace
                else:
                    return Err_Cannot
            else:
                return Err_Invalid
        else:
            return Err_NotOpen

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)
        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = {}
            for i in xrange(tb.mRowNum):
                score = tb.get(i, 0, 0, True)
                rewardstr = tb.get(i, 1, "", False).replace("\"", "")

                extrareward = [
                    [int(value) for value in reward.split(",")]
                        for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2)
                ]

                rewards[score] = extrareward
            self.mRewards = rewards
            return True

        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)
            
            s = MMain.getSetting("arenascore_s")
            g = MMain.getSetting("arenascore_g")
            r = MMain.getSetting("arenarecord")
            zeroTime = self.getZerotimestamp()
            if s and s[0] == zeroTime:
                self.mScore = s[1]
            else:
                self.mScore = {}
            if g and g[0] == zeroTime:
                self.mGloble = g[1]
            else:
                self.mGloble = {}
            if r:
                self.mArenaRecord = r

        elif msg == MSG_DAY_CHANGED:
            self.mScore = {}
            self.mGloble = {}

        elif msg == MSG_PLAYER_ENTER_ARENA:
            player = param0
            t,rank = param1
            if t == 0:
                pass
            if player.getUUID() in self.mScore:
                score = self.mScore[player.getUUID()]
            else:
                score = 0

            if t == 1:
                score += 2
            elif t == 2:
                score += 1
            self.mScore[player.getUUID()] = score
            self.checkHasReward(player)

        elif msg == MSG_TIME_MINUTE:
            curTime = time.time()
            curLTime = time.localtime(curTime)
            if curLTime.tm_min % 10 == 3:
                zeroTime = self.getZerotimestamp()
                MMain.setSetting("arenascore_s", [zeroTime, self.mScore,])
                MMain.setSetting("arenascore_g", [zeroTime, self.mGloble, ])
                MMain.setSetting("arenarecord", self.mArenaRecord)

    def getMenu(self, player, npcID):
        return []

    def checkHasReward(self, player):
        hasReward = False
        score = self.mScore[player.getUUID()]
        for i in self.mRewards:
            if i <= score:
                if player.getUUID() not in self.mGloble:
                    hasReward = True
                    break
                else:
                    if i not in self.mGloble[player.getUUID()]:
                        hasReward = True
                        break

        self.notifyActReward(player, hasReward)

    def addArenaRecord(self, data):
        curTime = time.time()
        playerName = data[0]
        TargetName = data[1]
        status = data[2]
        uprank = data[3]
        if TargetName in self.mArenaRecord:
            while len(self.mArenaRecord[TargetName]) >= 3:
                del self.mArenaRecord[TargetName][0]
            self.mArenaRecord[TargetName].append((playerName, int(curTime), status, uprank))
        else:
            temp = []
            temp.append((playerName, int(curTime), status, uprank))
            self.mArenaRecord[TargetName] = temp

    def getArenaRecord(self, playerName):
        if playerName in self.mArenaRecord:
            return self.mArenaRecord[playerName]
        else:
            return []

    def sendArenaDanChange(self, player, dan):
        message = GlobalStrings[106]
        if dan == 0:
            message = GlobalStrings[107]
        elif dan == 200:
            message = GlobalStrings[108]
        elif dan == 1000:
            message = GlobalStrings[109]
        elif dan == 3000:
            message = GlobalStrings[110]
        elif dan == 5000:
            message = GlobalStrings[111]
        MMain.sendBoxMessage(player, message)

ModuleID = 12
Instance = ArenaScore(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_DAY_CHANGED,
    MSG_PLAYER_ENTER_ARENA,
    MSG_TIME_MINUTE,
])