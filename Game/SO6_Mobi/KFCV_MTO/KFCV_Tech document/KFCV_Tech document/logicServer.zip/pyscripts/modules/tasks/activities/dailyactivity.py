#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

TYPE_LOGIN              = 1#  登录
TYPE_LEVEL              = 2#  达到等级
TYPE_VIP_LEVEL          = 3#  达到VIP等级
TYPE_GET_MONEY          = 4#  获得金币
TYPE_BATTLE_POINT       = 5#  达到战力
TYPE_THIS_DUNGEON       = 6#  完成指定副本
TYPE_DUNGEON_NUM        = 7#  完成副本数量
TYPE_HARD_DUNGEON       = 8#  完成困难副本数量
TYPE_THIS_TASK          = 9#  完成指定任务
TYPE_TASK_NUM           = 10#  完成任务数量
TYPE_DAILY_TASK         = 11#  完成日常任务
TYPE_ARENA              = 12#  挑战竞技场
TYPE_ARENA_WIN          = 13#  获得竞技场胜利次数
TYPE_ROLE_TRAIN         = 14#  角色强化
TYPE_ITEM_DROP          = 15#  道具分解
TYPE_ITEM_EXCHANGE      = 16#  道具兑换
TYPE_ITEM_ADVANCE       = 17#  道具进阶
TYPE_ITEM_UPGRADE       = 18#  道具升级
TYPE_ITEM_STRENGTH      = 19#  道具强化(进阶和升级都是强化)
TYPE_SKILL_ADVANCE      = 20#  技能进阶
TYPE_SKILL_UPGARDE      = 21#  技能升级
TYPE_SKILL_STRENGTH     = 22#  技能强化(进阶和升级都是强化)
TYPE_TALENT_ADVANCE     = 23#  心法进阶(备用)
TYPE_TALENT_UPGRADE     = 24#  心法升级
TYPE_TALENT_STRENGTH    = 25#  心法强化(备用)
TYPE_STONE_USE          = 26#  镶嵌石头
TYPE_STONE_COMBINE      = 27#  合成石头
TYPE_SINGLE_PVP         = 28#  单人PVP
TYPE_SINGLE_BOSS        = 29#  单人BOSS
TYPE_MULT_BOSS          = 30#  多人BOSS
TYPE_BUY_MONEY          = 31#  金币兑换
TYPE_LOTTERY            = 32#  抽奖
TYPE_JOIN_GUILD         = 33#  加入公会
TYPE_FRIEND             = 34#  好友
TYPE_EIGHTEEN           = 35#  十八摸
TYPE_ESCORT             = 36#  护送
TYPE_MONEYDUNGEON       = 37# 雪月密境，
TYPE_ENDLESS            = 38# 无尽之塔
TYPE_PROTECTATHENA      = 39# 守卫佛塔
TYPE_UPGRADEPET         = 40# 升级宠物
TYPE_INVOKEPET          = 41# 获得宠物
TYPE_ADVANCEPET         = 42# 升阶宠物
TYPE_FINISHTHREESTAR    = 43# 三星通关
TYPE_ARENATOSTEP        = 44# 擂台赛到达某段位
TYPE_ITEM_UPGRADELEVEL  = 45# 道具强化最小等级
TYPE_PLUNDER            = 46# 掠夺


DATA_INDEX_POINT            = 0
DATA_INDEX_REWARD           = 1

DATA_TASK_INDEX_TYPE        = 0
DATA_TASK_INDEX_LEVEL       = 1
DATA_TASK_INDEX_NAME        = 2
DATA_TASK_INDEX_VALUE       = 3
DATA_TASK_INDEX_REWARD      = 4

class DailyActivity(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mTasks = {}
        self.mInitData = {}                 #taskType:count

    def getPlayerData(self, player):
        data = getModuleData(player, self.mID, {})
        if not "Tasks" in data:
            data["Tasks"] = copy.deepcopy(self.mInitData)

        return data

    def getName(self):
        return "DailyActivity"

    def isActived(self, player):
        if player.getLevel() >= 10:
            return True
        else:
            return False

    def getInfo(self, player):
        result = {}

        data = self.getPlayerData(player)
        taskData = data["Tasks"]

        showTaskData = []

        for tType in taskData:
            if tType in self.mTasks:
                realValue = taskData[tType]
                task = self.mTasks[tType]

                taskType = task[DATA_TASK_INDEX_TYPE]
                taskLevel = task[DATA_TASK_INDEX_LEVEL]
                taskName = task[DATA_TASK_INDEX_NAME]
                taskValue = task[DATA_TASK_INDEX_VALUE]
                taskReward = task[DATA_TASK_INDEX_REWARD]
                
                if realValue >= taskValue:
                    realValue = taskValue

                showTaskData.append((
                    taskType,
                    taskLevel,
                    taskName,
                    realValue,
                    taskValue,
                    taskReward,
                ))

        result["Tasks"] = showTaskData
        return json.dumps(result)

    def doAction(self, player, actData):
        actData = json.loads(actData)

        data = self.getPlayerData(player)
        taskData = data["Tasks"]
        taskType = actData["Complete"]

        if taskType in taskData and taskType in self.mTasks:
            realValue = taskData[taskType]
            task = self.mTasks[taskType]
            taskValue = task[DATA_TASK_INDEX_VALUE]
            taskLevel = task[DATA_TASK_INDEX_LEVEL]
            if realValue >= taskValue and player.getLevel() >= taskLevel:
                rewards = task[DATA_TASK_INDEX_REWARD]
                if self.canAddAllReward(player, rewards):
                    del taskData[taskType]
                    for reward in rewards:
                        self.addReward(player, reward)                    
                else:
                    return Err_NotEnoughSpace
                return Err_Ok
            else:
                return Err_Cannot
        else:
            return Err_Invalid

    def loadConfig(self, path):
        tasksFilename = "%stasks.txt" % (path)

        syslog("Loading DailyActivity config...")

        tb = TabFile()
        if tb.load(tasksFilename):
            tasks = {}
            initdata = {}
            for i in xrange(tb.mRowNum):
                task = []
                taskType = tb.get(i, DATA_TASK_INDEX_TYPE, 0, True)
                taskLevel = tb.get(i, DATA_TASK_INDEX_LEVEL, 0, True)
                taskName = tb.get(i, DATA_TASK_INDEX_NAME, "", False)                
                taskValue = tb.get(i, DATA_TASK_INDEX_VALUE, 0, True)
                tmpItems = tb.get(i, DATA_TASK_INDEX_REWARD, "", False).replace("\"", "")
                taskReward = []
                if tmpItems:
                    taskReward = [
                    [int(value) for value in reward.split(",")]
                        for reward in tmpItems.split(";") if reward and reward.count(',') in (1, 2)]
                task = [taskType, taskLevel, taskName, taskValue, taskReward,]

                tasks[taskType] = task
                initdata[taskType] = 0
            self.mTasks = tasks
            self.mInitData = initdata
            return True
        else:
            syserr("Load %s failed." % (tasksFilename))
            return False

    def addPoint(self, player, taskType, point):
        data = self.getPlayerData(player)
        taskData = data["Tasks"]
        
        if taskType in taskData:
            taskData[taskType] += point

        self.checkHasReward(player, taskType)

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        else:
            player = param0
            if player and self.isValid(player):
                if msg == MSG_PLAYER_ONLINE:
                    self.addPoint(player, TYPE_LOGIN, 1)
                    hasReward = False
                    if self.isActived(player):
                        data = self.getPlayerData(player)
                        taskData = data["Tasks"]
                        for taskType in taskData:
                            realValue = taskData[taskType]
                            task = self.mTasks[taskType]
                            if realValue >= task[DATA_TASK_INDEX_VALUE] and player.getLevel() >= task[DATA_TASK_INDEX_LEVEL]:
                                hasReward = True
                    if hasReward:
                        self.notifyActReward(player, hasReward)
                elif msg == MSG_PLAYER_LEVELUP:
                    hasReward = False
                    if self.isActived(player):
                        data = self.getPlayerData(player)
                        taskData = data["Tasks"]
                        for taskType in taskData:
                            realValue = taskData[taskType]
                            task = self.mTasks[taskType]
                            if realValue >= task[DATA_TASK_INDEX_VALUE] and player.getLevel() >= task[DATA_TASK_INDEX_LEVEL]:
                                hasReward = True
                    if hasReward:
                        self.notifyActReward(player, hasReward)

                elif msg == MSG_PLAYER_DAY_CHANGED:
                    data = self.getPlayerData(player)
                    data["Tasks"] = copy.deepcopy(self.mInitData)
                    self.addPoint(player, TYPE_LOGIN, 1)
                    self.notifyActReward(player, False)

                elif msg == MSG_PLAYER_FINISH_DUNGEON:
                    dungeon, dungeonStar, costTime = param1
                    dungeonID = dungeon.getID()
                    dungeonType = int(dungeonID / 10000)
                    if dungeonType == 2:
                        self.addPoint(player, TYPE_DUNGEON_NUM, 1)
                        if int(dungeon.getDungeonDegree()) != 0:
                            self.addPoint(player, TYPE_HARD_DUNGEON, 1)
                    elif dungeonType == 11:
                        self.addPoint(player, TYPE_MONEYDUNGEON, 1)
                    elif dungeonType == 5:
                        self.addPoint(player, TYPE_ENDLESS, 1)
                    elif dungeonType == 9:
                        self.addPoint(player, TYPE_PROTECTATHENA, 1)

                elif msg == MSG_PLAYER_SINGLE_PVP:
                    self.addPoint(player, TYPE_SINGLE_PVP, 1)

                elif msg == MSG_PLAYER_ENTER_ARENA:
                    result,rank = param1
                    if result == 0:
                        self.addPoint(player, TYPE_ARENA, 1)
                        
                    if result == 1:
                        self.addPoint(player, TYPE_ARENA_WIN, 1) 

                elif msg == MSG_PLAYER_TRAIN_ROLE:
                    self.addPoint(player, TYPE_ROLE_TRAIN, 1)

                elif msg == MSG_PLAYER_DROP_ITEM:
                    self.addPoint(player, TYPE_ITEM_DROP, 1)

                elif msg == MSG_PLAYER_STONE_USE:
                    self.addPoint(player, TYPE_STONE_USE, 1)

                elif msg == MSG_PLAYER_SINGLE_BOSS:
                    self.addPoint(player, TYPE_SINGLE_BOSS, 1)

                elif msg == MSG_PLAYER_LOTTERY:
                    typ, action = param1
                    if action == 1:
                        self.addPoint(player, TYPE_LOTTERY, 1)
                    elif action == 2:
                        self.addPoint(player, TYPE_LOTTERY, 10)

                elif msg == MSG_PLAYER_JOIN_EIGHTEEN:
                    self.addPoint(player, TYPE_EIGHTEEN, 1)
                elif msg == MSG_PLAYER_PET_INVOKE:
                    self.addPoint(player, TYPE_INVOKEPET, 1)
                elif msg == MSG_PLAYER_PET_UPGRADE:
                    self.addPoint(player, TYPE_UPGRADEPET, 1)
                elif msg == MSG_PLAYER_PET_ADVANCE:
                    self.addPoint(player, TYPE_ADVANCEPET, 1)
                elif msg == MSG_PLAYER_BUY_MONEY:
                    self.addPoint(player, TYPE_BUY_MONEY, 1)
                elif msg == MSG_PLAYER_JOIN_PLUDER:
                    self.addPoint(player, TYPE_PLUNDER, 1)

    def getMenu(self, player, npcID):
        return []

    def checkHasReward(self, player, taskType):
        hasReward = False
        if self.isActived(player):
            data = self.getPlayerData(player)
            taskData = data["Tasks"]
            if taskType in taskData and taskType in self.mTasks:
                realValue = taskData[taskType]
                task = self.mTasks[taskType]
                if realValue >= task[DATA_TASK_INDEX_VALUE] and player.getLevel() >= task[DATA_TASK_INDEX_LEVEL]:
                    hasReward = True

        self.notifyActReward(player, hasReward)

ModuleID = 11
Instance = DailyActivity(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_LEVELUP,
    MSG_PLAYER_DAY_CHANGED,
    MSG_PLAYER_FINISH_DUNGEON,
    MSG_PLAYER_SINGLE_PVP,
    MSG_PLAYER_ENTER_ARENA,
    MSG_PLAYER_TRAIN_ROLE,
    MSG_PLAYER_DROP_ITEM,
    MSG_PLAYER_STONE_USE,
    MSG_PLAYER_SINGLE_BOSS,
    MSG_PLAYER_LOTTERY,
    MSG_PLAYER_JOIN_EIGHTEEN,
    MSG_PLAYER_BUY_MONEY,
    MSG_PLAYER_JOIN_PLUDER,
    MSG_PLAYER_PET_INVOKE,
    MSG_PLAYER_PET_UPGRADE,
    MSG_PLAYER_PET_ADVANCE,
])
