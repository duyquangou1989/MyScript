#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

REWARD_INDEX_TYPE           = 0
REWARD_INDEX_VALUE          = 1

RESULT_NOT_ACTIVED = json.dumps({"Result":1, "ResultDesc":GlobalStrings[50]})
RESULT_INDEX_ERROR = json.dumps({"Result":2, "ResultDesc":GlobalStrings[173]})
RESULT_ALREADY = json.dumps({"Result":3, "ResultDesc":GlobalStrings[174]})
RESULT_BAG_FULL = json.dumps({"Result":4, "ResultDesc":GlobalStrings[168]})
RESULT_NOT_FINISHED = json.dumps({"Result":5, "ResultDesc":GlobalStrings[175]})

class AccumulativeRecharge(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID

        self.mRewards = {}
        self.mInitData = [0, {}]

    def isActived(self, player):
        actived = ActivityBase.isActived(self, player)

        data = self.getPlayerData(player, self.mInitData)
        for goldMoney in self.mRewards:
            if not goldMoney in data[1]:
                return actived
        return False

    def getName(self):
        return GlobalStrings[177]

    def getInfo(self, player):
        data = self.getPlayerData(player, self.mInitData)
        curGoldMoney = data[0]

        rewards = []
        for goldMoney in self.mRewards:
            canGetReward = False
            gotReward = False
            if curGoldMoney >= goldMoney:
                canGetReward = True
                if goldMoney in data[1]:
                    gotReward = True

            rewards.append((
                goldMoney,
                self.mRewards[goldMoney],
                canGetReward,
                gotReward,
            ))
        rewards.sort()

        info = {}
        info["Value"] = curGoldMoney
        info["Rewards"] = rewards
        info["BeginTime"] = self.mBeginTime
        info["EndTime"] = self.mEndTime

        return json.dumps(info)

    def doAction(self, player, actData):
        if self.isActived(player):
            data = self.getPlayerData(player, self.mInitData)

            actData = json.loads(actData)
            targetValue = actData["Value"]

            if targetValue in self.mRewards:
                if targetValue not in data[1]:
                    if data[0] >= targetValue:
                        rewards = self.mRewards[targetValue]
                        if self.canAddAllReward(player, rewards):
                            data[1][targetValue] = True
                            message = GlobalStrings[172]
                            for reward in rewards:
                                self.addReward(player, reward)
                                message += self.getRewardDesc(reward)

                            self.checkHasReward(player)
                            player.saveToDB()
                            return json.dumps({
                                "Result": 0,
                                "ResultDesc": message,
                            })
                        else:
                            return RESULT_BAG_FULL
                    else:
                        return RESULT_NOT_FINISHED
                else:
                    return RESULT_ALREADY
            else:
                return RESULT_INDEX_ERROR

        else:
            return RESULT_NOT_ACTIVED

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)

        syslog("Loading AccumulativeRecharge config...")

        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = {}
            for i in xrange(tb.mRowNum):
                offset = 0;

                goldMoney = tb.get(i, 0, 0, True)
                rewardType = tb.get(i, 1, 0, True)
                rewardValue = tb.get(i, 2, "", False).replace("\"", "")

                if rewardType == REWARD_TYPE_ITEM:
                    tmpItems = []
                    tmpBlocks = rewardValue.split(";")
                    for tmpBlock in tmpBlocks:
                        itemBlocks = tmpBlock.split(",")
                        if len(itemBlocks) == 3:
                            tmpItems.append((
                                int(itemBlocks[0]),
                                int(itemBlocks[1]),
                                int(itemBlocks[2]),
                            ))
                    rewardValue = tmpItems
                else:
                    rewardValue = int(rewardValue)

                if goldMoney in rewards:
                    rewards[goldMoney].append((
                        rewardType,
                        rewardValue,
                    ))
                else:
                    rewards[goldMoney] = [(
                        rewardType,
                        rewardValue,
                    ),]

            self.mRewards = rewards

            return True

        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False

    def checkHasReward(self, player):
        data = self.getPlayerData(player, self.mInitData)

        hasReward = False
        for targetValue in self.mRewards:
            if targetValue not in data[1]:
                if data[0] >= targetValue:
                    hasReward = True
                    break

        self.notifyActReward(player, hasReward)

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_ONLINE:
            player = param0

            if self.isActived(player):
                self.checkHasReward(player)

        elif msg == MSG_PLAYER_GOLDMONEY_CHANGED:
            player = param0
            value, way, productId = param1

            if self.isActived(player):
                if way == GMCW_Pay:
                    data = self.getPlayerData(player, self.mInitData)
                    data[0] += value
                    self.checkHasReward(player)

    def getMenu(self, player, npcID):
        return []


ModuleID = 12
Instance = AccumulativeRecharge(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_GOLDMONEY_CHANGED,
])
