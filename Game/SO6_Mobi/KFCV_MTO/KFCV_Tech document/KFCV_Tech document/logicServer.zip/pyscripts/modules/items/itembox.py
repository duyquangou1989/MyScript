#coding=utf8

import MMain
import MItem
import item
import json
from gamedefines import *
from traceback import print_exc
from activitybase import *

class ItemBox(item.Item):
    def __init__(self):
        item.Item.__init__(self)
        self.mColor = ["2EE43E","2EE43E","2EE43E","13b1ff","13b1ff","13b1ff","AE2DE6","AE2DE6","AE2DE6","E68D2D","E68D2D","E68D2D"]

    def canUse(self, player):
        if self.getLevelLimitation() > player.getLevel():
            return False
        elif not self.isAvailable():
            return False 
        return True

    def doUse(self, player):
        if self.canUse(player):
            giftSubType = self.getItemSubType()
            giftID = self.getID()
            try:
                import gift
                rewards = gift.Instance.calReward(giftID)            
                if self.canAddAllReward(player, rewards):
                    self.changeNum(-1)

                    for reward in rewards:
                        self.addReward(player, reward)
                        msg = GlobalStrings[0]
                        if len(reward) == 3:
                            #itemName = MMain.getItemName(reward[0], reward[1])
                            msg += self.getRewardDesc(reward)
                        if len(reward) == 2:
                            if reward[0] == REWARD_TYPE_MONEY:
                                msg += GlobalStrings[1] % reward[1]
                            elif reward[0] == REWARD_TYPE_GOLDMONEY:
                                msg += GlobalStrings[2] % reward[1]
                            elif reward[0] == REWARD_TYPE_VITALITY:
                                msg += GlobalStrings[3] % reward[1]
                            elif reward[0] == REWARD_TYPE_EXPERIENCE:
                                msg += GlobalStrings[4] % reward[1]
                            elif reward[0] == REWARD_TYPE_ENERGY:
                                msg += GlobalStrings[5] % reward[1]
                            elif reward[0] == REWARD_TYPE_SPAR:
                                msg += GlobalStrings[6] % reward[1]

                        MMain.sendCenterMessage(player, msg)

                    return True
                else:
                    MMain.sendCenterMessage(player, GlobalStrings[7]) 
            except:
                print_exc()
                return False
        else:
            MMain.sendCenterMessage(player, GlobalStrings[8])
                
        return False

    def canAddAllReward(self, player, rewards):
        items = {}
        for reward in rewards:
            if len(reward) == 3:
                itemType = reward[0]
                itemID = reward[1]
                itemNum = reward[2]

                if itemType in items:
                    if itemID in items[itemType]:
                        items[itemType][itemID] += itemNum
                    else:
                        items[itemType][itemID] = itemNum
                else:
                    items[itemType] = {
                        itemID: itemNum
                    }

        if len(items):
            realItems = []
            for itemType in items:
                for itemID in items[itemType]:
                    itemNum = items[itemType][itemID]
                    realItems.append((
                        itemType,
                        itemID,
                        itemNum,
                    ))
            if player.canAddToBag(realItems):
                return True
            else:
                return False
        else:
            return True
        
    def addReward(self, player, reward):
        if len(reward) == 3:
                MMain.addItemToPlayer(player, MMain.createItem(reward[0], reward[1], reward[2]))

        elif len(reward) == 2:
            rewardType = reward[0]
            rewardValue = reward[1]

            if rewardType == REWARD_TYPE_MONEY:
                player.addMoney(rewardValue)

            elif rewardType == REWARD_TYPE_GOLDMONEY:
                player.addGoldMoney(rewardValue)

            elif rewardType == REWARD_TYPE_GOLDMONEY_PURCHASED:
                pass

            elif rewardType == REWARD_TYPE_VITALITY:
                player.addVitality(rewardValue)

            elif rewardType == REWARD_TYPE_EXPERIENCE:
                player.addExperience(rewardValue)

            elif rewardType == REWARD_TYPE_ENERGY:
                player.addEnergy(rewardValue)

            elif rewardType == REWARD_TYPE_SPAR:
                player.addSpar(rewardValue)

    def getItemColor(self, itemQuality):
        if itemQuality >= 0 and itemQuality <= 11:
            return self.mColor[itemQuality]
        else:
            return "FFFFFF"

    def getRewardDesc(self, reward):
        if len(reward) == 3:
            itemName = MMain.getItemName(reward[0], reward[1])
            itemQuality = MMain.getItemQuality(reward[0], reward[1])
            return "[%s]%s[-]x%s" % (self.getItemColor(itemQuality), itemName, reward[2])
        else:
            return ""
item.gItemMgr.register(MItem.ItemType.Box, ItemBox)
