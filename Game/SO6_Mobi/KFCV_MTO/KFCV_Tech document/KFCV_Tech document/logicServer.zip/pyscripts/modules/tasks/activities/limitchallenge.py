#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

TASK_TYPE_LEVEL        = 1
TASK_TYPE_POWER        = 2
TASK_TYPE_DAILYGOLDUSE = 3
TASK_TYPE_TOTALGOLDUSE = 4

TASK_DESC_TYPE     = 0
TASK_DESC_LABEL    = 1
TASK_DESC_VALUE    = 2
TASK_DESC_BEGIN    = 3
TASK_DESC_CONTINUE = 4
TASK_DESC_DETAIL   = 5

TASK_ID       = 0
TASK_LABEL    = 1
TASK_TYPE     = 2
TASK_LEVEL    = 3
TASK_BEGIN    = 4
TASK_CONTINUE = 5
TASK_DESC     = 6
TASK_VALUE    = 7
TASK_REWARD   = 8

class LimitChallenge(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        self.mID = moduleID
        self.mTasks = {}     #tid:[id, label, type, level, begin, continue, value, rewardid[,],]
        self.mGlobal = {}    #UUID:self.mInitData
        self.mInitData = {}  #taskid:[realvalue, taskvalue, canget, got, invalid]
        self.mActivityDesc = {}    #taskType:[type, label, time]
        self.mDebugTime = 0

    def isActived(self, player):
        return ActivityBase.isActived(self, player)

    def getName(self):
        return "LimitChallenge"

    def changeDebugTime(self, time):
        self.mDebugTime = time

    def getPlayerData(self, player):
        if "s_limitchallenge" not in player.__dict__:
            data = copy.deepcopy(self.mInitData)
            curDay = self.getCurDay()
            for tid in data:
                if tid in self.mTasks:
                    task = self.mTasks[tid]
                    endTime = task[TASK_BEGIN] + task[TASK_CONTINUE]
                    detail = data[tid]
                    if curDay >= endTime:
                        detail[4] = True
                    if task[TASK_TYPE] == TASK_TYPE_LEVEL:
                        detail[0] = player.getLevel()
                    elif task[TASK_TYPE] == TASK_TYPE_POWER:
                        detail[0] = player.getBattlePoint()
            player.s_limitchallenge = data
        return player.s_limitchallenge

    def getLastEndTime(self, player):
    	if "s_lcEnd" not in player.__dict__:
    		player.s_lcEnd = 0
    	return player.s_lcEnd

    def getCurDay(self):
        return int((self.getCurTime() - self.mBeginTime) / 86400) + 1

    def getCurTime(self):
        return (int)(time.time() + self.mDebugTime)

    def getInfo(self, player):
        result = {}
        taskData = self.getPlayerData(player)
        curDay = self.getCurDay()
        tasksDesc = []
        validType = []
        tasksDetail = []

        for taskType in self.mActivityDesc:
            desc = self.mActivityDesc[taskType]
            curTime = self.getCurTime()
            if curTime >= desc[3] and curTime < desc[4]:
                tasksDesc.append(self.mActivityDesc[taskType])
                validType.append(taskType)

        for tid in taskData:
            detail = taskData[tid]
            if tid in self.mTasks:
                realValue = detail[0]
                task = self.mTasks[tid]
                taskType     = task[TASK_TYPE]
                if taskType in validType:
                    taskID       = task[TASK_ID]
                    taskLevel    = task[TASK_LEVEL]
                    taskBegin    = task[TASK_BEGIN]
                    taskContinue = task[TASK_CONTINUE]
                    taskDesc     = task[TASK_DESC]
                    taskValue    = task[TASK_VALUE]
                    taskReward   = task[TASK_REWARD]
                    realValue    = detail[0]
                    canGetReward = detail[2]
                    alreadyGet   = detail[3]
                    invalid      = detail[4]

                    tasksDetail.append((
                        taskID,
                        taskType,
                        taskLevel,
                        taskBegin,
                        taskContinue,
                        taskDesc,
                        realValue,
                        taskValue,
                        taskReward,
                        canGetReward,
                        alreadyGet,
                        invalid,
                    ))

        result["Desc"] = tasksDesc
        result["Detail"] = tasksDetail
        result["CurDay"] = self.getCurDay()
        result["BeginTime"] = self.mBeginTime
        result["EndTime"] = self.mEndTime

        return json.dumps(result)

    def doAction(self, player, actData):
        actData = json.loads(actData)
        taskData = self.getPlayerData(player)
        taskID = actData["Complete"]
        curDay = self.getCurDay()
        
        if taskID in taskData and taskID in self.mTasks:
            detail = taskData[taskID]
            realValue = detail[0]
            task = self.mTasks[taskID]
            taskBegin = task[TASK_BEGIN]
            taskValue = task[TASK_VALUE]
            
            if curDay >= taskBegin:
                if detail[2]:
                    if not detail[3]:
                        rewards = task[TASK_REWARD]
                        for reward in rewards:
                            self.addReward(player, reward)
                        detail[3] = True
                        
                        return Err_Ok
                    else:
                        return Err_Repetition
                else:
                    return Err_Cannot
            else:
                return Err_Cannot
        else:
            return Err_Invalid
                            
    def doTask(self, player, ttype, extra):
        hasReward = False
        taskData = self.getPlayerData(player)
        for taskID in taskData:
            detail = taskData[taskID]
            
            if taskID in self.mTasks:
                task = self.mTasks[taskID]
                taskBegin = task[TASK_BEGIN]
                taskEnd = task[TASK_CONTINUE] + taskBegin
                curDay = self.getCurDay()

                if task[TASK_TYPE] == ttype:
                    if ttype == TASK_TYPE_POWER or ttype == TASK_TYPE_LEVEL:
                        detail[0] = extra
                    elif ttype == TASK_TYPE_DAILYGOLDUSE or ttype == TASK_TYPE_TOTALGOLDUSE:
                        if curDay >= taskBegin:
                            detail[0] += extra
                    
                    if not detail[3] and not detail[4]:
                        if curDay >= taskEnd:
                            detail[2] = False
                            detail[4] = True
                        elif curDay >= taskBegin:
                            if detail[0] >= detail[1]:
                                detail[2] = True
                                hasReward = True
        if hasReward:
            self.notifyActReward(player, hasReward)

    def updatePlayerData(self, player, dayChange):
    	curDay = self.getCurDay()
        curTime = self.getCurTime()
        lastEndTime = self.getLastEndTime(player)
        if curTime > lastEndTime:
            player.s_limitchallenge = {}
            player.s_lcEnd = self.mEndTime

        taskData = self.getPlayerData(player)
        hasReward = False

        #check player data
        for tid in self.mTasks:
            task = self.mTasks[tid]

            taskBegin    = task[TASK_BEGIN]
            taskContinue = task[TASK_CONTINUE]
            taskValue    = task[TASK_VALUE]
            taskType     = task[TASK_TYPE]
            if tid not in taskData:
                taskData[tid] = [0, taskValue, False, False, False]
            else:
                taskData[tid][1] = taskValue
            detail = taskData[tid]

            if curDay < taskBegin:
                detail[0] = 0
                detail[2] = False
                detail[3] = False
                detail[4] = False
            elif curDay >= taskBegin and curDay < taskBegin + taskContinue:
                detail[4] = False
                if not detail[3]:
                    if detail[0] >= detail[1]:
                        detail[2] = True
                    else:
                        detail[2] = False
            else:
                detail[2] = False
                detail[3] = False
                detail[4] = True

        for tid in taskData:
            if tid in self.mTasks:
                task = self.mTasks[tid]
                detail = taskData[tid]
                if task[TASK_TYPE] == TASK_TYPE_DAILYGOLDUSE and dayChange:
                    detail[0] = 0
                    detail[2] = False
                    detail[3] = False
                    detail[4] = False
                else:
                    if not detail[4] and not detail[3]:
                        taskBegin = task[TASK_BEGIN]
                        taskEnd = task[TASK_BEGIN] + task[TASK_CONTINUE]
                        if detail[2]:
                            if taskEnd <= curDay:
                                detail[2] = False
                                detail[3] = False
                                detail[4] = True
                            else:
                                hasReward = True
                        else:
                            if taskBegin <= curDay and taskEnd > curDay:
                                if detail[0] > detail[1]:
                                    detail[2] = True
                                    hasReward = True
                            elif taskEnd <= curDay:
                                detail[4] = True

                    if task[TASK_TYPE] == TASK_TYPE_LEVEL:
                        detail[0] = player.getLevel()

                    elif task[TASK_TYPE] == TASK_TYPE_POWER:
                        detail[0] = player.getBattlePoint()

        if hasReward:
            self.notifyActReward(player, hasReward)

    def loadConfig(self, path):
        tasksFilename = "%stasks.txt" % (path) #task
        descFilename = "%sdesc.txt" % (path) #taskDesc

        syslog("Loading limitChallenge config...")

        tb = TabFile()
        if tb.load(descFilename):
            activeDesc = {}
            for i in xrange(tb.mRowNum):
                task = []

                taskType        =     tb.get(i, TASK_DESC_TYPE, 0, True)
                taskLabel       =     tb.get(i, TASK_DESC_LABEL, "", False)
                taskValue       =     tb.get(i, TASK_DESC_VALUE, "", False)
                taskBegin       =     tb.get(i, TASK_DESC_BEGIN, 0, True)
                taskContinue    =     tb.get(i, TASK_DESC_CONTINUE, 0, True)
                taskDetail      =     tb.get(i, TASK_DESC_DETAIL, "", False)
                taskBeginTime   =     self.mBeginTime + (taskBegin - 1) * 86400
                taskEndTime     =     taskBeginTime + taskContinue * 86400 - 1
                task = [taskType, taskLabel, taskValue, taskBeginTime, taskEndTime, taskDetail]

                if taskType not in activeDesc:
                    activeDesc[taskType] = task
            self.mActivityDesc = activeDesc
        else:
            syserr("Load %s failed." % (descFilename))
            return False

        tb = TabFile()
        if tb.load(tasksFilename):
            tasks = {}
            initdata = {}
            for i in xrange(tb.mRowNum):
                task = []

                taskID          =     tb.get(i, TASK_ID, 0, True)
                taskLabel       =     tb.get(i, TASK_LABEL, "", False)
                taskType        =     tb.get(i, TASK_TYPE, 0, True)
                taskLevel       =     tb.get(i, TASK_LEVEL, 0, True)
                taskDesc        =     tb.get(i, TASK_DESC, "", False)
                taskValue       =     tb.get(i, TASK_VALUE, 0, True)
                taskBegin       =     tb.get(i, TASK_BEGIN, 0, True)
                taskContinue    =     tb.get(i, TASK_CONTINUE, 0, True)
                tmpItems        =     tb.get(i, TASK_REWARD, "", False).replace("\"", "")

                if tmpItems:
                    taskReward = [
                        [int(value) for value in reward.split(",")]
                            for reward in tmpItems.split(";") if reward and reward.count(',') in (1, 2)
                    ]

                desc = self.mActivityDesc[taskType]
                actBegin = desc[3]
                actEnd = desc[4]
                subBegin = actBegin + (taskBegin - 1) * 86400
                subEnd = subBegin + taskContinue * 86400 - 1
                
                if subEnd > actEnd:
                    syserr(" %s config error." % (tasksFilename))
                    return False
                subBeginDay = (int)((subBegin - self.mBeginTime) / 86400) + 1
                task = [taskID, taskLabel, taskType, taskLevel, subBeginDay, taskContinue, taskDesc, taskValue, taskReward]
                tasks[taskID] = task
                initdata[taskID] = [0, taskValue, False, False, False]

            self.mTasks = tasks
            self.mInitData = initdata
        else:
            syserr("Load %s failed." % (tasksFilename))
            return False

        return True

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        # elif msg == MSG_DAY_CHANGED:
        #     if self.getCurTime() >= self.mEndTime:
        #         self.mGlobal = {}
        #         MMain.setSetting("LimitChallenge", self.mGlobal)

        elif self.isActived(param0):
            player = param0
            if msg == MSG_PLAYER_DAY_CHANGED:
                self.updatePlayerData(player, True)
            elif msg == MSG_PLAYER_LEVELUP:
                self.doTask(player, TASK_TYPE_LEVEL, player.getLevel())
            elif msg == MSG_PLAYER_BATTLEPOINT_CHANGED:
                self.doTask(player, TASK_TYPE_POWER, player.getBattlePoint())
            elif msg == MSG_PLAYER_ONLINE:
                self.updatePlayerData(player, False)
            elif msg == MSG_PLAYER_GOLDMONEY_CHANGED:
                if param1[1] == GMCW_GoldMoneyUse:
                    self.doTask(player, TASK_TYPE_DAILYGOLDUSE, -param1[0])
                    self.doTask(player, TASK_TYPE_TOTALGOLDUSE, -param1[0])

ModuleID = 57
Instance = LimitChallenge(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
    MSG_DAY_CHANGED,
    MSG_PLAYER_DAY_CHANGED,
    MSG_PLAYER_GOLDMONEY_CHANGED,
    MSG_PLAYER_LEVELUP,
    MSG_PLAYER_BATTLEPOINT_CHANGED,
])