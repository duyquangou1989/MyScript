#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
import util
import datetime
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *
from traceback import print_exc
from guildbattlemsghandler import *
from guildbattlemsghandler_fight import *
from guildbattle_reward import *
from guildbattlecfg import *

OpenSwitch = True
Debug = False
EnterNoLimt = False

Battle_Msg_List = [
    MSG_BATTLEGAME_GAME_DATA_SYNC,
    MSG_BATTLEGAME_PLAYER_JOINED,
    MSG_BATTLEGAME_PLAYER_DEAD,
    MSG_BATTLEGAME_PLAYER_QUIT,
    MSG_BATTLEGAME_ACTOR_DEAD,
    MSG_BATTLEGAME_PLAYER_REVIVE,
    MSG_BATTLEGAME_PLAYER_NEED_REVIVE,
    MSG_BATTLEGAME_PLAYER_REQUEST_REVIVE,
]

class GuildBattle(ActivityBase):
    def __init__(self, taskID):
        ActivityBase.__init__(self)
        self.mID = ModuleID

        self.mPeriod = GUILD_BATTLE_PERIOD_NONE
        self.mLastPeriod = GUILD_BATTLE_PERIOD_NONE

        self.mGameIndex = -1
        #self.mGuildBattleMgr = GuildBattleMgr()

        engine.Instance.registerTextProtocol("C2S_GuildBattleHelp", self.onAskHelp)

        self.mPeriodHandlerNone = GuildBattleHandler_None(self)
        self.mPeriodHandlerAuction = GuildBattleHandler_Auction(self)
        self.mPeriodHandlerShow = GuildBattleHandler_Show(self)
        self.mPeriodHandlerFight = GuildBattleHandler_Fight(self)
        self.mPeriodHandlerOver = GuildBattleHandler_Over(self)
        self.mPeriodHandler = self.mPeriodHandlerNone
        self.mPeriodHandlers = {}
        self.mPeriodHandlers[GUILD_BATTLE_PERIOD_NONE]      = self.mPeriodHandlerNone
        self.mPeriodHandlers[GUILD_BATTLE_PERIOD_AUCTION]   = self.mPeriodHandlerAuction
        self.mPeriodHandlers[GUILD_BATTLE_PERIOD_SHOW]      = self.mPeriodHandlerShow
        self.mPeriodHandlers[GUILD_BATTLE_PERIOD_FIGHT]     = self.mPeriodHandlerFight
        self.mPeriodHandlers[GUILD_BATTLE_PERIOD_OVER]      = self.mPeriodHandlerOver

        self.resetFightData()
        self.mGuildIdNames = {}     # id to name

        self.mPersonalRank = []         # 排好序的列表，定时刷新
        self.mPersonalRankPart = []         # 排好序的列表（取前20），直接返回给客户端
        self.mPersonalRankByName = {}   #  {名字:排名}
        self.mPersonalRankTime = 0      # 刷新时间


        self.mBattleFieldIds = {}       # towerNo : BS的战场ID
        self.mBattleFieldIndexs = {}    # id to towerNo
        self.mInitOver = False

    def resetFightData(self):
        self.mTowerData = {}
        for i in Battle_Towers_List:
            self.mTowerData[i] = [{}, None]  # 人的列表{公会1:[A，B], 公会2:[c，d]}，占领公会，

        self.mCityFight = {}    # {1:[公会1，公会2]} 防守方在前面
        self.mFightData = {}    # {公会名:[公会鼓舞剩余时间]}
        self.mRewardData = {}   # {玩家名:{1:100, 2:200}}
        self.mTimer = 0
        self.mPlayerFightData = {}  # {玩家名:[]} #[血量1，血量2，血量3],复活剩余时间, 个人鼓舞剩余时间，免费复活一次时间，进攻buf剩余时间
        self.mCityOccupyResult ={}  # 占领信息 {公会名:[[1,原公会], [3, None]]}
        self.mCityOccupyedResult = {} # 被占领信息 {公会名:[[1,新公会]]}

    def newRound(self):
        self.mPlayerData = {"killRank":{}}
        self.mCitySaveData["auction"] = {}

        self.mCityAucRank = {}
        for no in Battle_City_Connect:
            self.mCityAucRank[no] = []

        self.resetFightData()

    def invoke(self, msg, param0, param1):

        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)
        elif msg == MSG_ACTIVITY_STARTOVER:
            self.loadConfig("settings/guild/activity/guildbattle/")

            if not self.isActived(None):
                self.mPeriod = GUILD_BATTLE_PERIOD_NONE
            else:
                self.mPeriod, self.mWeekPeriod = self.calThisWeekPeriod()

            self.mLastPeriod = self.mPeriod
            print("guild battle period:" + str(self.mPeriod))

            # 读取数据库的数据
            self.mGuildData = self.getSetting("GuildBattleData")
            if not self.mGuildData:
                self.mGuildData = {}

            if "victory" not in self.mGuildData:
                self.mGuildData["victory"] = [None,0]     # 第一公会，连胜记录

            #  "name1" : [3, 1,公会名] # 击杀，死亡
            self.mPlayerData = self.getSetting("GuildBattlePlayerData")
            if not self.mPlayerData:
                self.mPlayerData = {"killRank":{}}

            self.mCitySaveData = self.getSetting("GuildBattleCityData")
            if not self.mCitySaveData:
                self.mCitySaveData = {"occupy":{}, "auction":{}}

            if "auction" not in self.mCitySaveData:
                self.mCitySaveData["auction"] = {}

            # {no : [['aaa', 11], ['ccc', 3], ['bbb', 2]]}
            self.mCityAucRank = {}
            for no in Battle_City_Connect:
                self.mCityAucRank[no] = []

            self.refreshAuctionRank()

            self.mInitOver = True

        # 服务器退出要存一次盘
        elif msg == MSG_SERVER_SHUTDOWN:
            if self.mInitOver:
                print("Save guild battle db when shutdown!")
                self.dataSaveToDB()

        elif msg == MSG_PLAYER_ONLINE:
            self.mPeriodHandlers[self.mPeriod].processPlayerOnline(param0)

        if not self.isActived(None) or not OpenSwitch:
            return

        if msg in Battle_Msg_List:
            self.mPeriodHandlers[self.mPeriod].processBattleMsg(msg, param0, param1)
        elif msg == MSG_PLAYER_JOIN_GUILD:
            self.sendInfoToPlayer(param0)

        elif msg == MSG_BATTLEGAME_GAME_STARTED:
            gameID = param0
            self.mGameIndex = gameID

            syslog("Game %s started." % (gameID))

        elif msg == MSG_BATTLEGAME_GAME_START_FAILED:
            gameID = param0
            self.mGameIndex = -1

            cityNo = self.mBattleFieldIndexs.get(gameID)
            if cityNo:
                if cityNo in self.mBattleFieldIds:
                    del self.mBattleFieldIds[cityNo]

                del self.mBattleFieldIndexs[gameID]

            syslog("Game %s start failed." % (gameID))

        elif msg == MSG_BATTLEGAME_GAME_FINISHED:
            gameID = param0
            if gameID == self.mGameIndex:
                self.mGameIndex = -1

            cityNo = self.mBattleFieldIndexs.get(gameID)
            if cityNo:
                if cityNo in self.mBattleFieldIds:
                    del self.mBattleFieldIds[cityNo]

                del self.mBattleFieldIndexs[gameID]


            syslog("Game %s finished" % (gameID))

        elif msg == MSG_TIME_MINUTE:
            if not Debug:
                self.mLastPeriod = self.mPeriod
                self.mPeriod, self.mWeekPeriod = self.calThisWeekPeriod()
                if self.mPeriod != self.mLastPeriod:
                    self.mPeriodHandlers[self.mLastPeriod].onExitPeriod()
                    self.mPeriodHandlers[self.mPeriod].onEnterPeriod()

            self.checkDayReward()

            self.processMsg(msg, param0, param1)
        else:
            self.processMsg(msg, param0, param1)

    def loadConfig(self, path):
        #print("load config:" + path)
        timeCfgs = []
        tb = TabFile()
        if tb.load(path + "time.txt"):
            for i in range(tb.mRowNum):
                timeCfg = []
                for j in range(5):
                    str = tb.get(i, j, "", False)
                    timeParam = util.loadStrToVec(str)
                    import guildbattletime
                    timeCfg.append(guildbattletime.cal_period_time(timeParam[0], timeParam[1], timeParam[2]))

                timeCfgs.append(timeCfg)

        self.mTimeCfg = timeCfgs

    def processMsg(self, msg, param0, param1):
        if msg == MSG_TIME_MINUTE:
            self.mPeriodHandlers[self.mPeriod].processTime(param0, param1)
        elif msg == MSG_TIME_SECOND:
            self.mPeriodHandlers[self.mPeriod].processSecond()

    def getInfo(self, player):
        # check 条件
        join = self.canJoin(player, True)

        if not join:
            return "{}"

        jsonData = {"type": "main_info"}
        return self.mPeriodHandlers[self.mPeriod].processClient(player, jsonData)

    def doAction(self, player, actData):
        join = self.canJoin(player, True)

        if not join:
            return "{}"

        jsonData = json.loads(actData)
        return self.mPeriodHandlers[self.mPeriod].processClient(player, jsonData)

    def setSetting(self, key, data):
        MMain.setSetting(key, data)

    def getSetting(self, key):
        return MMain.getSetting(key)

    def dataSaveToDB(self):
        self.setSetting("GuildBattleData", self.mGuildData)
        self.setSetting("GuildBattlePlayerData", self.mPlayerData)
        self.setSetting("GuildBattleCityData", self.mCitySaveData)

    def canJoin(self, player, showMsg = False):
        if not OpenSwitch:
            MMain.sendCenterMessage(player, GlobalStrings[182])
            return False

        if not self.isActived(player):
            #days = (datetime.date.fromtimestamp(self.mBeginTime) - datetime.date.today()).days
            #MMain.sendCenterMessage(player, GlobalStrings[183] % days)
            MMain.sendCenterMessage(player, GlobalStrings[184])
            return False

        """
        if player.getLevel() < Register_Player_Level:
            if showMsg:
                MMain.sendCenterMessage(player, Register_Player_Level_Msg % Register_Player_Level)
                return False
        """

        guildName = player.getGuildName()
        guild = MMain.getGuildByName(guildName)
        join = True

        if not guild:
            join = False
        else:
            guildMember = guild.getMember(player.getName())
            if not guildMember:
                join = False
            else:
                if guild.getLevel() < Register_Guild_Level:
                    join = False

        if not join:
            if showMsg:
                MMain.sendCenterMessage(player, Register_Guild_Level_Msg % Register_Guild_Level)
            return False

        if guild.getAllMembersNum() < Register_Guild_Member:
            if showMsg:
                MMain.sendCenterMessage(player, Register_Guild_Member_Msg % Register_Guild_Member)
            return False

        return True

    # 检测是否会长
    def isMaster(self, player):
        guildName = player.getGuildName()
        guild = MMain.getGuildByName(guildName)
        if not guild:
            return False

        guildMember = guild.getMember(player.getName())
        if not guildMember:
            return False

        if guildMember.getPost() == 5:
            return  True

        return  False

    # no为空表示刷新全部
    def refreshAuctionRank(self, no=None):
        noList = []
        if not no:
            noList = Battle_City_Connect.keys()
        else:
            noList = [no]

        for no in noList:
            auctionInfo = self.mCitySaveData["auction"].get(no)
            if not auctionInfo:
                continue
            # 排序用于缓存
            rankData = sorted(auctionInfo.items(), key=lambda auctionInfo:(auctionInfo[1][0],-auctionInfo[1][1]), reverse=True)
            retData = []
            for i in range(min(3, len(rankData))):
                retData.append([rankData[i][0], rankData[i][1][0]])

            self.mCityAucRank[no] = retData



    # 获取个人排行数据
    def getPersonalRank(self, player):
        self.checkRefreshRank()

        myRank = self.mPersonalRankByName.get(player.getName(), 0)
        return {"data":[self.mPersonalRankPart, myRank]}

    def getGuildPersonalRank(self, player):
        self.checkRefreshRank()

        guildName = player.getGuildName()
        guild = MMain.getGuildByName(guildName)
        if not guild:
            return

        guildMembers = guild.getAllMembers()
        guildRank = []
        for rank in self.mPersonalRank:
            if rank[0] in guildMembers:
                guildRank.append(rank)

        myRank = self.mPersonalRankByName.get(player.getName(), 0)
        return {"data":[guildRank, myRank, len(guildMembers)]}

    def checkRefreshRank(self):
        curTime = time.time()
        # 5秒排一次
        if curTime - self.mPersonalRankTime > 5:
            self.mPersonalRankTime = curTime

            rank = {}
            self.mPersonalRankByName = {}
            personalData = self.mPlayerData["killRank"]
            #for name in personalData:
            rankList =  sorted(personalData.items(), key=lambda personalData:(personalData[1][0], -personalData[1][1]), reverse=True)

            for i in range(len(rankList)):
                self.mPersonalRankByName[rankList[i][0]] = i + 1
            self.mPersonalRank = rankList
            self.mPersonalRankPart = rankList[:20]     # 取前20       [name1, name2]
            # [('name1', [3, 1]), ('name2', [1, 2])]


    def getCampId(self, guildName):
        id = MMain.hashStr2ID(guildName) / 2
        self.mGuildIdNames[id] = guildName
        return id

    def getGuildNameById(self, id):
        return self.mGuildIdNames.get(id)

    def getTopOne(self):
        return self.mGuildData["victory"][0]

    def checkDayReward(self):
        curLTime = time.localtime(time.time())
        if curLTime.tm_hour == Day_Reward_Time[0] and curLTime.tm_min == Day_Reward_Time[1]:
            # 发奖
            cityInfo = self.mCitySaveData["occupy"]
            for cityNo in cityInfo:
                guildName = cityInfo[cityNo]
                if not guildName:
                    continue
                print("guild battle reward :" + guildName)
                guild = MMain.getGuildByName(guildName)
                if guild:
                    guildMembers = guild.getAllMembers()
                    for name in guildMembers:
                        mail = {}
                        mail["RecvUUID"] = ""
                        mail["RecvName"] = name
                        mail["CreateTime"] = int(time.time())
                        mail["ValidTime"] = mail["CreateTime"] + 86400 * 16
                        mail["Head"] = GlobalStrings[185]
                        mail["Body"] = GlobalStrings[186] % City_Config[cityNo][0]
                        mail["Res"] = City_Config[cityNo][3][0]
                        mail["Items"] = City_Config[cityNo][3][1]
                        MMain.sendMail(mail)

    def getCityName(self, cityNo):
        config = City_Config.get(cityNo)
        if config:
            return config[0]
        else:
            return GlobalStrings[187]

    def onAskHelp(self, player, data):
        towerNo = data[0]
        guild = MMain.getGuildByName(player.getGuildName())
        if guild:
            guildMembers = guild.getAllMembers()
            for name in guildMembers:
                memPlayer = MMain.getPlayerByName(name)
                if memPlayer and memPlayer.getClientID() != -1:
                    MMain.sendTextProtocol(memPlayer, "S2C_GuildBattleHelp", (player.getName(),towerNo))


    def calThisWeekPeriod(self):
        import guildbattletime
        return guildbattletime.calThisWeekPeriod(self.mTimeCfg)

    def calNextPeriodTime(self):
        import guildbattletime
        return guildbattletime.calNextPeriodTime(self.mTimeCfg)

    def calNextBattleTimeDesc(self):
        import guildbattletime
        return guildbattletime.calNextBattleTimeDesc(self.mTimeCfg)

    def sendInfoToPlayer(self,player):
        if self.mPeriod != GUILD_BATTLE_PERIOD_NONE:
            nextTime, periodTime = self.calNextPeriodTime()
            MMain.sendTextProtocol(player, "S2C_NotifyGuildBattleBegin", (self.mPeriod, nextTime, periodTime))

        MMain.sendTextProtocol(player, "S2C_NotifyGuildBattleInfo", (Battle_Meritorious_Buy_Ratio,self.mGuildData["victory"][0]))


ModuleID = 59
Instance = GuildBattle(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_ACTIVITY_STARTOVER,
    MSG_SERVER_SHUTDOWN,
    MSG_TIME_SECOND,
    MSG_TIME_MINUTE,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_JOIN_GUILD,

    MSG_BATTLEGAME_GAME_STARTED,
    MSG_BATTLEGAME_GAME_START_FAILED,
    MSG_BATTLEGAME_GAME_FINISHED,
    MSG_BATTLEGAME_GAME_DATA_SYNC,
    MSG_BATTLEGAME_PLAYER_JOINED,
    MSG_BATTLEGAME_PLAYER_DEAD,
    MSG_BATTLEGAME_PLAYER_QUIT,
    MSG_BATTLEGAME_ACTOR_DEAD,
    MSG_BATTLEGAME_PLAYER_REVIVE,
    MSG_BATTLEGAME_PLAYER_NEED_REVIVE,
    MSG_BATTLEGAME_PLAYER_REQUEST_REVIVE,
])