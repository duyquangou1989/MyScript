#coding=utf8

Register_Guild_Level    = 3        # 报名时 公会等级>=N级
Register_Guild_Level_Msg = GlobalStrings[161]
Register_Guild_Member = 30
Register_Guild_Member_Msg = GlobalStrings[162]
Register_Player_Level    = 1
Register_Player_Level_Msg = GlobalStrings[163]


Announce_Msg_Acution = GlobalStrings[164]
Announce_Msg_Show = GlobalStrings[165]
Announce_Msg_Fight = GlobalStrings[166]



Revive_Cold_Time = 60       # 复活等待时间
ReviveInBattle_Cost = 50           # 战场里面复活
Revive_Cost_Up = {1: 5, 2: 10, 3: 15, 4: 20, 5: 25, 6: 30, 7: 35, 8: 40, 9: 45, 10: 50, 11: 55, 12: 60}
Revive_Cost = 60            # 最大复活消耗

Inspire_Single_Time         = 90        # 每次购买鼓舞增加秒数
Inspire_Single_Time_Max     = 900       # 鼓舞最大秒数
Inspire_Single_Cost         = 5
Inspire_Single_Buff         = 5         # 鼓舞增加百分比

Inspire_All_Time         = 300        # 每次购买鼓舞增加秒数
Inspire_All_Time_Max     = 900       # 鼓舞最大秒数
Inspire_All_Cost         = 250
Inspire_All_Buff         = 5         # 鼓舞增加百分比

# 独大公会buff
BuffOther_Time         = 900
BuffOther_Time_Max     = 900       # 鼓舞最大秒数
BuffOther_Cost         = 5
BuffOther_Buff         = 5         # 鼓舞增加百分比

Inspire_Single_Buff_ID  = 1
Inspire_All_Buff_ID     = 2
BuffOther_ID            = 3

# 购买战功与个人贡献的比率
Battle_Meritorious_Buy_Ratio = 3

Auction_Min_Price       = 2000      # 竞拍最小出价

Day_Reward_Time = [20, 0]        # 每日奖励发放时间
Personal_Reward_Max = {1:200000, 2:300}    # 个人奖励上限

Kill_Announce = {
    50 : GlobalStrings[167],
    100 : GlobalStrings[168],
    200 : GlobalStrings[169],
    500 : GlobalStrings[170],
    1000 : GlobalStrings[171],
}

Combo_Kill_Announce = {
    15 : GlobalStrings[172],
    30 : GlobalStrings[173],
    45 : GlobalStrings[174],
    60 : GlobalStrings[175],
    100 : GlobalStrings[176],
}

End_Annouce = {
    "big1" : GlobalStrings[177],
    "big2" : GlobalStrings[178],
    "mid1" : GlobalStrings[179],
    "mid2" : GlobalStrings[180],
}

Auction_Notify_Msg = GlobalStrings[181]

# zone连接区域
Battle_City_Connect = {
    1 : [2,3,4,5],
    2 : [1,6,7],
    3 : [1,8,9],
    4 : [1,10,11],
    5 : [1,12,13],
}

Battle_Citys = {
    1 : [11,12,13,14,15],   # 大城池
    2 : [21,22,23],      # 中城池
    3 : [31,32,33],
    4 : [41,42,43],
    5 : [51,52,53],
    6 : [61],               # 小城池
    7 : [71],
    8 : [81],
    9 : [91],
    10 : [101],
    11 : [111],
    12 : [121],
    13 : [131],
}

Battle_City_Count = len(Battle_Citys)

Battle_Towers_List = []
for num in Battle_Citys:
    for no in Battle_Citys[num]:
        Battle_Towers_List.append(no)

# 塔编号除以10就是城的编号，方便使用
def towerToCity(towerNo):
    return int(towerNo / 10)



