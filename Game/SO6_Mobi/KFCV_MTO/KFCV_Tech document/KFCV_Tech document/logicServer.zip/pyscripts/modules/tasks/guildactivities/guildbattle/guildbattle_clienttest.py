#coding=utf8

import json
import MMain
import guildbattle
import guildbattle_reward
from guildbattle import Instance
self = Instance
from guildbattletime import *

Account = "sl11332"
ServerId = 8

def getPlayer():
    return MMain.getPlayerByAccount(Account, ServerId)


# testttttttttttttttttttttttttttttttttttttttttttttt
def debugPeriodBegin(reset = False):
    self.mPeriod = GUILD_BATTLE_PERIOD_NONE
    self.mLastPeriod = self.mPeriod

    if reset:
        self.newRound()


def debugNextPeriod():

    guildbattle.Debug = True

    if self.mPeriod != GUILD_BATTLE_PERIOD_OVER:
        self.mLastPeriod = self.mPeriod
        self.mPeriod = self.mPeriod + 1

    self.mPeriodHandlers[self.mLastPeriod].onExitPeriod()
    self.mPeriodHandlers[self.mPeriod].onEnterPeriod()

def getInfo(player):
    return self.getInfo(player)

"""
·未开放
ret["state"] = "not_open"

·竞拍期
ret["state"] = "auction"
ret["data"] = [leftTime, cityInfo, guildFeats]
ret["city"] = {CityID:[0,0,我公会能否竞拍]}

·展示期
 ret["state"] = "show"
 ret["data"] = [leftTime, cityInfo, guildFeats]
 ret["city"] = {CityID:[0,0,我公会能否竞拍]}

 ·战斗期
  ret["state"] = "fight"
  ret["data"] = [leftTime, cityInfo, guildFeats, playerInfo, [个人复活，个人鼓舞，公会鼓舞, 鼓舞秒数，公会鼓舞秒数,个人鼓舞比，公会鼓舞比，进攻鼓舞花费，秒数，百分比]]
  ret["city"] = {CityID:[3, 2，我公会能进否]}

·结算期
  ret["state"] = "over_info"

"""
def maininfo(player):
    actData = {"type":"main_info"}
    return self.doAction(player, json.dumps(actData))

# return  "data" = [['aaa', 11], ['ccc', 3], ['bbb', 2]]
# "myPrice" : 100
def auctionInfo(player, no):
    actData = {"type":"auction_info", "no":no}
    return self.doAction(player, json.dumps(actData))


# return "data" = [['aaa', 11], ['ccc', 3], ['bbb', 2]]
# "myPrice" : 100
def auctionPrice(player, no, price):
    actData = {"type":"auction_price", "data" : [no, price]}
    return self.doAction(player, json.dumps(actData))


# retData = {"join" : True, "tower" : {towerNo : [友方数，敌方数，占领公会]}, "fight": [进攻方，防守方]}
def towerInfo(player, cityNo):
    actData = {"type":"tower_info", "data" : cityNo}
    return self.doAction(player, json.dumps(actData))


# 请求进入战斗，no为编号
def enterbattle(player, towerNo):
    actData = {"type":"enter_battle", "data":towerNo}
    return self.doAction(player, json.dumps(actData))

"""
{ "data" :
 [
   [('name1', [3, 1]), ('name2', [1, 2])],     # [击杀数, 死亡数]
   1   # 我的排名
 ]
}
"""
def personaldata(player):
    actData = {"type":"personal_data"}
    return self.doAction(player, json.dumps(actData))


"""
# 复活
{"result": "ok", "data" : coldtime}
{"result": "colding"}

"""
def revive(player):
    actData = {"type":"revive"}
    return self.doAction(player, json.dumps(actData))

# 个人鼓舞
"""
{"result": "ok", "time": 294.62006783485413}
{"result": "full", "time": 290.42038798332214}
"""
def inspire_single(player):
    actData = {"type":"inspire_single"}
    return self.doAction(player, json.dumps(actData))

# 公会鼓舞
"""
{"result": "ok", "time": 294.62006783485413}
{"result": "full", "time": 290.42038798332214}
"""
def inspire_all(player):
    actData = {"type":"inspire_all"}
    return self.doAction(player, json.dumps(actData))

# 进攻鼓舞
"""
{"result": "ok", "time": 294.62006783485413}
{"result": "full", "time": 290.42038798332214}
"""
def inspire_attack(player):
    actData = {"type":"inspire_attack"}
    return self.doAction(player, json.dumps(actData))

"""
"awards" : [(1, 100), (2, 200)]
"occupyInfo" :  [[1,原公会], [3, None]]  # 占领信息
"""
def inspire_attack(player):
    actData = {"type":"over_info"}
    return self.doAction(player, json.dumps(actData))



"""
宠物加成
# return [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
// 生命
// 攻击
// 防御
// 暴击
// 韧性
// 命中
// 闪避
// 打击力
// 抗打击力
// 护盾恢复
// 护盾cd
"""
def pet_info(player):
    actData = {"type":"pet_info"}
    return self.doAction(player, json.dumps(actData))




