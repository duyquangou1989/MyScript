#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

EIGHTEEN_RESET_COUNT        = 0
EIGHTEEN_CURDUNGEONID       = 1
EIGHTEEN_CURSTAGE           = 2

RESET_COUNT                 = 1
OPENLEVEL                   = 18
INIT_DUNGEONID              = 40001

class Eighteen(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mGlobalMsg = []
        self.mEighteen = {}                                                 # level  :extrareward
        self.mInitData = [RESET_COUNT, INIT_DUNGEONID, 1,]                 # resetCount, dungeonID, level

    def isActived(self, player):
        if player.getLevel() >= OPENLEVEL:
            data = self.getPlayerForeverData(player, self.mInitData)
            if len(data) != 3:
                data = copy.deepcopy(self.mInitData)
                data[EIGHTEEN_RESET_COUNT] = 1
                data[EIGHTEEN_CURDUNGEONID] = INIT_DUNGEONID
                data[EIGHTEEN_CURSTAGE] = 1
                #setModuleData(player, self.mID, data)
                self.setPlayerForeverData(player, data)

            return True
        else:
            return False

    def getName(self):
        return "Eighteen"

    def getInfo(self, player):
        if self.isActived(player):
            data = self.getPlayerForeverData(player, self.mInitData)
            resetCount = data[EIGHTEEN_RESET_COUNT]
            curDungeonID = data[EIGHTEEN_CURDUNGEONID]
            curStage = data[EIGHTEEN_CURSTAGE]

            if curStage in self.mEighteen:
                rewardslist = self.mEighteen[curStage]
                for i in rewardslist:
                    if player.getLevel() >= i[3] and player.getLevel() <= i[4]:
                        cos = i[1]
                        money = int(cos * (player.getLevel() * 25 + 5000) / 10)
                        
                        moneyreward = [REWARD_TYPE_MONEY, money]
                        rewards = copy.deepcopy(i[2])
                        rewards.append(moneyreward)

                        info = {}
                        info["Result"] = 1
                        info["ResetCount"] = resetCount
                        info["CurStage"] = curStage
                        info["CurDungeonID"] = curDungeonID
                        info["CurReward"] = rewards
                        info["Msg"] = self.mGlobalMsg
                        return json.dumps(info)
                        
            elif curStage == 0:
                info = {}
                info["Result"] = 1
                info["ResetCount"] = resetCount
                info["CurStage"] = curStage
                info["CurDungeonID"] = curDungeonID
                info["CurReward"] = []
                info["Msg"] = self.mGlobalMsg
                return json.dumps(info)
            else:
                return Err_Unknown
        else:
            return Err_NotOpen

    def doAction(self, player, actData):
        if self.isActived(player):
            data = self.getPlayerForeverData(player, self.mInitData)

            actData = json.loads(actData)
            action = actData["Reset"]

            if data[EIGHTEEN_RESET_COUNT] > 0:
                data[EIGHTEEN_RESET_COUNT] -= 1
                data[EIGHTEEN_CURDUNGEONID] = INIT_DUNGEONID
                data[EIGHTEEN_CURSTAGE] = 1
                return Err_Ok
            else:
                return Err_NotEnoughCount

    def loadConfig(self, path):
        rewardsFilename = "%seighteenreward.txt" % (path)
        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = {}
            for i in xrange(tb.mRowNum):
                level = tb.get(i, 0, 0, True)
                cos = tb.get(i, 1, 0, True)
                rewardstr = tb.get(i, 2, "", False)
                levelbegin = tb.get(i, 3, 0, True)
                levelend = tb.get(i, 4, 0, True)

                extrareward = [
                    [int(value) for value in reward.split(",")]
                        for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2)
                ]

                if level not in rewards:
                    rewards[level] = [[level, cos, extrareward, levelbegin, levelend, ], ]
                else:
                    rewards[level].append([level, cos, extrareward, levelbegin, levelend, ])

            self.mEighteen = rewards
            return True

        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False

    def addPoint(self, player):
        data = self.getPlayerForeverData(player, self.mInitData)
        data[EIGHTEEN_RESET_COUNT] += 1
        return True
        
    def checkHasReward(self, player):
        pass

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_DAY_CHANGED:
            player = param0

            if self.isActived(player):
                data = self.getPlayerForeverData(player, self.mInitData)
                data[EIGHTEEN_RESET_COUNT] = RESET_COUNT

        elif msg == MSG_PLAYER_FINISH_DUNGEON:
            player = param0
            dungeon, star, costTime = param1
            if self.isActived(player):
                dungeonID = dungeon.getID()
                dungeonType = int(dungeonID / 10000)
                if dungeonType == 4:
                    data = self.getPlayerForeverData(player, self.mInitData)
                    if data[EIGHTEEN_CURDUNGEONID] == dungeonID:
                        curStage = data[EIGHTEEN_CURSTAGE]
                        if curStage in self.mEighteen:
                            playerLevel = player.getLevel()
                            rewardslist = self.mEighteen[curStage]

                            for i in rewardslist:
                                if playerLevel >= i[3] and playerLevel <= i[4]:
                                    rewards = copy.deepcopy(i[2])
                                    cos = i[1]
                                    money = int(cos * (player.getLevel() * 25 + 5000) / 10)
                                    
                                    for i in xrange(10):
                                        moneyreward = [REWARD_TYPE_MONEY, int(money / 10)]
                                        rewards.append(moneyreward)

                                    if self.canAddAllReward(player, rewards):
                                        for reward in rewards:
                                            self.addReward(player, reward)
                                    break

                        if data[EIGHTEEN_CURSTAGE] == 18:
                            data[EIGHTEEN_CURDUNGEONID] = -1
                            data[EIGHTEEN_CURSTAGE] = 0
                            msg = GlobalStrings[60] % player.getName()
                            self.mGlobalMsg.insert(0, msg)
                            msgNum = len(self.mGlobalMsg)
                            while msgNum > 5:
                                del self.mGlobalMsg[msgNum - 1]
                                msgNum = len(self.mGlobalMsg)
                        else:
                            data[EIGHTEEN_CURDUNGEONID] += 1
                            data[EIGHTEEN_CURSTAGE] += 1
                        response = (
                            self.mID,
                            dungeonID
                        )
                        engine.Instance.invoke(MSG_PLAYER_JOIN_EIGHTEEN, player, None)
                        MMain.sendTextProtocol(player, "S2C_NotifyActFinish", response)

    def getMenu(self, player, npcID):
        return []

ModuleID = 18
Instance = Eighteen(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_DAY_CHANGED,
    MSG_PLAYER_FINISH_DUNGEON,
])
