#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *


class WarmUp(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        self.mID = moduleID

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self) 
        else:
            player = param0
            if msg == MSG_PLAYER_DAY_CHANGED:
                MMain.addPlayerPurchasedGoldMoney(player, 2000)

ModuleID = 100
Instance = WarmUp(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_DAY_CHANGED,
    MSG_PLAYER_CREATED,
])