#coding=utf8

### 基础道具
import itemweapon
import itemarmor
import itembox
import itemconsumable
import itemmaterial
import itemtalent
import itemstone

###独立的文本协议接受器
##import tprotocolreceiver

### 任务
import maintask                 # ID 1 任务系统
import commReward               # ID 2 通用奖励
import sparshop                 # ID 3 晶石商店
#import achievement              # ID 4 经书系统
import gift                     # ID 5 礼包系统
import receivevilality          # ID 6 吃大餐
#import sevendaytarget           # ID 7 七日目标
import multiboss                # ID 8 多人Boss
import protectAthena            # ID 9 守卫雅典娜
import guildbuddha              # ID 10 公会礼佛
import dailyactivity            # ID 11 每日任务
import arenascore               # ID 12 竞技场积分
import carnival                 # ID 13 嘉年华
import firstrecharge            # ID 14 首冲
import accumulativelogin        # ID 15 累计登录
import accumulativelogin7       # ID 16 新号七天乐
import lottery                  # ID 17 抽獎活動
import eighteen                 # ID 18 十八摸
import dungeoncard              # ID 19 副本翻牌
import infocenter               # ID 20 LED
import doublespar               # ID 21 双倍熔炼
import multrewards              # ID 22 多倍掉落
import mall                     # ID 23 商城
import accumulativelogin5       # ID 24 连续签到
##import richman                # ID 25 勇者游戏
##import indianajones           # ID 26 夺宝奇兵
##import kingleague             # ID 27 王者争霸
##import dailyfirstrecharge     # ID 28 每日首充
import viprewards               # ID 29 vip礼包
import onlinegift               # ID 30 在线时长礼包
import levelgift                # ID 31 成长礼包
import nextdaygift              # ID 32 次日礼包
import logingift                # ID 33 登陆礼包
import endless                  # ID 34 无尽之塔
import rebatecard               # ID 35 周卡 月卡 终身哈
import levelupgold              # ID 36 成长礼包
import golddoublereward         # ID 37 元宝双倍
import persentforcharge         # ID 38 充值满XX金额赠送道具
import chargebonus              # ID 41 红包
import daytotalpay              # ID 42 每日累冲
import totalpay                 # ID 43 累计充值
import guilddungeon             # ID 44 公会副本
import moneydungeon             # ID 45 零落秘境
import friendgive               # ID 46 好友赠送体力
import titlesys                 # ID 47 称号系统
import worship                  # ID 48 膜拜
import dropextra                # ID 49 熔炼获得额外材料
import guildfire                # ID 50 公会擂台赛
import personreward             # ID 51 福心高照
import fivestar                 # ID 52 五星好评
import plunder                  # ID 55 掠夺
import rankreward               # ID 56 排名奖励
import limitchallenge           # ID 57 限时挑战
import openrankreward           # ID 58 开服排名奖励
import guildbattle              # ID 59 公会战
import groupBuy                 # ID 60 限时团购
import mysticlottery            # ID 61 神奇抽奖
import guildscience             # ID 62 公会科技
import limittotalpay            # ID 63 限时累计充值
import festivalgift             # ID 64 节假日活动
import worldloot                # ID 65 世界掉落
import invitation              # ID 80 邀请
import warmup                   # ID 100 预热活动（临时上线使用结束后取消）
