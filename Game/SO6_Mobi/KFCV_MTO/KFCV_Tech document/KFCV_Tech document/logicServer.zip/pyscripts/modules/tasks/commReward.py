#coding=utf8

import engine
import MMain
import sys
import random
import time
from tabfile import TabFile
from messages import *
from gamedefines import *

REWARD_TYPE_MONEY               = 1     # 银币
REWARD_TYPE_GOLDMONEY           = 2     # 金币
REWARD_TYPE_GOLDMONEY_PURCHASED = 3     # 真金
REWARD_TYPE_VITALITY            = 4     # 体力
REWARD_TYPE_EXPERIENCE          = 5     # 经验
REWARD_TYPE_ENERGY              = 6     # 真气
REWARD_TYPE_SPAR                = 7     # 晶石

COMM_INDEX_COMMREWARDID         = 0
COMM_INDEX_FIXREWARD            = 1
COMM_INDEX_CTRLREWARD           = 2
COMM_INDEX_CTRLRATE             = 3
COMM_INDEX_CTRLHIT              = 4
COMM_INDEX_MUTEXLOOTID          = 5
COMM_INDEX_MUTEXLOOTNUM         = 6
COMM_INDEX_SHARELOOTID          = 7
COMM_INDEX_CARD                 = 8
COMM_INDEX_COUNT                = 9

class CommReward:
    def __init__(self, moduleID):
        self.mID = moduleID
        self.mCommReward = {}                       #commRewardID:content
        self.mAtlasLoot = {}                        #itemID:[dungeonID]
        self.mCommRewardFrom = {}                   #commReward:[dungeonID]
        self.mLootItem = {}                         #commRewardID:[itemID]
        self.mCardsReward = {}                      #cardID:[]

    def loadDungeon(self, filename):
        syslog("Loading dungeon...")

        tb = TabFile()
        if tb.load(filename):
            for i in xrange(tb.mRowNum):

                dungeonID               = tb.get(i, 0, 0, True)
                commRewardID            = tb.get(i, 24, 0, True)

                if commRewardID not in self.mCommRewardFrom:
                    self.mCommRewardFrom[commRewardID] = [dungeonID,]
                else:
                    self.mCommRewardFrom[commRewardID].append(dungeonID);
            
            return True
        else:
            syserr("Load dungeon config failed...")
            return False

    def loadCommReward(self, filename):
        syslog("Loading commReward...")
        tb = TabFile()
        if tb.load(filename):
            for i in xrange(tb.mRowNum):
                commReward = [None for j in xrange(COMM_INDEX_COUNT)]

                commRewardID                                    = tb.get(i, COMM_INDEX_COMMREWARDID, 0, True)
                fixReward                                       = tb.get(i, COMM_INDEX_FIXREWARD, "", False).replace("\"", "")
                ctrlReward                                      = tb.get(i, COMM_INDEX_CTRLREWARD, "", False).replace("\"", "")
                ctrlrate                                        = tb.get(i, COMM_INDEX_CTRLRATE, 0, True)
                ctrlhit                                         = tb.get(i, COMM_INDEX_CTRLHIT, 0, True)
                mutexLootID                                     = tb.get(i, COMM_INDEX_MUTEXLOOTID, 0, True)
                mutexlootnum                                    = tb.get(i, COMM_INDEX_MUTEXLOOTNUM, 0, True)
                shareLootID                                     = tb.get(i, COMM_INDEX_SHARELOOTID, 0, True)
                cardID                                          = tb.get(i, COMM_INDEX_CARD, 0, True)

                commReward[COMM_INDEX_COMMREWARDID]             = commRewardID
                commReward[COMM_INDEX_CTRLRATE]                 = ctrlrate
                commReward[COMM_INDEX_CTRLHIT]                  = ctrlhit
                commReward[COMM_INDEX_MUTEXLOOTNUM]             = mutexlootnum

                self.mCardsReward[commRewardID] = cardID
                self.mLootItem[commRewardID] = []

                if fixReward:
                    commReward[COMM_INDEX_FIXREWARD] = [
                        [int(value) for value in reward.split(",")]
                            for reward in fixReward.split(";") if reward and reward.count(',') in (1, 2)
                    ]
                else:
                    commReward[COMM_INDEX_FIXREWARD] = []

                if ctrlReward:
                    commReward[COMM_INDEX_CTRLREWARD] = [
                        [int(value) for value in reward.split(",")]
                            for reward in ctrlReward.split(";") if reward and reward.count(',') in (1, 2)
                    ]
                else:
                    commReward[COMM_INDEX_CTRLREWARD] = []

                mutextotolrate = 0
                mutexrateList = []
                mutexrewardList = []
                if mutexLootID:
                    mutexfile = "settings/assistLoot/%s.txt" % (mutexLootID)

                    mutextb = TabFile()
                    commReward[COMM_INDEX_MUTEXLOOTID] = [mutextotolrate, mutexrateList, mutexrewardList,]
                    if mutextb.load(mutexfile):
                        for j in xrange(mutextb.mRowNum):
                            idx                                 = mutextb.get(j, 0, 0, True)
                            rewardstr                           = mutextb.get(j, 1, "", False).replace("\"", "")
                            rate                                = mutextb.get(j, 2, 0, True)

                            if rewardstr and rate != 0:
                                mutexreward = [
                                    [int(value) for value in reward.split(",")]
                                        for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2)
                                ]
                                if mutexreward:
                                    mutexreward = mutexreward[0]
                                mutextotolrate += rate
                                mutexrateList.append(mutextotolrate)
                                mutexrewardList.append(mutexreward)
                            else:
                                syserr("Load %s at line %s failed..." % (mutexfile, j))

                        commReward[COMM_INDEX_MUTEXLOOTID] = [mutextotolrate, mutexrateList, mutexrewardList,]

                    else:
                        syserr("Load %s failed..." % (mutexfile))
                        return False
                else:
                    commReward[COMM_INDEX_MUTEXLOOTID] = [mutextotolrate, mutexrateList, mutexrewardList,]

                sharetotolrate = 0
                sharerateList = []
                sharerewardList = []
                if shareLootID:
                    sharefile = "settings/assistLoot/%s.txt" % (shareLootID)

                    sharetb = TabFile()
                    commReward[COMM_INDEX_SHARELOOTID] = [sharetotolrate, sharerateList, sharerewardList]
                    if sharetb.load(sharefile):
                        for j in xrange(sharetb.mRowNum):
                            idx                                 = sharetb.get(j, 0, 0, True)
                            rewardstr                           = sharetb.get(j, 1, "", False).replace("\"", "")
                            rate                                = sharetb.get(j, 2, 0, True)

                            if rewardstr and rate != 0:
                                sharereward = [
                                    [int(value) for value in reward.split(",")]
                                        for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2)
                                ]
                                if sharereward:
                                    sharereward = sharereward[0]
                                sharerateList.append(rate)
                                sharerewardList.append(sharereward)
                            else:
                                syserr("Load %s at line %s failed..." % (sharefile, j))

                        commReward[COMM_INDEX_SHARELOOTID] = [sharetotolrate, sharerateList, sharerewardList]
                        
                    else:
                        syserr("Load %s failed..." % (sharefile))
                        return False
                else:
                    commReward[COMM_INDEX_SHARELOOTID] = [sharetotolrate, sharerateList, sharerewardList]

                # for atlas loot
                if commRewardID in self.mLootItem:
                    itemList = self.mLootItem[commRewardID]
                else:
                    itemList = []

                for data in commReward[COMM_INDEX_FIXREWARD]:
                    if type(data) == type([]) and len(data) == 3:
                        itemID = data[1]
                        itemList.append(itemID)
                        if commRewardID in self.mCommRewardFrom:
                            newdungeonList = self.mCommRewardFrom[commRewardID]
                            if itemID in self.mAtlasLoot:
                                olddungeonList = self.mAtlasLoot[itemID]
                                self.mAtlasLoot[itemID] = list(set(olddungeonList) | set(newdungeonList))
                            else:
                                self.mAtlasLoot[itemID] = list(set(newdungeonList))

                for data in commReward[COMM_INDEX_CTRLREWARD]:
                    if type(data) == type([]) and len(data) == 3:
                        itemID = data[1]
                        itemList.append(itemID)
                        if commRewardID in self.mCommRewardFrom:
                            newdungeonList = self.mCommRewardFrom[commRewardID]
                            if itemID in self.mAtlasLoot:
                                olddungeonList = self.mAtlasLoot[itemID]
                                self.mAtlasLoot[itemID] = list(set(olddungeonList) | set(newdungeonList))
                            else:
                                self.mAtlasLoot[itemID] = list(set(newdungeonList))

                for data in commReward[COMM_INDEX_MUTEXLOOTID][2]:
                    if type(data) == type([]) and len(data) == 3:
                        itemID = data[1]
                        itemList.append(itemID)
                        if commRewardID in self.mCommRewardFrom:
                            newdungeonList = self.mCommRewardFrom[commRewardID]
                            if itemID in self.mAtlasLoot:
                                olddungeonList = self.mAtlasLoot[itemID]
                                self.mAtlasLoot[itemID] = list(set(olddungeonList) | set(newdungeonList))
                            else:
                                self.mAtlasLoot[itemID] = list(set(newdungeonList))

                for data in commReward[COMM_INDEX_SHARELOOTID][2]:
                    if type(data) == type([]) and len(data) == 3:
                        itemID = data[1]
                        itemList.append(itemID)
                        if commRewardID in self.mCommRewardFrom:
                            newdungeonList = self.mCommRewardFrom[commRewardID]
                            if itemID in self.mAtlasLoot:
                                olddungeonList = self.mAtlasLoot[itemID]
                                self.mAtlasLoot[itemID] = list(set(olddungeonList) | set(newdungeonList))
                            else:
                                self.mAtlasLoot[itemID] = list(set(newdungeonList))
                
                self.mCommReward[commRewardID] = commReward
                self.mLootItem[commRewardID] = itemList
                
            self.mCommRewardFrom = {}
            return True
        else:
            syserr("Load commReward failed...")
            return False

    def calCard(self, commRewardID, extra):
        if commRewardID in self.mCardsReward:
            return self.mCardsReward[commRewardID]
        return 0

    def calReward(self, commRewardID, extra):
        pph = extra[0]
        hit = extra[1]

        totalreward = []
        if commRewardID in self.mCommReward:
            commReward = self.mCommReward[commRewardID]
            # fix
            for i in commReward[COMM_INDEX_FIXREWARD]:
                if i:
                    totalreward.append(i)

            # ctrl
            if commReward[COMM_INDEX_CTRLRATE] > 0:
                if pph >= commReward[COMM_INDEX_CTRLHIT]:
                    extra[1] = 1
                    for i in commReward[COMM_INDEX_CTRLREWARD]:
                        if i:
                            totalreward.append(i)
                else:
                    ctrl = random.randint(1, 10000)
                    if ctrl < commReward[COMM_INDEX_CTRLRATE]:
                        extra[1] = 1
                        for i in commReward[COMM_INDEX_CTRLREWARD]:
                            if i:
                                totalreward.append(i)

            # mutex
            mutex = commReward[COMM_INDEX_MUTEXLOOTID]
            mutexNum = commReward[COMM_INDEX_MUTEXLOOTNUM]
            for k in xrange(mutexNum):
                mutexIndex = 0
                if mutex[0] >= 1:
                    mutexRand = random.randint(1, 10000)
                    for i in mutex[1]:
                        if mutexRand <= i:
                            m = mutex[2][mutexIndex]
                            if m:
                                totalreward.append(m)
                                    
                            break
                        else:
                            mutexIndex += 1
                            continue

            # share
            share = commReward[COMM_INDEX_SHARELOOTID]
            shareIndex = 0
            for i in share[1]:
                shareRand = random.randint(1, 10000)
                if shareRand < i:
                    m = share[2][shareIndex]
                    if m:
                        totalreward.append(m)
                            
                shareIndex += 1
        return totalreward

    def getAtlasLoot(self, itemID):
        if itemID in self.mAtlasLoot:
            return self.mAtlasLoot[itemID]
        else:
            return []

    def getLootItem(self, commRewardID):
        if commRewardID in self.mLootItem:
            return self.mLootItem[commRewardID]
        else:
            return []

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            isLoadOk = True
            isLoadOk &= self.loadDungeon("settings/dungeon.txt")
            if not isLoadOk:
                syserr("Load settings/dungeon.txt failed")
                sys.exit(1)

            isLoadOk &= self.loadCommReward("settings/assistLoot/commonReward.txt")
            if not isLoadOk:
                syserr("Load settings/assistLoot/commonReward.txt failed")
                sys.exit(1)
        
ModuleID = 2
Instance = CommReward(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
])
