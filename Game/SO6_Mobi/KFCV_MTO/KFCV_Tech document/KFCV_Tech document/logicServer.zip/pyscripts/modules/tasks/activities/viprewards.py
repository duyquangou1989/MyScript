#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

class VipRewards(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID

        self.mRewards = []
        self.mInitData = {}
        self.mVipLevelInfo = {}
    def isActived(self, player):
        return True

    def getName(self):
        return "VipRewards"

    def isShow(self, player):
        pdata = self.getPlayerForeverData(player, self.mInitData)
        for level in pdata:
            if pdata[level] != 2:
                return True
        return False

    def getInfo(self, player):
        pdata = self.getPlayerForeverData(player, self.mInitData)
        result = []
        for rewardLevel in self.mRewards:
            rewards = self.mRewards[rewardLevel]
            if rewardLevel in pdata:
                canGetReward = False
                GotReward = False
                if pdata[rewardLevel] == 0:
                    pass
                elif pdata[rewardLevel] == 1:
                    canGetReward = True
                elif pdata[rewardLevel] == 2:
                    canGetReward = True
                    GotReward = True

                result.append((rewardLevel, rewards, canGetReward, GotReward,self.mVipLevelInfo[rewardLevel]))
        info = {}
        info["VipRewards"] = result
        info["total"] = player.getGoldMoneyPurchased()
        return json.dumps(info)

    def doAction(self, player, actData):
        if self.isActived(player):
            pdata = self.getPlayerForeverData(player, self.mInitData)
            actdata = json.loads(actData)

            rewardLevel = actdata["Level"]

            if rewardLevel in self.mRewards:
                rewards = self.mRewards[rewardLevel][0] + self.mRewards[rewardLevel][1]
                level = player.getVipLevel()

                if rewardLevel in pdata:
                    if pdata[rewardLevel] == 0:
                        return Err_Cannot
                    elif pdata[rewardLevel] == 1:
                        if self.canAddAllReward(player, rewards):
                            pdata[rewardLevel] = 2
                            for reward in rewards:
                                self.addReward(player, reward)
                            player.saveToDB()
                            return Err_Ok
                        else:
                            return Err_NotEnoughSpace
                    elif pdata[rewardLevel] == 2:
                        return Err_Repetition
                else:
                    return Err_Invalid
            else:
                return Err_Invalid
        else:
            return Err_NotOpen

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)
        viplevelfilename = "settings/vip/viplevel.txt"
        syslog("Loading VipRewards config...")

        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = {}
            initData = {}
            for i in xrange(tb.mRowNum):
                offset = 0;

                level = tb.get(i, 0, 0, True)
                rewardstr = tb.get(i, 1, "", False).replace("\"", "")
                extrastr = tb.get(i, 2, "", False).replace("\"", "")

                extrareward = [
                    [int(value) for value in reward.split(",")]
                        for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2)
                ]

                extra = [
                    [int(value) for value in reward.split(",")]
                        for reward in extrastr.split(";") if reward and reward.count(',') in (1, 2)
                ]

                rewards[level] = [extrareward, extra, ]

                initData[level] = 0

            self.mRewards = rewards
            self.mInitData = initData

            tb = TabFile()
            if tb.load(viplevelfilename):
                for i in xrange(tb.mRowNum):
                    info = tb.get(i, 0, 0, True)
                    self.mVipLevelInfo[i + 1] = info
        else:
            syserr("Loading %s failed." % (rewardsFilename))
            return False

        return True

    def checkHasReward(self, player):
        data = self.getPlayerForeverData(player, self.mInitData)

        hasReward = False
        for rewardLevel in self.mRewards:
            if rewardLevel in data:
                if data[rewardLevel] == 1:
                    hasReward = True
                    break

        self.notifyActReward(player, hasReward)

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_ONLINE:
            player = param0

            if self.isActived(player):
                pdata = self.getPlayerForeverData(player, self.mInitData)
                for level in self.mInitData:
                    if level not in pdata:
                        pdata[level] = self.mInitData[level]

                self.checkHasReward(player)

        elif msg == MSG_PLAYER_VIPLEVEL_CHANGED:
            player = param0

            if self.isActived(player):
                level = player.getVipLevel()

                pdata = self.getPlayerForeverData(player, self.mInitData)

                for l in self.mRewards:
                    if l in pdata:
                        if level >= l and pdata[l] == 0:
                            pdata[l] = 1

                self.checkHasReward(player)

    def getMenu(self, player, npcID):
        return []

ModuleID = 29
Instance = VipRewards(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,

    MSG_PLAYER_ONLINE,
    MSG_PLAYER_VIPLEVEL_CHANGED,
])