#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

EIGHTEEN_RESET_COUNT        = 0
EIGHTEEN_CURDUNGEONID       = 1
EIGHTEEN_CURSTAGE           = 2

OPENLEVEL                   = 20

class MultiBoss(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mPvETime = {}                      # index:[bossbegin, bossend, count]
        self.mInitData = []                     # 3, 3

    def isOpened(self):
        curTime = time.time()
        curLTime = time.localtime(curTime)

        curMinute = curLTime.tm_hour * 60 + curLTime.tm_min

        for i in self.mPvETime:
            bossTime = self.mPvETime[i]
            if curMinute >= bossTime[0] and curMinute < bossTime[1]:
                return i
        return -1

    def getName(self):
        return "MultiBoss"

    def getInfo(self, player):
        bossID = self.isOpened()
        if bossID == 0 or bossID == 1:
            data = self.getPlayerForeverData(player, self.mInitData)
            info = {}
            info["Result"] = 1
            info["Count"] = data[bossID]
            info["Time"] = self.mPvETime
            info["CurTime"] = int(time.time())
            return json.dumps(info)

        elif bossID == -1:
            info = {}
            info["Result"] = 19
            info["Count"] = 0
            info["Time"] = self.mPvETime
            info["CurTime"] = int(time.time())
            return json.dumps(info)

    def doAction(self, player, actData):
        pass

    def getPvECount(self, player):
        bossID = self.isOpened()
        if bossID == 0 or bossID == 1:
            data = self.getPlayerForeverData(player, self.mInitData)
            return data[bossID]

        elif bossID == -1:
            return -1

    def doPvE(self, player):
        bossID = self.isOpened()
        if bossID == 0 or bossID == 1:
            data = self.getPlayerForeverData(player, self.mInitData)
            if data[bossID] > 0:
                data[bossID] -= 1

    def addPvE(self, player):
        bossID = self.isOpened()
        if bossID == 0 or bossID == 1:
            data = self.getPlayerForeverData(player, self.mInitData)
            data[bossID] += 1
            return True
        return False

    def loadConfig(self, path):
        filename = "%sbosstime.txt" % (path)

        syslog("Loading PvE Config...")

        tb = TabFile()
        if tb.load(filename):
            bossTimes = {}
            initCount = []
            for i in xrange(tb.mRowNum):
                bossCount                           = tb.get(i, 0, 0, True)
                bossTimeBegin                       = tb.get(i, 1, 0, True)
                bossTimeEnd                         = tb.get(i, 2, 0, True)

                if bossTimeBegin >= bossTimeEnd:
                    syserr("Loading PvE Config failed...")
                    return False
                bossTimes[i] = [bossTimeBegin, bossTimeEnd, bossCount]
                initCount.append(bossCount)
                
            self.mPvETime = bossTimes
            self.mInitData = initCount
            return True
        else:
            syserr("Loading PvE Config failed...")
            return False

    def checkHasReward(self, player):
        pass

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_ONLINE:
            player = param0
            data = self.getPlayerForeverData(player, self.mInitData)

        elif msg == MSG_PLAYER_DAY_CHANGED:
            player = param0
            #setModuleData(player, self.mID, self.mInitData)
            self.setPlayerForeverData(player, self.mInitData)

    def getMenu(self, player, npcID):
        return []

ModuleID = 8
Instance = MultiBoss(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_DAY_CHANGED,  
])
