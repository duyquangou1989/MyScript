#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
import bisect
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

UPGOLD = 52

class LevelUpGold(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        self.mID = moduleID
        self.InitData = {}

    def getName(self):
        return "LevelUpGold"
        
    def isOpened(self):
        return True

    def doSetOrUpInfo(self, player, goldMoney):
        if not "s_aupGoldStaus" in player.__dict__:
            player.s_aupGoldStaus = 0
        if player.s_aupGoldStaus == 0:
            player.s_aupGoldStaus = 1
            level = player.getLevel()
            mail = {}
            mail["RecvUUID"] = player.getUUID()
            mail["RecvName"] = player.getName()
            mail["CreateTime"] = int(time.time())
            mail["ValidTime"] = mail["CreateTime"] + 86400 * 16
            mail["Head"] = ""
            mail["Body"] = GlobalStrings[33]
            mail["Res"] = []
            mail["Items"] = []
            MMain.sendMail(mail)
            player.addGoldMoney(self.InitData[0])
            for temp in self.InitData:
                if temp <= level and temp > 0:
                    mail = {}
                    mail["RecvUUID"] = player.getUUID()
                    mail["RecvName"] = player.getName()
                    mail["CreateTime"] = int(time.time())
                    mail["ValidTime"] = mail["CreateTime"] + 86400 * 16
                    mail["Head"] = ""
                    mail["Body"] = GlobalStrings[34] % (temp, temp)
                    mail["Res"] = [(2,self.InitData[temp])]
                    mail["Items"] = []
                    MMain.sendMail(mail)
                    
        MMain.notifyActivityInfo(player, self.mID)

    def getInfo(self, player):
        if not "s_aupGoldStaus" in player.__dict__:
            player.s_aupGoldStaus = 0
        upInfo = {}
        upInfo["hasupgold"] = player.s_aupGoldStaus
        infol = []
        for i in self.InitData:
            infol.append((i,self.InitData[i]))
        upInfo["initinfo"] = infol
        upInfo["goldmoney"] = UPGOLD
        return json.dumps(upInfo)

    def doAction(self, player, actData):
        pass

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)
        tb = TabFile()
        if tb.load(rewardsFilename):
            initdata = {}
            for i in xrange(tb.mRowNum):
                level = tb.get(i, 0, 0, True)
                reward = tb.get(i, 1, 0, True)
                initdata[level] = reward
            self.InitData = initdata
        else:
            syserr("Load %s failed." % (rewardsFilename))
            return False
        return True

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
           MMain.registerActivity(self.mID, self)
           
        elif msg == MSG_PLAYER_GOLDMONEY_CHANGED:
            player = param0
            goldMoney = param1[0]
            payWay = param1[1]
            productId = param1[2]
            if payWay == GMCW_Pay:
                if productId == "sl_tw_520":
                    #player.addGoldMoney(-goldMoney)
                    self.doSetOrUpInfo(player, goldMoney)

        elif msg == MSG_PLAYER_LEVELUP:
            player = param0
            level = player.getLevel()
            if not "s_aupGoldStaus" in player.__dict__:
                player.s_aupGoldStaus = 0
            if player.s_aupGoldStaus == 1:
                if level in self.InitData:
                    mail = {}
                    mail["RecvUUID"] = player.getUUID()
                    mail["RecvName"] = player.getName()
                    mail["CreateTime"] = int(time.time())
                    mail["ValidTime"] = mail["CreateTime"] + 86400 * 16
                    mail["Head"] = ""
                    mail["Body"] = GlobalStrings[34] % (level, level)
                    mail["Res"] = [(2,self.InitData[level])]
                    mail["Items"] = []
                    MMain.sendMail(mail)

    def getMenu(self, player, npcID):
        return []

ModuleID = 36
Instance = LevelUpGold(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_GOLDMONEY_CHANGED,
    MSG_PLAYER_LEVELUP,
])
