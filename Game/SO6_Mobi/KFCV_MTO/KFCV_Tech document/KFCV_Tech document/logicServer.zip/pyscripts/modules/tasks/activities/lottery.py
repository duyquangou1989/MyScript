#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

class Lottery(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID
        self.mTables = {}
        self.mGloble = {}
        self.mInitData = [0, {},]

    def getName(self):
        return "Lottery"

    def getPlayerData(self, player):
        if "s_lotterys" not in player.__dict__:
            if player.getUUID() in self.mGloble:
                player.s_lotterys = self.mGloble[player.getUUID()]
            else:
                player.s_lotterys = copy.deepcopy(self.mInitData)
        return player.s_lotterys

    def getInfo(self, player):
        result = {}
        data = self.getPlayerData(player)
        count = data[0]
        result["Count"] = count
        his = []

        for i in data[1]:
            his.append((i, data[1][i]))
        result["Got"] = his
        rewards = []
        for i in self.mTables:
            rewards.append((i, self.mTables[i]))
        result["Rewards"] = rewards
        return json.dumps(result)

    def doAction(self, player, actData):
        actData = json.loads(actData)

        #if player.getUUID() not in self.mGloble:
        #    self.mGloble[player.getUUID()] = copy.deepcopy(self.mInitData)
        #data = self.mGloble[player.getUUID()]
        data = self.getPlayerData(player)
        idx = actData["Get"]

        if idx in self.mTables:
            if idx in data[1]:
                if data[1][idx] == 0:
                    return Err_Cannot
                elif data[1][idx] == 1:
                    rewards = self.mTables[idx]
                    if self.canAddAllReward(player, rewards):
                        for reward in rewards:
                            self.addReward(player, reward)
                        data[1][idx] = 2
                        return Err_Ok
                    else:
                        return Err_NotEnoughSpace
                elif data[1][idx] == 2:
                    return Err_Repetition
            else:
                return Err_Invalid
        else:
            return Err_Invalid

    def loadConfig(self, path):
        tasksFilename = "%slottery.txt" % (path)
        tb = TabFile()
        if tb.load(tasksFilename):
            tables = {}
            initdata = [0, {},]
            for i in xrange(tb.mRowNum):
                num = tb.get(i, 0, 0, True)
                rewardstr = tb.get(i, 1, "", False).replace("\"", "")
                taskReward = []
                if rewardstr:
                    taskReward = [
                        [int(value) for value in reward.split(",")]
                            for reward in rewardstr.split(";") if reward and reward.count(',') in (1, 2) 
                    ]
                tables[num] = taskReward
                initdata[1][num] = 0
            self.mTables = tables
            self.mInitData = initdata
            return True
        else:
            syserr("Load %s failed." % (tasksFilename))
            return False

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)
            #globleData = MMain.getSetting("lottery_globledata")
            #if globleData:
            #   self.mGloble = globleData
        elif msg == MSG_PLAYER_DAY_CHANGED:
            #self.mGloble = {}
            player = param0
            player.s_lotterys = copy.deepcopy(self.mInitData)
        elif msg == MSG_PLAYER_ONLINE:
            player = param0
            self.checkHasReward(player)
            
        elif msg == MSG_PLAYER_LOTTERY:
            player = param0
            typ, action = param1
            if typ == 2:
                #playerUUID = player.getUUID()
                #if playerUUID not in self.mGloble:
                #    self.mGloble[playerUUID] = copy.deepcopy(self.mInitData)
                data = self.getPlayerData(player)
                if action == 1:
                    data[0] += 1
                elif action == 2:
                    data[0] += 10

                self.checkHasReward(player)
        elif msg == MSG_TIME_MINUTE:
            pass
            #curTime = time.time()
            #curLTime = time.localtime(curTime)
            #if curLTime.tm_min % 5 == 3:
            #    MMain.setSetting("lottery_globledata",self.mGloble)

    def getMenu(self, player, npcID):
        return []

    def checkHasReward(self, player):
        hasReward = False
        if self.isActived(player):
            data = self.getPlayerData(player)
            count = data[0]
            got = data[1]
            for n in got:
                if count >= n and got[n] == 0:
                    got[n] = 1
                    hasReward = True

        self.notifyActReward(player, hasReward)

ModuleID = 17
Instance = Lottery(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_PLAYER_DAY_CHANGED,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_LOTTERY,
    MSG_TIME_MINUTE,
])
