#coding=utf8

ItemQualityColor = {
    0:"[F5F0C6]",
    1:"[A0E71F]",
    2:"[15a5ef]",
    3:"[9515ef]",
    4:"[ef8615]",
    5:"[FF7200]",
}

def getQualityColorCode(quality):
    if quality in ItemQualityColor:
        return ItemQualityColor[quality]
    else:
        return "[ffffff]"