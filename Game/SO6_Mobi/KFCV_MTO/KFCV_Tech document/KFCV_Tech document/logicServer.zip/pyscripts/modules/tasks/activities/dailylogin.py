#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

REWARD_INDEX_TYPE       = 0
REWARD_INDEX_VALUE      = 1
REWARD_INDEX_PERCENT    = 2
REWARD_INDEX_WEIGHTS    = 3

REWARD_SMALL            = 1
REWARD_MEDIUM           = 2
REWARD_BIG              = 3

class DailyLogin(ActivityBase):
    def __init__(self, moduleID):
        ActivityBase.__init__(self)

        self.mID = moduleID

        self.mInitData = [0]
        self.mRewards = []

        engine.Instance.registerTextProtocol("C2S_DailyLogin", self.onProtocol)

    def isActived(self, player):
        return True
        
    def canGetReward(self, lastTime):
        curLTime = time.localtime()
        lastLTime = time.localtime(lastTime)

        if curLTime.tm_year == lastLTime.tm_year and curLTime.tm_mon == lastLTime.tm_mon and curLTime.tm_mday == lastLTime.tm_mday:
            return False
        else:
            return True

    def loadConfig(self, path):
        rewardsFilename = "%srewards.txt" % (path)

        syslog("Loading DailyLogin config...")

        tb = TabFile()
        if tb.load(rewardsFilename):
            rewards = []
            for i in xrange(tb.mRowNum):
                rewardType = tb.get(i, REWARD_INDEX_TYPE, 0, True)
                rewardValue = tb.get(i, REWARD_INDEX_VALUE, "", False).replace("\"", "")
                rewardPercent = tb.get(i, REWARD_INDEX_PERCENT, 0, True)
                rewardWeights = tb.get(i, REWARD_INDEX_WEIGHTS, 0, True)
                
                if rewardType == REWARD_TYPE_ITEM:
                    tmpItems = []
                    tmpBlocks = rewardValue.split(";")
                    for tmpBlock in tmpBlocks:
                        itemBlocks = tmpBlock.split(",")
                        if len(itemBlocks) == 3:
                            tmpItems.append((
                                int(itemBlocks[0]),
                                int(itemBlocks[1]),
                                int(itemBlocks[2]),
                            ))
                    rewardValue = tmpItems
                else:
                    rewardValue = int(rewardValue)

                rewards.append((
                    rewardType,
                    rewardValue,
                    rewardPercent,
                    rewardWeights,
                ))

            self.mRewards = rewards
        else:
            syserr("Loading %s failed." % (rewardsFilename))
            return False

        return True

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_PLAYER_ONLINE:
            player = param0

            if self.isActived(player):
                data = getModuleData(player, self.mID, self.mInitData)
                if self.canGetReward(data[0]):
                    if player.getLevel() >= 10:
                        self.showGUI(player)

    def getMenu(self, player, npcID):
        return []

    def showGUI(self, player):
        response = ["showGUI"]
        MMain.sendTextProtocol(player, "S2C_DailyLogin", response)

    def calReward(self):
        percent = 0
        randomPercent = random.randint(1, 10000)
        for reward in self.mRewards:
            percent += reward[REWARD_INDEX_PERCENT]
            if randomPercent <= percent:
                return (
                    reward[REWARD_INDEX_TYPE],
                    reward[REWARD_INDEX_VALUE],
                    reward[REWARD_INDEX_WEIGHTS],
                )

        return None

    def getRandomReward(self):
        return self.mRewards[random.randint(0, len(self.mRewards) - 1)]

    def onProtocol(self, player, data):
        data = getModuleData(player, self.mID, self.mInitData)
        canGetReward = self.canGetReward(data[0])
        if canGetReward:
            rewards = []
            rewardsExtra = []
            for i in xrange(3):
                rewards.append(self.calReward())
            
            message = GlobalStrings[210]
            for reward in rewards:
                self.addReward(player, reward)
                message += self.getRewardDesc(reward)

            result = {
                "Rewards": rewards,
                "RewardDesc": message,
            }
            data[0] = int(time.time())
            player.saveToDB()

            MMain.sendTextProtocol(player, "S2C_DailyLogin", ["showResult", json.dumps(result), ])
        else:
            MMain.sendBoxMessage(player, GlobalStrings[211])

ModuleID = 18
Instance = DailyLogin(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,

    MSG_PLAYER_ONLINE,
])
