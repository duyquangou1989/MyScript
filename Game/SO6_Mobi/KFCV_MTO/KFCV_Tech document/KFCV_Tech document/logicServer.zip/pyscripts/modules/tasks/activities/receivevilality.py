#coding=utf8

import engine
import MMain
import sys
import time
import json
import random
from tabfile import TabFile
from messages import *
from gamedefines import *
from activitybase import *

class ReceiveVilality(ActivityBase):

    def __init__(self, moduleID):
        ActivityBase.__init__(self)
        self.mID = moduleID
        self.mTableData = []
        self.starttimes = []
        self.mInitData = 0
        self.mgotReward = 0
        engine.Instance.registerTextProtocol("C2S_EatFeast", self.onProtocol)

    def getName(self):
        return "ReceiveVilality"

    def checkPlayerData(self, player):
        if not "s_vilalitystatus" in player.__dict__:
            player.s_vilalitystatus = 0

    def getCurMinute(self):
        curCTime = time.time()
        curLTime = time.localtime(curCTime)
        curMin = curLTime.tm_hour * 60 + curLTime.tm_min
        return curMin

    def notifyPlayersEatFeast(self):
        curMin = self.getCurMinute()
        if curMin in self.starttimes:
            if curMin == self.starttimes[0]:
                cmsg = GlobalStrings[48]
            elif curMin == self.starttimes[1]:
                cmsg = GlobalStrings[49]
            elif curMin == self.starttimes[2]:
                cmsg = GlobalStrings[50]
            MMain.sendHorseMessage(cmsg)
            MMain.sendAllSysMessage(cmsg)
            players = MMain.getAllPlayers()
            for tmpplayer in players:
                self.notifyActReward(tmpplayer , True)

    def notifyPlayerEatTeast(self , player):
        if not "s_vilalitystatus" in player.__dict__:
            player.s_vilalitystatus = 0
        timecope = self.mTableData
        pdata = player.s_vilalitystatus
        timeinfo = self.getCurMinute()
        for times in xrange(3):
            if timeinfo >= timecope[times][0] and timeinfo <= timecope[times][1]:
                if (pdata & (1 << times)) == 0:
                    self.notifyActReward(player , True)
                else:
                    self.notifyActReward(player , False)
                    
    def getInfo(self,player):
        if not "s_vilalitystatus" in player.__dict__:
            player.s_vilalitystatus = 0
        pdata = player.s_vilalitystatus
        jinfo = []
        for tabledata in self.mTableData:
            if self.getCurMinute() >= tabledata[0] and self.getCurMinute() <= tabledata[1]:
                jinfo.append((tabledata[0],tabledata[1],tabledata[2],1))
            else:
                jinfo.append((tabledata[0],tabledata[1],tabledata[2],0))        
        return json.dumps({
            "Result": 1,
            "ResultDesc": "",
            "Action":"info",
            "CurTime":time.time(),
            "Info": jinfo,
            "Status":pdata
        })

    def getVilality(self , player , dotype):
        pdata = player.s_vilalitystatus
        timeinfo = self.getCurMinute()
        timecope = self.mTableData
        if timeinfo >= timecope[dotype][0] and timeinfo <= timecope[dotype][1]:
            if (pdata & (1 << dotype)) == 0:
                pdata |= (1 << dotype)
                player.s_vilalitystatus = pdata
                self.addReward(player , self.mTableData[dotype][2])
                return json.dumps({
                            "Result": 1,
                            "ResultDesc": GlobalStrings[51],
                            "Action": "getvilality"
                        })
            else:
                return json.dumps({
                            "Result": 13,
                            "ResultDesc": GlobalStrings[52],
                            "Action": "getvilality"
                        })

    def doAction(self , player , actdata):
        data = json.loads(actdata)

        actionType = data["Action"]
        if actionType == "info":
            return self.getInfo(player)

        elif actionType == "getvilality":
            infotype = data["type"]
            return self.getVilality(player , infotype)


    def loadConfig(self , path):
        rewardFilename = "%sreceivevlality.txt" % (path)
        tb = TabFile()
        if tb.load(rewardFilename):
            tabledata = []
            for i in xrange(tb.mRowNum):
                starttime = tb.get(i, 0, 0, True)
                endtime = tb.get(i, 1, 0, True)
                reward = tb.get(i, 2, "", False).replace("\\n", "\n").replace("\"", "")
                self.starttimes.append(starttime)
                tmpItem = []
                tmpBlocks = reward.split(";")
                if tmpBlocks:
                    itemBlocks = tmpBlocks[0].split(",")
                    if len(itemBlocks) == 2:
                        tmpItem = (
                            int(itemBlocks[0]),
                            int(itemBlocks[1]),
                        )
                tabledata.append((starttime ,endtime ,tmpItem))
            self.mTableData = tabledata
            return True
        else:
            syserr("Load %s failed." % (filename))
            return False

    def onProtocol(self, player, data):
        result = self.doAction(player, data[0])
        response = (result, )
        MMain.sendTextProtocol(player, "S2C_EatFeast", response)

    def invoke(self, msg, param0, param1):
        if msg == MSG_SERVER_STARTUP:
            MMain.registerActivity(self.mID, self)

        elif msg == MSG_TIME_MINUTE:
            self.notifyPlayersEatFeast()

        elif msg == MSG_PLAYER_ONLINE:
            player = param0

            if not "s_vilalitystatus" in player.__dict__:
                player.s_vilalitystatus = 0
            self.notifyPlayerEatTeast(player)

        elif msg == MSG_PLAYER_DAY_CHANGED:
            player = param0

            if not "s_vilalitystatus" in player.__dict__:
                player.s_vilalitystatus = 0
            player.s_vilalitystatus = 0

        elif msg == MSG_PLAYER_CREATED:
            player = param0
            self.checkPlayerData(player)


ModuleID = 6
Instance = ReceiveVilality(ModuleID)
engine.Instance.register(ModuleID, Instance, [
    MSG_SERVER_STARTUP,
    MSG_TIME_MINUTE,
    MSG_PLAYER_ONLINE,
    MSG_PLAYER_DAY_CHANGED,
    MSG_PLAYER_CREATED,
])
