import MMain
MMain.reloadAllActivityConfig()
