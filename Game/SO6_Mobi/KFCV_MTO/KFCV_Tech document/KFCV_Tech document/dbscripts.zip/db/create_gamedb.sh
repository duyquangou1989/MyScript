#!/bin/bash

SQL_dir="./SQL"
# game data databases
data_db_user="root"
data_db_host="127.0.0.1"
data_db_port="3306"
data_db_passwd="123456"
data_db_name="GameSL_data_01"

# game log dabases
log_db_user="root"
log_db_host="127.0.0.1"
log_db_port="3306"
log_db_passwd="123456"
log_db_name="GameSL_Log_01"


data_connect="mysql -u $data_db_user -h $data_db_host -P$data_db_port -p$data_db_passwd"
log_connect="mysql -u $log_db_user -h $log_db_host -P$log_db_port -p$log_db_passwd"

# check mysql connections
$data_connect -e "show databases;" > /dev/null 2>&1
if [[ "$?" != "0" ]]; then
    echo "GameData connected failed "
    exit 1
fi

$data_connect -e " show databases;" > /dev/null 2>&1
if [[ "$?" != "0" ]]; then
    echo "GameLog connected failed "
    exit 1
fi



echo -e "\nCreate GameData database: ${data_db_name} "

$data_connect -e "Create Schema ${data_db_name} Charset=utf8 Collate utf8_general_ci"

$data_connect "${data_db_name}" < ${SQL_dir}/Game.sql
$data_connect "${data_db_name}" < ${SQL_dir}/Guild.sql
$data_connect "${data_db_name}" < ${SQL_dir}/Mail.sql
$data_connect "${data_db_name}" < ${SQL_dir}/Invitation.sql


$log_connect e "\nCreate GameData database: ${log_db_name} "

$log_connect -e "Create Schema ${log_db_name} Charset=utf8 Collate utf8_general_ci"
$log_connect "${log_db_name}" < ${SQL_dir}/Log.sql