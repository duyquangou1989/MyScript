﻿CREATE TABLE IF NOT EXISTS `Packs` (
    `ChannelID` int(11) NOT NULL,
    `MailHead` varchar(64) DEFAULT "",
    `MailBody` varchar(1024) DEFAULT "",
    `MailResources` varchar(512) DEFAULT "",
    `MailItems` varchar(512) DEFAULT "",
    `MailValidTime` int(11) DEFAULT 0,
    PRIMARY KEY (`ChannelID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ActiveKeys` (
    `ActiveKey` varchar(64) NOT NULL,
    `ChannelID` int(11) NOT NULL,
	`CanRepeat` int(11) DEFAULT 0,
    `ServerID` int(11) DEFAULT 0,
    `PlayerName` varchar(64) DEFAULT "",
    `PlayerUUID` varchar(64) DEFAULT "",
    `PlayerAccount` varchar(64) DEFAULT "",
    `PlayerCreateTime` int(11) DEFAULT 0,
    `CreateTime` int(11) DEFAULT 0,
    `UseTime` int(11) DEFAULT 0,
    `ValidTime` int(11) DEFAULT 0,
    PRIMARY KEY (`ActiveKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `KeySeq` (
    `Seq` int(11) NOT NULL DEFAULT 10000,
    PRIMARY KEY (`Seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DELIMITER $$

DROP PROCEDURE IF EXISTS `createActiveKey` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `createActiveKey` (
    _channelID int(11),
    _num int(11),
    _canRepeat int(11)
)
BEGIN
    DECLARE activeKey varchar(64);
    DECLARE lastTime int(11);
    DECLARE i int(11);
    DECLARE curTime int(11);
    set activeKey = "";
    set lastTime = 0;
    set i = 0;
    set curTime = 0;
    select unix_timestamp(now()) into curTime;
    select max(`Seq`) into lastTime from `KeySeq`;
    while i < _num do
        select CHAR(97 + _channelID % 26, 97 + _channelID % 7, 97 + lastTime % 26, 97 + (lastTime + i) % 7, 97 + (lastTime - i) % 11, 97 + (lastTime + i) % 13, 97 + (lastTime - i) % 17, 97 + (lastTime + i) % 19, 97 + (lastTime - i) % 23) into activeKey;
        insert into `ActiveKeys` (`ActiveKey`, `ChannelID`, `CanRepeat`, `CreateTime`, `ValidTime`) values (activeKey, _channelID, _canRepeat, curTime, curTime + 86400 * 365);
        
        set i = i + 1;
    end while;
    
    insert into `KeySeq` (`Seq`) values (lastTime + _num);
    
END $$

DROP PROCEDURE IF EXISTS `saveActiveKey` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `saveActiveKey` (
    _channelID int(11),
    _activeKey varchar(64)
)
BEGIN
    insert into `ActiveKeys` (`ActiveKey`, `ChannelID`, `CreateTime`) values (_activeKey, _channelID, unix_timestamp(now()));
END $$

DROP PROCEDURE IF EXISTS `loadChannelPack` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `loadChannelPack` (
    _channelID int(11)
)
BEGIN
    select * from `Packs` where `ChannelID` = _channelID;
END $$

DROP PROCEDURE IF EXISTS `saveChannelPack` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `saveChannelPack` (
    _channelID int(11),
    _mailHead varchar(64),
    _mailBody varchar(1024),
    _mailResources varchar(512),
    _mailItems varchar(512),
    _mailValidTime int(11)
)
BEGIN
    insert into `Packs` (
        `ChannelID`,
        `MailHead`,
        `MailBody`,
        `MailResources`,
        `MailItems`,
        `MailValidTime`)
        values (
            _channelID,
            _mailHead,
            _mailBody,
            _mailResources,
            _mailItems,
            _mailValidTime)
            on duplicate key update 
                `MailHead` = _mailHead,
                `MailBody` = _mailBody,
                `MailResources` = _mailResources,
                `MailItems` = _mailItems,
                `MailValidTime` = _mailValidTime;
END $$

DROP PROCEDURE IF EXISTS `useActiveKey` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `useActiveKey` (
    _activeKey varchar(64),
    _serverID int(11),
    _playerName varchar(64),
    _playerUUID varchar(64),
    _playerAccount varchar(64),
    _playerCreateTime int(11)
)
BEGIN
    DECLARE usedChannelID int(11);
    DECLARE usedPlayerName varchar(64);
    DECLARE usedPlayerUUID varchar(64);
    DECLARE usedPlayerAccount varchar(64);
    DECLARE usedPlayerCreateTime int(11);
    DECLARE usedServerID int(11);
    DECLARE validKeyNum int(11);
    DECLARE usedCanRepeat int(11);
    DECLARE num int(11);

    set usedChannelID = 0;
    set usedPlayerName = "";
    set usedPlayerUUID = "";
    set usedPlayerAccount = "";
    set usedPlayerCreateTime = 0;
    set usedServerID = 0;
    set validKeyNum = 0;
    set usedCanRepeat = 0;
    set num = 0;

    select `ChannelID`, `CanRepeat`, `PlayerName`, `PlayerUUID`, `PlayerAccount`, `PlayerCreateTime`, `ServerID`, Count(*) into usedChannelID, usedCanRepeat, usedPlayerName, usedPlayerUUID, usedPlayerAccount, usedPlayerCreateTime, usedServerID, validKeyNum from `ActiveKeys` where 
        `ActiveKey` = _activeKey and `ValidTime` >= unix_timestamp(now());

    if validKeyNum != 0 then
        select Count(*) into num from `ActiveKeys` where `PlayerUUID` = _playerUUID and `ChannelID` = usedChannelID and `ServerID` = _serverID;

        if num != 0 and usedCanRepeat = 0 then
            select 4;
        else
            if usedPlayerName = "" then
                select 1;
                update `ActiveKeys` set 
                    `ServerID` = _serverID,
                    `PlayerName` = _playerName,
                    `PlayerUUID` = _playerUUID,
                    `PlayerAccount` = _playerAccount,
                    `PlayerCreateTime` = _playerCreateTime,
                    `UseTime` = unix_timestamp(now()) where `ActiveKey` = _activeKey;
                select _playerName, _playerUUID;
                select * from `Packs` where `ChannelID` = usedChannelID;
            else
                select 3;
            end if;
        end if;
    else
        select 2;
    end if;

END $$

DELIMITER ;