CREATE TABLE IF NOT EXISTS `Guild` (
    `ServerID` int(11) NOT NULL,
    `Name` varchar(64) NOT NULL,
    `Master` varchar(64) NOT NULL,
    `Level` int(11) DEFAULT 1,
    `Experience` int(11) DEFAULT 0,
    `Announcement` varchar(1024) DEFAULT "",
    `GuildMoney` int(11) DEFAULT 0,
    `ActiveTime` int(11) DEFAULT 0,
    `Battle` int(11) DEFAULT 0,
    `BattleAuc` int(11) DEFAULT 0,
    `PythonData` blob,
    PRIMARY KEY (`ServerID`, `Name`),
    KEY `ServerID` (`ServerID`),
    KEY `Master` (`Master`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `GuildApplication` (
    `ServerID` int(11) NOT NULL,
    `GuildName` varchar(64) NOT NULL,
    `Name` varchar(64) NOT NULL,
    `Level` int(11) DEFAULT 1,
    `VipLevel` int(11) DEFAULT 0,
    `Job` int(11) DEFAULT 1,
    `Gender` int(11) DEFAULT 0,
    `ApplyTime` int(11) DEFAULT 0,
    `Message` varchar(256) DEFAULT "",
    PRIMARY KEY (`ServerID`, `GuildName`, `Name`),
    KEY `ServerID` (`ServerID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `GuildEvent` (
    `ServerID` int(11) NOT NULL,
    `UUID` varchar(64) NOT NULL,
    `GuildName` varchar(64) NOT NULL,
    `Account` varchar(64) NOT NULL,
    `Name` varchar(64) NOT NULL,
    `Level` int(11) DEFAULT 1,
    `VipLevel` int(11) DEFAULT 0,
    `Job` int(11) DEFAULT 0,
    `EventType` int(11) DEFAULT 0,
    `Param0` int(11) DEFAULT 0,
    `Param1` int(11) DEFAULT 0,
    `Param2` int(11) DEFAULT 0,
    `ParamDescription` varchar(512) DEFAULT "",
    PRIMARY KEY (`UUID`),
    KEY `ServerID` (`ServerID`),
    KEY `GuildName` (`GuildName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `GuildMember` (
    `ServerID` int(11) NOT NULL,
    `Name` varchar(64) NOT NULL,
    `GuildName` varchar(64) NOT NULL,
    `Post` int(11) DEFAULT 0,
    `Level` int(11) DEFAULT 0,
    `VipLevel` int(11) DEFAULT 0,
    `Gender` int(11) DEFAULT 0,
    `Meritorious` int(11) DEFAULT 0,
    `TotalMeritorious` int(11) DEFAULT 0,
    `JoinTime` int(11) DEFAULT 0,
    `LogoutTime` int(11) DEFAULT 0,
    `GotReward` int(11) DEFAULT 0,
    `GotRewardTime` int(11) DEFAULT 0,
    `PythonData` blob,
    PRIMARY KEY (`ServerID`, `Name`),
    KEY `ServerID` (`ServerID`),
    KEY `GuildName` (`GuildName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DELIMITER $$

DROP PROCEDURE IF EXISTS `loadAllGuilds` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `loadAllGuilds`(_serverID int)
BEGIN
    select * from `Guild` where ServerID = _serverID;
    select * from `GuildMember` where ServerID = _serverID;
    select * from `GuildEvent` where ServerID = _serverID order by ServerID desc limit 30;
    select * from `GuildApplication` where ServerID = _serverID;
END $$

DROP PROCEDURE IF EXISTS `saveGuild` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `saveGuild`(
    _serverID int,
    _name varchar(64),
    _master varchar(64),
    _level int(11),
    _experience int(11),
    _announcement varchar(512),
    _guildmoney int(11),
    _activetime int(11),
    _battle int(11),
    _battleauc int(11),
    _pythonData blob
)
BEGIN
    insert into `Guild` (
        `ServerID`,
        `Name`,
        `Master`,
        `Level`,
        `Experience`,
        `Announcement`,
    	`GuildMoney`,
    	`ActiveTime`,
        `Battle`,
        `BattleAuc`,
        `PythonData`)
        values (
            _serverID,
            _name,
            _master,
            _level,
            _experience,
            _announcement,
    	    _guildmoney,
    	    _activetime,
            _battle,
            _battleauc,
            _pythonData) 
            on duplicate key update 
                `Master` = _master,
                `Level` = _level,
                `Experience` = _experience,
                `Announcement` = _announcement,
        		`GuildMoney` = _guildmoney,
        		`ActiveTime` = _activetime,
                `Battle` = _battle,
                `BattleAuc` = _battleauc,
                `PythonData` = _pythonData;
END $$

DROP PROCEDURE IF EXISTS `saveGuildEvent` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `saveGuildEvent`(
    _serverID int(11),
    _uuid varchar(64),
    _guildName varchar(64),
    _account varchar(64),
    _name varchar(64),
    _level int(11),
    _vipLevel int(11),
    _job int(11),
    _type int(11),
    _param0 int(11),
    _param1 int(11),
    _param2 int(11),
    _paramDescription varchar(1024)
)
BEGIN
    insert into `GuildEvent` (
        `ServerID`, `UUID`, `GuildName`, `Account`, `Name`, `Level`, `VipLevel`, `Job`, `EventType`, `Param0`, `Param1`, `Param2`, `ParamDescription`)
        values (
            _serverID, _uuid, _guildName, _account, _name, _level, _vipLevel, _job, _type, _param0, _param1, _param2, _paramDescription)
            on duplicate key update 
                `Level` = _level,
                `VipLevel` = _vipLevel,
                `Job` = _job,
                `EventType` = _type,
                `Param0` = _param0,
                `Param1` = _param1,
                `Param2` = _param2,
                `ParamDescription` = _paramDescription;
END $$

DROP PROCEDURE IF EXISTS `saveGuildApplication` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `saveGuildApplication`(
    _serverID int(11),
    _guildName varchar(64),
    _name varchar(64),
    _level int(11),
    _vipLevel int(11),
    _job int(11),
    _gender int(11),
    _applyTime int(11),
    _message int(11)
)
BEGIN
    insert into `GuildApplication` (
        `ServerID`, `GuildName`, `Name`, `Level`, `VipLevel`, `Job`, `Gender`, `ApplyTime`, `Message`)
        values (
            _serverID, _guildName, _name, _level, _vipLevel, _job, _gender, _applyTime, _message)
            on duplicate key update 
                `Level` = _level,
                `VipLevel` = _vipLevel,
                `Job` = _job,
                `Gender` = _gender,
                `ApplyTime` = _applyTime,
                `Message` = _message;
END $$

DROP PROCEDURE IF EXISTS `saveGuildMember` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `saveGuildMember`(
    _serverID int(11),
    _name varchar(64),
    _guildName varchar(64),
    _post int(11),
    _level int(11),
    _vipLevel int(11),
    _gender int(11),
    _meritorious int(11),
    _totalmeritorious int(11),
    _joinTime int(11),
    _logoutTime int(11),
    _gotReward int(11),
    _gotRewardTime int(11),
    _pythonData blob
)
BEGIN
    insert into `GuildMember` (
        `ServerID`, `Name`, `GuildName`, `Post`, `Level`, `VipLevel`, `Gender`, `Meritorious`,`TotalMeritorious`, `JoinTime`, `LogoutTime`, `GotReward`, `GotRewardTime`, `PythonData`)
        values (
            _serverID, _name, _guildName, _post, _level, _vipLevel, _gender, _meritorious, _totalmeritorious, _joinTime, _logoutTime, _gotReward, _gotRewardTime, _pythonData)
            on duplicate key update 
                `Post` = _post,
                `Level` = _level,
                `VipLevel` = _vipLevel,
                `Gender` = _gender,
                `Meritorious` = _meritorious,
		`TotalMeritorious` = _totalmeritorious,
                `JoinTime` = _joinTime,
                `LogoutTime` = _logoutTime,
                `GotReward` = _gotReward,
                `GotRewardTime` = _gotRewardTime,
                `PythonData` = _pythonData;
END $$

DROP PROCEDURE IF EXISTS `deleteGuild` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `deleteGuild`(
    _serverID int(11),
    _name varchar(64)
)
BEGIN
    delete from `Guild` where `ServerID` = _serverID and `Name` = _name;
    delete from `GuildEvent` where `ServerID` = _serverID and `GuildName` = _name;
    delete from `GuildApplication` where `ServerID` = _serverID and `GuildName` = _name;
    delete from `GuildMember` where `ServerID` = _serverID and `GuildName` = _name;
END $$

DROP PROCEDURE IF EXISTS `deleteGuildEvent` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `deleteGuildEvent`(
    _serverID int(11),
    _uuid int(11)
)
BEGIN
    delete from `GuildEvent` where `ServerID` = _serverID and `UUID` = _uuid;
END $$

DROP PROCEDURE IF EXISTS `deleteGuildApplication` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `deleteGuildApplication`(
    _serverID int(11),
    _guildName varchar(64),
    _name varchar(64)
)
BEGIN
    delete from `GuildApplication` where `ServerID` = _serverID and `GuildName` = _guildName and `Name` = _name;
END $$

DROP PROCEDURE IF EXISTS `deleteGuildMember` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `deleteGuildMember`(
    _serverID int(11),
    _name varchar(64)
)
BEGIN
    delete from `GuildMember` where `ServerID` = _serverID and `Name` = _name;
END $$
