#coding=utf8

import os
import sys
import re
import codecs


# 定义编码类型
ET_NONE, ET_ANSI, ET_UTF8_NO_BOM, ET_UTF8, ET_UNICODELITTLEENDIAN, ET_UNICODEBIGENDIAN = range(6)

# 定义转码错误码
ENCODE_SUCCESS, ERR_ENCODE_EXCEPTION, ERR_ENCODE_SOURCE_UNREALIZED, ERR_ENCODE_TARGET_UNREALIZED = range(4)

def GetEncode(filename):
    pfile = open(filename, "rb")
    data = pfile.read()
    pfile.close()
    alen = len(data)
    if alen > 3 and data[:3] == codecs.BOM_UTF8:
        #print "ET_UTF8"
        return ET_UTF8
    if alen >= 2 and ord(data[0]) == 0xFF and ord(data[1]) == 0xFE:
        return ET_UNICODELITTLEENDIAN
    if alen >= 2 and ord(data[0]) == 0xFE and ord(data[1]) == 0xFF:
        return ET_UNICODEBIGENDIAN

    lastch = 0
    good = 0
    bad = 0
    for char in data:
        ch = ord(char)
        if(ch & 0xC0) == 0x80:
            if(lastch & 0xC0) == 0xC0:
                good += 1
            elif (lastch & 0x80) == 0:
                bad += 1
        elif (lastch & 0xC0) == 0xC0:
            bad += 1
        lastch = ch
    if good >= bad:
        #print "ET_UTF8_NO_BOM"
        return ET_UTF8_NO_BOM
    else:
        #print "ET_ANSI"
        return ET_ANSI

def CheckTab(filename):
    count = 0
    columns = 0
    tmpcol = 0
    broken = []
    tab = "\t"
    enter = "\r\n"
    pfile = open(filename, "rb")
    alllines = pfile.readlines()
    pfile.close()
    for eachline in alllines:
        count += 1
        li = re.findall(tab, eachline)
        if count == 1:
            if len(li) > 0:
                columns = li.count(tab) + 1
            else:
                columns = 1
        else:
            tmpcol = 1
            if len(li) > 0:
                tmpcol += li.count(tab)
            if tmpcol < columns:
                if eachline.find(enter) != -1:
                    alllines[count-1] = eachline.split(enter)[0]
                    for i in range(0, columns - tmpcol):
                        alllines[count-1] += tab
                    alllines[count-1] += enter
                else:
                    for i in range(0, columns - tmpcol):
                        alllines[count-1] += tab
                broken.append(count)
    if len(broken) > 0:
        pfile = open(filename, "wb")
        pfile.writelines(alllines)
        pfile.close()
    return broken

# 返回0表示转码成功，返回其他表示错误码，详见错误码定义
def Encode(filename, source_encode, target_encode):
    if source_encode != ET_ANSI and source_encode != ET_UTF8_NO_BOM and source_encode != ET_UTF8:
        return ERR_ENCODE_SOURCE_UNREALIZED
    if target_encode != ET_ANSI and target_encode != ET_UTF8_NO_BOM:
        return ERR_ENCODE_TARGET_UNREALIZED
    pfile = open(filename, "r")
    if source_encode == ET_UTF8:
        pfile.seek(3)
    data = pfile.read()
    pfile.close()
    try:
        if source_encode == ET_UTF8 and target_encode == ET_UTF8_NO_BOM:
            pass
        elif target_encode == ET_UTF8_NO_BOM:
            data = data.decode("gbk").encode("utf-8")
        elif target_encode == ET_ANSI:
            data = data.decode("utf-8").encode("gbk")
    except:
        return ERR_ENCODE_EXCEPTION
    pfile = open(filename, "w")
    pfile.write(data)
    pfile.close()
    return ENCODE_SUCCESS

def ShowMenu1():
    print u"1.只检查tab"
    print u"2.只转码"
    print u"3.检查和转码同时进行"
    print u"0.退出"

def ShowMenu2():
    print u"1.ANSI"
    print u"2.UTF-8"
    print u"0.Exit"

def ShowTips():
    print ""



                            

if __name__ == "__main__":
    
    print "-------------------------------------------------"
    print u"|遍历脚本当前路径下以及子路径下所有的txt配置文件。"
    print u"|检查配置文件tab个数是否正确。"
    print u"|对配置文件批量进行转码。"
    print "-------------------------------------------------"
    
    root_dir = os.getcwd()
    source_encode = ET_NONE
    target_encode = ET_NONE
    select = 0
    broken = []
    alen = 0
    err_encode = ENCODE_SUCCESS
    
    ShowMenu1()
    select = input(unicode('请选择：','utf-8').encode('gbk'))

    if select == 0:
        sys.exit(0)
    if select != 1 and select != 2 and select != 3:
        print u"选择错误，程序退出！"
        sys.exit(0)
    if select == 2 or select == 3:
        ShowMenu2()
        target_encode = input(unicode('请选择转换后的编码类型：','utf-8').encode('gbk'))
        if target_encode == 0:
            sys.exit(0)
            

    print u">>>>>>>>>>>>>>>>>>>>>>>开始>>>>>>>>>>>>>>>>>>>>>>>>"

    num = 1
    for root, d, f in os.walk(root_dir):
        for i in f:
            filename = root + "\\" + i
            if(filename.endswith(".txt")):
                source_encode = GetEncode(filename)
                if source_encode == ET_UNICODELITTLEENDIAN or source_encode == ET_UNICODEBIGENDIAN:
                    print u"编码类型不是ANSI和UTF-8中的一种，请手动修改",
                    print " ==> " + filename
                    continue
                    #ShowTips()
                if select == 1 or select == 3:
                    broken = CheckTab(filename)
                    alen = len(broken)
                    if alen > 0:
                        print u"错误行:",
                        for i in range(0, alen):
                            print broken[i],
                    else:
                        print u"格式无错误",
                if select == 2 or select == 3:
                    if source_encode != target_encode:
                        err_encode = Encode(filename, source_encode, target_encode)
                        if err_encode == ENCODE_SUCCESS:
                            print u"转码成功",
                        else:
                            print u"转码失败(err = %d)" %(err_encode),
                    else:
                        print u"无需转码",
                print u"  完成 " + str(num),
                print " ==> " + filename
                num += 1

    os.system('pause')



                
