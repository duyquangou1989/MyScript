﻿set names utf8;
INSERT INTO `KeySeq` VALUES (unix_timestamp(now()));
INSERT INTO `Packs` VALUES (600055, '圣诞礼包①','恭喜您获得礼包奖励', '1,50000;6,500;', '5,55010001,10;4,44330001,5;', 86400 * 7);
INSERT INTO `Packs` VALUES (600056, '圣诞礼包②','恭喜您获得礼包奖励', '2,50;4,150;', '3,33020014,10;4,44303001,1;', 86400 * 7);
INSERT INTO `Packs` VALUES (600057, '元旦礼包①','恭喜您获得礼包奖励', '1,30000;6,1000;', '5,55080001,20;3,33020014,1;', 86400 * 7);
INSERT INTO `Packs` VALUES (600058, '元宝礼包②','恭喜您获得礼包奖励', '2,100;4,100;', '4,44320001,1;3,33020061,1;', 86400 * 7);

call createActiveKey(600055, 1000, 0);
call createActiveKey(600056, 1000, 0);
call createActiveKey(600057, 1000, 0);
call createActiveKey(600058, 1000, 0);

