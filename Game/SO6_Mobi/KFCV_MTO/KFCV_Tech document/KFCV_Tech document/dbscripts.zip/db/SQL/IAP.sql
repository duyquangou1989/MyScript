CREATE TABLE IF NOT EXISTS `iap` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ServerID` int(11) DEFAULT -1,
  `Account` varchar(64) DEFAULT "",
  `Name` varchar(64) DEFAULT "",
  `ProductID` varchar(256) DEFAULT "",
  `TransactionID` varchar(512) DEFAULT "",
  `BuyTime` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `Account` (`Account`),
  KEY `ServerID` (`ServerID`),
  KEY `Name` (`Name`),
  KEY `TransactionID` (`TransactionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ServerID` int (11) DEFAULT -1,
  `Account` varchar(64) DEFAULT "",
  `Name` varchar(64) DEFAULT "",
  `ProductID` varchar(256) DEFAULT "",
  `CooOrderSerial` varchar(512) DEFAULT "",
  `PayType` int(11) DEFAULT 0,
  `Finished` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `Account` (`Account`),
  KEY `ServerID` (`ServerID`),
  KEY `ProductID` (`ProductID`),
  KEY `CooOrderSerial` (`CooOrderSerial`),
  KEY `PayType` (`PayType`),
  KEY `Finished` (`Finished`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `unhandled` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ServerID` int (11) DEFAULT -1,
  `Account` varchar(64) DEFAULT "",
  `Name` varchar(64) DEFAULT "",
  `ProductID` varchar(256) DEFAULT "",
  `CooOrderSerial` varchar(512) DEFAULT "",
  `TransactionID` varchar(1024) DEFAULT "",
  `PurchasedDate` int(11) DEFAULT 0,
  `Quantity` int(11) DEFAULT 0,
  `Money` int(11) DEFAULT 0,
  `PayType` int(11) DEFAULT 0,
  `Finished` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `Account` (`Account`),
  KEY `ServerID` (`ServerID`),
  KEY `CooOrderSerial` (`CooOrderSerial`),
  KEY `PayType` (`PayType`),
  KEY `Finished` (`Finished`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DELIMITER $$

DROP PROCEDURE IF EXISTS `createOrderSerial` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `createOrderSerial`(_serverID int, _account varchar(64), _name varchar(64), _productID varchar(256), _iapType int)
BEGIN
    declare orderSerial varchar(512);
    set orderSerial = uuid();
    insert into `orders` (`ServerID`, `Account`, `Name`, `ProductID`, `CooOrderSerial`, `PayType`, `Finished`) values (_serverID, _account, _name, _productID, orderSerial, _iapType, 0);
    select orderSerial;
END $$

DROP PROCEDURE IF EXISTS `createOrderSerial_ChinaNet` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `createOrderSerial_ChinaNet`(_serverID int, _account varchar(64), _name varchar(64), _productID varchar(256), _iapType int)
BEGIN
    declare orderSerial varchar(512);
    declare osID int;
    set orderSerial = "";
    set osID = -1;

    create table if not exists `orders_chinanet` ( `id` int(11) not null auto_increment, `OrderID` int (11) default 0, primary key (`id`)) engine=InnoDB default charset=utf8;
    select `id`, `OrderID` into osID, orderSerial from `orders_chinanet` limit 1;
    if osID < 0 then
        set orderSerial = 1;
        insert into `orders_chinanet` (`OrderID`) values (orderSerial);
    else
        set orderSerial = orderSerial + 1;
        update `orders_chinanet` set `OrderID` = orderSerial where `id` = osID;
    end if;
        
    insert into `orders` (`ServerID`, `Account`, `Name`, `ProductID`, `CooOrderSerial`, `PayType`, `Finished`) values (_serverID, _account, _name, _productID, orderSerial, _iapType, 0);
    select orderSerial;
END $$

DROP PROCEDURE IF EXISTS `saveIAPPurchase` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `saveIAPPurchase`(_serverID int, _account varchar(64), _name varchar(64), _productID varchar(256), _transactionID varchar(256), _buyTime int, _orderSerial varchar(256))
BEGIN
    declare pid int;
    set pid = -1;
    select `id` into pid from `iap` where `TransactionID` = _transactionID limit 1;
    if pid > 0 then
        select 0;
    else
        update `orders` set `Finished` = 1 where `CooOrderSerial` = _orderSerial;
		update `unhandled` set `Finished` = 1 where `CooOrderSerial` = _orderSerial;
        insert into `iap` (`ServerID`, `Account`, `Name`, `ProductID`, `TransactionID`, `BuyTime`) values(_serverID, _account, _name, _productID, _transactionID, _buyTime);
        select 1;
    end if;
END $$

DROP PROCEDURE IF EXISTS `loadAllUnFinishedOrder` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `loadAllUnFinishedOrder`(_serverID int, _account varchar(64), _iapType int)
BEGIN
    select `ProductID`, `CooOrderSerial` from `orders` where `ServerID` = _serverID and `Account` = _account and `PayType` = _iapType and `Finished` = 0;
END $$

DROP PROCEDURE IF EXISTS `saveUnhandledResult` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `saveUnhandledResult`(
    _productID varchar(256),
    _cooOrderSerial varchar(256),
    _transactionID varchar(1024),
    _purchasedDate int(11),
    _quantity int(11),
    _money int(11),
    _payType int(11))
BEGIN
    declare pid int;
    declare oid int;
    declare _serverID int;
    declare _account varchar(64);
    declare _name varchar(64);
    declare _productID varchar(256);
    set oid = -1;
    set pid = -1;
    
    select `id` into pid from `unhandled` where `TransactionID` = _transactionID limit 1;
    if pid > 0 then
        select 0;
    else
        select `id`, `ServerID`, `Account`, `Name`, `productID` into oid, _serverID, _account, _name, _productID from `orders` where `CooOrderSerial` = _cooOrderSerial;

        if oid > 0 then

            insert into `unhandled` (
                `ServerID`, 
                `Account`, 
                `Name`, 
                `ProductID`, 
                `CooOrderSerial`,
                `TransactionID`, 
                `PurchasedDate`,
                `Quantity`,
                `Money`,
                `PayType`,
                `Finished`
            ) values(
                _serverID, 
                _account, 
                _name, 
                _productID, 
                _cooOrderSerial,
                _transactionID,
                _purchasedDate,
                _quantity,
                _money,
                _payType,
                0
            );
            select 1, _serverID, _account, _name, _productID;
        else
            select 0;
        end if;
    end if;
END $$


DROP PROCEDURE IF EXISTS `saveUnhandledResultForApp` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `saveUnhandledResultForApp`(
    _serverID int,
    _account varchar(64),
    _name varchar(64),
    _productID varchar(256),
    _cooOrderSerial varchar(256),
    _transactionID varchar(1024),
    _purchasedDate int(11),
    _quantity int(11),
    _money int(11),
    _payType int(11))
BEGIN
    declare pid int;
    declare oid int;

    set oid = -1;
    set pid = -1;
    
    select `id` into pid from `unhandled` where `TransactionID` = _transactionID limit 1;
    if pid > 0 then
        select 0;
    else
        insert ignore into `orders` (
            `ServerID`, 
            `Account`, 
            `Name`,
            `ProductID`, 
            `CooOrderSerial`, 
            `PayType`, 
            `Finished`
        ) values (
            _serverID, 
            _account, 
            _name,
            _productID, 
            _cooOrderSerial, 
            _payType, 
            0
        );

        insert into `unhandled` (
            `ServerID`, 
            `Account`, 
            `Name`, 
            `ProductID`, 
            `CooOrderSerial`,
            `TransactionID`, 
            `PurchasedDate`,
            `Quantity`,
            `Money`,
            `PayType`,
            `Finished`
        ) values(
            _serverID, 
            _account, 
            _name, 
            _productID, 
            _cooOrderSerial,
            _transactionID,
            _purchasedDate,
            _quantity,
            _money,
            _payType,
            0
        );
        select 1;
    end if;
END $$
DELIMITER ;