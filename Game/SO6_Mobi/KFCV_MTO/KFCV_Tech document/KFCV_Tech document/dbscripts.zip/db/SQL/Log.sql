CREATE TABLE IF NOT EXISTS `Logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ServerAccountID` int(11) DEFAULT -1,
  `Account` varchar(64) DEFAULT "",
  `Name` varchar(64) DEFAULT "",
  `Level` int(11) DEFAULT 0,
  `VipLevel` int(11) DEFAULT 0,
  `LogTime` int(11) DEFAULT 0,
  `LogType` int(11) DEFAULT -1,
  `Param0` int(11) DEFAULT -1,
  `Param1` int(11) DEFAULT -1,
  `Param2` int(11) DEFAULT -1,
  `Param3` int(11) DEFAULT -1,
  `ParamDescription` varchar(1024) DEFAULT -1,
  PRIMARY KEY (`id`),
  KEY `Account` (`Account`),
  KEY `ServerAccountID` (`ServerAccountID`),
  KEY `Name` (`Name`),
  KEY `LogTime` (`LogTime`),
  KEY `LogType` (`LogType`),
  KEY `Param0` (`Param0`),
  KEY `Param1` (`Param1`),
  KEY `Param2` (`Param2`),
  KEY `Param3` (`Param3`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DELIMITER $$

DROP PROCEDURE IF EXISTS `insertLog` $$
CREATE DEFINER=`admin`@`%` PROCEDURE `insertLog`(
    _serverAccountID int,
    _account varchar(64),
    _name varchar(64),
	_level int,
    _vipLevel int,
    _logType int,
    _param0 int,
    _param1 int,
    _param2 int,
    _param3 int,
    _paramDescription varchar(1024)
)
BEGIN
    declare tableName varchar(64);
    declare sqlString varchar(1024);
    declare dateTime varchar(128);
    declare sqlCreateString varchar(1024);
    declare paramServerAccountID int;
    declare paramAccount varchar(64);
    declare paramName varchar(64);
    declare paramLevel int;
    declare paramVipLevel int;
    declare paramLogType int;
    declare paramParam0 int;
    declare paramParam1 int;
    declare paramParam2 int;
    declare paramParam3 int;
    
    set @dateTime = curdate();
    set @tableName = concat('`Logs_', year(@dateTime), '_', lpad(month(@dateTime), 2, '0'), '_', lpad(day(@dateTime), 2, '0'), '`');
    set @sqlString = concat('insert into ', @tableName, ' (`ServerAccountID`,`Account`,`Name`,`Level`,`VipLevel`,`LogTime`,`LogType`,`Param0`,`Param1`,`Param2`,`Param3`,`ParamDescription`) values (?,?,?,?,?,',unix_timestamp(),',?,?,?,?,?,?)'); 
    set @sqlCreateString = concat('create table if not exists ', @tableName, '(`id` int(11) NOT NULL AUTO_INCREMENT,`ServerAccountID` int(11) DEFAULT -1,`Account` varchar(64) DEFAULT "",`Name` varchar(64) DEFAULT "",`Level` int(11) DEFAULT 0,`VipLevel` int(11) DEFAULT 0,`LogTime` int(11) DEFAULT 0,`LogType` int(11) DEFAULT -1,`Param0` int(11) DEFAULT -1,`Param1` int(11) DEFAULT -1,`Param2` int(11) DEFAULT -1,`Param3` int(11) DEFAULT -1,`ParamDescription` varchar(1024) DEFAULT -1,PRIMARY KEY (`id`),KEY `Account` (`Account`),KEY `ServerAccountID` (`ServerAccountID`),KEY `Name` (`Name`),KEY `LogTime` (`LogTime`),KEY `LogType` (`LogType`),KEY `Param0` (`Param0`),KEY `Param1` (`Param1`),KEY `Param2` (`Param2`),KEY `Param3` (`Param3`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;');

    set @paramServerAccountID = _serverAccountID;
    set @paramAccount = _account;
    set @paramName = _name;
    set @paramLevel = _level;
    set @paramVipLevel = _vipLevel;
    set @paramLogType = _logType;
    set @paramParam0 = _param0;
    set @paramParam1 = _param1;
    set @paramParam2 = _param2;
    set @paramParam3 = _param3;
    set @paramParamDescription = _paramDescription;

    prepare stmt from @sqlCreateString;
    execute stmt;
    deallocate prepare stmt;
    
    prepare stmt from @sqlString;
    execute stmt using @paramServerAccountID, @paramAccount, @paramName, @paramLevel, @paramVipLevel, @paramLogType, @paramParam0, @paramParam1, @paramParam2, @paramParam3, @paramParamDescription;
    deallocate prepare stmt;
END $$
DELIMITER ;


