ALTER TABLE `Pet` ADD COLUMN `Talents` varchar(1024) AFTER `Status`;
ALTER TABLE `Guild` add column `Battle` int(11) after `ActiveTime`;
ALTER TABLE `Guild` add column `BattleAuc` int(11) after `Battle`;