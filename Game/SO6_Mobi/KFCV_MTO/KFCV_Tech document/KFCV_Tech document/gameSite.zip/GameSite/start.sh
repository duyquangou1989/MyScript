nohup python scripts/main.py 8787 &
