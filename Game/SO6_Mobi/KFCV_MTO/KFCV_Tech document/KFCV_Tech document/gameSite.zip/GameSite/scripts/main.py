#coding=utf8
import web
import hashlib
import time
import random
import re
import sys
import os
try:
    import json
except:
    import simplejson as json

import redis

import urllib2
import urllib
from web import form
from traceback import print_exc

from tenjin.helpers import *
import tenjin
engine = tenjin.Engine(postfix=".html", preprocess=True)

urls = (
    '/crossdomain.xml', 'CrossDomain',
    '/login', 'LoginAcc',
    '/register', 'RegisterAcc',
    '/loginex', 'LoginAccEx',
    '/debugger', 'DebuggerHTML',
    '/', 'Main',
)
app = web.application(urls, globals())
cookies = urllib2.HTTPCookieProcessor()
opener = urllib2.build_opener(cookies)
urllib2.install_opener(opener)

serverLists = None
#serverBaseUrl = "http://221.237.157.134:8088/"
serverBaseUrl = "http://192.168.0.220/"
staticUrl = "static/"
staticDir = "%s/%s" % (os.getcwd(), staticUrl)
packageUrl = "packages/"

#if len(sys.argv) > 1:
#    serverBaseUrl = "http://%s/" % (sys.argv[1])

r = redis.Redis("127.0.0.1")

def getConfig(configName):
    configFile = open("options/main.config", "r")
    configs = json.loads(configFile.read())
    configFile.close()

    return configs[configName]

class Main:
    def GET(self):
        global serverLists
        if serverLists is None:
            serverLists = []

            urls = [
                ["http://192.168.0.220/static/serverlists/internal.txt", "王者之戒"],
                ["http://192.168.0.220/static/serverlists/zzb_internal.txt", "至尊宝"],
                ["http://192.168.0.220/static/serverlists/dota.txt", "暴走刀塔"]
            ]

            for url in urls:
                try:
                    serverLists.extend(self.GetServerList(url[0], url[1]))
                except:
                    print_exc()
        packages = []
        games = []
        gameName = getConfig("GameName")
        suffixName = getConfig("SuffixName")
        for prefix in gameName:
            data = []
            for suffix in suffixName:
                data.append([suffix, "%s_%s" % (suffix, prefix)])
            packages.append([gameName[prefix], data])
            games.append([gameName[prefix], prefix])

        servers = serverLists
        accTypes = getConfig("AccountTypes")
        return engine.render(":templates/main", locals())
            

    def GetServerList(self, url, prefix):
        servers = []
        data = urllib2.urlopen(url).read()
        lines = data.split("\n")
        first = True
        for line in lines:
            if not first:
                if line:
                    blocks = line.split("\t")
                    servers.append(["%s - %s" % (prefix, blocks[1]), blocks[2], blocks[3]])
            else:
                first = False

        return servers

class CrossDomain:
    def GET(self):
        return '''<?xml version="1.0"?>
<cross-domain-policy>
<allow-access-from domain="*"/>
</cross-domain-policy>'''.decode("utf8").encode("gbk")

class RegisterAcc:
    def GET(self):
        registerErr = ""
        return engine.render(":templates/register", locals())

    def POST(self):
        data = web.input(username="", password="", password_r="")
        if not data.username:
            registerErr = "用户名不能为空"
            return engine.render(":templates/register", locals())
        elif data.password == "":
            registerErr = "密码不能为空"
            return engine.render(":templates/register", locals())
        elif data.password != data.password_r:
            registerErr = "两次密码不一致"
            return engine.render(":templates/register", locals())

        if r.hset("account:%s" % (data.username.lower()), "password", hashlib.md5(data.password).hexdigest()):
            web.setcookie("Username", data.username.lower(), 3600)
            raise web.seeother("/")
        else:
            registerErr = "注册失败！"
            return engine.render(":templates/register", locals())

class LoginAccEx:
    def POST(self):
        data = web.input(username = "", password = "")
        password = r.hget("account:%s" % (data.username.lower()), "password")
        if password == hashlib.md5(data.password).hexdigest():
            identifyCode = hashlib.md5(data.username.lower() + str(random.randint(0, 10000000)) + str(time.time())).hexdigest();
            if r.set(identifyCode, data.username.lower()):
                r.expire(identifyCode, 3600)
                return identifyCode
            else:
                return ""
        else:
            return ""

    def GET(self):
        return self.POST()

class LoginAcc:
    def GET(self):
        self.POST()
        
    def POST(self):
        data = web.input(
            username = "", 
            password = "", 
            server="",
            loginType="",
            gameType="")

        identifyCode = None
        if data.loginType == "AT_Internal":
            identifyCode = self.internalHttpLogin(data.username, data.password)
        elif data.loginType == "AT_D":
            identifyCode = self.dHttpLogin(data.username, data.password)
        elif data.loginType == "AT_MoreFun":
            identifyCode = self.mfHttpLogin(data.username, data.password)
        elif data.loginType == "AT_LeYou":
            identifyCode = self.lyHttpLogin(data.username, data.password)
        elif data.loginType == "AT_YWWY":
            identifyCode = self.ywwyHttpLogin(data.username, data.password)

        if identifyCode is None:
            return "Login failed."
        else:
            blocks = data.server.split(":")
            serverUrl = blocks[0]
            serverPort = blocks[1]
            gameType = data.gameType
            loginType = data.loginType
            baseUrl = serverBaseUrl
            print baseUrl
            return engine.render(":templates/game", locals())

    def lyHttpLogin(self, username, password):
        PRIVATE_KEY='*aigame365#'
        targetUri = "http://api.aigame365.com/api/loginService.shtml"
        param = {}
        param["appid"] = "zzb"
        param["username"] = username
        param["password"] = hashlib.md5(password+PRIVATE_KEY).hexdigest()
        param["partner"] = "aigame"
        param["mac"] = hashlib.md5(param["appid"] + username + param["password"] + param["partner"] + PRIVATE_KEY).hexdigest()

        request = urllib2.Request(targetUri, urllib.urlencode(param))
        response = urllib2.urlopen(request)
        result = response.read()

        result = json.loads(result)
        if result["result"] == "1":
            identifyCode = "%s:%s" % (result["info"]["uid"], result["info"]["sid"])
            return identifyCode
        else:
            return None

    def dHttpLogin(self, username, password):
        targetUri = "http://connect.d.cn/open/member/login/"
        param = {}
        param["serverName"] = "zhizunbao"
        param["appId"] = 240
        param["needRemember"] = 0
        param["userId"] = username
        param["password"] = password

        request = urllib2.Request(targetUri, urllib.urlencode(param))
        response = urllib2.urlopen(request)
        result = response.read()

        result = json.loads(result)
        identifyCode = result["token"].replace("\"", "")
        if identifyCode:
            return identifyCode
        else:
            return None

    def mfHttpLogin(self, username, password):
        targetUri = "http://1737game.com/game_gateway.php?appkey=IDVDdh9IRR180utE&action=api_login"
        param = {}
        param["username"] = username
        param["password"] = password

        request = urllib2.Request(targetUri, urllib.urlencode(param))
        response = urllib2.urlopen(request)
        result = response.read()

        data = re.findall("connect://succes/\?uid=.*&sessionid=.*", result)
        if len(data):
            blocks = data[0].split("?")[1].split("&")

            uid = blocks[0].split("=")[1]
            sessionid = blocks[1].split("=")[1].split("\"")[0]

            return "user%s:%s" % (uid, sessionid)
        else:
            return None

    def internalHttpLogin(self, username, password):
        targetUri = "%sloginex?username=%s&password=%s" % (serverBaseUrl, username, password)

        request = urllib2.Request(targetUri)
        response = urllib2.urlopen(request)
        result = response.read()

        if result:
            return result
        else:
            return None

    def ywwyHttpLogin(self, username, password):
        data = {
            "username": username,
            "password": password,
            }
        urllib2.urlopen("http://my.youyoule.com/Pglogin/logfo?appid=10000001&callback=success%%3A//").read()

        request = urllib2.Request("http://my.youyoule.com/Pglogin/login?appid=10000001", urllib.urlencode(data))
        response = urllib2.urlopen(request)

        result = response.read()

        if result:
            d = re.findall("window\\.location\\.href='.*'", result)
            if len(d):
                d = d[0].split("?")[1]
                tmpBlocks = d.replace("'", "").split("&")
                userID = tmpBlocks[0].split("=")[1];
                session = tmpBlocks[1].split("=")[1];
                return "%s:%s" % (userID, session)
            else:
                return None
        else:
            return None


if __name__ == "__main__":
    app.run()
