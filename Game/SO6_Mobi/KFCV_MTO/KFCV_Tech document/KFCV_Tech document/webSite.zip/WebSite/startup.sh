nohup python scripts/main.py 8280 > web.8280.log &
nohup python scripts/main.py 8281 > web.8281.log &
nohup python scripts/main.py 8282 > web.8282.log &
nohup python scripts/main.py 8283 > web.8283.log &
nohup python scripts/main.py 8284 > web.8284.log &
nohup python scripts/main.py 8285 > web.8285.log &

