#coding=utf8

import tornadoredis
import tornado.web
import tornado.gen
import tornado.httpserver
import tornado.web
import tornado.ioloop
import tornado.options
import time
import os

class Handler_XmlProlicy(tornado.web.RequestHandler):
    def get(self):
        msg = '''<?xml version="1.0"?>
<cross-domain-policy>
<allow-access-from domain="*"/>
</cross-domain-policy>'''.decode("utf8").encode("gbk")
        self.write(msg)
        self.flush()
        self.finish()

class Handler_Index(tornado.web.RequestHandler):
    @tornado.gen.coroutine
    def get(self):
        self.application.checkPermission(self)
        self.write("")
        self.flush()
        self.finish()
