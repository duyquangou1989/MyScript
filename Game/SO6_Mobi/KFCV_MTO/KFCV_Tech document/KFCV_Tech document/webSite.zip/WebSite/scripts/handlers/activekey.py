#coding=utf8

import tornadoredis
import tornado.web
import tornado.gen
import tornado.httpserver
import tornado.web
import tornado.ioloop
import tornado.options
import time
import os
import hashlib
import urllib2
import json
from traceback import print_exc

class Handler_UseActiveKey(tornado.web.RequestHandler):
    @tornado.gen.coroutine
    def get(self):
        self.application.checkPermission(self)

        r = self.application.mRedis
        db = self.application.mMySQL

        serverID = self.get_argument("svrid").replace("'", "")
        name = self.get_argument("n").replace("'", "")
        uuid = self.get_argument("u").replace("'", "")
        activeKey = self.get_argument("k").replace("'", "")

        result = {
            "Error": 0,
            "PlayerUUID": uuid,
        }
        try:
            cur = yield db.execute("begin")
            cur = yield db.execute("select `ChannelID`, `PlayerUUID` from `ActiveKeys` where `ActiveKey` = '%s' and `ValidTime` >= unix_timestamp(now()) for update;" % (activeKey))
            data = cur.fetchall()
            if len(data) > 0:
                row = data[0]
                channelID = int(row[0])
                usedPlayerUUID = row[1]

                if not usedPlayerUUID:
                    cur = yield db.execute("select count(*) from `ActiveKeys` where `PlayerUUID`='%s' and `ChannelID`='%s' and `ServerID`='%s';" % ( 
                                          uuid,
                                          channelID,
                                          serverID))
                    data = cur.fetchall()
                    if len(data) > 0:
                        usedNum = int(data[0][0])
                        if usedNum <= 0:
                            result["Error"] = 1
                            yield db.execute("update `ActiveKeys` set `ServerID`='%s', `PlayerName`='%s', `PlayerUUID`='%s', `UseTime`=unix_timestamp(now()) where `ActiveKey`='%s';" % (
                                serverID,
                                name,
                                uuid,
                                activeKey))
                        else:
                            # used
                            result["Error"] = 4
                else:
                    # used
                    result["Error"] = 3
            else:
                # no activekey
                result["Error"] = 2

            if result["Error"] == 1:
                # ok
                yield db.execute("commit")

                cur = yield db.execute("select * from `Packs` where `ChannelID`=%s;" % (channelID))
                data = cur.fetchall()

                if len(data) > 0:
                    row = data[0]
                    result["MailHead"] = row[1]
                    result["MailBody"] = row[2]
                    result["MailValidTime"] = row[3]
                    result["MailRewards"] = row[4]
                else:
                    result["Error"] = 5
            else:
                # failed
                yield db.execute("rollback")
        except:
            print_exc()

        self.write(json.dumps(result))
        self.flush()
        self.finish()
