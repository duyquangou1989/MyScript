from tornado_mysql.tests.test_issues import *
from tornado_mysql.tests.test_basic import *
from tornado_mysql.tests.test_nextset import *
from tornado_mysql.tests.test_DictCursor import *
from tornado_mysql.tests.test_connection import TestConnection
from tornado_mysql.tests.test_SSCursor import TestSSCursor
#from pymysql.tests.thirdparty import *

if __name__ == "__main__":
    import unittest
    unittest.main()
