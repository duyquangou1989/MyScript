#coding=utf8

import tornado.web
import tornado.gen
import tornado.httpserver
import tornado.web
import tornado.ioloop
import tornado.options
import redis
import time
import os
import hashlib
import urllib2
import json
import random

class Handler_Login(tornado.web.RequestHandler):
    def get(self):
        self.application.checkPermission(self)

        r = self.application.mRedis

        username = self.get_argument("username")
        password = self.get_argument("password")

        identifyCode = ""
        hashedPassword = r.hget("account:%s" % (username.lower()), "password")
        if hashedPassword == hashlib.md5(password).hexdigest():
            identifyCode = hashlib.md5(username.lower() + str(random.randint(0, 100000)) + str(time.time())).hexdigest();
            if r.set(identifyCode, username.lower()):
                r.expire(identifyCode, 3600)

        self.write(identifyCode)
        self.flush()
        self.finish()

class Handler_CheckPermission(tornado.web.RequestHandler):
    def get(self):
        r = self.application.mRedis
        configs = self.application.mConfigs

        maxPlayers = configs["Game"]["MaxPlayers"]
        canLogin = False

        if maxPlayers > 0:
            keyName = "svr:players"

            udid = self.get_argument("u")
            playerNum = r.scard(keyName)
            if playerNum == None:
                playerNum = 0
            else:
                playerNum = int(playerNum)

            if playerNum < maxPlayers:
                canLogin = True
            else:
                canLogin = r.sismember(keyName, udid)
        else:
            canLogin = True

        self.write(json.dumps({"CanLogin": canLogin}))
        self.flush()
        self.finish()

class Handler_PlayerCreated(tornado.web.RequestHandler):
    def get(self):
        self.application.checkPermission(self)

        r = self.application.mRedis
        configs = self.application.mConfigs

        maxPlayers = configs["Game"]["MaxPlayers"]

        if maxPlayers > 0:
            udid = self.get_argument("u")
            keyName = "svr:players"
            r.sadd(keyName, udid)

        self.write("")
        self.flush()
        self.finish()
