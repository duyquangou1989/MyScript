#coding=utf8

import tornadoredis
import tornado.web
import tornado.gen
import tornado.httpserver
import tornado.web
import tornado.ioloop
import tornado.options
import time
import os
import json

Server_State_Good       = 1,
Server_State_Busy       = 2,
Server_State_Hot        = 3,
Server_State_New        = 4,
Server_State_Recommend  = 5,

class Handler_Game_Status(tornado.web.RequestHandler):
    def get(self):
        self.application.checkPermission(self)

        r = self.application.mRedis

        serverID = self.get_argument("svrid")
        serverName = self.get_argument("svrname")
        httpIP = self.get_argument("httpip")
        httpPort = self.get_argument("httpport")
        curPlayers = self.get_argument("curplayers")
        maxPlayers = self.get_argument("maxplayers")
        updateTime = int(time.time())

        data = {}
        data["id"] = serverID
        data["name"] = serverName
        data["http:ip"] = httpIP
        data["http:port"] = httpPort
        data["curplayers"] = curPlayers
        data["maxplayers"] = maxPlayers
        data["updatetime"] = updateTime

        p = r.pipeline()
        p.hmset("game:%s" % (serverID), data)
        p.sadd("game:ids", serverID)
        ret = p.execute()

        self.write(str(ret))
        self.flush()

        ##
        if float(curPlayers) / maxPlayers > 0.7:
            filename = "static/serverlist.txt"
            try:
                f = open(filename, "r")
                lines = f.readlines()
                f.close()
                newlines = ""
                for line in lines:
                    while line[-1:] == "\r" or line[-1:] == "\n":
                        line = line[:-1]
                        
                    s = line.split("\t")
                    if len(s) > 0:
                        if s[0] == ServerID:
                            s[6] = Server_State_Busy
                        newlines += "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t\n" % (
                            s[0],
                            s[1],
                            s[2],
                            s[3],
                            s[4],
                            s[5],
                            s[6],
                            s[7],
                            s[8]
                            )
                f = open(filename, "w")
                f.writelines(newlines)
                f.close()
                
            except:
                print_exc()
        ##     
        self.finish()

class Handler_Connector_Status(tornado.web.RequestHandler):
    def get(self):
        self.application.checkPermission(self)

        r = self.application.mRedis

        serverID = self.get_argument("svrid")
        serverIP = self.get_argument("svrip")
        serverPort = self.get_argument("svrport")
        curClients = self.get_argument("curclients")
        maxClients = self.get_argument("maxclients")
        updateTime = int(time.time())
        
        connectorID = "%s:%s" % (serverIP, serverPort)

        data = {}
        data["id"] = connectorID
        data["svrip"] = serverIP
        data["svrport"] = serverPort
        data["curclients"] = curClients
        data["maxclients"] = maxClients
        
        p = r.pipeline()
        p.hmset("game:%s:connector:%s" % (serverID, connectorID), data)
        p.expire("game:%s:connector:%s" % (serverID, connectorID), 12)
        p.sadd("game:%s:connectors" % (serverID), connectorID)
        ret = p.execute()

        self.write(str(ret))
        self.flush()
        self.finish()

class Handler_ServerLists(tornado.web.RequestHandler):
    def get(self):
        r = self.application.mRedis

        version = self.get_argument("ver", default = "")
        svrlistsCacheKey = "game:svrlist:cache:%s" % (version)
        svrlists = None #r.get(svrlistsCacheKey)

        if svrlists == None:
            curTime = int(time.time())

            fields = [
                "id",
                "name",
                "http:ip",
                "http:port",
                "curplayers",
                "maxplayers",
                "updatetime",
            ]

            servers = []
            serverIDs = r.smembers("game:ids")

            _servers = []
            p = r.pipeline()
            for serverID in serverIDs:
                gameKeyName = "game:%s" % (serverID)
                p.hmget(gameKeyName, fields)
            _servers = p.execute()

            for svr in _servers:
                if len(svr) > 0 and svr[0] != None:
                    serverID = svr[0]
                    serverName = svr[1]
                    serverHttpIP = svr[2]
                    serverHttpPort = svr[3]
                    serverCurPlayers = svr[4]
                    serverMaxPlayers = svr[5]
                    serverUpdateTime = svr[6]
                    serverStatus = 1

                    curPlayers = float(serverCurPlayers)
                    maxPlayers = float(serverMaxPlayers)

                    timeOut = False
                    if serverUpdateTime != None:
                        if curTime - int(serverUpdateTime) > 30:
                            timeOut = True

                    if curPlayers / maxPlayers > 0.7:
                        serverStatus = 2
                    
                    cfields = [
                        "id",
                        "svrip",
                        "svrport",
                        "curclients",
                        "maxclients",
                    ]
                    needRemoveConnectors = []
                    connectors = []
                    connectorIDs = r.smembers("game:%s:connectors" % (serverID))

                    _conn = []
                    for connectorID in connectorIDs:
                        keyName = "game:%s:connector:%s" % (serverID, connectorID)
                        p.hmget(keyName, cfields)
                    _conn = p.execute()

                    for conn in _conn:
                        if len(conn) > 0 and conn[0] != None:
                            connectorID = conn[0]
                            connSvrIP = conn[1]
                            connSvrPort = conn[2]
                            connCurClients = conn[3]
                            connMaxClients = conn[4]

                            connector = [
                                connSvrIP,
                                connSvrPort,
                            ]
                            curClients = float(connCurClients)
                            maxClients = float(connMaxClients)

                            if maxClients <= 0:
                                maxClients = 1

                            rate = curClients / maxClients
                            if rate >= 0:
                                connectors.append((rate, connector))

                    serverIP = ""
                    serverPort = 0

                    if len(connectors) <= 0 or timeOut:
                        serverStatus = 0
                    else:
                        connectors.sort(reverse=False)
                        connector = connectors[0][1]

                        serverIP = connector[0]
                        serverPort = connector[1]

                    servers.append((
                        int(serverID),
                        serverName,
                        serverStatus,
                        serverIP,
                        serverPort,
                    ))

            servers.sort(reverse=True)
            svrlists = "ServerID\tServerName\tServerIP\tServerPort\tServerLoginUrl\tServerStatus\tServerVersion\n"

            svrID = 1
            for server in servers:
                svrlists += "%s\t%s\t%s\t%s\t%s\t%s\t%s\n" % (
                    server[0],
                    server[1],
                    server[3],
                    server[4],
                    "",
                    server[2],
                    "")

            p = r.pipeline()
            p.set(svrlistsCacheKey, svrlists)
            p.expire(svrlistsCacheKey, 10)
            p.execute()

        self.write(svrlists)
        self.flush()
        self.finish()