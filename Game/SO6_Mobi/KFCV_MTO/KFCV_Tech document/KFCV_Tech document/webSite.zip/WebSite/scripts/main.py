#coding=utf8

import tornado.web
import tornado.gen
import tornado.httpserver
import tornado.web
import tornado.ioloop
import tornado.options
import time
import os
import json
import sys
import redis

from tornado_mysql import pools

reload(sys)
sys.setdefaultencoding('utf-8')

from handlers import (
    # public api
    Handler_XmlProlicy, 
    Handler_Ranks,
    Handler_ServerLists,
    Handler_CheckPermission,
    Handler_LevelupInfo,

    # private api
    Handler_Game_Status, 
    Handler_Connector_Status,
    Handler_Update_Ranks,
    Handler_PlayerCreated,
    Handler_UseActiveKey,

    Handler_Login,
    Handler_Index,
)

TEMPLATE_PATH = os.path.join(os.path.dirname(__file__), "../templates")
STATIC_PATH = os.path.join(os.path.dirname(__file__), "../static")

class Application(tornado.web.Application):
    def __init__(self):
        configFile = open("configs/main.json")
        self.mConfigs = json.loads(configFile.read())
        configFile.close()

        handlers = [
            # public api
            (r"/crossdomain.xml", Handler_XmlProlicy),
            (r"/svrlists", Handler_ServerLists),
            (r"/ranks", Handler_Ranks),
            (r"/permission", Handler_CheckPermission),
            (r"/lvlup", Handler_LevelupInfo),

            # test api
            (r"/loginex", Handler_Login),
            (r"/", Handler_Index),

            # private api
            (r"/private/game_status", Handler_Game_Status),
            (r"/private/connector_status", Handler_Connector_Status),
            (r"/private/update_ranks", Handler_Update_Ranks),
            (r"/private/player_created", Handler_PlayerCreated),
            (r"/private/use_activekey", Handler_UseActiveKey),
        ]
        settings = dict(
            template_path = TEMPLATE_PATH,
            static_path = STATIC_PATH,
            debug = self.mConfigs["Debug"]
        )
        tornado.web.Application.__init__(self, handlers, **settings)
        print "Connecting to redis...",
        self.mRedis = redis.Redis(
            self.mConfigs["Redis"]["Hostname"],
            self.mConfigs["Redis"]["Hostport"]
        );
        print "ok"

        print "Connecting to mysql...",
        self.mMySQL = pools.Pool(
            dict(
                host=self.mConfigs["MySQL"]["Hostname"], 
                port=self.mConfigs["MySQL"]["Hostport"], 
                user=self.mConfigs["MySQL"]["Username"], 
                passwd=self.mConfigs["MySQL"]["Password"], 
                db=self.mConfigs["MySQL"]["Database"],
                charset="utf8"),
            max_idle_connections=1,
            max_recycle_sec=3)
        print "ok"

    def checkPermission(self, handler):
        remote_ip = handler.request.remote_ip
        permissionIP = self.mConfigs["PermissionIP"]
        result = True
        if len(permissionIP) > 0:
            if remote_ip not in permissionIP:
                result = False
                for ipAddress in permissionIP:
                    if remote_ip.startswith(ipAddress):
                        result = True
                        break

        if not result:
            raise tornado.web.HTTPError(403, "permission denied")

def main():
    app = Application()
    svr = tornado.httpserver.HTTPServer(app)
    if len(sys.argv) > 1:
        svr.listen(int(sys.argv[1]))
    else:
        svr.listen(int(app.mConfigs["ServicePort"]))
    print "Startup ok"
    tornado.ioloop.IOLoop.instance().start()

if __name__ == "__main__":
    main()