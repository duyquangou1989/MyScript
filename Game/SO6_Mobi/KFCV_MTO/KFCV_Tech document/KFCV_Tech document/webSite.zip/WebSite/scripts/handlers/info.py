#coding=utf8

import tornado.web
import tornado.gen
import tornado.httpserver
import tornado.web
import tornado.ioloop
import tornado.options
import redis
import time
import os
import hashlib
import urllib2
import json

class Handler_LevelupInfo(tornado.web.RequestHandler):
    def get(self):
        r = self.application.mRedis

        level = self.get_argument("l");

        keyName = "lvl:info:%s" % (level)
        data = None #r.get(keyName)
        if data == None:
            filename = "configs/levelup/level_%s.txt" % (level)
            if os.path.exists(filename):
                f = open(filename, "r")
                data = f.read()
                f.close()
            else:
                data = ""

            p = r.pipeline()
            p.set(keyName, data)
            p.expire(keyName, 86400) # 缓存一天，若需要即时更新，手动清楚对应redis数据即可
            p.execute()

        self.write(data)
        self.flush()
        self.finish()
