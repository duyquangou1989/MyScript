#coding=utf8

from .index import (
    Handler_XmlProlicy,
    Handler_Index,
)
from .auth import (
    Handler_Login,
    Handler_CheckPermission,
    Handler_PlayerCreated,
)
from .server import (
    Handler_Game_Status,
    Handler_Connector_Status,
    Handler_ServerLists,
)
from .ranks import (
    Handler_Ranks,
    Handler_Update_Ranks)
from .info import (
    Handler_LevelupInfo,
)
from .activekey import (
    Handler_UseActiveKey,
)