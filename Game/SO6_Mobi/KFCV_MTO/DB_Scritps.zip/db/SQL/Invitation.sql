CREATE TABLE IF NOT EXISTS `Invitation` (
    `Account` varchar(64) DEFAULT "",
    `InvitationCode` varchar(64) DEFAULT "",
    PRIMARY KEY (`Account`),
    KEY (`InvitationCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `InvitationShip` (
    `InvitationCode` varchar(64) DEFAULT "",
    `ToInvitationCode` varchar(64) DEFAULT "",
    `Extra` int(11) DEFAULT 0,
    PRIMARY KEY (`InvitationCode`, `ToInvitationCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DELIMITER $$

DROP PROCEDURE IF EXISTS `createInvitationCode` $$
CREATE DEFINER=`root`@`%` PROCEDURE `createInvitationCode` (
    _account varchar(64),
    _code varchar(64)
)
BEGIN
    insert into `Invitation` (`Account`, `InvitationCode`) values (_account, _code) on duplicate key update  `InvitationCode` = _code;
END $$

DROP PROCEDURE IF EXISTS `commitInvitation` $$
CREATE DEFINER=`root`@`%` PROCEDURE `commitInvitation` (
    _myInvitationCode varchar(64),
    _upInvitationCode varchar(64)
)
BEGIN
    insert into `InvitationShip` (`InvitationCode`, `ToInvitationCode`,`Extra`) values (_upInvitationCode, _myInvitationCode, 0);
END $$

DROP PROCEDURE IF EXISTS `countInvitation` $$
CREATE DEFINER=`root`@`%` PROCEDURE `countInvitation` (
    _account varchar(64)
)
BEGIN
    declare _count int;
    declare _extra int;
    declare _code varchar(64);
    set _count = 0;
    set _extra = 0;
    set _code = "";
    select `InvitationCode` into _code from `Invitation` where `Account` = _account limit 1;
    if _code = "" then
        select _account, 0, 0;
    else
        select count(1) into _count from `InvitationShip` where `InvitationCode` = _code;
        select count(1) into _extra from `InvitationShip` where `InvitationCode` = _code and `Extra` = 0;
        update `InvitationShip` set `Extra` = 1 where `InvitationCode` = _code;
        select _account, _count, _extra;
    end if;
END $$

DROP PROCEDURE IF EXISTS `checkInvitation` $$
CREATE DEFINER=`root`@`%` PROCEDURE `checkInvitation` (
    _code varchar(64)
)
BEGIN
    declare _account varchar(64);
    set _account = "";
    select `Account` into _account from `Invitation` where `InvitationCode` = _code;
    if _account = "" then
        select _account, _code, 0;
    else
        select _account, _code, 1;
    end if;
END $$

DELIMITER ;