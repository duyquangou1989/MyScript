CREATE TABLE IF NOT EXISTS `Player` (
  `UUID` varchar(64) NOT NULL,
  `ServerID` int(11) DEFAULT -1,
  `OldServerID` int(11) DEFAULT -1,
  `Account` varchar(64) DEFAULT "",
  `Name` varchar(64) DEFAULT "",
  `GuildName` varchar(64) DEFAULT "",
  `Channel` int(11) DEFAULT 0,
  `Icon` int(11) DEFAULT 0,
  `Vitality` int(11) DEFAULT 0,
  `Vigor` int(11) DEFAULT 0,
  `Experience` int(11) DEFAULT 0,
  `Level` int(11) DEFAULT 0,
  `VipLevel` int(11) DEFAULT 0,
  `BagSize` int(11) DEFAULT 0,
  `Money` int(11) DEFAULT 0,
  `GoldMoney` int(11) DEFAULT 0,
  `GoldMoneyPurchased` int(11) DEFAULT 0,
  `Energy` int(11) DEFAULT 0,
  `Spar` int(11) DEFAULT 0,
  `CreateTime` int(11) DEFAULT 0,
  `LoginTime` int(11) DEFAULT 0,
  `LogoutTime` int(11) DEFAULT 0,
  `PlayedTime` int(11) DEFAULT 0,  
  `SceneID` int(11) DEFAULT 0,
  `BattleID` int(11) DEFAULT 0,
  `ArenaPoint` int(11) DEFAULT 0,
  `BossPoint` int(11) DEFAULT 0,
  `ForbiddenLogin` int(11) DEFAULT 0,
  `ForbiddenChat` int(11) DEFAULT 0,
  `RandomCount` varchar(64) DEFAULT "",
  `RandomCD` varchar(64) DEFAULT "", 
  `PythonData` blob,
  PRIMARY KEY (`UUID`),
  KEY `ServerID` (`ServerID`),
  KEY `Account` (`Account`),
  KEY `Name` (`Name`),
  KEY `Level` (`Level`),
  KEY `VipLevel` (`VipLevel`),
  KEY `CreateTime` (`CreateTime`),
  KEY `LoginTime` (`LoginTime`),
  KEY `LogoutTime` (`LogoutTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Role` (
  `UUID` varchar(64) NOT NULL,
  `PlayerUUID` varchar(64) NOT NULL,
  `RoleID` int(11) DEFAULT 0,
  `RoleJob` int(11) DEFAULT 0,
  `Level` int(11) DEFAULT 0,
  `Life` int(11) DEFAULT 0,
  `Attack` int(11) DEFAULT 0,
  `Defence` int(11) DEFAULT 0,
  `Critical` int(11) DEFAULT 0,
  `AntiCritical` int(11) DEFAULT 0,
  `Hit` int(11) DEFAULT 0,
  `Dodge` int(11) DEFAULT 0,
  `LifeExp` int(11) DEFAULT 0,
  `AttackExp` int(11) DEFAULT 0,
  `DefenceExp` int(11) DEFAULT 0,
  `CriticalExp` int(11) DEFAULT 0,
  `AntiCriticalExp` int(11) DEFAULT 0,
  `HitExp` int(11) DEFAULT 0,
  `DodgeExp` int(11) DEFAULT 0,
  `Skill` varchar(512) DEFAULT "",
  `Talent` varchar(512) DEFAULT "",
  `CasketInfo` varchar(512) DEFAULT "",
  `PythonData` blob,
  PRIMARY KEY (`UUID`),
  KEY `PlayerUUID` (`PlayerUUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Pet` (
  `UUID` varchar(64) NOT NULL,
  `PlayerUUID` varchar(64) NOT NULL,
  `PetID` int(11) DEFAULT 0,
  `Stage` int(11) DEFAULT 0,
  `Status` int(11) DEFAULT 0,
  `Talents` varchar(1024) DEFAULT "",
  `PythonData` blob,
  PRIMARY KEY (`UUID`),
  KEY `PlayerUUID` (`PlayerUUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `Item` (
  `UUID` varchar(64) NOT NULL,
  `RoleUUID` varchar(64) DEFAULT "",
  `PlayerUUID` varchar(64) NOT NULL,
  `ItemType` int(11) DEFAULT -1,
  `ItemID` int(11) DEFAULT -1,
  `ItemNum` int(11) DEFAULT 0,
  `ItemAvailableTime` int(11) DEFAULT 0,
  `ItemStatus` int(11) DEFAULT 0,
  `ItemPosition` int(11) DEFAULT 0,
  `ItemQuality` int(11) DEFAULT 0,
  `ItemSpar` int(11) DEFAULT 0,
  `ItemSuitID` int(11) DEFAULT 0,
  `ItemSpecID` int(11) DEFAULT 0,
  `ItemAttr` varchar(256) DEFAULT 0,  
  `PythonData` blob,
  PRIMARY KEY (`UUID`),
  KEY `PlayerUUID` (`PlayerUUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `BuyNum` (
  `UUID` varchar(64) NOT NULL,
  `BuyType` int(11) DEFAULT 0,
  `Value` int(11) DEFAULT 0,
  PRIMARY KEY (`UUID`, `BuyType`),
  KEY `BuyType` (`BuyType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ArenaInfo` (
  `ServerID` int(11) NOT NULL,
  `Rank` int(11) NOT NULL,
  `UUID` varchar(64) NOT NULL,
  `Account` varchar(64) NOT NULL,
  `Name` varchar(64) NOT NULL,
  `Robot` int(11) DEFAULT 1,
  `Level` int(11) DEFAULT 0,
  `Icon` int(11) DEFAULT 0,
  `BattlePoint` int(11) DEFAULT 0,
  `Vip` int(11) DEFAULT 0,
  PRIMARY KEY (`ServerID`, `Rank`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Friend` (
  `ServerID` int (11) NOT NULL,
  `PlayerUUID` varchar(64) NOT NULL,
  `PlayerName` varchar(64) NOT NULL,
  `FriendUUID` varchar(64) NOT NULL,
  `FriendName` varchar(64) NOT NULL,
  PRIMARY KEY (`ServerID`, `PlayerName`, `FriendName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DELIMITER $$

DROP PROCEDURE IF EXISTS `loadAccAndName` $$
CREATE DEFINER=`root`@`%` PROCEDURE `loadAccAndName`(_serverID int)
BEGIN
    select `UUID`, `Account`, `Name`, `OldServerID` from `Player` where `ServerID` = _serverID;
END $$

DROP PROCEDURE IF EXISTS `loadPlayer` $$
CREATE DEFINER=`root`@`%` PROCEDURE `loadPlayer`(_serverID int, _name varchar(64))
BEGIN
    declare _playerUUID varchar(64);
    set _playerUUID = "";
    select `UUID` into _playerUUID from `Player` where `ServerID` = _serverID and `Name` = _name limit 1;
    if _playerUUID != "" then
        select 1;
        select * from `Player` where `UUID` = _playerUUID;
        select * from `Role` where `PlayerUUID` = _playerUUID order by `RoleID`;
        select * from `Pet` where `PlayerUUID` = _playerUUID order by `UUID`;
        select * from `Item` where `PlayerUUID` = _playerUUID order by `UUID`;
        select * from `BuyNum` where `UUID` = _playerUUID;
    else
        select 0;
    end if;
    
END $$

DROP PROCEDURE IF EXISTS `saveBuyNum` $$
CREATE DEFINER=`root`@`%` PROCEDURE `saveBuyNum`(
    _uuid varchar(64),
    _buyType int(11),
    _value int(11))
BEGIN
    insert into `BuyNum` (
        `UUID`,
        `BuyType`,
        `Value`) 
        values (
            _uuid,
            _buyType,
            _value)
            on duplicate key update 
                `Value` = _value;
END $$

DROP PROCEDURE IF EXISTS `savePlayerData` $$
CREATE DEFINER=`root`@`%` PROCEDURE `savePlayerData`(
    _uuid varchar(64),
    _serverID int(11),
    _oldServerID int(11),
    _account varchar(64),
    _name varchar(64),
    _guildName varchar(64),
    _channel int(11),
    _icon int(11),
    _vitality int(11),
    _vigor int(11),
    _experience int(11),
    _level int(11),
    _vipLevel int(11),
    _bagSize int(11),
    _money int(11),
    _goldMoney int(11),
    _goldMoneyPurchased int(11),
    _energy int(11),
    _spar int(11),
    _createTime int(11),
    _loginTime int(11),
    _logoutTime int(11),
    _playedTime int(11),
    _sceneID int(11),
    _battleID int(11),
    _arenaPoint int(11),
    _bossPoint int(11),
    _forbiddenLogin int(11),
    _forbiddenChat int(11),
    _randomCount varchar(64),
    _randomCD varchar(64),
    _pythonData blob)
BEGIN
    insert into `Player` (
        `UUID`, 
        `ServerID`, 
        `OldServerID`,
        `Account`, 
        `Name`, 
        `GuildName`, 
        `Channel`,
        `Icon`, 
        `Vitality`, 
        `Vigor`,
        `Experience`, 
        `Level`, 
        `VipLevel`, 
        `BagSize`,
        `Money`, 
        `GoldMoney`, 
        `GoldMoneyPurchased`,
        `Energy`,
        `Spar`,
        `CreateTime`, 
        `LoginTime`, 
        `LogoutTime`, 
        `PlayedTime`,
        `SceneID`, 
        `BattleID`,
        `ArenaPoint`,
        `BossPoint`,
        `ForbiddenLogin`,
        `ForbiddenChat`,
        `RandomCount`,
        `RandomCD`,
        `PythonData`)
        values (
            _uuid,
            _serverID,
            _oldServerID,
            _account,
            _name,
            _guildName,
            _channel,
            _icon,
            _vitality,
            _vigor,
            _experience,
            _level,
            _vipLevel,
            _bagSize,
            _money,
            _goldMoney,
            _goldMoneyPurchased,
            _energy,
            _spar,
            _createTime,
            _loginTime,
            _logoutTime,
            _playedTime,
            _sceneID,
            _battleID,
            _arenaPoint,
            _bossPoint,
            _forbiddenLogin,
            _forbiddenChat,
            _randomCount,
            _randomCD,
            _pythonData)
            on duplicate key update 
                `GuildName` = _guildName, 
                `Vitality` = _vitality, 
                `Experience` = _experience, 
                `Level` = _level, 
                `VipLevel` = _vipLevel, 
                `Vigor` = _vigor,
                `BagSize` = _bagSize, 
                `Money` = _money, 
                `GoldMoney` = _goldMoney, 
                `GoldMoneyPurchased` = _goldMoneyPurchased, 
                `Energy` = _energy,
                `Spar` = _spar,
                `CreateTime` = _createTime, 
                `LoginTime` = _loginTime, 
                `LogoutTime` = _logoutTime, 
                `PlayedTime` = _playedTime,
                `SceneID` = _sceneID,    
                `BattleID` = _battleID,
                `ArenaPoint` = _arenaPoint,
                `BossPoint` = _bossPoint,
                `ForbiddenLogin` = _forbiddenLogin,
                `ForbiddenChat` = _forbiddenChat,
                `RandomCount` = _randomCount,
                `RandomCD` = _randomCD,
                `PythonData` = _pythonData;
END $$

DROP PROCEDURE IF EXISTS `saveRoleData` $$
CREATE DEFINER=`root`@`%` PROCEDURE `saveRoleData`(
    _uuid varchar(64),
    _playerUUID varchar(64),
    _roleID int(11),
    _roleJob int(11),
    _level int(11),
    _life int(11),
    _attack int(11),
    _defence int(11),
    _critical int(11),
    _anticritical int(11),
    _hit int(11),
    _dodge int(11),
    _lifeExp int(11),
    _attackExp int(11),
    _defenceExp int(11),
    _criticalExp int(11),
    _anticriticalExp int(11),
    _hitExp int(11),
    _dodgeExp int(11),
    _skill varchar(512),
    _talent varchar(512),
    _casketInfo varchar(512),
    _pythonData blob)
BEGIN
    insert into `Role` (
        `UUID`,
        `PlayerUUID`,
        `RoleID`,
        `RoleJob`,
        `Level`,
        `Life`,
        `Attack`,
        `Defence`,
        `Critical`,
        `AntiCritical`,
        `Hit`,
        `Dodge`,
        `LifeExp`,
        `AttackExp`,
        `DefenceExp`,
        `CriticalExp`,
        `AntiCriticalExp`,
        `HitExp`,
        `DodgeExp`,
        `Skill`,
        `Talent`,
        `CasketInfo`,
        `PythonData`)
        values (
            _uuid,
            _playerUUID,
            _roleID,
            _roleJob,
            _level,
            _life,
            _attack,
            _defence,
            _critical,
            _anticritical,
            _hit,
            _dodge,
            _lifeExp,
            _attackExp,
            _defenceExp,
            _criticalExp,
            _anticriticalExp,
            _hitExp,
            _dodgeExp,			
            _skill,
            _talent,
            _casketInfo,
            _pythonData)
            on duplicate key update
                `RoleID` = _roleID,
                `RoleJob` = _roleJob,
                `Level` = _level,
                `Life` = _life,
                `Attack` = _attack,
                `Defence` = _defence,
                `Critical` = _critical,
                `AntiCritical` = _anticritical,
                `Hit` = _hit,
                `Dodge` = _dodge,
                `LifeExp` = _lifeExp,
                `AttackExp` = _attackExp,
                `DefenceExp` = _defenceExp,
                `CriticalExp` = _criticalExp,
                `AntiCriticalExp` = _anticriticalExp,
                `HitExp` = _hitExp,
                `DodgeExp` = _dodgeExp,				
                `Skill` = _skill,
                `Talent` = _talent,
                `CasketInfo` = _casketInfo,
                `PythonData` = _pythonData;
END $$

CREATE TABLE IF NOT EXISTS `Pet` (
  `UUID` varchar(64) NOT NULL,
  `PlayerUUID` varchar(64) NOT NULL,
  `PetID` int(11) DEFAULT 0,
  `Stage` int(11) DEFAULT 0,
  `Status` int(11) DEFAULT 0,
  `PythonData` blob,
  PRIMARY KEY (`UUID`),
  KEY `PlayerUUID` (`PlayerUUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP PROCEDURE IF EXISTS `savePetData` $$
CREATE DEFINER=`root`@`%` PROCEDURE `savePetData`(
    _uuid varchar(64),
    _playerUUID varchar(64),
    _petID int(11),
    _stage int(11),
    _status int(11),
    _talents varchar(1024),
    _pythonData blob)
BEGIN
    insert into `Pet` (
        `UUID`,
        `PlayerUUID`,
        `PetID`,
        `Stage`,
        `Status`,
        `Talents`,
        `PythonData`)
        values (
            _uuid,
            _playerUUID,
            _petID,
            _stage,
            _status,
            _talents,
            _pythonData)
            on duplicate key update
                `PetID` = _petID,
                `Stage` = _stage,
                `Status` = _status, 
                `Talents` = _talents,
                `PythonData` = _pythonData;
END $$

DROP PROCEDURE IF EXISTS `saveItemData` $$
CREATE DEFINER=`root`@`%` PROCEDURE `saveItemData`(
    _uuid varchar(64),
    _roleUUID varchar(64),
    _playerUUID varchar(64),
    _itemType int(11),
    _itemID int(11),
    _itemNum int(11),
    _itemAvailableTime int(11),
    _itemStatus int(11),
    _itemPosition int(11),
    _itemQuality int(11),
    _itemSpar int(11),
    _itemSuitID int(11),
    _itemSpecID int(11),
    _itemAttr varchar(256),
    _pythonData blob)
BEGIN
    insert into `Item` (
        `UUID`,
        `RoleUUID`,
        `PlayerUUID`,
        `ItemType`,
        `ItemID`,
        `ItemNum`,
        `ItemAvailableTime`,
        `ItemStatus`,
        `ItemPosition`,
        `ItemQuality`,
        `ItemSpar`,
        `ItemSuitID`,
        `ItemSpecID`,
        `ItemAttr`,
        `PythonData`)
        values (
            _uuid,
            _roleUUID,
            _playerUUID,
            _itemType,
            _itemID,
            _itemNum,
            _itemAvailableTime,
            _itemStatus,
            _itemPosition,
            _itemQuality,
            _itemSpar,
            _itemSuitID,
            _itemSpecID,
            _itemAttr,
            _pythonData)
            on duplicate key update
                `RoleUUID` = _roleUUID,
                `ItemType` = _itemType,
                `ItemID` = _itemID,
                `ItemNum` = _itemNum,
                `ItemAvailableTime` = _itemAvailableTime,
                `ItemStatus` = _itemStatus,
                `ItemPosition` = _itemPosition,
                `ItemQuality` = _itemQuality,
                `ItemSpar` = _itemSpar,
                `ItemSuitID` = _itemSuitID,
                `ItemSpecID` = _itemSpecID,
                `ItemAttr` = _itemAttr,
                `PythonData` = _pythonData;
END $$


DROP PROCEDURE IF EXISTS `loadAllArenaData` $$
CREATE DEFINER=`root`@`%` PROCEDURE `loadAllArenaData`(_serverID int(11))
BEGIN
    select * from `ArenaInfo` where `ServerID` = _serverID;
END $$

DROP PROCEDURE IF EXISTS `saveArenaInfoData` $$
CREATE DEFINER=`root`@`%` PROCEDURE `saveArenaInfoData`(
    _serverID int(11),
    _rank int(11),
    _uuid varchar(64),
    _account varchar(64),
    _name varchar(64),
    _robot int(11),
    _level int(11),
    _icon int(11),
    _battlePoint int(11),
    _vip int(11))
BEGIN
    insert into `ArenaInfo` (
        `ServerID`,
        `Rank`,
        `UUID`,
        `Account`,
        `Name`,
        `Robot`,
        `Level`,
        `Icon`,
        `BattlePoint`,
        `Vip`)
        values (
            _serverID,
            _rank,
            _uuid,
            _account,
            _name,
            _robot,
            _level,
            _icon,
            _battlePoint,
            _vip)
            on duplicate key update
                `UUID` = _uuid,
                `Account` = _account,
                `Name` = _name,
                `Robot` = _robot,
                `Level` = _level,
                `Icon` = _icon,
                `BattlePoint` = _battlePoint,
                `Vip` = _vip;

END $$

DROP PROCEDURE IF EXISTS `loadAllFriends` $$
CREATE DEFINER=`root`@`%` PROCEDURE `loadAllFriends`(
    _serverID int(11))
BEGIN
    select `PlayerUUID`, `PlayerName`, `FriendUUID`, `FriendName` from `Friend` where `ServerID` = _serverID;
    select `UUID`, `Account`, `Name`, `GuildName`, `Icon`, `Level`, `VipLevel` from `Player` where `ServerID` = _serverID;
END $$

DROP PROCEDURE IF EXISTS `addFriend` $$
CREATE DEFINER=`root`@`%` PROCEDURE `addFriend`(
    _serverID int(11),
    _playerUUID varchar(64),
    _playerName varchar(64),
    _friendUUID varchar(64),
    _friendName varchar(64))
BEGIN
    insert into `Friend` (`ServerID`, `PlayerUUID`, `PlayerName`, `FriendUUID`, `FriendName`) values (_serverID, _playerUUID, _playerName, _friendUUID, _friendName);
END $$

DROP PROCEDURE IF EXISTS `removeFriend` $$
CREATE DEFINER=`root`@`%` PROCEDURE `removeFriend`(
    _serverID int(11),
    _playerName varchar(64),
    _friendName varchar(64))
BEGIN
    delete from `Friend` where `ServerID` = _serverID and `PlayerName` = _playerName and `FriendName` = _friendName;
END $$

DELIMITER ;