CREATE TABLE IF NOT EXISTS `Mails` (
    `UUID` int(11) NOT NULL AUTO_INCREMENT,
	`ServerID` int(11) DEFAULT -1,
	`ReadFlag` int(11) DEFAULT 1,
	`Time` int(11) DEFAULT 0,
    `ValidTime` int(11) DEFAULT 0,
    `SenderUUID` varchar(64),
    `SenderName` varchar(64),
	`RecverUUID` varchar(64) NOT NULL,
    `RecverName` varchar(64) NOT NULL,
    `MailHead` varchar(64) DEFAULT "",
	`MailBody` varchar(1024) DEFAULT "",
	`Resources` varchar(512) DEFAULT "",
    `Items` varchar(512) DEFAULT "",
    PRIMARY KEY (`UUID`, `RecverUUID`),
    KEY `ServerID` (`ServerID`),
	KEY `ReadFlag` (`ReadFlag`),
	KEY	`RecverUUID` (`RecverUUID`),
	KEY `Time` (`Time`),
	KEY	`ValidTime` (`ValidTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Mails_DEL` (
    `UUID` int(11) NOT NULL,
	`ServerID` int(11) DEFAULT -1,
	`ReadFlag` int(11) DEFAULT 1,
	`Time` int(11) DEFAULT 0,
    `ValidTime` int(11) DEFAULT 0,
    `SenderUUID` varchar(64),
    `SenderName` varchar(64),
	`RecverUUID` varchar(64) NOT NULL,
    `RecverName` varchar(64) NOT NULL,
    `MailHead` varchar(64) DEFAULT "",
	`MailBody` varchar(1024) DEFAULT "",
	`Resources` varchar(512) DEFAULT "",
    `Items` varchar(512) DEFAULT "",
    PRIMARY KEY (`UUID`, `RecverUUID`),
    KEY `ServerID` (`ServerID`),
	KEY `ReadFlag` (`ReadFlag`),
	KEY	`RecverUUID` (`RecverUUID`),
	KEY `Time` (`Time`),
	KEY	`ValidTime` (`ValidTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DELIMITER $$

DROP PROCEDURE IF EXISTS `saveMail` $$
CREATE DEFINER=`root`@`%` PROCEDURE `saveMail`(
	_ServerID int,
	_Time int,
	_ValidTime int,
	_SenderUUID varchar(64),
	_SenderName varchar(64),
	_RecverUUID varchar(64),
	_RecverName varchar(64),
	_MailHead varchar(64),
	_MailBody varchar(512),
	_Resources varchar(512),
	_Items varchar(512))
BEGIN

	select UUID into _RecverUUID from `Player` where `Name` = _RecverName and `ServerID` = _ServerID limit 1;
	insert into `Mails` (`ServerID`, `ReadFlag`, `Time`, `ValidTime`, `SenderUUID`, `SenderName`,
						`RecverUUID`, `RecverName`, `MailHead`, `MailBody`, `Resources`, `Items`)
		values (_serverID, 1, _Time, _ValidTime, _SenderUUID, _SenderName,
				_RecverUUID, _RecverName, _MailHead, _MailBody, _Resources, _Items);

END $$

DROP PROCEDURE IF EXISTS `saveMailAll` $$
CREATE DEFINER=`root`@`%` PROCEDURE `saveMailAll`(
	_ServerID int,
	_Time int,
	_ValidTime int,
	_MailHead varchar(64),
	_MailBody varchar(512),
	_Resources varchar(512),
	_Items varchar(512))
BEGIN
	DECLARE _SenderUUID varchar(64);
	DECLARE _SenderName varchar(64);
	DECLARE _RecverUUID varchar(64);
	DECLARE _RecverName varchar(64);
	DECLARE done int;
	DECLARE p_cursor CURSOR FOR SELECT `UUID`, `Name` FROM `Player`;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
	open p_cursor;
	cursor_loop:loop
		FETCH p_cursor into _RecverUUID, _RecverName;
		
		if done = 1 then
			leave cursor_loop;
		end if;
		insert into `Mails` (`ServerID`, `ReadFlag`, `Time`, `ValidTime`, `SenderUUID`, `SenderName`,
							`RecverUUID`, `RecverName`, `MailHead`, `MailBody`, `Resources`, `Items`)
			values (_serverID, 1, _Time, _ValidTime, _SenderUUID, _SenderName,
					_RecverUUID, _RecverName, _MailHead, _MailBody, _Resources, _Items);
	end loop cursor_loop;
	close p_cursor;
	
END $$

DROP PROCEDURE IF EXISTS `readMail` $$
CREATE DEFINER=`root`@`%` PROCEDURE `readMail`(
	_UUID int,
	_RecverUUID varchar(64))
BEGIN
	update `Mails` set	`ReadFlag` 	= 0
					where 
					`UUID` = _UUID and
					`RecverUUID` = _RecverUUID;
END $$

DROP PROCEDURE IF EXISTS `checkMail` $$
CREATE DEFINER=`root`@`%` PROCEDURE `checkMail`(
	_RecverUUID varchar(64))
BEGIN
	declare unReadCount int;
	set unReadCount = 0;
	select count(*) into unReadCount from `Mails`
		where `RecverUUID` = _RecverUUID and `ValidTime` >= unix_timestamp() and `Time` <= unix_timestamp() and `ReadFlag` = 1;	
	select unReadCount, _RecverUUID;
END $$

DROP PROCEDURE IF EXISTS `loadMail` $$
CREATE DEFINER=`root`@`%` PROCEDURE `loadMail`(
	_RecverUUID varchar(64))
BEGIN
	select * from `Mails` where `RecverUUID` = _RecverUUID and `ValidTime` >= unix_timestamp() and `Time` <= unix_timestamp() order by `ReadFlag`,`Time` desc limit 30;
END $$

DROP PROCEDURE IF EXISTS `deleteMail` $$
CREATE DEFINER=`root`@`%` PROCEDURE `deleteMail`(
	_UUID int,
	_RecverUUID varchar(64))
BEGIN
	insert ignore into `Mails_DEL` select * from `Mails` where `UUID` = _UUID and `RecverUUID` = _RecverUUID; 
    delete from `Mails` where `UUID` = _UUID and `RecverUUID` = _RecverUUID;
END $$

DROP PROCEDURE IF EXISTS `clearMail` $$
CREATE DEFINER=`root`@`%` PROCEDURE `clearMail`(_ServerID int)
BEGIN
	insert ignore into `Mails_DEL` select * from `Mails` where `ValidTime` <= unix_timestamp();
    delete from `Mails` where `ValidTime` <= unix_timestamp();
END $$

DELIMITER ;