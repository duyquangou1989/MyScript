CREATE TABLE IF NOT EXISTS `RankSystem` (
  `RankType` INT NOT NULL ,
  `ServerID` INT NOT NULL ,
  `Name` VARCHAR(64) NOT NULL ,
  `Value` INT NULL ,
  `LastRank` INT NULL ,
  `Week` VARCHAR(64) NOT NULL ,
  PRIMARY KEY (`RankType`, `ServerID`, `Name`, `Week`)
);

DELIMITER $$

DROP PROCEDURE IF EXISTS `saveRankData` $$
CREATE DEFINER=`root`@`%` PROCEDURE `saveRankData`(
    _rankType int,
    _serverID int, 
    _name varchar(64), 
    _value int, 
    _lastRank int,
    _week varchar(64),
    _isUpdate int)
BEGIN
    if _isUpdate = 1 then
        insert into `RankSystem` (`RankType`, `ServerID`, `Name`, `Value`, `LastRank`, `Week`)
            values (_rankType, _serverID, _name, _value, _lastRank, _week)
                on duplicate key update `Value`=`Value`+_value, `LastRank`=_lastRank;
    else
        insert into `RankSystem` (`RankType`, `ServerID`, `Name`, `Value`, `LastRank`, `Week`)
            values (_rankType, _serverID, _name, _value, _lastRank, _week)
                on duplicate key update `Value`=_value, `LastRank`=_lastRank;
    end if;

    select `Value` from `RankSystem` 
        where 
            `ServerID` = _serverID and 
            `RankType` = _rankType and
            `Name` = _name and
            `Week` = _week;
END $$

DROP PROCEDURE IF EXISTS `loadRankData` $$
CREATE DEFINER=`root`@`%` PROCEDURE `loadRankData`(
    _rankType int,
    _serverID int, 
    _name varchar(64), 
    _week varchar(64))
BEGIN
    select * from `RankSystem` 
        where 
            `ServerID` = _serverID and 
            `RankType` = _rankType and
            `Name` = _name and
            `Week` = _week;
END $$

DELIMITER ;