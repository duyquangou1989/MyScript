CREATE TABLE IF NOT EXISTS `ProxyOrders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ServerID` varchar(64) DEFAULT "",
  `UserID` varchar(64) DEFAULT "",
  `PID` varchar(64) DEFAULT "",
  `Gold` varchar(64) DEFAULT "",
  `Timestamp` varchar(64) DEFAULT "",
  `OrderID` varchar(128) DEFAULT "",
  `Finished` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DELIMITER $$

DROP PROCEDURE IF EXISTS `addNewPayRequest` $$
CREATE DEFINER=`root`@`%` PROCEDURE `addNewPayRequest`(
  _serverID varchar(64), 
  _userID varchar(64),
  _pid varchar(64),
  _gold varchar(64),
  _timestamp varchar(64),
  _orderID varchar(128))
BEGIN
    declare POrderID varchar(128);
    set POrderID = "-1";
    select `OrderID` into POrderID from `ProxyOrders` where `OrderID` = _orderID;
    if POrderID = "-1" and POrderID != _orderID then
        insert into `ProxyOrders` 
          (`ServerID`, `UserID`, `PID`, `Gold`, `Timestamp`, `OrderID`, `Finished`)
          values
          (_serverID, _userID, _pid, _gold, _timestamp, _orderID, 0);
        select 1;
    else
        select 0;
    end if;
END $$

DROP PROCEDURE IF EXISTS `finishNewPayRequest` $$
CREATE DEFINER=`root`@`%` PROCEDURE `finishNewPayRequest`(_orderID varchar(128))
BEGIN
    update `ProxyOrders` set `Finished` = 1 where `OrderID` = _orderID;
END $$

DELIMITER ;