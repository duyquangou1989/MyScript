CREATE TABLE IF NOT EXISTS `Settings` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `ServerAccountID` int(11) DEFAULT -1,
  `Name` varchar(256) DEFAULT "",
  `Data` blob,
  `UpdateTime` int(11),
  PRIMARY KEY (`id`),
  KEY `Name` (`Name`),
  KEY `ServerAccountID` (`ServerAccountID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
