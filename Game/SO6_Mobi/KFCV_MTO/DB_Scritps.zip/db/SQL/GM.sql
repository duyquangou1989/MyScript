CREATE TABLE IF NOT EXISTS `GMRecord` (
    `SerialID` varchar(64) DEFAULT "",
    `OperatorID` int(11) DEFAULT -1,
    `Action` int(11) DEFAULT 0,
    `RequestData` varchar(1024) DEFAULT "",
    `Time` int(11) DEFAULT 0,
    `Result` int(11) DEFAULT -1,
    `Finished` int(11) DEFAULT 0,
    PRIMARY KEY (`SerialID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DELIMITER $$

DROP PROCEDURE IF EXISTS `saveRequest` $$
CREATE DEFINER=`root`@`%` PROCEDURE `saveRequest`(
    _serialID varchar(64),
    _operatorID int(11),
    _action int(11),
    _requestData varchar(1024)
)
BEGIN
    insert into `GMRecord` 
        (`SerialID`, `OperatorID`, `Action`, `RequestData`, `Time`, `Result`) values
            (_serialID, _operatorID, _action, _requestData, unix_timestamp(), -1);
    select _serialID;
END $$

DROP PROCEDURE IF EXISTS `finishRequest` $$
CREATE DEFINER=`root`@`%` PROCEDURE `finishRequest`(
    _serialID varchar(64),
    _result int(11)
)
BEGIN
    update `GMRecord` set 
        `Result` = _result,
        `Finished` = 1 
            where `SerialID` = _serialID;
END $$

DELIMITER ;
