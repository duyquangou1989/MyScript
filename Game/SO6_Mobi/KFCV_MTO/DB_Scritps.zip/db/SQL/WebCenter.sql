CREATE TABLE IF NOT EXISTS `Create` (
  `Account` varchar(64) NOT NULL,
  `UDID` varchar(64) DEFAULT NULL,
  `ServerID` int(11) DEFAULT 0,
  `Channel` int(11) DEFAULT 0,
  `CreateTime` int(11) DEFAULT 0,
  PRIMARY KEY (`Account`),
  KEY `Channel` (`Channel`),
  KEY `ServerID` (`ServerID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `Active` (
  `Account` varchar(64) NOT NULL,
  `UDID` varchar(64) DEFAULT NULL,
  `ServerID` int(11) DEFAULT 0,
  `Channel` int(11) DEFAULT 0,
  `CreateTime` int(11) DEFAULT 0,
  `LoginTime` int(11) DEFAULT 0,
  `Level` int(11) DEFAULT 0,
  `VipLevel` int(11) DEFAULT 0,
  PRIMARY KEY (`Account`),
  KEY `Channel` (`Channel`),
  KEY `ServerID` (`ServerID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Retention` (
  `Day` varchar(64) NOT NULL,
  `Create` int(11) DEFAULT 0,
  `Retention_1` int(11) DEFAULT 0,
  `Retention_2` int(11) DEFAULT 0,
  `Retention_3` int(11) DEFAULT 0,
  `Retention_4` int(11) DEFAULT 0,
  `Retention_5` int(11) DEFAULT 0,
  `Retention_6` int(11) DEFAULT 0,
  `Retention_7` int(11) DEFAULT 0,  
  PRIMARY KEY (`Day`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `RetentionByChannel` (
  `Day` varchar(64) NOT NULL,
  `Channel` int(11) DEFAULT 0,
  `Create` int(11) DEFAULT 0,
  `Retention_1` int(11) DEFAULT 0,
  `Retention_2` int(11) DEFAULT 0,
  `Retention_3` int(11) DEFAULT 0,
  `Retention_4` int(11) DEFAULT 0,
  `Retention_5` int(11) DEFAULT 0,
  `Retention_6` int(11) DEFAULT 0,
  `Retention_7` int(11) DEFAULT 0,  
  PRIMARY KEY (`Day`, `Channel`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Channel` (
  `Channel` int(11) DEFAULT 0,
  PRIMARY KEY (`Channel`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DELIMITER $$

DROP PROCEDURE IF EXISTS `insertCreate` $$
CREATE DEFINER=`root`@`%` PROCEDURE `insertCreate`(
    _account varchar(64),
    _udid varchar(64),
    _serverid int,
    _channel int,
    _createtime int
)
BEGIN
    declare tableName varchar(64);
    declare sqlString varchar(1024);
    declare sqlChannel varchar(1024);
    declare dateTime varchar(128);
    declare sqlCreateString varchar(1024);
    declare paramAccount varchar(64);
    declare paramUDID varchar(64);
    declare paramServerID int;
    declare paramChannel int;
    declare paramCreateTime int;
    
    set @dateTime = curdate();
    set @tableName = concat('`Create_', year(@dateTime), '_', lpad(month(@dateTime), 2, '0'), '_', lpad(day(@dateTime), 2, '0'), '`');
    set @sqlString = concat('insert ignore into ', @tableName, ' (`Account`,`UDID`,`ServerID`,`Channel`,`CreateTime`) values (?,?,?,?,?)'); 
    set @sqlChannel = concat('insert ignore into `Channel` (`Channel`) values (', _channel, ')');
    set @sqlCreateString = concat('create table if not exists ', @tableName, '(`Account` varchar(64) NOT NULL,`UDID` varchar(64) DEFAULT NULL,`ServerID` int(11) DEFAULT 0,`Channel` int(11) DEFAULT 0,`CreateTime` int(11) DEFAULT 0,PRIMARY KEY (`Account`),KEY `Channel` (`Channel`),KEY `ServerID` (`ServerID`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;');

    set @paramAccount = _account;
    set @paramUDID = _udid;
    set @paramServerID = _serverid;
    set @paramChannel = _channel;
    set @paramCreateTime = _createtime;

    prepare stmt from @sqlCreateString;
    execute stmt;
    deallocate prepare stmt;
    
    prepare stmt from @sqlString;
    execute stmt using @paramAccount, @paramUDID, @paramServerID, @paramChannel, @paramCreateTime;
    deallocate prepare stmt;

    prepare stmt from @sqlChannel;
    execute stmt;
    deallocate prepare stmt;
END $$

DROP PROCEDURE IF EXISTS `insertActive` $$
CREATE DEFINER=`root`@`%` PROCEDURE `insertActive`(
    _account varchar(64),
    _udid varchar(64),
    _serverid int,
    _channel int,
    _createtime int,
    _logintime int,
    _level int,
    _viplevel int
)
BEGIN
    declare tableName varchar(64);
    declare sqlString varchar(1024);
    declare dateTime varchar(128);
    declare sqlCreateString varchar(1024);
    declare paramAccount varchar(64);
    declare paramUDID varchar(64);
    declare paramServerID int;
    declare paramChannel int;
    declare paramCreateTime int;
    declare paramLoginTime int;
    declare paramLevel int;
    declare paramVipLevel int;
    
    set @dateTime = curdate();
    set @tableName = concat('`Active_', year(@dateTime), '_', lpad(month(@dateTime), 2, '0'), '_', lpad(day(@dateTime), 2, '0'), '`');
    set @sqlString = concat('insert into ', @tableName, ' (`Account`,`UDID`,`ServerID`,`Channel`,`CreateTime`, `LoginTime`, `Level`, `VipLevel`) values (?,?,?,?,?,?,?,?) on duplicate key update `Level` = ?, `VipLevel` = ?;'); 
    set @sqlCreateString = concat('create table if not exists ', @tableName, '(`Account` varchar(64) NOT NULL,`UDID` varchar(64) DEFAULT NULL,`ServerID` int(11) DEFAULT 0,`Channel` int(11) DEFAULT 0,`CreateTime` int(11) DEFAULT 0,`LoginTime` int(11) DEFAULT 0,`Level` int(11) DEFAULT 0,`VipLevel` int(11) DEFAULT 0,PRIMARY KEY (`Account`),KEY `Channel` (`Channel`),KEY `ServerID` (`ServerID`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;');

    set @paramAccount = _account;
    set @paramUDID = _udid;
    set @paramServerID = _serverid;
    set @paramChannel = _channel;
    set @paramCreateTime = _createtime;
    set @paramLoginTime = _logintime;
    set @paramLevel = _level;
    set @paramVipLevel = _viplevel;

    prepare stmt from @sqlCreateString;
    execute stmt;
    deallocate prepare stmt;
    
    prepare stmt from @sqlString;
    execute stmt using @paramAccount, @paramUDID, @paramServerID, @paramChannel, @paramCreateTime, @paramLoginTime, @paramLevel, @paramVipLevel, @paramLevel, @paramVipLevel;
    deallocate prepare stmt;
END $$

DROP PROCEDURE IF EXISTS `calRetention` $$
CREATE DEFINER=`root`@`%` PROCEDURE `calRetention`(
)
BEGIN
    declare cvar int;
    declare avar int;
    declare deltavar int;
    declare ctab varchar(64);
    declare atab varchar(64);
    declare cdateTime varchar(64);
    declare cdaystring varchar(64);
    declare adateTime varchar(64);
    declare adaystring varchar(64);
    declare tablename varchar(64);
    declare sqlString varchar(1024);

    declare createnum int;
    declare reten1num int;
    declare reten2num int;
    declare reten3num int;
    declare reten4num int;
    declare reten5num int;
    declare reten6num int;
    declare reten7num int;

    set createnum = 0;
    set reten1num = 0;
    set reten2num = 0;
    set reten3num = 0;
    set reten4num = 0;
    set reten5num = 0;
    set reten6num = 0;
    set reten7num = 0;

    set cvar = 0;
    while cvar < 7 do
        set cdateTime = curdate() - cvar;
        set cdaystring = concat(year(cdateTime), '_', lpad(month(cdateTime), 2, '0'), '_', lpad(day(cdateTime), 2, '0'));
        set ctab = concat('Create_', cdaystring);
        set tablename = "";
        select `TABLE_NAME` into tablename from `INFORMATION_SCHEMA`.`TABLES` where `TABLE_NAME` = ctab;
        if tablename != "" then
            set avar = 0;
            while avar <= cvar do
                if cvar = avar then
                    set @p_createnum = 0;
                    set sqlString = "";
                    set sqlString = concat('select count(1) into @p_createnum from ', ctab);

                    set @p_sql = sqlString;
                    prepare stmt from @p_sql;
                    execute stmt;
                    deallocate prepare stmt;
                    set createnum = @p_createnum;
                else
                    set adateTime = curdate() - avar;
                    set adaystring = concat(year(adateTime), '_', lpad(month(adateTime), 2, '0'), '_', lpad(day(adateTime), 2, '0'));
                    set atab = concat('Active_', adaystring);
                    set tablename = "";
                    select `TABLE_NAME` into tablename from `INFORMATION_SCHEMA`.`TABLES` where `TABLE_NAME` = atab;
                    if tablename != "" then
                        set deltavar = cvar - avar;

                        set sqlString = "";
                        case deltavar
                        when 1 then
                            set sqlString = concat('select count(1) into @p_reten1num from ', ctab, ' where exists (select 1 from ', atab, ' where ', atab, '.Account = ', ctab, '.Account)');
                            select sqlString;
                            set @p_sql = sqlString;
                            prepare stmt from @p_sql;
                            execute stmt;
                            deallocate prepare stmt;
                            set reten1num = @p_reten1num;
                        when 2 then
                            set sqlString = concat('select count(1) into @p_reten2num from ', ctab, ' where exists (select 1 from ', atab, ' where ', atab, '.Account = ', ctab, '.Account)');
                            select sqlString;
                            set @p_sql = sqlString;
                            prepare stmt from @p_sql;
                            execute stmt;
                            deallocate prepare stmt;
                            set reten2num = @p_reten2num;
                        when 3 then
                            set sqlString = concat('select count(1) into @p_reten3num from ', ctab, ' where exists (select 1 from ', atab, ' where ', atab, '.Account = ', ctab, '.Account)');
                            select sqlString;
                            set @p_sql = sqlString;
                            prepare stmt from @p_sql;
                            execute stmt;
                            deallocate prepare stmt;
                            set reten3num = @p_reten3num;
                        when 4 then
                            set sqlString = concat('select count(1) into @p_reten4num from ', ctab, ' where exists (select 1 from ', atab, ' where ', atab, '.Account = ', ctab, '.Account)');
                            select sqlString;
                            set @p_sql = sqlString;
                            prepare stmt from @p_sql;
                            execute stmt;
                            deallocate prepare stmt;
                            set reten4num = @p_reten4num;
                        when 5 then
                            set sqlString = concat('select count(1) into @p_reten5num from ', ctab, ' where exists (select 1 from ', atab, ' where ', atab, '.Account = ', ctab, '.Account)');
                            select sqlString;
                            set @p_sql = sqlString;
                            prepare stmt from @p_sql;
                            execute stmt;
                            deallocate prepare stmt;
                            set reten5num = @p_reten5num;
                        when 6 then
                            set sqlString = concat('select count(1) into @p_reten6num from ', ctab, ' where exists (select 1 from ', atab, ' where ', atab, '.Account = ', ctab, '.Account)');
                            select sqlString;
                            set @p_sql = sqlString;
                            prepare stmt from @p_sql;
                            execute stmt;
                            deallocate prepare stmt;
                            set reten6num = @p_reten6num;
                        when 7 then
                            set sqlString = concat('select count(1) into @p_reten7num from ', ctab, ' where exists (select 1 from ', atab, ' where ', atab, '.Account = ', ctab, '.Account)');
                            select sqlString;
                            set @p_sql = sqlString;
                            prepare stmt from @p_sql;
                            execute stmt;
                            deallocate prepare stmt;
                            set reten7num = @p_reten7num;
                        end case;

                    end if;                
                    
                end if;
                
                set avar = avar + 1;
            end while;

            set sqlString = "";
            set sqlString = concat('insert into `Retention` (`Day`, `Create`, `Retention_1`, `Retention_2`, `Retention_3`, `Retention_4`, `Retention_5`, `Retention_6`, `Retention_7`) values ("',cdaystring,'", ',createnum,', ',reten1num,', ',reten2num,', ',reten3num,', ',reten4num,', ',reten5num,', ',reten6num,', ',reten7num,') on duplicate key update `Create` = ',createnum,', `Retention_1` = ',reten1num,', `Retention_2` = ',reten2num,', `Retention_3` = ',reten3num,', `Retention_4` = ',reten4num,', `Retention_5` = ',reten5num,', `Retention_6` = ',reten6num,', `Retention_7` = ',reten7num,';');
            set @p_sql = sqlString;
            prepare stmt from @p_sql;
            execute stmt;
            deallocate prepare stmt;
            
        end if;

        set cvar = cvar + 1;
    end while;
END $$

DROP PROCEDURE IF EXISTS `calRetentionByChannel` $$
CREATE DEFINER=`root`@`%` PROCEDURE `calRetentionByChannel`(
)
BEGIN
    declare cvar int;
    declare avar int;
    declare deltavar int;
    declare ctab varchar(64);
    declare atab varchar(64);
    declare cdateTime varchar(64);
    declare cdaystring varchar(64);
    declare adateTime varchar(64);
    declare adaystring varchar(64);
    declare tablename varchar(64);
    declare sqlString varchar(1024);
    declare channelString varchar(1024);

    declare _channel int;
    declare createnum int;
    declare reten1num int;
    declare reten2num int;
    declare reten3num int;
    declare reten4num int;
    declare reten5num int;
    declare reten6num int;
    declare reten7num int;

    declare done int;
    declare p_cursor cursor for select `Channel` from `Channel`;
    declare continue handler for not found set done = 1;
    open p_cursor;
    cursor_loop:loop
        fetch p_cursor into _channel;

        if done = 1 then
            leave cursor_loop;
        end if;

        set createnum = 0;
        set reten1num = 0;
        set reten2num = 0;
        set reten3num = 0;
        set reten4num = 0;
        set reten5num = 0;
        set reten6num = 0;
        set reten7num = 0;
        set cvar = 0;
        while cvar < 7 do
            set cdateTime = curdate() - cvar;
            set cdaystring = concat(year(cdateTime), '_', lpad(month(cdateTime), 2, '0'), '_', lpad(day(cdateTime), 2, '0'));
            set ctab = concat('Create_', cdaystring);
            set tablename = "";
            select `TABLE_NAME` into tablename from `INFORMATION_SCHEMA`.`TABLES` where `TABLE_NAME` = ctab;
            if tablename != "" then
                set avar = 0;
                while avar <= cvar do
                    if cvar = avar then
                        set @p_createnum = 0;
                        set sqlString = "";
                        set sqlString = concat('select count(1) into @p_createnum from ', ctab, ' where Channel = ', _channel);

                        set @p_sql = sqlString;
                        prepare stmt from @p_sql;
                        execute stmt;
                        deallocate prepare stmt;
                        set createnum = @p_createnum;
                    else
                        set adateTime = curdate() - avar;
                        set adaystring = concat(year(adateTime), '_', lpad(month(adateTime), 2, '0'), '_', lpad(day(adateTime), 2, '0'));
                        set atab = concat('Active_', adaystring);
                        set tablename = "";
                        select `TABLE_NAME` into tablename from `INFORMATION_SCHEMA`.`TABLES` where `TABLE_NAME` = atab;
                        if tablename != "" then
                            set deltavar = cvar - avar;

                            set sqlString = "";
                            case deltavar
                            when 1 then
                                set sqlString = concat('select count(1) into @p_reten1num from ', ctab, ' where Channel = ', _channel ,' and exists (select 1 from ', atab, ' where ', atab, '.Account = ', ctab, '.Account)');
                                select sqlString;
                                set @p_sql = sqlString;
                                prepare stmt from @p_sql;
                                execute stmt;
                                deallocate prepare stmt;
                                set reten1num = @p_reten1num;
                            when 2 then
                                set sqlString = concat('select count(1) into @p_reten2num from ', ctab, ' where Channel = ', _channel ,' and exists (select 1 from ', atab, ' where ', atab, '.Account = ', ctab, '.Account)');
                                select sqlString;
                                set @p_sql = sqlString;
                                prepare stmt from @p_sql;
                                execute stmt;
                                deallocate prepare stmt;
                                set reten2num = @p_reten2num;
                            when 3 then
                                set sqlString = concat('select count(1) into @p_reten3num from ', ctab, ' where Channel = ', _channel ,' and exists (select 1 from ', atab, ' where ', atab, '.Account = ', ctab, '.Account)');
                                select sqlString;
                                set @p_sql = sqlString;
                                prepare stmt from @p_sql;
                                execute stmt;
                                deallocate prepare stmt;
                                set reten3num = @p_reten3num;
                            when 4 then
                                set sqlString = concat('select count(1) into @p_reten4num from ', ctab, ' where Channel = ', _channel ,' and exists (select 1 from ', atab, ' where ', atab, '.Account = ', ctab, '.Account)');
                                select sqlString;
                                set @p_sql = sqlString;
                                prepare stmt from @p_sql;
                                execute stmt;
                                deallocate prepare stmt;
                                set reten4num = @p_reten4num;
                            when 5 then
                                set sqlString = concat('select count(1) into @p_reten5num from ', ctab, ' where Channel = ', _channel ,' and exists (select 1 from ', atab, ' where ', atab, '.Account = ', ctab, '.Account)');
                                select sqlString;
                                set @p_sql = sqlString;
                                prepare stmt from @p_sql;
                                execute stmt;
                                deallocate prepare stmt;
                                set reten5num = @p_reten5num;
                            when 6 then
                                set sqlString = concat('select count(1) into @p_reten6num from ', ctab, ' where Channel = ', _channel ,' and exists (select 1 from ', atab, ' where ', atab, '.Account = ', ctab, '.Account)');
                                select sqlString;
                                set @p_sql = sqlString;
                                prepare stmt from @p_sql;
                                execute stmt;
                                deallocate prepare stmt;
                                set reten6num = @p_reten6num;
                            when 7 then
                                set sqlString = concat('select count(1) into @p_reten7num from ', ctab, ' where Channel = ', _channel ,' and exists (select 1 from ', atab, ' where ', atab, '.Account = ', ctab, '.Account)');
                                select sqlString;
                                set @p_sql = sqlString;
                                prepare stmt from @p_sql;
                                execute stmt;
                                deallocate prepare stmt;
                                set reten7num = @p_reten7num;
                            end case;

                        end if;                
                        
                    end if;
                    
                    set avar = avar + 1;
                end while;

                set sqlString = "";
                set sqlString = concat('insert into `RetentionByChannel` (`Day`, `Channel`, `Create`, `Retention_1`, `Retention_2`, `Retention_3`, `Retention_4`, `Retention_5`, `Retention_6`, `Retention_7`) values ("',cdaystring,'", ',_channel,', ',createnum,', ',reten1num,', ',reten2num,', ',reten3num,', ',reten4num,', ',reten5num,', ',reten6num,', ',reten7num,') on duplicate key update `Create` = ',createnum,', `Retention_1` = ',reten1num,', `Retention_2` = ',reten2num,', `Retention_3` = ',reten3num,', `Retention_4` = ',reten4num,', `Retention_5` = ',reten5num,', `Retention_6` = ',reten6num,', `Retention_7` = ',reten7num,';');
                set @p_sql = sqlString;
                prepare stmt from @p_sql;
                execute stmt;
                deallocate prepare stmt;
                
            end if;

            set cvar = cvar + 1;
        end while;

    end loop cursor_loop;
    close p_cursor;

END $$

DELIMITER ;

DROP EVENT IF EXISTS `event_Retention`;
CREATE EVENT IF NOT EXISTS event_Retention
    ON SCHEDULE EVERY 1 HOUR
    STARTS '2015-10-24 00:58:00'
    ON COMPLETION PRESERVE
DO CALL CALRETENTION();

DROP EVENT IF EXISTS `event_RetentionByChannel`;
CREATE EVENT IF NOT EXISTS event_RetentionByChannel
    ON SCHEDULE EVERY 1 HOUR
    STARTS '2015-10-24 00:58:00'
    ON COMPLETION PRESERVE
DO CALL CALRETENTIONBYCHANNEL();

-- SET GLOBAL event_scheduler = 1;
